import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,existsSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {dirname,resolve} from 'node:path';
import {fileURLToPath} from 'node:url';
import {CONVERSATIONS} from './source/src/content/story.js';
import {DialogueRunner,testCondition} from './source/src/game/narrative.js';
import {GameState} from './source/src/game/state.js';
import {setLocale} from './source/src/content/i18n.js';
import {JA} from './source/src/content/locale/ja.js';

const base=dirname(fileURLToPath(import.meta.url));
assert.equal(existsSync(resolve(base,'raw.json')),false,'Retain the prior evidence.');
const hash=x=>createHash('sha256').update(x).digest('hex');
const norm=s=>s.replace(/\s+/g,' ').trim();
const actual=JSON.parse(readFileSync(resolve(base,'../narrative-ac9cd44/transcript-en-publish.json'),'utf8'));
const filtered=JSON.parse(readFileSync(resolve(base,'../narrative-review-input-r1/dialogue.json'),'utf8'));
const intended=CONVERSATIONS.final.nodes.choose.choices.find(c=>c.goto==='e_evac');
assert.deepEqual(intended.if,{all:[{flag:'sol_debrief'},{trust:['sol',16]}]});
const candidates={
  supplied:{
    en:'Sol would have to run it with you. She needs to hear what happened in the flood, and to know she can rely on you.',
    ja:'ソルと二人で回すしかない。水害で何が起きたかを彼女に話し、頼れる相手だと思ってもらう必要がある。',
    interpretation:'General conjunction of a flood debrief and sufficient trust; it does not assert the debrief has not already happened.',
    caveat:'Hear what happened can suggest missing factual information. The actual debrief is largely Sol speaking and saying she already has the names; the code requires this encounter, not a new factual report.'
  },
  precise:{
    en:'Sol would have to run it with you. You need to have spoken with her since the flood, and she needs to know she can rely on you.',
    ja:'ソルと二人で回すしかない。水害のあとに彼女と話していて、頼れる相手だと思ってもらえている必要がある。',
    interpretation:'States two prerequisites without claiming either one is currently unmet. Spoken with her maps to sol_debrief and reliance maps to the existing trust predicate.',
    caveat:'Still a joint-prerequisite explanation, not a dynamic display of the particular missing predicate; prose quality and real rendered fit are unmeasured.'
  }
};
writeFileSync(resolve(base,'candidate-text.json'),JSON.stringify(candidates,null,2)+'\n');

const originalJa=JA.c.final.choose.why[3];
const originalFinal=JSON.stringify(CONVERSATIONS.final);
let S=new GameState();
for(const flag of ['sol_met','crisis_done','crisis_saved_some','crisis_stacks'])S.set(flag);
// A constructed entry value makes actual ac_some's +5 land on the recorded final trust 3.
// It is not claimed as a measured historical per-node state.
S.trust.set('sol',-2);
const entry={flags:[...S.flags],trust:S.trustOf('sol')};
const runner=new DialogueRunner(S,{});const debrief=[];
setLocale('en');
runner.on('node',(node,choices)=>debrief.push({id:node.id,text:node.text,solDebriefAtEmit:S.has('sol_debrief'),trustAtEmit:S.trustOf('sol'),choices:choices?.map(c=>c.goto)||[]}));
runner.start(CONVERSATIONS.sol_first);
let budget=20;
while(runner.active){assert.ok(budget-->0);assert.equal(runner.choices(),null);runner.advance();}
assert.deepEqual(debrief.map(n=>n.id),['again','after_crisis','ac_some','ac_end','ac_stacks','ac_close']);
for(let i=0;i<5;i++){
 const event=actual.events[97+i];assert.equal(norm(debrief[i+1].text),norm(event.text));
 assert.deepEqual(event,filtered.events[97+i]);
}
const atClose=debrief.find(n=>n.id==='ac_close');assert.equal(atClose.solDebriefAtEmit,true);assert.equal(atClose.trustAtEmit,3);
assert.equal(actual.execution.trust.find(([id])=>id==='sol')[1],3);
let observedFinal;
const finalRunner=new DialogueRunner(S,{});
finalRunner.on('node',(node,choices)=>{observedFinal={node:node.id,text:node.text,evacuation:choices.find(c=>c.goto==='e_evac'),solDebrief:S.has('sol_debrief'),trust:S.trustOf('sol')};});
finalRunner.start(CONVERSATIONS.final,'choose');
assert.equal(observedFinal.evacuation.locked,true);
assert.equal(observedFinal.evacuation.why,actual.events[115].choices[3].why);
assert.equal(observedFinal.evacuation.why,filtered.events[115].choices[3].why);
const atFinalBeforeChoose={flags:[...S.flags],choices:[...S.choices]};
finalRunner.choose(finalRunner.choices().findIndex(c=>c.goto==='e_evac'));
assert.equal(finalRunner.node.id,'choose');assert.deepEqual([...S.choices],atFinalBeforeChoose.choices);

const table=[];
try{
 for(const language of ['en','ja'])for(const debriefDone of [false,true])for(const trust of [3,15,16,17]){
  const state=new GameState();if(debriefDone)state.set('sol_debrief');state.trust.set('sol',trust);
  const expected=debriefDone&&trust>=16;
  const predicates=intended.if.all.map(c=>testCondition(c,state));
  assert.equal(testCondition(intended.if,state),expected);
  const outputs={};
  for(const name of ['original','supplied','precise']){
   const convo=structuredClone(CONVERSATIONS.final);
   if(name!=='original')convo.nodes.choose.choices.find(c=>c.goto==='e_evac').why=candidates[name].en;
   JA.c.final.choose.why[3]=name==='original'?originalJa:candidates[name].ja;
   setLocale(language);let shown;const r=new DialogueRunner(state,{});
   r.on('node',(node,cs)=>{shown=cs?.find(c=>c.goto==='e_evac');});
   r.start(convo,'choose');
   assert.equal(shown.locked,!expected);assert.equal(shown.ci,3);
   assert.equal(shown.why,name==='original'?(language==='en'?intended.why:originalJa):candidates[name][language]);
   assert.deepEqual(r.choices().find(c=>c.goto==='e_evac').if,intended.if);
   outputs[name]={why:shown.why,locked:shown.locked,offered:true,choiceIndex:shown.ci};
   const other=structuredClone(convo);other.nodes.choose.choices.find(c=>c.goto==='e_evac').why=intended.why;
   assert.equal(JSON.stringify(other),originalFinal,'Only the reason text changes in the candidate conversation.');
  }
  table.push({language,debriefDone,trust,predicates,unlocked:expected,missing:[!debriefDone?'debrief':null,trust<16?'trust':null].filter(Boolean),outputs});
 }
}finally{JA.c.final.choose.why[3]=originalJa;setLocale('en');}
assert.equal(JSON.stringify(CONVERSATIONS.final),originalFinal);
const pins=JSON.parse(readFileSync(resolve(base,'source-pins.json'),'utf8'));
for(const p of pins.files)assert.equal(hash(readFileSync(resolve(base,'source',p.path))),p.sha256);
for(const p of pins.garageRepairUnchangedAtStart)assert.equal(hash(readFileSync(resolve(base,'../survival',p.path))),p.sha256);
const result={
 checkedAt:new Date().toISOString(),nodeVersion:process.version,ok:true,
 scope:'Fixed source CPU boundary diagnosis using actual DialogueRunner/testCondition/i18n. No browser/server, full route, game mechanics edit, product mutation, gas inference, element verdict or blind comparison.',
 sourcePinsSha256:hash(readFileSync(resolve(base,'source-pins.json'))),probeSha256:hash(readFileSync(fileURLToPath(import.meta.url))),
 originalCapture:{path:'../narrative-ac9cd44/transcript-en-publish.json',sha256:hash(readFileSync(resolve(base,'../narrative-ac9cd44/transcript-en-publish.json'))),bundleSha256:actual.bundleSha256,scope:actual.scope,executionTrustSol:3,captureSucceeded:actual.captureSucceeded,captureErrors:actual.captureErrors,selectedEvents:[98,99,100,101,102,116]},
 fixtures:{entry,meaning:'Explicit source-boundary entry state. The flags select the same displayed branch, and -2 plus actual ac_some +5 yields the recorded trust 3; no historical per-node trust measurement is claimed.',finalEntry:'Actual final conversation started at choose to inspect this predicate only.'},
 debrief,observedFinal,
 diagnosis:{debriefSetBeforeCloseEmission:true,trustAfterReproducedDebrief:3,thresholdUnchanged:16,locked:true,missingPredicate:'trust',legacyWhyFalseClaim:'Legacy reason asserts no meeting since the flood even though this source state has completed that debrief.',codeMechanism:'DialogueRunner.goto applies node effects before localiseNode and emit; ac_close sets sol_debrief. Final choice requires both debrief and trust>=16; the static reason describes only missing debrief.',historicalLimit:'Raw capture records displayed text and final trust, not per-event hidden flags. The source-boundary reproduction establishes the mechanism in pinned code and correspondence to captured text; it is not a new ordinary-play replay of the original run.'},
 table,candidateSourceUnchanged:true,garageRepairSourcesUnchanged:true,
 interpretationBoundary:'Natural-language adequacy is a scoped semantic reading, not something the boolean fixtures mechanically prove. Both candidate texts leave the condition, threshold, visibility, index, target and effects unchanged. The supplied hear wording has a factual-report implication absent from the actual predicate; the precise candidate avoids that implication.'
};
writeFileSync(resolve(base,'raw.json'),JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify({ok:true,matchedDebriefEvents:5,states:table.length,candidateReasons:2,threshold:16,rawSha256:hash(readFileSync(resolve(base,'raw.json')))}));
