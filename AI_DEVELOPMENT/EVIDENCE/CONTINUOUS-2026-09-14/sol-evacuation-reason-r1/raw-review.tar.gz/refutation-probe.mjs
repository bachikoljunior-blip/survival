import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import { pathToFileURL, fileURLToPath } from 'node:url';
import * as OriginalStory from './source/src/content/story.js';
import * as OriginalNarrative from './source/src/game/narrative.js';
import * as OriginalState from './source/src/game/state.js';
import * as OriginalI18n from './source/src/content/i18n.js';
import { JA as OriginalJA } from './source/src/content/locale/ja.js';
import { STORY2_JA } from './source/src/content/locale/ja/story2.js';

const root=path.dirname(fileURLToPath(import.meta.url));
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const read=p=>fs.readFileSync(path.join(root,p));
const load=p=>JSON.parse(read(p));
const norm=s=>s.replace(/\s+/g,' ').trim();
assert(!fs.existsSync(path.join(root,'refutation-raw.json')),'Keep earlier refutation output intact.');
const pins=load('source-pins.json');
const candidate=load('candidate-text.json').precise;
const primary=load('raw.json');
const protectedFiles=['review.json','candidate-text.json','probe.mjs','raw.json','source-pins.json',...pins.files.map(p=>'source/'+p.path)];
const before=Object.fromEntries(protectedFiles.map(p=>[p,sha(read(p))]));
const result={scope:'Independent pinned-source CPU refutation only; isolated two-string source variant, no repository edits, browser, server, ordinary route or native measurement',runtime:process.version,checks:[],errors:[],protectedHashesBefore:before};
try {
  for(const p of pins.files)assert.equal(sha(read('source/'+p.path)),p.sha256);
  const actualPath=path.join(root,'../narrative-ac9cd44/transcript-en-publish.json');
  const actualBytes=fs.readFileSync(actualPath),actual=JSON.parse(actualBytes);
  assert.equal(sha(actualBytes),'7323c6999a2a956807a74043afe337cd8850f10a178d245dc42e0aabbab9d6be');
  const O=OriginalStory.CONVERSATIONS;
  const originalChoice=O.final.nodes.choose.choices.find(c=>c.goto==='e_evac');
  const expectedCondition={all:[{flag:'sol_debrief'},{trust:['sol',16]}]};
  assert.deepEqual(originalChoice.if,expectedCondition);
  assert.equal(OriginalJA.c.final.choose.why[3],STORY2_JA.c.final.choose.why[3]);

  // Read the actual flag event and actual node emission ordering, not a forced
  // effect/perception stub. Entry flags and trust are explicit CPU fixtures.
  const state=new OriginalState.GameState();
  for(const flag of ['sol_met','crisis_done','crisis_saved_some','crisis_stacks'])state.set(flag);
  state.trust.set('sol',-2);
  OriginalI18n.setLocale('en');
  const order=[],nodes=[];
  state.on('flag',(...args)=>order.push({event:'state.flag',args}));
  const runner=new OriginalNarrative.DialogueRunner(state,{});
  runner.on('node',(node,choices)=>{order.push({event:'node',id:node.id,solDebrief:state.has('sol_debrief')});nodes.push({id:node.id,text:node.text,solDebrief:state.has('sol_debrief'),trust:state.trustOf('sol')});});
  runner.start(O.sol_first);
  for(let i=0;runner.active&&i<20;i++){assert.equal(runner.choices(),null);runner.advance();}
  assert.equal(runner.active,false);
  assert.deepEqual(nodes.map(n=>n.id),['again','after_crisis','ac_some','ac_end','ac_stacks','ac_close']);
  for(let i=0;i<5;i++)assert.equal(norm(nodes[i+1].text),norm(actual.events[97+i].text));
  assert.equal(nodes.at(-1).solDebrief,true);assert.equal(state.trustOf('sol'),3);
  const flagIndex=order.findIndex(e=>e.event==='state.flag'&&e.args[0]==='sol_debrief');
  const closeIndex=order.findIndex(e=>e.event==='node'&&e.id==='ac_close');
  assert(flagIndex>=0&&flagIndex<closeIndex);
  let displayed;
  const final=new OriginalNarrative.DialogueRunner(state,{});
  final.on('node',(node,choices)=>{displayed=choices?.find(c=>c.goto==='e_evac');});
  final.start(O.final,'choose');
  assert(displayed.locked);assert.equal(displayed.why,actual.events[115].choices[3].why);
  final.choose(final.choices().findIndex(c=>c.goto==='e_evac'));
  assert.equal(final.node.id,'choose');assert(!state.chose('final','evacuate'));
  result.checks.push({id:'original-local-cause',nodes,eventOrder:order,flagEventBeforeCloseEmission:true,lockedAfterDebrief:true,trust:3,condition:expectedCondition,oldReason:displayed.why,lockedChoiceProducesNoFinalAction:true,capturedCorrespondence:{events:[98,99,100,101,102,116],trustSol:actual.execution.trust.find(x=>x[0]==='sol')[1],captureSucceeded:actual.captureSucceeded},limit:'Historical per-event flags and pre-debrief trust were not recorded. Trust -2 is constructed entry state; direct final choose is a boundary probe, not full-route replay.'});

  // Apply the intended edits in a private source copy so the real JA merge and
  // real localisation imports must find the replacement at its proposed leaf.
  const variantRoot=path.join(root,'refutation-candidate-source');
  assert(!fs.existsSync(variantRoot),'Keep private variant output intact.');
  fs.mkdirSync(variantRoot,{recursive:true});
  fs.copyFileSync(path.join(root,'source/package.json'),path.join(variantRoot,'package.json'));
  const changed=[];
  for(const p of pins.files){
    let text=read('source/'+p.path).toString('utf8');
    if(p.path==='src/content/story.js'){
      const needle="why: '"+originalChoice.why+"'";
      assert.equal(text.split(needle).length,2);
      text=text.replace(needle,'why: '+JSON.stringify(candidate.en));
    }
    if(p.path==='src/content/locale/ja/story2.js'){
      const needle='3: `'+OriginalJA.c.final.choose.why[3]+'`';
      assert.equal(text.split(needle).length,2);
      text=text.replace(needle,'3: '+JSON.stringify(candidate.ja));
    }
    const output=path.join(variantRoot,p.path);fs.mkdirSync(path.dirname(output),{recursive:true});fs.writeFileSync(output,text);
    if(sha(Buffer.from(text))!==p.sha256)changed.push({file:p.path,sha256:sha(Buffer.from(text)),beforeSha256:p.sha256});
  }
  assert.deepEqual(changed.map(c=>c.file).sort(),['src/content/locale/ja/story2.js','src/content/story.js']);
  const moduleAt=p=>import(pathToFileURL(path.join(variantRoot,p)).href);
  const [{CONVERSATIONS:V},VN,VS,VI,{JA:VJA}]=await Promise.all([moduleAt('src/content/story.js'),moduleAt('src/game/narrative.js'),moduleAt('src/game/state.js'),moduleAt('src/content/i18n.js'),moduleAt('src/content/locale/ja.js')]);
  const restored=structuredClone(V);restored.final.nodes.choose.choices.find(c=>c.goto==='e_evac').why=originalChoice.why;
  assert.deepEqual(restored,O);
  const restoredJA=structuredClone(VJA);restoredJA.c.final.choose.why[3]=OriginalJA.c.final.choose.why[3];assert.deepEqual(restoredJA,OriginalJA);
  assert.equal(VJA.c.final.choose.why[3],candidate.ja);
  const table=[];
  for(const language of ['en','ja'])for(const done of [false,true])for(const trust of [3,15,16,17]){
    const expected=done&&trust>=16,row={language,debriefDone:done,trust,expectedUnlocked:expected,outputs:{}};
    for(const [label,C,N,S,I,why] of [['original',O,OriginalNarrative,OriginalState,OriginalI18n,language==='en'?originalChoice.why:OriginalJA.c.final.choose.why[3]],['precise',V,VN,VS,VI,candidate[language]]]){
      const s=new S.GameState();if(done)s.set('sol_debrief');s.trust.set('sol',trust);I.setLocale(language);
      const d=new N.DialogueRunner(s,{});let shown;
      d.on('node',(node,choices)=>{shown=choices?.find(c=>c.goto==='e_evac');});d.start(C.final,'choose');
      assert.equal(shown.ci,3);assert.equal(shown.locked,!expected);assert.equal(shown.why,why);assert.deepEqual(shown.if,expectedCondition);
      const displayedChoice=structuredClone(shown);
      d.choose(d.choices().findIndex(c=>c.goto==='e_evac'));
      assert.equal(s.chose('final','evacuate'),expected);assert.equal(d.node.id,expected?'e_evac':'choose');
      row.outputs[label]={choice:displayedChoice,afterChooseNode:d.node.id,recordedEvacuate:s.chose('final','evacuate')};
    }
    const baselineChoice=structuredClone(row.outputs.original.choice),candidateChoice=structuredClone(row.outputs.precise.choice);
    delete baselineChoice.why;delete candidateChoice.why;assert.deepEqual(candidateChoice,baselineChoice);
    const parent=primary.table.find(r=>r.language===language&&r.debriefDone===done&&r.trust===trust);assert(parent);
    assert.equal(parent.unlocked,expected);assert.equal(parent.outputs.precise.why,row.outputs.precise.choice.why);assert.equal(parent.outputs.original.why,row.outputs.original.choice.why);
    table.push(row);
  }
  OriginalI18n.setLocale('en');VI.setLocale('en');
  result.checks.push({id:'actual-source-candidate-and-16-states',changedFiles:changed,entireConversationsEqualExceptWhy:true,entireMergedJaEqualExceptWhy:true,table,primaryAll16RowsAgree:true,actualSourceLeafLocalization:true,threshold:16,otherConditionsTargetsEffectsUnchanged:true});
}catch(error){result.errors.push({message:error.message,stack:error.stack});}
result.protectedHashesAfter=Object.fromEntries(protectedFiles.map(p=>[p,sha(read(p))]));
try{assert.deepEqual(result.protectedHashesAfter,before);result.originalArtifactsUnchanged=true;}catch(error){result.errors.push({message:error.message,stack:error.stack});}
fs.writeFileSync(path.join(root,'refutation-raw.json'),JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify({checkGroups:result.checks.length,errors:result.errors,originalArtifactsUnchanged:result.originalArtifactsUnchanged},null,2));
if(result.errors.length)process.exitCode=1;
