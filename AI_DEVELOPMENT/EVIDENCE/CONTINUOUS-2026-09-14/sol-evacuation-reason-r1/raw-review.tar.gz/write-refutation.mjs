import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { validateFindings } from '../survival/.kit/lib/plan/findings.mjs';
const root=path.dirname(new URL(import.meta.url).pathname);
const read=p=>fs.readFileSync(path.join(root,p));
const load=p=>JSON.parse(read(p));
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const raw=load('refutation-raw.json'),primary=load('review.json'),candidate=load('candidate-text.json');
assert.equal(raw.errors.length,0);assert(raw.originalArtifactsUnchanged);
assert.equal(raw.checks[1].table.length,16);
const finding={
  id:'NR1-01-CAUSE',severity:'minor',shot:'Pinned source ac_close emission and final choose; actual capture E098-E102/E116 correspondence',
  problem:'With sol_debrief true after the actual ac_close node effect and Sol trust 3, the final evacuation option is correctly locked by the trust>=16 conjunct. Its unchanged English and Japanese reason nevertheless assert that Ren has not faced Sol since the flood.',
  why:'The static explanation denies the completed prerequisite and omits the trust requirement that still blocks this reproduced state.',
  owner:'src/content/story.js',
  fix:'Apply only candidate-text.json precise.en to final.choose e_evac why in src/content/story.js and precise.ja to c.final.choose.why.3 in src/content/locale/ja/story2.js. Keep sol_debrief AND trust[sol,16], showLocked, authored index3, goto and effects unchanged. Read python -m json.tool /workspace/scratch/0b7ad82bafe7/sol-evacuation-reason-r1/refutation-raw.json: all16 states must retain the same lock and selection outcomes; only why changes.',
  hypothesis:'Confirmed at the pinned CPU source boundary: DialogueRunner.goto applies ac_close effects before emitting its localized text; the choice condition is the conjunction of the completed debrief flag and trust>=16. The historical transcript does not directly record flags at E102 or the pre-debrief trust value.',
  refutation:'SURVIVED: independent actual flag-event ordering, local branch reproduction,16 state comparisons and real localized imports of an isolated two-string source variant did not refute the mismatch.',
  evidence:['refutation-raw.json checks.original-local-cause','refutation-raw.json checks.actual-source-candidate-and-16-states','refutation-probe.mjs','source/src/game/narrative.js','source/src/content/story.js:2186','source/src/content/locale/ja/story2.js:501'],
};
const report={
  verdict:'FAIL',score:0,
  scoreMeaning:'Unscored schema sentinel; no overall product, narrative quality, native, literary or element score.',
  verdictMeaning:'The original unchanged reason-text finding survives. No additional concrete defect was found in the proposed precise strings within this scope.',
  blindComparison:'No blind comparison was performed. Source execution and localized text checks do not measure ordinary play, rendered fit, prose preference or which complete game a stranger would choose.',
  round:'sol-evacuation-reason-independent-refutation-r1',profile:'local-reason-predicate-and-localization',tier:'CPU-source-refutation',nativeResolution:'0x0',
  findings:[finding],
  independence:{role:'Separate refuter of acquisition_path_review finding NR1-01-CAUSE',originalReview:'review.json',originalReviewModified:false,additionalAgents:0},
  scope:{repositoryEdits:0,originalEvidenceEdits:0,browserServerNativeOrNetworkRuns:0,ordinaryFullPlaythroughs:0,privateSourceVariant:'refutation-candidate-source/',privateVariantChangedStrings:2,conditionOrThresholdChanges:0},
  refutedAlternatives:[
    {claim:'The evacuation lock itself is wrong because Sol was already met.',result:'REFUTED',basis:'The unchanged gate requires both sol_debrief and trust>=16. True/3 correctly remains locked; true/16 and true/17 unlock. No threshold or condition change is justified.'},
    {claim:'ac_close only records the debrief after its text is emitted or after finishing the conversation.',result:'REFUTED',basis:'The independent real GameState flag event precedes the real DialogueRunner ac_close node emission, and its node listener already observes sol_debrief=true.'},
    {claim:'The proposed Japanese source leaf might be overridden by the later locale merge, even though mutating the already-merged JA table appears to work.',result:'REFUTED_FOR_THE_PRECISE_CANDIDATE',basis:'The separate probe edits only the proposed story.js and ja/story2.js strings in an isolated source copy and imports its real locale modules. The resulting merged JA and all conversations differ from the originals only at the intended reason values. The candidate reaches the actual localization output for all16 states.'},
    {claim:'The candidate might alter visibility, authored index, goto, effects, lock state or selected final action.',result:'REFUTED',basis:'All16 state/locale combinations agree with the original predicate and primary raw table. Actual locked selection stays at choose and records no evacuation; actual unlocked selection enters e_evac and records final=evacuate. Entire choice objects differ only in why.'},
  ],
  candidateAssessment:{
    acceptedForThisBoundedFix:'precise',text:candidate.precise,
    semanticReading:'Both languages state the debrief and trust prerequisites generally, without asserting that either particular prerequisite is currently missing. Spoken with her since the flood and 水害のあとに彼女と話していて describe the encounter; reliance describes the existing trust requirement.',
    noNewConcreteContradictionFound:true,
    unchangedBooleanCondition:{all:[{flag:'sol_debrief'},{trust:['sol',16]}]},
    limitation:'This is a joint-prerequisite explanation, not a dynamic diagnosis of exactly which conjunct is missing. CPU truth tables verify conditions and output strings, not literary quality or every ordinary-play interpretation.',
    suppliedAlternative:'The supplied hear-what-happened version also does not explicitly deny the prior meeting. Sol already knowing the names supports a wording-precision caution, but does not by itself prove she knows every relevant fact or make that alternative a demonstrated new Boolean defect. The precise version avoids introducing that factual-report implication.',
  },
  historicalEvidenceBoundary:{
    actualTranscript:'../narrative-ac9cd44/transcript-en-publish.json',sha256:'7323c6999a2a956807a74043afe337cd8850f10a178d245dc42e0aabbab9d6be',
    matchedDisplayedEvents:[98,99,100,101,102,116],recordedExecutionTrustSol:3,
    directlyRecordedPerEventFlags:false,originalCaptureSucceeded:raw.checks[0].capturedCorrespondence.captureSucceeded,
    interpretation:'The original shortened-driver capture and the fixed-source branch have matching displayed debrief text and old locked reason. The independent source run establishes the effect-before-emission mechanism. It does not retroactively create historical flag telemetry or an ordinary full-route replay.',
    fixture:'The CPU branch uses explicit crisis flags and entry trust -2; the actual ac_some effect adds5 and yields3. The historical pre-debrief trust -2 was not measured. Final choose is entered directly as a predicate boundary.',
  },
  measurements:{independentCheckGroups:raw.checks.length,stateLocaleCombinations:16,outputVariants:['original','precise'],unchangedOriginalArtifacts:true,localRuntime:raw.runtime,raw:'refutation-raw.json'},
  originalReviewStatus:{strictValidation:load('validation.json'),survivingFindingIds:['NR1-01-CAUSE'],additionalFindings:0},
  artifactPins:{originalReviewSha256:sha(read('review.json')),originalRawSha256:sha(read('raw.json')),candidateTextSha256:sha(read('candidate-text.json')),sourcePinsSha256:sha(read('source-pins.json')),sourcePackageSha256:sha(read('source/package.json')),refutationRawSha256:sha(read('refutation-raw.json')),refutationProbeSha256:sha(read('refutation-probe.mjs'))},
  sourceHashes:raw.protectedHashesAfter,
  privateSourceVariant:raw.checks[1].changedFiles,
  limits:['No product condition, threshold, trust value, flag behavior, target or effect was changed.','No normal full playthrough, new UI rendering, current CI capture, native device, blind comparison or element achievement was measured.','The original review/raw/candidate/source files were hashed before and after and remain byte-identical.','The private candidate source is a proof fixture only; it is not an applied repository change.'],
  nextAction:'Apply the two precise why strings only if proceeding with this bounded text fix, preserve the predicate and acquire the changed localized output in the existing CI. No gameplay threshold adjustment or expanded route claim follows from this refutation.',
};
const owners=new Set(execFileSync('git',['ls-files','src'],{cwd:path.join(root,'../survival'),encoding:'utf8'}).trim().split('\n'));
const validation=validateFindings(report,{strict:true,knownOwners:owners});assert(validation.ok,JSON.stringify(validation));
fs.writeFileSync(path.join(root,'refutation.json'),JSON.stringify(report,null,2)+'\n');
fs.writeFileSync(path.join(root,'refutation-validation.json'),JSON.stringify(validation,null,2)+'\n');
console.log(JSON.stringify({validation,survivingFindings:1,candidateNewDefects:0,refutationSha256:sha(read('refutation.json')),rawSha256:sha(read('refutation-raw.json'))},null,2));
