import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { createHash } from 'node:crypto';
import assert from 'node:assert/strict';
import { selectIOSSimulator } from './survival/tools/select-ios-simulator.mjs';
import { Game } from './survival/src/game/game.js';
import { Actor, STATE } from './survival/src/actors/actor.js';
import { Input } from './survival/src/core/input.js';
import { Emitter } from './survival/src/core/util.js';

const base = '/workspace/scratch/0b7ad82bafe7';
const hash = bytes => createHash('sha256').update(bytes).digest('hex');
const paths=['tools/select-ios-simulator.mjs','tools/test-ios-safari.mjs','.github/workflows/mobile-simulator.yml','.github/workflows/pages.yml','tools/mobile_trench_consequences.mjs','tools/test-iphone-webkit.mjs','src/core/input.js','src/actors/actor.js','src/game/game.js','src/core/util.js'];
const sources=Object.fromEntries(paths.map(path=>{const bytes=readFileSync(`${base}/survival/${path}`);return [path,{sha256:hash(bytes),bytes:bytes.length}];}));
const helper=readFileSync(`${base}/survival/tools/mobile_trench_consequences.mjs`,'utf8');
const oldHelper=helper.replace('17.8, Math.atan2(77 - 74, 17.8 - 18));','17.8, 0);');
assert.equal(hash(oldHelper),'52ca2085334a1a606bc5cff3773789d929b7d7830eeccc3139e493cd00663a56');
mkdirSync(`${base}/ios-trench-r2-source-initial/tools`,{recursive:true});
writeFileSync(`${base}/ios-trench-r2-source-initial/tools/mobile_trench_consequences.mjs`,oldHelper);
writeFileSync(`${base}/ios-trench-r2-helper-facing-revision.mjs`,helper);

const checks=[];
const run=(name,f)=>checks.push({name,...f()});
const inventory=JSON.parse(readFileSync(`${base}/ci-ios-3aa5e4f/simulator-inventory.json`,'utf8'));
run('SDK26.0 matches actual runtime.version26.0.1 without changing patch to26.0',()=>{
  const value=selectIOSSimulator(inventory,'26.0');
  assert.equal(value.platformVersion,'26.0.1');assert.equal(value.runtime,'com.apple.CoreSimulator.SimRuntime.iOS-26-0');
  return {passed:true,value};
});
run('Absent/malformed SDKs and unavailable matching SDK fail closed',()=>{
  const results=[];
  for(const value of [undefined,null,'','18','v18.5','18.5beta','18.5.1.2','18.5\n26.2','27.0']) {
    let error;try{selectIOSSimulator(inventory,value);}catch(e){error=e.message;}
    assert.ok(error);results.push({input:value??null,error});
  }
  return {passed:true,results};
});
run('Selector does not mutate inventory or process environment',()=>{
  const beforeInventory=JSON.stringify(inventory),beforeEnv=JSON.stringify(process.env);
  selectIOSSimulator(inventory,'18.5');
  assert.equal(JSON.stringify(inventory),beforeInventory);assert.equal(JSON.stringify(process.env),beforeEnv);
  return {passed:true,inventoryPreserved:true,environmentPreserved:true};
});

// Minimal host for the actual interaction cone and actual key-to-button code.
// No world rendering, browser acquisition or trusted event is simulated.
const noop=()=>{};
const interaction={id:'trench_talk',kind:'examine',x:74,y:1.4,z:18,range:3.4,prompt:'Show them the order'};
const player={pos:{x:77,y:0.05,z:17.8},yaw:0,state:STATE.IDLE};
const g=Object.assign(Object.create(Game.prototype),{player,city:{interactions:[interaction]},director:{currentInterior:null,npcInteractTarget:()=>null},world:{climbAt:()=>null},hud:{setPrompt:noop}});
run('Initial yaw0 is excluded by actual Game interaction cone; facing-only correction selects target',()=>{
  Game.prototype._updateInteractTarget.call(g);
  const originalTarget=player.interactTarget?.id??null;
  assert.equal(originalTarget,null);
  const dx=74-77,dz=18-17.8,d=Math.hypot(dx,dz),originalDot=dz/d*-1;
  player.yaw=Math.atan2(77-74,17.8-18);
  Game.prototype._updateInteractTarget.call(g);
  assert.equal(player.interactTarget?.id,'trench_talk');
  return {passed:true,originalTarget,originalDot,range:d,correctedYaw:player.yaw,correctedTarget:player.interactTarget.id};
});
run('Actual KeyE down/up maps to interact and disabling input clears old held edges',()=>{
  class CpuInput extends Input {_install(){}}
  const input=new CpuInput({});
  const event={code:'KeyE',repeat:false,metaKey:false,ctrlKey:false,altKey:false,preventDefault:noop};
  input._onKey(event,true);input.step(1/60);
  assert.equal(input.pressed('interact'),true);
  input._onKey(event,false);input.step(1/60);
  assert.equal(input.down('interact'),false);
  input._onKey(event,true);input.setEnabled(false);input.setEnabled(true);input.step(1/60);
  assert.equal(input.down('interact'),false);assert.equal(input.pressed('interact'),false);
  return {passed:true,pressedOnDown:true,releasedOnUp:true,oldModeEdgesCleared:true,trustedInputMeasured:false};
});

// Use actual Actor.damage + Actor.emit + Game._drainEvents + Emitter. Only
// unused appearance outputs and body construction are inert host fields.
function actor(){return Object.assign(Object.create(Actor.prototype),{dead:false,iframes:0,guarding:false,combatAssist:0,hp:120,maxHp:120,poise:100,poiseCurrent:100,poiseResist:1,events:[],animator:{react:noop}});}
const hurtActor=actor();
const eventGame=Object.assign(new Emitter(),{player:hurtActor,time:8,input:{clearToggle:noop}});
const log={input:[],damage:[]};
const callback=helper.match(/log\.offDamage = g\.on\('actor:hurt', (\(actor, hit\) => \{[\s\S]*?\n    \})\);/)[1];
const callbackFunction=Function('g','log',`return ${callback}`)(eventGame,log);
const off=eventGame.on('actor:hurt',callbackFunction);
const attacker={kind:'warden'};
run('Actual sourced hurt event reaches exact helper observer after event drain',()=>{
  const result=hurtActor.damage({source:attacker,kind:'blunt',amount:10,poise:1});
  Game.prototype._drainEvents.call(eventGame,hurtActor);
  assert.equal(log.damage.length,1);assert.equal(log.damage[0].amount,10);assert.equal(log.damage[0].kind,'warden');
  return {passed:true,result,hp:hurtActor.hp,recorded:structuredClone(log.damage)};
});
run('Source-free gas hurt is not mislabeled an enemy hit',()=>{
  hurtActor.damage({kind:'gas',amount:1,poise:0});Game.prototype._drainEvents.call(eventGame,hurtActor);
  assert.equal(log.damage.length,1);return {passed:true,enemyRecords:log.damage.length};
});
run('Endpoint pending enemy hurt can be omitted by actor:hurt-only zero-hit predicate',()=>{
  log.damage.length=0;const hpBefore=hurtActor.hp;
  const result=hurtActor.damage({source:attacker,kind:'blunt',amount:10,poise:1});
  const pending=hurtActor.events.map(e=>({name:e.name,amount:e.data?.amount,sourceKind:e.data?.source?.kind}));
  // This is the helper's predicate at an endpoint before the next frame drain.
  const predicate=log.damage.length===0;
  assert.equal(result.amount,10);assert.equal(hurtActor.hp,hpBefore-10);assert.equal(predicate,true);
  Game.prototype._drainEvents.call(eventGame,hurtActor);
  assert.equal(log.damage.length,1);
  return {passed:true,defectObserved:true,hpBefore,hpAfter:hurtActor.hp,pending,zeroHitPredicateBeforeDrain:predicate,recordsAfterDrain:structuredClone(log.damage),scope:'CPU event-boundary negative control; not an observed attack in the browser run.'};
});
run('Actual observer unsubscribe prevents old-listener accumulation on completed path',()=>{
  const count=log.damage.length;off();hurtActor.damage({source:attacker,kind:'blunt',amount:1,poise:0});Game.prototype._drainEvents.call(eventGame,hurtActor);
  assert.equal(log.damage.length,count);return {passed:true,recordsBefore:count,recordsAfter:log.damage.length};
});

const result={checkedAt:new Date().toISOString(),scope:'Limited independent CPU refutation. No browser, server, real Simulator, full City, trusted input, visual or audio measurement.',sources,initialHelperSnapshot:{path:'ios-trench-r2-source-initial/tools/mobile_trench_consequences.mjs',sha256:hash(oldHelper),note:'Reconstructed only by reverting the one observed facing edit, then verified byte-hash matches the original review-start SHA. Current source kept separately.'},checks};
writeFileSync(`${base}/ios-trench-r2-refutation-probe.json`,JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify({checks:checks.length,passed:checks.every(c=>c.passed),eventBoundaryDefect:checks.some(c=>c.defectObserved)}));
