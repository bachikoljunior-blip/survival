"""Actual selector CLI and workflow shell at mocked Mac command boundaries.
No simulator, browser, Appium server, network or game process is started.
"""
import hashlib, json, os, pathlib, shutil, subprocess, yaml

ROOT = pathlib.Path(__file__).parent
REPO = ROOT / 'survival'
RAW = ROOT / 'ios-trench-acquisition-r2-platform-raw'
RAW.mkdir(exist_ok=True)
INVENTORY = ROOT / 'ci-ios-3aa5e4f/simulator-inventory.json'
sha = lambda b: hashlib.sha256(b).hexdigest()
files = ['tools/select-ios-simulator.mjs', 'tools/test-ios-safari.mjs',
         '.github/workflows/mobile-simulator.yml', '.github/workflows/pages.yml']
hashes = {p: sha((REPO / p).read_bytes()) for p in files}
source = REPO / files[0]
results = []
for name, sdk, wanted, version in [
    ('real-sdk18.5', '18.5', '22A3039C-6A45-47F4-82D4-80C58CA94379', '18.5'),
    ('real-sdk26.0-patch-runtime', '26.0', 'F3967A6C-63E1-4323-9EA7-6C26D42F77A3', '26.0.1'),
    ('same-major-minor-sdk-patch', '18.5.9', '22A3039C-6A45-47F4-82D4-80C58CA94379', '18.5'),
    ('no-match', '19.0', None, None),
    ('invalid-sdk', 'not-a-version', None, None),
    ('empty-sdk', '', None, None),
]:
    record = RAW / (name + '.json')
    assert not record.exists(), 'Do not overwrite earlier raw records'
    r = subprocess.run(['node', str(source), sdk, str(INVENTORY), str(record)], capture_output=True, text=True)
    if wanted:
        assert r.returncode == 0, r.stderr
        assert r.stdout == wanted + '\t' + version + '\n'
        saved = json.loads(record.read_text())
        assert saved['udid'] == wanted and saved['platformVersion'] == version and saved['sdkVersion'] == sdk
    else:
        assert r.returncode != 0 and r.stdout == '' and not record.exists()
        assert ('No available iPhone SE 3 runtime matches active SDK' if name == 'no-match' else 'Invalid active iPhone Simulator SDK version') in r.stderr
        saved = None
    results.append({'name': name, 'sdk': sdk, 'returncode': r.returncode,
                    'stdout': r.stdout, 'stderr': r.stderr, 'record': saved})

workflows = {}
for rel in files[2:]:
    d = yaml.safe_load((REPO / rel).read_text())
    step = next(s for s in d['jobs']['ios-safari']['steps'] if s.get('id') == 'simulator')
    assert step['shell'] == 'bash'
    workflows[rel] = step['run']
    launch = next(s for s in d['jobs']['ios-safari']['steps'] if s.get('name') == 'Exercise Mobile Safari through Appium')
    assert launch['env']['IOS_SIMULATOR_UDID'] == '${{ steps.simulator.outputs.udid }}'
    assert launch['env']['IOS_SIMULATOR_PLATFORM_VERSION'] == '${{ steps.simulator.outputs.platform_version }}'
    assert launch['run'] == 'npm run test:ios-safari'
assert len(set(workflows.values())) == 1, 'Workflow selector steps differ'
d = yaml.safe_load((REPO / files[2]).read_text())
on = d.get('on', d.get(True))  # PyYAML 1.1 parses GitHub's `on` as true.
assert 'tools/select-ios-simulator.mjs' in on['push']['paths']

stubdir = RAW / 'mock-mac-bin'
stubdir.mkdir()
stub = '''#!/usr/bin/env python3
import sys,os,json,pathlib
name=pathlib.Path(sys.argv[0]).name;args=sys.argv[1:]
with open(os.environ['REVIEW_COMMAND_LOG'],'a') as f:f.write(json.dumps({'name':name,'args':args})+'\\n')
if name=='xcode-select' and args==['-p']:print('/Applications/Xcode_16.4.app/Contents/Developer')
elif name=='xcodebuild' and args==['-version']:print('Xcode 16.4\\nBuild version 16F6')
elif name=='xcrun' and args==['--sdk','iphonesimulator','--show-sdk-version']:print(os.environ['REVIEW_SDK'])
elif name=='xcrun' and args==['simctl','list','--json']:print(pathlib.Path(os.environ['REVIEW_INVENTORY']).read_text(),end='')
elif name=='xcrun' and args[:2] in [['simctl','boot'],['simctl','bootstatus']]:pass
else:raise RuntimeError('Unexpected mocked command: '+name+repr(args))
'''
for name in ['xcode-select', 'xcodebuild', 'xcrun']:
    p = stubdir / name
    p.write_text(stub)
    p.chmod(0o755)

shell_runs = []
for name, sdk in [('workflow-match', '18.5'), ('workflow-no-match', '19.0')]:
    cwd = RAW / name
    (cwd / 'tools').mkdir(parents=True)
    shutil.copyfile(source, cwd / files[0])
    output = cwd / 'github-output.txt'
    commands = cwd / 'mock-command-log.ndjson'
    env = dict(os.environ, PATH=str(stubdir) + os.pathsep + os.environ['PATH'],
               GITHUB_OUTPUT=str(output), REVIEW_COMMAND_LOG=str(commands), REVIEW_SDK=sdk, REVIEW_INVENTORY=str(INVENTORY))
    r = subprocess.run(['bash', '--noprofile', '--norc', '-e', '-o', 'pipefail', '-c', next(iter(workflows.values()))], cwd=cwd, env=env, capture_output=True, text=True)
    calls = [json.loads(s) for s in commands.read_text().splitlines()]
    boot = [x for x in calls if x['name'] == 'xcrun' and x['args'][:2] == ['simctl', 'boot']]
    saved = cwd / 'test-results/ios-safari/simulator-selection.json'
    if sdk == '18.5':
        assert r.returncode == 0 and len(boot) == 1
        assert boot[0]['args'][2] == '22A3039C-6A45-47F4-82D4-80C58CA94379'
        assert output.read_text() == 'udid=22A3039C-6A45-47F4-82D4-80C58CA94379\nplatform_version=18.5\n'
        assert json.loads(saved.read_text())['platformVersion'] == '18.5'
    else:
        assert r.returncode != 0 and not boot and not output.exists() and not saved.exists()
    for f in ['xcode-path.txt', 'xcode-version.txt', 'simulator-sdk-version.txt', 'simulator-inventory.json']:
        assert (cwd / 'test-results/ios-safari' / f).exists(), f
    shell_runs.append({'name': name, 'sdk': sdk, 'returncode': r.returncode, 'stdout': r.stdout, 'stderr': r.stderr,
                       'mockCommands': calls, 'githubOutput': output.read_text() if output.exists() else None})

for p, h in hashes.items():
    assert sha((REPO / p).read_bytes()) == h, 'Source changed during probe: ' + p
report = {'scope': 'Actual selector CLI with recorded prior CI inventory; actual identical YAML shell blocks executed only with stub xcode-select/xcodebuild/xcrun boundaries. This verifies file/env wiring and failure handling; it is not Mac SDK, Simulator, WDA or Safari execution.',
          'sourceHashes': hashes, 'inventory': {'path': str(INVENTORY), 'sha256': sha(INVENTORY.read_bytes())},
          'cliCases': results, 'workflowBodiesIdentical': True, 'workflowSelectorPathTriggersPush': True,
          'workflowCases': shell_runs}
(ROOT / 'ios-trench-acquisition-r2-platform-probe.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'cliCases': len(results), 'workflowCases': len(shell_runs), 'allAssertionsPassed': True, 'sourceHashes': hashes}))
