import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { EventEmitter } from 'node:events';
import { setTimeout as delay } from 'node:timers/promises';
import { join } from 'node:path';
import vm from 'node:vm';
import assert from 'node:assert/strict';
import { Actor } from './survival/src/actors/actor.js';
import { Game } from './survival/src/game/game.js';
import { GameState } from './survival/src/game/state.js';
import { Emitter } from './survival/src/core/util.js';
import { validateFindings } from './survival/.kit/lib/plan/findings.mjs';

const sha = s => createHash('sha256').update(s).digest('hex');
const noop = () => {};
const sourceDir = 'ios-http-trench-r4-refutation-sources';
mkdirSync(sourceDir, { recursive: true });
const currentHttp = readFileSync('survival/tools/webdriver-request.mjs', 'utf8');
const trench = readFileSync('survival/tools/mobile_trench_consequences.mjs', 'utf8');
const oldHttp = readFileSync('ios-acquisition-timeout-r1-sources/webdriver-request.mjs', 'utf8');
assert.equal(sha(oldHttp), '67403231aa422f53241360f5a3476291ede54a07c19b100b10e3780cad7ea23b');
assert.equal(sha(currentHttp), '38901ca0b27ec6a5acfd9e398c873f4c85536b4af73e44d8b5fb65f242ad9fd1');
assert.equal(sha(trench), '49495954200bf2c6305ba92bc04132fb860ef24dbcd470b83ed8689e234fa3df');
writeFileSync(`${sourceDir}/webdriver-request.mjs`, currentHttp, { flag: 'wx' });
writeFileSync(`${sourceDir}/mobile_trench_consequences.mjs`, trench, { flag: 'wx' });
const sources = Object.fromEntries(['tools/webdriver-request.mjs', 'tools/mobile_trench_consequences.mjs',
  'src/actors/actor.js', 'src/game/game.js', 'src/game/state.js', 'src/core/util.js'].map(path => {
  const bytes = readFileSync('survival/' + path); return [path, { sha256: sha(bytes), bytes: bytes.length }];
}));
const checks = [];
async function run(name, fn) { checks.push({ name, ...await fn() }); }

// Transport substitution owns connection behavior. No real http.request,
// browser, server, socket or dispatcher is created by this probe.
function httpFixture(source, { realTimer = false } = {}) {
  const capture = { requests: [], signals: [] };
  const controlledAbort = { timeout(ms) {
    const controller = new AbortController();
    capture.signals.push({ ms, controller });
    return controller.signal;
  } };
  const transport = protocol => ({ request(url, options, receive) {
    const req = new EventEmitter();
    const entry = { url: url.href, options, receive, req, protocol, destroyed: false, endedBody: undefined };
    req.end = data => { entry.endedBody = data; };
    req.destroy = error => {
      if (entry.destroyed) return;
      entry.destroyed = true;
      req.emit('error', error);
    };
    options.signal.addEventListener('abort', () => {
      const error = new Error('The operation was aborted'); error.name = 'AbortError';
      error.cause = options.signal.reason; req.destroy(error);
    }, { once: true });
    capture.requests.push(entry); return req;
  } });
  const context = vm.createContext({ http: transport('http:'), https: transport('https:'), URL, Buffer,
    AbortSignal: realTimer ? AbortSignal : controlledAbort });
  const code = source.replace(/^import .*;\n/gm, '').replace('export function ', 'function ');
  vm.runInContext(code + '\nglobalThis.invoke = requestWebDriver;', context);
  const respond = (entry, status = 200) => {
    const res = new EventEmitter(); res.statusCode = status; res.setEncoding = noop;
    entry.receive(res); return res;
  };
  return { ...capture, invoke: context.invoke, respond };
}
const observe = promise => {
  const outcome = { state: 'pending' };
  promise.then(value => { outcome.state = 'fulfilled'; outcome.value = value; }, error => {
    outcome.state = 'rejected'; outcome.error = { name: error.name, message: error.message };
  });
  return outcome;
};
await run('Preserved first transport: null JSON escapes callback and leaves request promise pending', async () => {
  const f = httpFixture(oldHttp), outcome = observe(f.invoke('http://appium.invalid/session'));
  const response = f.respond(f.requests[0]); response.emit('data', 'null');
  let escaped; try { response.emit('end'); } catch (error) { escaped = { name: error.name, message: error.message }; }
  await Promise.resolve();
  assert.equal(escaped?.name, 'TypeError'); assert.equal(outcome.state, 'pending');
  const beforeCleanup = structuredClone(outcome);
  f.signals[0].controller.abort(); await Promise.resolve();
  return { passed: true, expectedDefectObserved: true, sourceSha256: sha(oldHttp), escaped, outcomeAtResponseEnd: beforeCleanup };
});
await run('Corrected transport: identical null JSON rejects without escaping end callback', async () => {
  const f = httpFixture(currentHttp), outcome = observe(f.invoke('http://appium.invalid/session'));
  const response = f.respond(f.requests[0]); response.emit('data', 'null');
  assert.doesNotThrow(() => response.emit('end')); await Promise.resolve();
  assert.equal(outcome.state, 'rejected'); assert.match(outcome.error.message, /invalid response envelope/);
  return { passed: true, outcome, sourceSha256: sha(currentHttp) };
});
await run('Corrected transport: valid W3C null value remains a successful command result', async () => {
  const f = httpFixture(currentHttp), promise = f.invoke('https://appium.invalid/session/x/url');
  const response = f.respond(f.requests[0]); response.emit('data', '{"value":null}'); response.emit('end');
  assert.equal(await promise, null); assert.equal(f.requests[0].protocol, 'https:');
  return { passed: true, value: null, transport: 'https:' };
});
await run('Response-stream error rejects even after headers and a partial JSON body', async () => {
  const f = httpFixture(currentHttp), outcome = observe(f.invoke('http://appium.invalid/session'));
  const response = f.respond(f.requests[0]); response.emit('data', '{"value":');
  response.emit('error', new Error('CPU partial-body reset')); await Promise.resolve();
  assert.equal(outcome.state, 'rejected'); assert.match(outcome.error.message, /partial-body reset/);
  return { passed: true, outcome };
});
await run('Actual AbortSignal timer is not restarted by a partial response body', async () => {
  const f = httpFixture(currentHttp, { realTimer: true });
  const started = Date.now(), outcome = observe(f.invoke('http://appium.invalid/session', { timeout: 12 }));
  const response = f.respond(f.requests[0]); response.emit('data', '{"value":');
  await delay(30);
  assert.equal(f.requests[0].options.signal.aborted, true);
  assert.equal(f.requests[0].destroyed, true); assert.equal(outcome.state, 'rejected');
  return { passed: true, requestedTimerMs: 12, observedAfterMs: Date.now() - started, outcome,
    scope: 'Actual Node AbortSignal timer; request destroy/error is the explicit fake-transport boundary, not an observed network abort.' };
});
await run('Unsupported URL protocol fails before issuing any transport request', async () => {
  const f = httpFixture(currentHttp);
  assert.throws(() => f.invoke('ftp://appium.invalid/session'), /Unsupported WebDriver protocol/);
  assert.equal(f.requests.length, 0);
  return { passed: true, requests: 0 };
});

// Exercise the exact helper with real Actor.damage/emit, Game._drainEvents,
// GameState.set, Emitter.on/off. World, rendering, page/frame acquisition and
// late-chapter setup are deliberately inert fixtures. The input is explicitly
// synthetic; the helper's trusted-input check remains false in these probes.
function actor() { return Object.assign(Object.create(Actor.prototype), { dead: false, iframes: 0,
  guarding: false, combatAssist: 0, hp: 120, maxHp: 120, poise: 100, poiseCurrent: 100,
  poiseResist: 1, events: [], animator: { react: noop }, radius: 0.3,
  placeAt: noop, interactTarget: { id: 'trench_talk' } }); }
async function trenchFixture(mode) {
  const player = actor(), state = new GameState(), keyboardListeners = new Set();
  const enemy = { kind: 'warden', faction: 'neutral', aggro: false, attack: null };
  const g = Object.assign(new Emitter(), { player, state, time: 10, mode: 'play',
    director: { _pollReach: noop, _raidActive: null }, dialogueUI: { hide: noop },
    world: { groundUnder: () => ({ y: 0 }) }, teleport: noop, quests: { start: noop },
    setMode: noop, _updateInteractTarget: noop, input: { clearToggle: noop },
    actors: [enemy, { ...enemy }, { ...enemy }],
    city: { _runtimeGroups: new Map([['trenchplant', { children: [{}], userData: {
      boxes: [1, 2, 3, 4].map(y1 => ({ tag: 'rubble', y0: y1 - 1, y1, x: 0, z: 0 })),
    } }]]) },
  });
  const C = { game: g, startNewGame: async () => {} };
  const window = { CINDERLINE: C,
    addEventListener: (type, listener) => { assert.equal(type, 'keydown'); keyboardListeners.add(listener); },
    removeEventListener: (type, listener) => { assert.equal(type, 'keydown'); keyboardListeners.delete(listener); },
  };
  const context = vm.createContext({ window, join });
  vm.runInContext(trench.replace(/^import .*;\n/gm, '').replace('export async function ', 'async function ')
    + '\nglobalThis.exercise = exerciseTrenchConsequences;', context);
  const report = { browser: 'CPU boundary fixture (no browser)' }, helperChecks = [];
  const snapshot = { mode }, counts = { keyUp: 0, waits: 0, screenshots: 0 };
  function hit(amount) { return player.damage({ source: enemy, kind: 'blunt', amount, poise: 1 }); }
  const page = {
    evaluate: async fn => fn(),
    screenshot: async () => {
      counts.screenshots++;
      if (mode === 'screenshot-failure') throw new Error('CPU screenshot failure');
    },
    keyboard: {
      down: async code => {
        for (const listener of keyboardListeners) listener({ code, isTrusted: false });
      },
      up: async () => { counts.keyUp++; },
    },
    waitForFunction: async (_fn, arg) => {
      counts.waits++;
      if (mode === 'wait-failure') throw new Error('CPU wait failure');
      if (arg !== null) {
        g.time = arg + 8;
        if (mode === 'before-and-after-drained' || mode === 'all-pending') hit(9);
      }
    },
  };
  const waitFrames = async () => {
    if (mode === 'frame-failure') throw new Error('CPU frame failure');
    // Both sides deliberately share simulation time to challenge timestamp-only classification.
    hit(5);
    const beforeIdentity = player.events.find(e => e.name === 'hurt').data;
    state.set('trench_talked');
    state.set('trench_passed'); state.set('trench_talked_through');
    snapshot.acceptedTime = g.time;
    snapshot.queuedBeforeAcceptanceHasActualIdentity = C.__trenchEvidence.queuedBeforeAcceptance.has(beforeIdentity);
    hit(7);
    const postIdentity = player.events.filter(e => e.name === 'hurt').at(-1).data;
    snapshot.postIdentityIncorrectlyMarkedBefore = C.__trenchEvidence.queuedBeforeAcceptance.has(postIdentity);
    if (mode !== 'all-pending') Game.prototype._drainEvents.call(g, player);
    const acceptedAt = C.__trenchEvidence.acceptedAt;
    g.time++;
    state.set('trench_talked'); // GameState ignores an unchanged true flag.
    snapshot.unchangedTruePreservedAcceptance = C.__trenchEvidence.acceptedAt === acceptedAt;
  };
  let error;
  try { await context.exercise({ page, root: '/fake', output: '/fake/results', report,
    check: (condition, name, detail) => helperChecks.push({ passed: !!condition, name, detail }), waitFrames }); }
  catch (e) { error = { name: e.name, message: e.message }; }
  const listenerCounts = { actorHurt: g._m.get('actor:hurt')?.length ?? 0,
    acceptance: state._m.get('flag')?.length ?? 0, keydown: keyboardListeners.size };
  return { snapshot, events: report.trenchConsequences.events, error, counts, listenerCounts,
    logDeleted: !Object.hasOwn(C, '__trenchEvidence'), pendingEvents: player.events.map(e => ({ name: e.name, amount: e.data?.amount })),
    helperChecks,
  };
}
await run('Pre-acceptance queued hurt stays before acceptance after real event drain; later drained and pending hits appear once', async () => {
  const result = await trenchFixture('before-and-after-drained');
  assert.equal(result.error, undefined);
  assert.equal(result.snapshot.queuedBeforeAcceptanceHasActualIdentity, true);
  assert.equal(result.snapshot.postIdentityIncorrectlyMarkedBefore, false);
  assert.equal(result.snapshot.unchangedTruePreservedAcceptance, true);
  assert.deepEqual(Array.from(result.events.beforeAcceptance, x => x.amount), [5]);
  assert.deepEqual(Array.from(result.events.damage, x => [x.amount, x.delivery]), [[7, 'drained'], [9, 'queued']]);
  assert.equal(result.helperChecks.find(x => x.name.includes('no enemy hit')).passed, false);
  assert.deepEqual(result.listenerCounts, { actorHurt: 0, acceptance: 0, keydown: 0 });
  return { passed: true, result };
});
await run('An undrained pre-acceptance hit is excluded while both later queued hits remain visible without duplicates', async () => {
  const result = await trenchFixture('all-pending');
  assert.equal(result.error, undefined);
  assert.deepEqual(Array.from(result.events.damage, x => [x.amount, x.delivery]), [[7, 'queued'], [9, 'queued']]);
  assert.deepEqual(result.pendingEvents.filter(x => x.name === 'hurt').map(x => x.amount), [5, 7, 9]);
  assert.equal(result.helperChecks.find(x => x.name.includes('no enemy hit')).passed, false);
  return { passed: true, result, queuePreservedBySnapshot: true };
});
for (const mode of ['screenshot-failure', 'frame-failure', 'wait-failure']) {
  await run(`Actual helper finally removes listeners and log after ${mode}`, async () => {
    const result = await trenchFixture(mode);
    assert.ok(result.error?.message.includes('CPU'));
    assert.deepEqual(result.listenerCounts, { actorHurt: 0, acceptance: 0, keydown: 0 });
    assert.equal(result.logDeleted, true);
    if (mode !== 'screenshot-failure') assert.equal(result.counts.keyUp, 1);
    return { passed: true, result };
  });
}
const nativeClient = process.binding('natives')['_http_client'];
const nativeAbort = process.binding('natives')['internal/streams/add-abort-signal'];
const nativeExcerpts = {
  httpClient: { sha256: sha(nativeClient), text: nativeClient.match(/const signal = options\.signal;[\s\S]{0,150}/)[0] },
  abortAdapter: { sha256: sha(nativeAbort), text: nativeAbort.match(/const onAbort = isNodeStream\(stream\)[\s\S]*?return stream;/)[0] },
};
const raw = {
  checkedAt: new Date().toISOString(), reviewer: '/root/acquisition_path_review/acquisition_refutation',
  scope: 'Independent bounded r4 refutation. Exact source functions run with explicit non-network and non-browser boundaries. Real Actor/Game event and state APIs are used only for the queue tests.',
  sources, previousTransportSha256: sha(oldHttp), localNode: process.version, nativeExcerpts, checks,
  exclusions: ['No actual CI run, Appium, Simulator, browser, socket, server, image, audio or trusted-input measurement.',
    'The fake HTTP transport explicitly implements signal-to-error forwarding. Native source is inspected separately; successful real HTTP delivery and abort are not inferred as a measurement.',
    'World/City build, full startNewGame, actual input acquisition and rendering are fixtures in the trench tests. Parent performs the distinct native-input integration test.',
    'The fixture sends isTrusted:false. Its trusted-input helper check remains false; passing assertions here refer only to the bounded queue/cleanup expectations.'],
};
writeFileSync('ios-http-trench-r4-refutation-probe.json', JSON.stringify(raw, null, 2) + '\n', { flag: 'wx' });
const review = {
  verdict: 'PASS', score: 100,
  verdictScope: 'The corrected transport and trench boundary changes pass this limited source/CPU refutation. Original transport null-envelope failure is preserved as resolved in a separate hash. This is not a browser, Simulator or quality pass.',
  round: 'ios-http-trench-r4-independent-refutation', profile: 'Transport response/timer boundary and trench event accounting/cleanup',
  tier: 'Source and CPU only', nativeResolution: '0x0',
  blindComparison: 'No blind comparison was performed. Source identities are known. No actual image, sound, reference preference or trusted browser input was measured, and no element is marked satisfied by this review.',
  checkedAt: raw.checkedAt, reviewer: raw.reviewer, scope: raw.scope, sources, findings: [],
  resolvedFindings: [{ severity: 'minor', owner: 'tools/webdriver-request.mjs',
    originalSha256: sha(oldHttp), correctedSha256: sha(currentHttp),
    symptom: 'An HTTP200 JSON null payload escaped the original response-end callback with TypeError while its returned promise stayed pending.',
    proof: 'The same EventEmitter response sequence reproduced the original failure and then produced a clean promise rejection with the corrected response-envelope guard. A valid {value:null} remains successful.',
    applicability: 'An invalid server/proxy response boundary, not an observed Appium response or CI crash.' }],
  verifiedBoundaries: [
    'Partial-response stream errors reject the command promise.',
    'The actual local AbortSignal timer expires while an incomplete body is pending; the explicit fake transport forwards the abort as request error. Chunks do not restart the signal timer.',
    'Unsupported URL protocol throws before a request is issued; https URLs select the https transport.',
    'Real Actor.damage payload identity survives real Game._drainEvents and separates a pre-acceptance queued hit from later hits even at the same simulation time.',
    'Already drained later hits and still-pending later hits are each counted once; the endpoint snapshot preserves the actor queue.',
    'Repeated GameState.set of an already true acceptance flag does not reset acceptance time.',
    'Screenshot, frame-wait and acceptance-wait failures run the actual helper finally; both listeners and the keydown handler are removed and the log is deleted. KeyE is released after frame-wait failure.',
  ],
  limitations: raw.exclusions,
  evidenceFiles: ['ios-http-trench-r4-refutation-probe.mjs', 'ios-http-trench-r4-refutation-probe.json',
    `${sourceDir}/webdriver-request.mjs`, `${sourceDir}/mobile_trench_consequences.mjs`,
    'ios-acquisition-timeout-r1-sources/webdriver-request.mjs'],
  checks: { total: checks.length, passed: checks.filter(x => x.passed).length },
};
review.validation = validateFindings(review, { strict: true, knownOwners: new Set(['tools/webdriver-request.mjs', 'tools/mobile_trench_consequences.mjs']) });
assert.equal(review.validation.ok, true, JSON.stringify(review.validation));
writeFileSync('ios-http-trench-r4-refutation.json', JSON.stringify(review, null, 2) + '\n', { flag: 'wx' });
console.log(JSON.stringify({ checks: checks.length, passed: checks.every(x => x.passed), validation: review.validation,
  path: 'ios-http-trench-r4-refutation.json' }));
