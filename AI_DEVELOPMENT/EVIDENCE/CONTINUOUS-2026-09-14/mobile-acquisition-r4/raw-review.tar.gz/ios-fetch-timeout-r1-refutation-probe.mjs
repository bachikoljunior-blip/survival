import { readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import { validateFindings } from './survival/.kit/lib/plan/findings.mjs';

const sha = s => createHash('sha256').update(s).digest('hex');
const sourcePath = 'ios-trench-r2-source-initial/tools/test-ios-safari.mjs';
const source = readFileSync(sourcePath, 'utf8');
assert.equal(sha(source), 'cd424a47cfe34441df87c6b5d2e0e11e7aaac0449ae47c5a919667566569d483');
const functionSource = source.match(/async function webdriver[\s\S]*?(?=\nlet sessionId)/)[0];
const calls = [];
const context = vm.createContext({ URL, APPIUM_URL: new URL('http://appium.invalid/'),
  fetch: async (url, options) => {
    calls.push({ url: url.href, keys: Object.keys(options), options });
    return { ok: true, status: 200, text: async () => '{"value":{"sessionId":"cpu-only"}}' };
  } });
vm.runInContext(functionSource + '\nglobalThis.invoke = webdriver;', context);
await context.invoke('session', { body: { capabilities: { alwaysMatch: {
  'appium:wdaLaunchTimeout': 240000,
} } } });
assert.equal(calls.length, 1);
assert.equal(calls[0].keys.includes('signal'), false);
assert.equal(calls[0].keys.includes('dispatcher'), false);

const embedded = process.binding('natives')['internal/deps/undici/undici'];
const extract = re => {
  const match = embedded.match(re);
  assert.ok(match, String(re));
  return { offset: match.index, text: match[0] };
};
const excerpts = {
  clientHeaders: extract(/this\[kHeadersTimeout\] = headersTimeout != null \? headersTimeout : 3e5;/),
  clientBody: extract(/this\[kBodyTimeout\] = bodyTimeout != null \? bodyTimeout : 3e5;/),
  requestOverride: extract(/const headersTimeout = request\.headersTimeout != null \? request\.headersTimeout : client\[kHeadersTimeout\];[\s\S]{0,100}/),
  fetchDispatch: extract(/function dispatch\(\{ body \}\)[\s\S]{0,1100}/),
  globalDispatcher: extract(/if \(getGlobalDispatcher2\(\) === void 0\) \{[\s\S]{0,100}/),
};
assert.equal(/headersTimeout|bodyTimeout/.test(excerpts.fetchDispatch.text), false);
const workflows = ['mobile-simulator.yml', 'pages.yml'].map(name => {
  const path = `ios-trench-r2-source-initial/.github/workflows/${name}`;
  const text = readFileSync(path, 'utf8');
  assert.match(text, /node-version: '22'/);
  assert.match(text, /timeout-minutes: 45/);
  return { path, sha256: sha(text), simulatorNodeMajor: 22, jobMinutes: 45 };
});
const nominalEnvelopeMs = 2 * 240000 + 10000;
assert.ok(nominalEnvelopeMs > 300000);
const raw = {
  checkedAt: new Date().toISOString(),
  scope: 'Preserved pre-transport-replacement source; VM fetch boundary and embedded local Node source only. No browser, server, socket, real Appium request or wall-time wait.',
  source: { path: sourcePath, sha256: sha(source) },
  runtime: { node: process.version, undici: process.versions.undici, embeddedSha256: sha(embedded) },
  functionSource, calls, excerpts, workflows,
  budget: { localDefaultHeaderTimeoutMs: 300000, wdaLaunchTimeoutMs: 240000,
    documentedSimulatorAttempts: 2, documentedRetryIntervalMs: 10000,
    nominalTwoWaitPlusIntervalMs: nominalEnvelopeMs,
    meaning: 'A possible configured server-side wait envelope, not a measured request duration or a rigorous upper bound including setup, driver scheduling or retries.' },
  officialCapabilities: {
    url: 'https://appium.github.io/appium-xcuitest-driver/latest/reference/capabilities/',
    facts: ['wdaLaunchTimeout governs WDA readiness waiting.', 'Simulator wdaStartupRetries defaults to two.', 'wdaStartupRetryInterval defaults to 10000 ms.'],
    acquisition: 'Read during this independent review; facts paraphrased. Installed driver runtime defaults not independently introspected.' },
  unavailableAcquisition: {
    url: 'https://undici.nodejs.org/api/Client',
    result: 'The web open returned a non-retryable safe-to-open error. This report uses the locally embedded primary implementation for the measured default; no blocked access was retried.' },
  checks: [
    { name: 'Preserved actual session request has no signal or dispatcher override', passed: true },
    { name: 'Local embedded Client header and body defaults are each 300000 ms', passed: true },
    { name: 'Local fetch dispatch does not set a request-level header/body timeout', passed: true },
    { name: 'Retained simulator workflows use Node22 with a 45-minute job budget', passed: true },
    { name: 'Nominal two 240-second waits plus one 10-second interval exceed 300 seconds', passed: true },
  ],
};
writeFileSync('ios-fetch-timeout-r1-refutation-probe.json', JSON.stringify(raw, null, 2) + '\n', { flag: 'wx' });
const review = {
  verdict: 'PASS', score: 100,
  verdictScope: 'The limited budget-risk argument survives refutation with explicit applicability limits. This is not a pass for an observed CI request, startup or product quality.',
  round: 'ios-fetch-timeout-r1-independent-refutation', profile: 'Configuration-risk argument review',
  tier: 'Source and CPU boundary only', nativeResolution: '0x0',
  blindComparison: 'No blind comparison occurred. Source identities are known and no browser, Simulator, image, sound, reference preference or product element judgment was measured.',
  checkedAt: raw.checkedAt, reviewer: '/root/acquisition_path_review/acquisition_refutation',
  scope: raw.scope, findings: [], sources: [raw.source, ...workflows],
  conclusion: 'The preserved default-fetch implementation has a supported conditional transport-budget risk: an HTTP response that withholds headers while two allowed WDA waits run can outlast the local default header wait. It is not evidence that CI actually timed out after 300 seconds.',
  counterarguments: [
    { claim: 'The CI request must terminate at exactly 300 seconds.', result: 'Not established. CI selects Node22, whereas the independently inspected implementation is Node24.19.0/Undici7.29.0; exact CI bundled Undici and runtime dispatcher configuration were not measured.' },
    { claim: 'The HTTP timeout is a total response wall-clock deadline.', result: 'False for the inspected Undici defaults. The header timer covers waiting for response headers and body timeout is inactivity while receiving a body. Early headers or continuing chunks can change which timer applies.' },
    { claim: 'Two configured WDA attempts guarantee 490000 ms of waiting.', result: 'False. Readiness can succeed or fail earlier; earlier retained logs did not show two independent complete readiness waits. The arithmetic is an allowed timing scenario, not a measured duration or strict maximum.' },
    { claim: 'The 45-minute CI job timeout or newCommandTimeout300 fixes the client wait.', result: 'They govern different boundaries. The job cap does not configure the fetch dispatcher; the Appium command-idle budget is not a client receive timeout.' },
    { claim: 'Setting a longer AbortSignal alone necessarily extends fetch headersTimeout.', result: 'Not supported. An outer abort deadline does not raise a shorter underlying dispatcher header timeout.' },
  ],
  nextRevision: 'Root has implemented a separate node:http/https transport. Its behavior is reviewed separately; it does not retroactively change this preserved source evidence.',
  evidenceFiles: ['ios-fetch-timeout-r1-refutation-probe.mjs', 'ios-fetch-timeout-r1-refutation-probe.json'],
  limitations: ['No physical-device, Simulator, browser or HTTP timing measurement.', 'Exact Appium installed driver retry control flow and exact CI Node22 Undici defaults are unmeasured in this independent pass.', 'The source-default conclusion applies directly only to the recorded local runtime.'],
};
review.validation = validateFindings(review, { strict: true, knownOwners: new Set(['tools/test-ios-safari.mjs']) });
assert.equal(review.validation.ok, true, JSON.stringify(review.validation));
writeFileSync('ios-fetch-timeout-r1-refutation.json', JSON.stringify(review, null, 2) + '\n', { flag: 'wx' });
console.log(JSON.stringify({ raw: 'ios-fetch-timeout-r1-refutation-probe.json', review: 'ios-fetch-timeout-r1-refutation.json', checks: raw.checks.length, validation: review.validation }));
