import fs from 'node:fs';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
import {validateFindings} from './survival/.kit/lib/plan/findings.mjs';
const root=new URL('./',import.meta.url),repo=new URL('./survival/',root),hash=b=>createHash('sha256').update(b).digest('hex');
const read=p=>JSON.parse(fs.readFileSync(new URL(p,root),'utf8'));
const integration=read('ios-trench-acquisition-r4-source-integration.json');
const sourceHashes=integration.sourceHashes,owners=new Set(Object.keys(sourceHashes));
for(const[p,s]of Object.entries(sourceHashes))assert.equal(hash(fs.readFileSync(new URL(p,repo))),s,'Review target changed: '+p);
const refutation=read('ios-http-trench-r4-refutation.json');assert.equal(refutation.verdict,'PASS');assert.equal(refutation.findings.length,0);
assert(validateFindings(refutation,{strict:true,knownOwners:owners}).ok);
const caps=read('ios-trench-acquisition-r3-capability-probe.json');assert(Object.values(caps.checks).every(Boolean));
const transport=read('ios-trench-acquisition-r4-http-probe.json');assert.equal(transport.passed,transport.total);assert.equal(transport.total,8);
const trench=read('ios-trench-acquisition-r3-helper-probe.json');assert.equal(trench.runs.length,2);assert(trench.runs.every(r=>!r.error&&r.expectations.mechanicChecksPassed===7&&r.expectations.noHitPredicateMatchesControl));
const evidenceNames=[
'ios-trench-acquisition-r2-platform-probe.py','ios-trench-acquisition-r2-platform-probe.json',
'ios-trench-acquisition-r2-facing.json','ios-trench-acquisition-r2-capability-probe.mjs','ios-trench-acquisition-r2-capability-probe.json',
'ios-trench-acquisition-r2-refutation.json','ios-trench-r2-refutation-probe.mjs','ios-trench-r2-refutation-probe.json',
'ios-trench-acquisition-r3-capability-probe.mjs','ios-trench-acquisition-r3-capability-probe.json',
'ios-trench-acquisition-r3-helper-probe.mjs','ios-trench-acquisition-r3-helper-probe.json',
'ios-trench-acquisition-r3-http-probe.mjs','ios-trench-acquisition-r3-http-probe.json',
'ios-trench-acquisition-r4-http-probe.mjs','ios-trench-acquisition-r4-http-probe.json',
'ios-trench-acquisition-r4-source-integration.json',
'ios-fetch-timeout-r1-refutation.json','ios-fetch-timeout-r1-refutation-probe.mjs','ios-fetch-timeout-r1-refutation-probe.json',
'ios-http-trench-r4-refutation.json','ios-http-trench-r4-refutation-probe.mjs','ios-http-trench-r4-refutation-probe.json',
'ios-wda-review.json','ios-wda-review-refutation.json','ios-wda-review-evidence.json'];
const evidenceFiles=evidenceNames.map(path=>{const b=fs.readFileSync(new URL(path,root));return {path,bytes:b.length,sha256:hash(b)};});
const review={
 verdict:'PASS',score:0,scoreMeaning:'Unscored schema placeholder. This review does not assign a game quality score.',
 verdictScope:'Only the seven pinned acquisition/CI source files and their bounded CPU behavior. No unresolved concrete defect survived the final refutation within this scope. This is not successful Appium/WDA startup, a smartphone browser pass, a reference comparison or an element judgment.',
 round:'ios-trench-acquisition-r4-2026-09-14',profile:'Shared SDK selection, Mobile Safari bootstrap evidence, bounded WebDriver transport and trench acquisition accounting',tier:'Source and CPU boundaries',nativeResolution:'0x0',
 blindComparison:'No blind comparison was conducted. Sources and implementation identities are known, no reference preference is measured, and the synthetic input is explicitly untrusted. This review cannot mark any concept element satisfied.',
 checkedAt:new Date().toISOString(),reviewer:'/root/acquisition_path_review',independentRefuter:'/root/acquisition_path_review/acquisition_refutation',
 branch:execFileSync('git',['branch','--show-current'],{cwd:repo,encoding:'utf8'}).trim(),baseCommit:execFileSync('git',['rev-parse','HEAD'],{cwd:repo,encoding:'utf8'}).trim(),sourceState:'Working-tree hashes, with snapshots and separate earlier revisions retained. No product or review-target file was edited by this reviewer.',sourceHashes,
 findings:[],
 resolvedFindings:[
  {owner:'tools/mobile_trench_consequences.mjs',severity:'major',initialSha256:'52ca2085334a1a606bc5cff3773789d929b7d7830eeccc3139e493cd00663a56',problem:'The initial yaw0 placement points outside the actual Game interaction cone, so the target is null and normal input cannot start the dialogue.',evidence:'Actual target selection produced dot -0.0665190105237737 below 0.25; changing only the yaw selected trench_talk. The corrected final helper then passed the complete CPU Game input/Director path.',resolution:'The root implementation faces the actual interaction, with final helper hash pinned above.',refutation:'ios-trench-acquisition-r2-refutation.json'},
  {owner:'tools/mobile_trench_consequences.mjs',severity:'minor',initialSha256:'d846f88f0108c38b4412fcbbf9564f705a487b9dd57b41f9dbc548055718af58',problem:'An endpoint enemy hit could reduce HP but remain queued after the actor event drain, leaving the earlier actor:hurt-only zero-hit predicate true.',evidence:'The original real Actor.damage 10HP negative control left the predicate true until Game._drainEvents. The final helper records the endpoint pending hit and the zero-hit predicate becomes false.',resolution:'Acceptance time and queued payload identity distinguish the previous interval; final pending damage is included without draining or altering the product queue. Separate refutation verifies earlier/later classification, no duplicates and failure cleanup.',refutation:'ios-http-trench-r4-refutation.json'},
  {owner:'tools/webdriver-request.mjs',severity:'minor',initialSha256:'67403231aa422f53241360f5a3476291ede54a07c19b100b10e3780cad7ea23b',problem:'An HTTP200 JSON null envelope escaped the response-end callback as TypeError while the returned Promise stayed pending.',evidence:'Independent negative control preserved the old exception and pending Promise. With the final response envelope guard, the same response cleanly rejects; seven invalid envelopes reject and {value:null} succeeds.',resolution:'Root added a response envelope guard. The corrected transport hash is pinned above.',refutation:'ios-http-trench-r4-refutation.json'}
 ],
 verifiedBoundaries:[
  {area:'Selector CLI and both actual workflow bodies',evidence:'ios-trench-acquisition-r2-platform-probe.json',result:'Six real CLI cases and two executions of the exact YAML shell block passed, with only Mac command boundaries replaced. Retained inventory SDK18.5 selects 22A3039C-6A45-47F4-82D4-80C58CA94379/18.5; SDK26.0 selects F3967A6C-63E1-4323-9EA7-6C26D42F77A3/26.0.1 despite an identifier without the patch suffix. No-match and malformed SDKs stop before boot or device outputs.',currentApplicability:'The selector and both boot shell blocks are unchanged; mobile workflow only adds the transport helper push path. The source comparison is separately recorded.'},
  {area:'Actual gate request body and budget branch',evidence:'ios-trench-acquisition-r3-capability-probe.json',result:'The real current source sends headless=true, showXcodeLog=true, wdaLaunchTimeout=240000 and the supplied exact platformVersion18.5. The session boundary gets900000ms. The forced pre-session error still gives a failed report, exit1 and zero game checks.'},
  {area:'New WebDriver transport',evidence:'ios-trench-acquisition-r4-http-probe.json',result:'Eight CPU boundary cases pass: split JSON/UTF8 framing, HTTPS500 message, malformedJSON, invalid-envelope matrix, valid value:null DELETE, finite25ms signal for no response, response stream error, and actual900000/90000ms gate branches. No request socket exists in the probe.'},
  {area:'Complete trench helper through actual CPU product methods',evidence:'ios-trench-acquisition-r3-helper-probe.json',result:'The exact helper and source-extracted main.startNewGame run using actual Game._playerInput, fixedUpdate, Director, quest and collision. Both nominal and endpoint-hit scenarios pass seven mechanical conditions. Nominal no-hit is true; injected real10HP hit is exported as queued and makes no-hit false. Trusted browser input is deliberately false in both cases, because no browser event occurred.'},
  {area:'Separate final refutation',evidence:'ios-http-trench-r4-refutation.json',result:'Eleven independent CPU expectations pass: corrected null response, transport/error/timer boundaries, pre-acceptance payload identity, once-only drained/pending accounting, passive queue preservation, stable acceptance time and screenshot/frame/wait failure cleanup.'}
 ],
 observations:[
  {area:'Outer HTTP budget',fact:'The previous fetch request had no explicit dispatcher or deadline. The local Node24.19/Undici7.29 source and current official Undici documentation use300000ms header defaults.',inference:'Two allowed240000ms WDA waits plus setup/interval can outlast such an outer header wait. Exact CI Node22 default and actual next-run timing were not measured.',resolution:'The current node:http/https helper has a finite total request budget, with no fetch header timer on WebDriver communication. This removes the identified configuration dependency without asserting the next WDA launch succeeds.',evidence:'ios-fetch-timeout-r1-refutation.json'},
  {area:'Prior fixture dialogue',fact:'Root now hides the preceding fixture display during trench staging. The CPU path invoked hide; no rendered image was produced.',limitation:'This does not claim that a general product startNewGame dialogue-visibility defect is fixed.'},
  {area:'SDK alignment hypothesis',fact:'Apple documents Xcode16.4 SDK18.5. The actual failed run selected runtime26.2 and made no game checks.',inference:'Selecting a runtime in the active SDK major/minor reduces an uncontrolled environment difference. The evidence does not establish that runtime26.2 caused a compiler failure.',evidence:'ios-wda-review.json'},
  {area:'Refuter terminology',clarification:'The separate report phrase native-input integration refers here only to the actual Game._playerInput CPU path. Acquisition is synthetic and isTrusted=false; no browser-native input or trusted event was measured.'}
 ],
 retainedActualFailure:{run:'34803864630',commit:'3aa5e4febbd52a44ddc87aca7aa6ecd7ab20e185',evidence:'ci-ios-3aa5e4f/appium.log',symptoms:'Headless mode was accepted and the old invisible-UI restart disappeared. WDA status never became ready, report.checks is empty and Appium terminated xcodebuild. The first nominal60000ms wait consumed123905ms; the second attempt failed almost immediately.',unknowns:'The excess first-attempt duration, immediate second-attempt failure and underlying WDA build/start mechanism remain unresolved. The current source fixes do not rewrite that failed result.'},
 primarySources:[
  {url:'https://appium.github.io/appium-xcuitest-driver/latest/reference/capabilities/',supports:'Definitions of isHeadless, showXcodeLog, wdaLaunchTimeout and startup retries.'},
  {url:'https://developer.apple.com/xcode/system-requirements/',supports:'Xcode16.4 SDK18.5. Its App Store deployment-target column is not proof that a particular Simulator build must fail.'},
  {url:'https://undici.nodejs.org/api/Client',supports:'Current Client header/body timeout defaults. Not substituted for exact CI Node22 bundled-source evidence.'},
  {url:'https://undici.nodejs.org/',supports:'Node global fetch depends on bundled Undici version.'}
 ],
 evidenceFiles,
 snapshots:['ios-trench-r2-source-initial/','ios-trench-r2-helper-facing-revision.mjs','ios-trench-acquisition-r3-http-source/','ios-trench-acquisition-r3-trench-source/','ios-trench-acquisition-r4-http-source/','ios-http-trench-r4-refutation-sources/'],
 limitations:[
  'No browser, local server, socket, Appium process or Simulator was started by either reviewer.',
  'CPU product integration uses appearance/UI, input acquisition and browser scheduling stubs; it is not a current bundled-build smartphone measurement.',
  'The final fixture tests runtime plant structure, not a traversed climb. The four-layer heap was not changed by this review and no climb pass is inferred from height.',
  'The retained actual failed CI run remains failed. A new existing-CI run must supply real startup, browser, image/audio and input evidence.',
  'All concept/element judgments remain unchanged. This source review is not a blind comparison or a completed quality work unit.'
 ],
 nextExecution:'Run the current pinned source through the already-authorized existing CI, inspect recorded SDK/selection/capability/Xcode logs and current build smartphone artifacts, then perform the separately required reference comparisons. Do not infer browser success from these CPU boundaries.'
};
review.validation=validateFindings(review,{strict:true,knownOwners:owners});assert(review.validation.ok,JSON.stringify(review.validation));
const out=new URL('./ios-trench-acquisition-r4-review.json',root);assert(!fs.existsSync(out));fs.writeFileSync(out,JSON.stringify(review,null,2)+'\n');
console.log(JSON.stringify({path:out.pathname,verdict:review.verdict,findings:review.findings.length,validation:review.validation,sha256:hash(fs.readFileSync(out)),sourceHashes}));
