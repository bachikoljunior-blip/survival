// Actual new transport with only request acquisition replaced at the socket boundary.
// No socket, local server, browser, Appium or Simulator is launched.
import fs from 'node:fs';
import vm from 'node:vm';
import path from 'node:path';
import assert from 'node:assert/strict';
import {EventEmitter} from 'node:events';
import {createHash} from 'node:crypto';
const repo=new URL('./survival/',import.meta.url),hash=b=>createHash('sha256').update(b).digest('hex');
const files=['tools/webdriver-request.mjs','tools/test-ios-safari.mjs','.github/workflows/mobile-simulator.yml'];
const sources=Object.fromEntries(files.map(p=>[p,fs.readFileSync(new URL(p,repo))]));
const out=new URL('./ios-trench-acquisition-r3-http-probe.json',import.meta.url);assert(!fs.existsSync(out));
const snapshot=new URL('./ios-trench-acquisition-r3-http-source/',import.meta.url);assert(!fs.existsSync(snapshot));
for(const [p,b]of Object.entries(sources)){const to=new URL(p,snapshot);fs.mkdirSync(path.dirname(to.pathname),{recursive:true});fs.writeFileSync(to,b);}
let responsePlan,active;
const attempts=[],checks=[];
function requestFactory(protocol){return (url,options,callback)=>{
  const req=new EventEmitter();active={protocol,url:String(url),method:options.method,headers:options.headers,signal:options.signal,body:null};attempts.push(active);
  req.end=data=>{
    active.body=data;
    if(responsePlan==='silent'){
      options.signal.addEventListener('abort',()=>{active.aborted=true;const error=new Error('Mock request transport reports AbortSignal cancellation');error.name='AbortError';req.emit('error',error);},{once:true});
      return;
    }
    queueMicrotask(()=>{
      const response=new EventEmitter();response.statusCode=responsePlan.status;response.setEncoding=encoding=>{active.encoding=encoding;};
      callback(response);
      for(const text of responsePlan.chunks??[])response.emit('data',text);
      if(responsePlan.error)response.emit('error',new Error(responsePlan.error));else response.emit('end');
    });
  };
  return req;
};}
const transportSource=sources['tools/webdriver-request.mjs'].toString().replace(/^import[^\n]+\n/gm,'').replace('export function requestWebDriver','function requestWebDriver');
const requestWebDriver=vm.runInNewContext(transportSource+'\nrequestWebDriver',{http:{request:requestFactory('http:')},https:{request:requestFactory('https:')},URL,Buffer,AbortSignal});
async function run(name,fn){try{checks.push({name,passed:true,...await fn()});}catch(error){checks.push({name,passed:false,error:String(error),stack:error.stack});}}
await run('HTTP 200 chunks return payload.value and byte-accurate UTF-8 request framing',async()=>{
  responsePlan={status:200,chunks:['{"value":{"message":','"煙の町","ok":true}}']};
  const result=await requestWebDriver('http://cpu-only.invalid/session',{body:{label:'煙'},timeout:1000});
  assert.equal(result.message,'煙の町');assert.equal(result.ok,true);assert.equal(active.headers['content-length'],Buffer.byteLength(active.body));assert.equal(active.protocol,'http:');assert.equal(active.encoding,'utf8');
  return {result,contentLength:active.headers['content-length'],bodyBytes:Buffer.byteLength(active.body)};
});
await run('HTTPS route preserves method and rejects an HTTP 500 server error',async()=>{
  responsePlan={status:500,chunks:['{"value":{"error":"session not created","message":"WDA fixture failure"}}']};
  await assert.rejects(requestWebDriver('https://cpu-only.invalid/session',{body:{},timeout:1000}),/WebDriver POST \/session: WDA fixture failure/);
  assert.equal(active.protocol,'https:');return {serverErrorPreserved:true,protocol:active.protocol};
});
await run('Malformed JSON on HTTP 200 is an explicit error',async()=>{
  responsePlan={status:200,chunks:['<!not-json>']};
  await assert.rejects(requestWebDriver('http://cpu-only.invalid/session',{timeout:1000}),/invalid JSON response \(HTTP 200\)/);return {rejected:true};
});
await run('No response triggers finite AbortSignal and request error rejection',async()=>{
  responsePlan='silent';const start=performance.now();
  // A bounded fixture timer keeps Node alive because AbortSignal.timeout is unrefed.
  const keeper=setTimeout(()=>{},200);
  try{await assert.rejects(requestWebDriver('http://cpu-only.invalid/session',{timeout:25}),e=>e.name==='AbortError');}finally{clearTimeout(keeper);}
  const elapsed=performance.now()-start;assert(active.signal.aborted);assert(active.aborted);assert(elapsed<200);return {configuredMs:25,elapsedMs:elapsed,signalAborted:true};
});
await run('Response stream errors reject instead of leaving the command pending',async()=>{
  responsePlan={status:200,chunks:['{"value":'],error:'fixture socket closed'};
  await assert.rejects(requestWebDriver('http://cpu-only.invalid/session',{timeout:1000}),/fixture socket closed/);return {rejected:true};
});
const gate=sources['tools/test-ios-safari.mjs'].toString();
const wrapper=gate.slice(gate.indexOf('function webdriver('),gate.indexOf("let sessionId = ''"));
const timeout=Number(gate.match(/const SESSION_REQUEST_TIMEOUT = (\d+);/)[1]);
const outgoing=[];
const call=vm.runInNewContext(wrapper+'\nwebdriver',{URL,APPIUM_URL:new URL('http://cpu-only.invalid/'),SESSION_REQUEST_TIMEOUT:timeout,requestWebDriver:(url,options)=>{const row={url:String(url),...options};outgoing.push(row);return row;}});
await run('Actual gate branch budgets session creation at 900000ms and ordinary commands at 90000ms',async()=>{
  call('session',{body:{}});call('session',{method:'POST',body:{}});call('session',{method:'GET'});call('session/cpu-id/actions',{body:{actions:[]}});
  assert.deepEqual(outgoing.map(o=>o.timeout),[900000,900000,90000,90000]);return {outgoing};
});
for(const[p,b]of Object.entries(sources))assert.equal(hash(fs.readFileSync(new URL(p,repo))),hash(b),'Source changed during probe: '+p);
const result={checkedAt:new Date().toISOString(),scope:'Unmodified HTTP helper source evaluated with http/https.request replaced by inert EventEmitter boundaries. Real AbortSignal.timeout is exercised over 25ms. These tests verify application framing, timer forwarding and error handling, not Node socket integration, Appium startup or browser behavior.',sourceHashes:Object.fromEntries(Object.entries(sources).map(([p,b])=>[p,hash(b)])),checks,passed:checks.filter(x=>x.passed).length,total:checks.length,attempts:attempts.map(({signal,...a})=>({...a,hasAbortSignal:!!signal,abortedAtEnd:signal?.aborted}))};
fs.writeFileSync(out,JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify({passed:result.passed,total:result.total,failures:checks.filter(x=>!x.passed)}));if(result.passed!==result.total)process.exitCode=1;
