// Executes the actual acquisition helper using real CPU Game/input/Director/physics.
// Input acquisition, browser transport, rendering and screenshots are inert stubs.
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {makeGame,inputFixture,Game,MODE,repo,pinSources} from './trench-perception-r2-fixture-v1.mjs';
import {exerciseTrenchConsequences} from './survival/tools/mobile_trench_consequences.mjs';
const hash=b=>createHash('sha256').update(b).digest('hex'),helperPath=repo+'/tools/mobile_trench_consequences.mjs';
const helper=fs.readFileSync(helperPath),sourceHashes=pinSources();sourceHashes['tools/mobile_trench_consequences.mjs']=hash(helper);
const resultPath=new URL('./ios-trench-acquisition-r3-helper-probe.json',import.meta.url);assert(!fs.existsSync(resultPath));
const snapshot=new URL('./ios-trench-acquisition-r3-trench-source/',import.meta.url);assert(!fs.existsSync(snapshot));
const snapshotPaths=['tools/mobile_trench_consequences.mjs','src/main.js','src/game/game.js','src/game/director.js','src/game/ai.js','src/game/state.js','src/actors/actor.js','src/world/city.js','src/world/props.js'];
for(const p of snapshotPaths){const to=new URL(p,snapshot);fs.mkdirSync(path.dirname(to.pathname),{recursive:true});fs.writeFileSync(to,fs.readFileSync(repo+'/'+p));}
const main=fs.readFileSync(repo+'/src/main.js','utf8');
const start=main.indexOf('  const startNewGame = async () => {'),end=main.indexOf('    // What to say about a save',start);assert(start>=0&&end>start);
const runs=[];
for(const injectEndpointHit of [false,true]){
  const g=makeGame(),input=inputFixture(g),flow=[],checks=[],windowListeners=new Map();
  const priorHide=g.dialogueUI.hide;let displayHides=0;g.dialogueUI.hide=()=>{displayHides++;priorHide();};
  const startNewGame=new Function('game','MODE','t','warnStorage','let leavingTitle = false;\n'+main.slice(start,end)+'\nreturn startNewGame;')(g,MODE,(_key,fallback)=>fallback,()=>{});
  let starts=0;const C={game:g,city:g.city,startNewGame:async()=>{starts++;await startNewGame();}};
  globalThis.window={CINDERLINE:C,addEventListener:(name,fn)=>{if(!windowListeners.has(name))windowListeners.set(name,new Set());windowListeners.get(name).add(fn);},removeEventListener:(name,fn)=>windowListeners.get(name)?.delete(fn)};
  let injected=null;
  const page={
    evaluate:async(fn,arg)=>{
      if(injectEndpointHit&&!injected&&fn.toString().includes('const C = window.CINDERLINE, log = C.__trenchEvidence;')){
        const hpBefore=g.player.hp,source=g.actors.find(a=>a.kind==='warden');assert(source);
        const outcome=g.player.damage({kind:'blunt',source,amount:10,poise:0});
        injected={time:g.time,outcome,hpBefore,hpAfter:g.player.hp,pending:g.player.events.filter(e=>e.name==='hurt').map(e=>({kind:e.data.kind,amount:e.data.amount,sourceKind:e.data.source?.kind??null}))};
        assert.equal(hpBefore-g.player.hp,10);
      }
      return fn(arg);
    },
    screenshot:async({path})=>flow.push({type:'screenshot-stub-no-file',path}),
    keyboard:{down:async code=>{assert.equal(code,'KeyE');input.held.add('interact');input.pending.add('interact');for(const fn of windowListeners.get('keydown')??[])fn({code,isTrusted:false});},up:async code=>{assert.equal(code,'KeyE');input.held.delete('interact');}},
    waitForFunction:async(fn,arg,options)=>{for(let i=0;i<6000;i++){if(fn(arg))return;g.fixedUpdate(1/60);}throw Error('CPU fixture iteration ceiling; no browser timeout was measured');},
  };
  const report={browser:'CPU fixture; no trusted browser event',checks};
  try{
    await exerciseTrenchConsequences({page,root:repo,output:'/cpu-fixture/no-images',check:(passed,name,detail)=>{checks.push({passed:!!passed,name,detail});return !!passed;},report,waitFrames:async(_page,n)=>{for(let i=0;i<n;i++)g.fixedUpdate(1/60);}});
  }catch(error){runs.push({injectEndpointHit,error:String(error),stack:error.stack,checks,report,flow});continue;}
  const browserOnly=checks.filter(c=>c.name.includes('trusted keyboard'));
  assert.equal(browserOnly.length,1);assert.equal(browserOnly[0].passed,false,'CPU event must never be called trusted');
  const noHit=checks.find(c=>c.name.includes('no enemy hit'));assert(noHit);assert.equal(noHit.passed,!injectEndpointHit);
  const mechanics=checks.filter(c=>!c.name.includes('trusted keyboard')&&!c.name.includes('no enemy hit'));
  assert(mechanics.every(c=>c.passed));assert.equal(starts,2);assert(displayHides>=1);assert.equal(windowListeners.get('keydown')?.size??0,0);assert.equal(C.__trenchEvidence,undefined);
  runs.push({injectEndpointHit,checks,report,flow,normalPlayerInputCalls:input.calls.length,starts,displayHides,injected,expectations:{trustedBrowserInputIntentionallyNotMeasured:true,mechanicChecks:mechanics.length,mechanicChecksPassed:mechanics.filter(c=>c.passed).length,noHitPredicateMatchesControl:true,listenersCleaned:true}});
}
for(const[p,s]of Object.entries(sourceHashes))assert.equal(hash(fs.readFileSync(repo+'/'+p)),s,'Source changed during probe: '+p);
const result={checkedAt:new Date().toISOString(),sourceHashes,scope:'The actual helper and source-extracted main.startNewGame run with actual Game._playerInput, fixedUpdate, Director, quest, Actor, collision and event methods. Device acquisition, browser scheduling, UI/appearance and image creation are stubs. Keyboard is explicitly untrusted so that one check remains false by design. The endpoint hit is an injected actual Actor.damage negative control, not an observed enemy attack. No browser/Simulator/visual/climb/blind-comparison result is claimed.',runs};
fs.writeFileSync(resultPath,JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify({runs:runs.map(r=>({endpointHit:r.injectEndpointHit,error:r.error,expectations:r.expectations,checks:r.checks.map(c=>({name:c.name,passed:c.passed}))}))}));if(runs.some(r=>r.error))process.exitCode=1;
