import assert from 'node:assert/strict';
import vm from 'node:vm';
import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {join} from 'node:path';
import {spawnSync} from 'node:child_process';
const P='/workspace/scratch/0b7ad82bafe7/narrative-acquisition-r3',read=n=>readFileSync(P+'/'+n,'utf8');
const old=read('source-before/tools/playthrough.mjs'),current=read('source/tools/playthrough.mjs'),ci=JSON.parse(read('original-ci/transcript-en-publish.json'));
const results=[];async function check(name,fn){try{results.push({name,status:'PASS',detail:await fn()});}catch(e){results.push({name,status:'FAIL',error:String(e.stack||e)});}}
async function collect(source,mode){
 const window={__CLTranscript:structuredClone(ci.events)},r=structuredClone(ci.execution);
 if(mode==='no-ending'){r.reachedEnding=false;r.ending=null;}
 const original=JSON.stringify(r),writes=[],transcriptFailures=[],errors=[];
 let waits=0;const order=[];
 const page={async waitForFunction(fn,arg,options){waits++;order.push('wait');assert.equal(arg,null);assert.equal(options.timeout,30000);assert.equal(fn(),false);if(mode==='timeout')throw Error('controlled timeout');await Promise.resolve();window.__CLTranscript.push({kind:'ending',title:'independent fixture',paragraphs:['ending body']});assert.equal(fn(),true);order.push('ending event');},async evaluate(fn){order.push('snapshot');return structuredClone(fn());}};
 const a=source.indexOf('  if (TRANSCRIPT) {\n'),b=source.indexOf('\n  results.push(r);',a);assert(a>=0&&b>a);
 await vm.runInNewContext('(async()=>{'+source.slice(a,b)+'})()',{TRANSCRIPT:true,page,window,r,path:'publish',LANG:null,errors,transcriptFailures,bundleSha256:ci.bundleSha256,OUT:'/memory',join,Buffer,createHash,writeFileSync:(n,data)=>writes.push(data),console:{log(){}}});
 assert.equal(writes.length,1);const transcript=JSON.parse(writes[0]);assert.equal(JSON.stringify(transcript.execution),original);
 const failed=vm.runInNewContext(source.match(/const failed = ([^\n]+);/)[1],{results:[r],errors,transcriptFailures});
 return {transcript,failed,waits,order};
}
await check('exact collector awaits signal, retains timed-out data, and skips wait without ending state',async()=>{
 const before=await collect(old,'arrive'),after=await collect(current,'arrive'),timeout=await collect(current,'timeout'),none=await collect(current,'no-ending');
 assert.equal(before.waits,0);assert.equal(before.transcript.events.length,118);assert.equal(before.failed,true);
 assert.deepEqual(after.order,['wait','ending event','snapshot']);assert.equal(after.transcript.events.length,119);assert.equal(after.transcript.captureSucceeded,true);assert.equal(after.failed,false);
 assert.deepEqual(timeout.transcript.events,ci.events);assert.equal(timeout.transcript.captureSucceeded,false);assert.equal(timeout.failed,true);assert.equal(timeout.transcript.browserErrors.length,0);assert.equal(timeout.transcript.captureErrors.length,2);
 assert.equal(none.waits,0);assert.equal(none.failed,true);
 return {old:{waits:before.waits,events:before.transcript.events.length,failed:before.failed},after:{order:after.order,events:after.transcript.events.length,failed:after.failed},timeout:{retainedEvents:timeout.transcript.events.length,captureErrors:timeout.transcript.captureErrors,rawExecutionUnchanged:true,failed:timeout.failed},noEnding:{waits:none.waits,failed:none.failed},limit:'Independent signal model with memory-only writes; actual production fade/finish ordering was reviewed in source and existing CPU evidence, not rerun here.'};
});
await check('exact Bash block attempts both processes and retains failure exit codes',()=>{
 function block(name){const text=read(name),a=text.indexOf('      - name: Record emitted dialogue and endings'),b=text.indexOf('      - name: Preserve original narrative output',a);assert(a>=0&&b>a);const section=text.slice(a,b),marker='        run: |\n';return section.slice(section.indexOf(marker)+marker.length).split('\n').filter(Boolean).map(s=>s.slice(10)).join('\n');}
 const stub='node() { printf "%s\\n" "$3"; if [ "$3" = publish ]; then return "$TASK_PUBLISH_RC"; else return "$TASK_DEAL_RC"; fi; }\n';
 function run(text,p,d){const r=spawnSync('/bin/bash',['--noprofile','--norc','-e','-o','pipefail','-c',stub+text],{encoding:'utf8',env:{TASK_PUBLISH_RC:String(p),TASK_DEAL_RC:String(d)}});assert.equal(r.error,undefined);return {inputs:[p,d],exit:r.status,paths:r.stdout.trim().split('\n').filter(Boolean),stderr:r.stderr};}
 const before=run(block('source-before/.github/workflows/gates.yml'),7,0);assert.deepEqual(before.paths,['publish']);assert.equal(before.exit,7);
 const after=[[0,0],[7,0],[0,9],[7,9]].map(([p,d])=>run(block('source/.github/workflows/gates.yml'),p,d));
 for(const r of after){assert.deepEqual(r.paths,['publish','deal']);assert.equal(r.exit,r.inputs[1]||r.inputs[0]);assert.equal(r.stderr,'');}
 return {before,after,limit:'Normal stub process exits under Bash only; no browser, server or CI.'};
});
const result={scope:'Only ending synchronization, failure retention and two-path shell continuation.',checks:results,passed:results.filter(x=>x.status==='PASS').length,failed:results.filter(x=>x.status==='FAIL').length};
writeFileSync(P+'/independent-results.json',JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result,null,2));process.exitCode=result.failed?1:0;
