import assert from 'node:assert/strict';
import vm from 'node:vm';
import {readFileSync,writeFileSync} from 'node:fs';
import {join} from 'node:path';
import {createHash} from 'node:crypto';
import {spawnSync} from 'node:child_process';
const BASE='/workspace/scratch/0b7ad82bafe7/narrative-acquisition-r3';
const load=p=>readFileSync(join(BASE,p),'utf8');
const after=load('source/tools/playthrough.mjs'), before=load('source-before/tools/playthrough.mjs');
const director=load('source/src/game/director.js'), screens=load('source/src/ui/screens.js');
const ciBytes=readFileSync(join(BASE,'original-ci/transcript-en-publish.json'));
const ci=JSON.parse(ciBytes), acquisition=JSON.parse(load('original-ci/acquisition.json'))[0];
const checks=[];
const check=async(name,fn)=>{try{checks.push({name,status:'PASS',detail:await fn()});}catch(e){checks.push({name,status:'FAIL',error:String(e.stack||e)});}};
const slice=(src,start,end)=>{const a=src.indexOf(start),b=src.indexOf(end,a);assert(a>=0&&b>a);return src.slice(a,b);};
const method=(src,start,end,name,globals)=>vm.runInNewContext('({'+slice(src,start,end)+'}).'+name,globals);
const actualFinish=slice(director,'  async finish() {','\n  // ------------------------------------------------------------------ tick');
const captureBlock=source=>slice(source,'  if (TRANSCRIPT) {\n','\n  results.push(r);');
const installer=source=>'(() => {'+slice(source,'if (TRANSCRIPT) await page.evaluate(() => {','\n});').slice('if (TRANSCRIPT) await page.evaluate(() => {'.length)+'})()';
function fixture(){
 let time=0;const timers=[],timeline=[];
 const clock={async next(){const t=timers.shift();assert(t,'expected a pending actual fade timer');time+=t.ms;timeline.push({action:'timer released',delay:t.ms,time});t.fn();for(let i=0;i<4;i++)await Promise.resolve();return t.ms;}};
 const setTimeout=(fn,ms)=>{timers.push({fn,ms});timeline.push({action:'timer scheduled',delay:ms,time});return timers.length;};
 const cl={toggle(){},add(){},remove(){}};
 const menus={fadeNode:{classList:cl},endTitle:{textContent:''},endBody:{children:[],set innerHTML(v){this.children=[];}},endNode:{classList:cl}};
 const uiGlobals={setTimeout,isCJK:()=>false,el:(tag,cls,parent)=>{const child={style:{},textContent:''};parent.children.push(child);return child;}};
 menus.fadeOut=method(screens,'  fadeOut(slow = false) {','\n  fadeIn(', 'fadeOut',uiGlobals);
 menus.fadeIn=method(screens,'  fadeIn(slow = false) {','\n\n  // ----------------------------------------------------------------- rotate','fadeIn',uiGlobals);
 menus.showEnding=method(screens,'  showEnding(ending, paragraphs) {','\n  hideEnding()', 'showEnding',uiGlobals);
 const state={_ending:null,count:()=>0,chose:()=>false,playTime:60,filtersUsed:0,deaths:0};
 Object.defineProperty(state,'ending',{get(){return this._ending;},set(value){this._ending=value;timeline.push({action:'ending state assigned',value,time});}});
 const G={menus,dialogueUI:{show(){},who:{textContent:''},full:''},player:{},setMode(){},hud:{setVisible(){}},emit(){}};
 const window={CINDERLINE:{game:G}};
 vm.runInNewContext(installer(after),{window});
 window.__CLTranscript.push(...structuredClone(ci.events));
 const wrapped=menus.showEnding;menus.showEnding=function(...args){timeline.push({action:'showEnding called',time});return wrapped.apply(this,args);};
 const finish=vm.runInNewContext('({'+actualFinish+'}).finish',{
  ENDINGS:[{id:'record',title:'CPU ending fixture',text:'CPU opening paragraph.\n\nCPU closing paragraph.',condition:{}}],
  EPILOGUE_BEATS:[],testCondition:()=>true,t:(key,fallback)=>fallback,isCJK:()=>false,
  MODE:{CINEMATIC:'C'},Storage:{save(){timeline.push({action:'Storage.save called',time});}}
 });
 return {window,state,timers,timeline,clock,start(){this.finished=finish.call({game:G,state});return this.finished;}};
}
async function capture(source,f,{timeout=false}={}){
 const writes=new Map(),logs=[],transcriptFailures=[],errors=[];
 const r={...structuredClone(ci.execution),ending:f.state.ending,reachedEnding:!!f.state.ending};
 let waits=0;
 const page={
  async waitForFunction(predicate,arg,options){
   waits++;assert.equal(arg,null);assert.equal(options.timeout,30000);
   f.timeline.push({action:'ending wait begins',predicate:predicate()});
   if(timeout)throw new Error('CPU controlled wait timeout');
   if(!predicate())assert.equal(await f.clock.next(),1800);
   assert.equal(predicate(),true);f.timeline.push({action:'ending wait completes'});
  },
  async evaluate(fn){f.timeline.push({action:'event snapshot read',endings:f.window.__CLTranscript.filter(e=>e.kind==='ending').length});return structuredClone(fn());}
 };
 const globals={TRANSCRIPT:true,page,window:f.window,r,path:'publish',LANG:null,errors,transcriptFailures,
  bundleSha256:ci.bundleSha256,OUT:'/cpu-memory-only',join,Buffer,createHash,
  writeFileSync:(name,data)=>writes.set(name,Buffer.from(data)),
  console:{log:(...v)=>logs.push(v.join(' '))}};
 await vm.runInNewContext('(async()=>{'+captureBlock(source)+'})()',globals);
 const bytes=[...writes.values()][0];assert(bytes);
 const transcript=JSON.parse(bytes);
 const expr=source.match(/const failed = ([^\n]+);/)[1];
 const failed=vm.runInNewContext(expr,{results:[r],errors,transcriptFailures});
 return {transcript,failed:Boolean(failed),waits,logs,rawExecution:r,transcriptFailures};
}
await check('original CI failure bytes and exact event counts retained',()=>{
 assert.equal(ciBytes.length,acquisition.metadata.bytes);assert.equal(createHash('sha256').update(ciBytes).digest('hex'),acquisition.metadata.sha256);
 const kinds=ci.events.reduce((a,e)=>(a[e.kind]=(a[e.kind]||0)+1,a),{});
 assert.deepEqual(kinds,{dialogue:95,choice:23});assert.equal(ci.execution.reachedEnding,true);assert.equal(ci.execution.ending,'record');
 assert.equal(ci.captureSucceeded,false);assert.equal(ci.browserErrors.length,0);
 return {bytes:ciBytes.length,sha256:acquisition.metadata.sha256,eventKinds:kinds,endingEvents:0,captureSucceeded:false};
});
await check('actual Director.finish and actual 1800ms fade reproduce old race; new capture waits for actual showEnding output',async()=>{
 const f=fixture();f.start();
 assert.equal(f.state.ending,'record');assert.equal(f.window.__CLTranscript.filter(e=>e.kind==='ending').length,0);assert.equal(f.timers[0].ms,1800);
 const old=await capture(before,f);
 assert.equal(old.waits,0);assert.equal(old.transcript.captureSucceeded,false);assert.equal(old.transcript.executionSucceeded,true);
 assert.equal(old.transcript.events.filter(e=>e.kind==='ending').length,0);assert.equal(old.failed,true);
 const fixed=await capture(after,f);
 assert.equal(fixed.waits,1);assert.equal(fixed.transcript.captureSucceeded,true);assert.equal(fixed.failed,false);
 const ending=fixed.transcript.events.filter(e=>e.kind==='ending');assert.equal(ending.length,1);assert.equal(ending[0].title,'CPU ending fixture');assert(ending[0].paragraphs.length>=2);
 assert.equal(f.state.ending,'record');await f.clock.next();await f.finished;
 const detail={method:'Extracted unchanged production Director.finish, Menus.fadeOut/fadeIn/showEnding, and actual collector wrapper/capture blocks. Story selection is a CPU fixture; timers are controlled, DOM is stubbed.',old:{captureSucceeded:old.transcript.captureSucceeded,failed:old.failed,endingEvents:0},fixed:{captureSucceeded:fixed.transcript.captureSucceeded,failed:fixed.failed,endingEvents:1},timeline:f.timeline};
 writeFileSync(join(BASE,'cpu-state-ui-race.json'),JSON.stringify(detail,null,2)+'\n');return detail;
});
await check('controlled wait timeout retains all original events and raw driver result as a failed capture',async()=>{
 const f=fixture();f.start();const beforeEvents=JSON.stringify(f.window.__CLTranscript);
 const r=await capture(after,f,{timeout:true});
 assert.equal(r.waits,1);assert.equal(r.failed,true);assert.equal(r.transcript.captureSucceeded,false);assert.equal(r.transcript.executionSucceeded,true);
 assert.equal(r.transcript.execution.reachedEnding,true);assert.equal(r.transcript.execution.ending,'record');
 assert.equal(JSON.stringify(r.transcript.events),beforeEvents);assert.equal(r.transcript.browserErrors.length,0);
 assert(r.transcript.captureErrors.includes('Ending UI did not arrive after the recorded ending state'));
 assert(r.transcript.captureErrors.includes('Complete ending text not captured'));
 const detail={method:'CPU controlled timeout at the actual fade barrier; no real 30-second wait or browser execution.',retainedEvents:r.transcript.events.length,rawExecutionUnchanged:JSON.stringify(r.transcript.execution)===JSON.stringify(r.rawExecution),captureErrors:r.transcript.captureErrors,executionSucceeded:r.transcript.executionSucceeded,captureSucceeded:r.transcript.captureSucceeded,failed:r.failed};
 writeFileSync(join(BASE,'cpu-timeout-retention.json'),JSON.stringify(detail,null,2)+'\n');return detail;
});
await check('non-ending driver result skips wait and remains incomplete',async()=>{
 const f=fixture();const r=await capture(after,f);
 assert.equal(r.waits,0);assert.equal(r.failed,true);assert.equal(r.transcript.executionSucceeded,false);assert.equal(r.transcript.captureSucceeded,false);
 return {waits:r.waits,executionSucceeded:false,captureSucceeded:false,failed:true};
});
const workflowBlock=src=>{
 const line='      - name: Record emitted dialogue and endings on contrasting story paths';
 const section=slice(src,line,'      - name: Preserve original narrative output');
 return section.slice(section.indexOf('        run: |\n')+'        run: |\n'.length).split('\n').filter(Boolean).map(l=>l.slice(10)).join('\n');
};
function runWorkflow(block,publishStatus,dealStatus){
 const stub='node() {\n  printf "%s\\n" "$3"\n  case "$3" in\n    publish) return "$TASK_PUBLISH_STATUS" ;;\n    deal) return "$TASK_DEAL_STATUS" ;;\n    *) return 99 ;;\n  esac\n}\n';
 const r=spawnSync('/bin/bash',['--noprofile','--norc','-eo','pipefail','-c',stub+block],{encoding:'utf8',env:{...process.env,TASK_PUBLISH_STATUS:String(publishStatus),TASK_DEAL_STATUS:String(dealStatus)}});
 assert.equal(r.error,undefined);return {publishStatus,dealStatus,exitStatus:r.status,paths:r.stdout.trim().split('\n').filter(Boolean),stderr:r.stderr};
}
await check('actual workflow shell block always attempts both paths and preserves nonzero status',()=>{
 const old=runWorkflow(workflowBlock(load('source-before/.github/workflows/gates.yml')),7,0);
 assert.equal(old.exitStatus,7);assert.deepEqual(old.paths,['publish']);
 const block=workflowBlock(load('source/.github/workflows/gates.yml'));
 const results=[[0,0],[7,0],[0,9],[7,9]].map(([p,d])=>runWorkflow(block,p,d));
 for(const r of results){assert.deepEqual(r.paths,['publish','deal']);assert.equal(r.exitStatus===0,r.publishStatus===0&&r.dealStatus===0);}
 assert.equal(results[1].exitStatus,7);assert.equal(results[3].exitStatus,9);
 const detail={method:'Exact frozen workflow run block executed with Bash -e -o pipefail; node is a shell stub returning selected statuses, so no game/browser/server/CI is invoked.',oldFailureControl:old,current:results};
 writeFileSync(join(BASE,'cpu-two-path-shell.json'),JSON.stringify(detail,null,2)+'\n');return detail;
});
const output={scope:'Only observed ending-state/UI race, timeout failure retention, and two-path continuation. No broad r2 rerun. CPU fixtures do not establish real CI success or E8/E9 quality.',checks,passed:checks.filter(c=>c.status==='PASS').length,failed:checks.filter(c=>c.status==='FAIL').length};
writeFileSync(join(BASE,'cpu-results.json'),JSON.stringify(output,null,2)+'\n');console.log(JSON.stringify(output,null,2));process.exitCode=output.failed?1:0;

