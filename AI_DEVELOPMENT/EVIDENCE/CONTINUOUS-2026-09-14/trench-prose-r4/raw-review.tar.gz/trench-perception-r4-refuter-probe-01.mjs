// R4 separate prose/routing refutation. Imports immutable production snapshot.
// No traversal replay, prolonged dialogue simulation, product or snapshot edits.
import fs from 'node:fs';
import assert from 'node:assert/strict';
import {execFileSync} from 'node:child_process';
import {root,repo,sha,pinSources,makeGame,inputFixture,Storage,swallowedErrors} from './trench-perception-r4-input-fixture.mjs';
import * as Story from './trench-perception-r4-source/src/content/story.js';
import {UI_JA} from './trench-perception-r4-source/src/content/locale/ja/ui.js';
import {CONTENT_JA} from './trench-perception-r4-source/src/content/locale/ja/content.js';
import {setLocale,locale,missingKeys} from './trench-perception-r4-source/src/content/i18n.js';
const pins=JSON.parse(fs.readFileSync(root+'/trench-perception-r4-source-pins.json','utf8'));
const parent=JSON.parse(fs.readFileSync(root+'/trench-perception-r4-probe-01.json','utf8'));
const sourceHashes=pinSources(),checks=[];assert.deepEqual(sourceHashes,pins.sourceHashes);assert.deepEqual(parent.sourceHashes,sourceHashes);assert.equal(parent.sourceUnchanged,true);
const baseline=pins.baseline;assert.equal(baseline,'10ddee91fbf74512d3d577ba50d9dabbc987193f');
const oldText=p=>execFileSync('git',['show',baseline+':'+p],{cwd:repo,encoding:'utf8'});
async function load(text,path){const s=text.replace(/from (['"])([^'"]+)\1/g,(_m,_q,p)=>'from '+JSON.stringify(p==='three'?new URL('./trench-perception-r4-source/node_modules/three/build/three.module.js',import.meta.url).href:new URL(p,new URL('./trench-perception-r4-source/'+path,import.meta.url)).href));return import('data:text/javascript;base64,'+Buffer.from(s).toString('base64'));}
const clone=v=>JSON.parse(JSON.stringify(v));
const report={createdAt:new Date().toISOString(),baseline,snapshot:pins.snapshot,sourceHashes,scope:'Independent exact source/data diff and old-save ending routing against the immutable R4 snapshot. Actual applySave/DialogueRunner/Director.finish/Storage; presentation is observed at menus.showEnding. Appearance/UI input acquisition/output devices are fixture stubs. Retained actual route replay is inspected, not repeated. No narrative-quality, sensory, blind, product or full-story-journey claim.',checks};
async function check(name,fn){const c={name,status:'running',result:{}};checks.push(c);try{await fn(c.result);c.status='completed';console.log(name+': completed');}catch(e){c.status='probe-error';c.error=String(e);c.stack=e.stack;console.log(name+': '+e.stack);}}
function differences(a,b,path=[],out=[]){
 if(Object.is(a,b))return out;
 if(a===null||b===null||typeof a!=='object'||typeof b!=='object'){out.push({path:path.join('.'),before:a,after:b});return out;}
 if(Array.isArray(a)!==Array.isArray(b)){out.push({path:path.join('.'),typeChange:true});return out;}
 const keys=new Set([...Object.keys(a),...Object.keys(b)]);
 for(const key of keys){if(!(key in a)||!(key in b))out.push({path:[...path,key].join('.'),keyChange:true});else differences(a[key],b[key],[...path,key],out);}
 return out;
}
let oldStory,oldUi,oldContent;

await check('exact-delta-independent-leaf-diff',async r=>{
 r.changedSourcePaths=[];for(const [path,h] of Object.entries(sourceHashes))if(sha(oldText(path))!==h)r.changedSourcePaths.push(path);
 assert.deepEqual(r.changedSourcePaths.slice().sort(),['src/game/director.js','src/content/story.js','src/content/locale/ja/ui.js','src/content/locale/ja/content.js'].sort());
 oldStory=await load(oldText('src/content/story.js'),'src/content/story.js');
 oldUi=(await load(oldText('src/content/locale/ja/ui.js'),'src/content/locale/ja/ui.js')).UI_JA;
 oldContent=(await load(oldText('src/content/locale/ja/content.js'),'src/content/locale/ja/content.js')).CONTENT_JA;
 r.storyDifferences=differences({...oldStory},{...Story});r.uiDifferences=differences(oldUi,UI_JA);r.contentDifferences=differences(oldContent,CONTENT_JA);
 assert.deepEqual(r.storyDifferences.map(d=>d.path).sort(),['ENDINGS.0.beats.8.text','ENDINGS.3.beats.1.text']);
 assert.deepEqual(r.uiDifferences.map(d=>d.path),['hud.pastthem']);
 assert.deepEqual(r.contentDifferences.map(d=>d.path).sort(),['e.everybody.beats.1','e.record.beats.8']);
 const oldDirector=oldText('src/game/director.js'),newDirector=fs.readFileSync(pins.snapshot+'/src/game/director.js','utf8');
 const notice='<b>Over the line.</b><br>You have the high ground.',prior='<b>Past them.</b><br>Nobody looked up.';
 const comment='        // This records the route, including a climb made under pursuit. It\n        // does not establish that no guard saw Ren or that nobody was hurt.\n';
 assert.equal(newDirector.split(notice).length-1,1);assert.equal(newDirector.split(comment).length-1,1);assert.equal(oldDirector.split(prior).length-1,1);
 const reversed=newDirector.replace(comment,'').replace(notice,prior);assert.equal(reversed,oldDirector);
 r.director={oldHash:sha(oldDirector),snapshotHash:sha(newDirector),reversedHash:sha(reversed),onlyOneNoticeAndTwoCommentLines:true};
 r.beatConditions={record:Story.ENDINGS[0].beats[8].condition,everybody:Story.ENDINGS[3].beats[1].condition};
 assert.deepEqual(r.beatConditions,{record:{flag:'trench_slipped'},everybody:{flag:'trench_slipped'}});
 r.threeHashes={module:sha(fs.readFileSync(pins.snapshot+'/node_modules/three/build/three.module.js')),core:sha(fs.readFileSync(pins.snapshot+'/node_modules/three/build/three.core.js'))};
 assert.equal(r.threeHashes.module,pins.threeModuleHash);assert.equal(r.threeHashes.core,pins.threeCoreHash);
});

await check('captured-original-save-and-notice-provenance',r=>{
 const original=parent.checks.find(c=>c.name==='original-director-save-and-current-notice-boundaries');assert.equal(original.status,'completed');
 r.legacySave=clone(original.result.legacySave);r.legacyPayloadSha256=sha(JSON.stringify(r.legacySave));
 assert.ok(r.legacySave.state.flags.includes('trench_slipped'));assert.ok(r.legacySave.state.flags.includes('trench_passed'));
 r.writerScope=original.result.writerScope;r.runs=[];
 for(const run of original.result.runs){
  const expected=run.label==='original-director-en'?'<b>Past them.</b><br>Nobody looked up.':run.language==='en'?'<b>Over the line.</b><br>You have the high ground.':UI_JA.hud.pastthem;
  const exact=run.notices.filter(n=>n.args[0]===expected);assert.equal(exact.length,1);assert.ok(run.final.enemies.some(e=>e.aggro));assert.equal(run.final.quest.step,2);assert.equal(run.final.player.pos[1],2.6);
  assert.ok(run.trace.some(s=>s.flags.includes('trench_slipped')));
  r.runs.push({label:run.label,language:run.language,expectedNotice:expected,noticeCount:exact.length,noticeTime:exact[0].time,finalTime:run.final.time,finalPosition:run.final.player.pos,quest:run.final.quest,flags:run.final.flags,enemyAlert:run.final.enemies.map(e=>({kind:e.kind,aggro:e.aggro,state:e.aiState,lastSeen:e.lastSeen})),scope:'Inspected captured production-path replay. Final alert state is not relabelled as a separately observed event at the exact notice frame.'});
 }
});

await check('legacy-save-locales-endings-and-exact-flag-toggle',async r=>{
 const legacy=parent.checks.find(c=>c.name==='original-director-save-and-current-notice-boundaries').result.legacySave;
 r.legacyPayloadSha256=sha(JSON.stringify(legacy));r.cases=[];
 for(const language of ['en','ja'])for(const endingId of ['record','everybody'])for(const flagPresent of [true,false]){
  setLocale(language);assert.equal(locale(),language);const payload=clone(legacy);if(!flagPresent)payload.state.flags=payload.state.flags.filter(f=>f!=='trench_slipped');
  const onlyDelta=differences(legacy,payload);if(flagPresent)assert.deepEqual(onlyDelta,[]);else assert.ok(onlyDelta.every(d=>d.path.startsWith('state.flags.')));
  const g=makeGame();inputFixture(g);const outputs=[],finishes=[];
  g.menus.showEnding=(ending,epilogue)=>outputs.push({ending:clone(ending),epilogue:clone(epilogue)});
  const finish=g.director.finish;g.director.finish=function(...args){const p=finish.apply(this,args);finishes.push(p);return p;};
  assert.equal(g.director.applySave(payload),true);const restored={flags:[...g.state.flags],quest:clone(g.state.quests.get('cinderline')),mode:g.mode,convo:g.director.dialogue.convo?.id};
  assert.equal(restored.quest.step,2);assert.equal(restored.convo,'final');assert.equal(g.state.has('trench_slipped'),flagPresent);
  const wanted=endingId==='record'?'e_publish':'e_evac',flow=[];
  for(let n=0;n<40&&g.director.dialogue.active;n++){
   const runner=g.director.dialogue,choices=runner.choices();flow.push({node:runner.node?.id,choices:choices?.map(c=>({goto:c.goto,locked:c.locked}))??null});
   if(choices){const index=choices.findIndex(c=>c.goto===wanted&&!c.locked);assert.ok(index>=0);g.dialogueUI.onChoose(index);}else g.dialogueUI.onAdvance();
   await Promise.resolve();
  }
  await Promise.all(finishes);assert.equal(g.director.dialogue.active,false);assert.equal(finishes.length,1);assert.equal(outputs.length,1);assert.equal(outputs[0].ending.id,endingId);
  const index=endingId==='record'?8:1,def=Story.ENDINGS.find(e=>e.id===endingId);
  // Expected Japanese comes directly from the authored table, not the same
  // t() call used by production finish, so English fallback cannot pass.
  const expected=language==='en'?def.beats[index].text:CONTENT_JA.e[endingId].beats[index];
  const other=endingId==='record'?'everybody':'record',otherIndex=other==='record'?8:1;
  const wrongBeat=language==='en'?Story.ENDINGS.find(e=>e.id===other).beats[otherIndex].text:CONTENT_JA.e[other].beats[otherIndex];
  const body=outputs[0].ending.text,occurrences=body.split(expected).length-1;
  assert.equal(occurrences,flagPresent?1:0);assert.equal(body.includes(wrongBeat),false);
  if(language==='ja')assert.equal(body.includes(def.beats[index].text),false);
  const oldParagraphs=language==='en'?[oldStory.ENDINGS[0].beats[8].text,oldStory.ENDINGS[3].beats[1].text]:[oldContent.e.record.beats[8],oldContent.e.everybody.beats[1]];
  const norm=s=>s.replace(/\s+/g,' ').trim();assert.ok(oldParagraphs.every(s=>!norm(body).includes(norm(s))));
  const saved=Storage.load();assert.ok(saved.completed);assert.equal(saved.state.ending,endingId);assert.equal(saved.state.flags.includes('trench_slipped'),flagPresent);assert.ok(saved.state.flags.includes('trench_passed'));
  assert.equal(g.time,0,'This text-routing probe must not advance dialogue simulation time');
  r.cases.push({language,endingId,flagPresent,payloadDelta:onlyDelta,restored,flow,expectedBeat:expected,occurrences,output:outputs[0],completedSave:saved,mode:g.mode,time:g.time});
 }
 r.pairedToggles=[];
 for(const language of ['en','ja'])for(const endingId of ['record','everybody']){
  const yes=r.cases.find(c=>c.language===language&&c.endingId===endingId&&c.flagPresent),no=r.cases.find(c=>c.language===language&&c.endingId===endingId&&!c.flagPresent);
  const stripped=yes.output.ending.text.split('\n\n').filter(p=>p!==yes.expectedBeat).join('\n\n');
  assert.equal(stripped,no.output.ending.text);assert.deepEqual(yes.output.epilogue,no.output.epilogue);
  r.pairedToggles.push({language,endingId,onlyExpectedParagraphChanges:true,epilogueIdentical:true});
 }
 r.missingChangedLocaleKeys=missingKeys().filter(k=>['ui.hud.pastthem','e.record.beats.8','e.everybody.beats.1'].includes(k));assert.deepEqual(r.missingChangedLocaleKeys,[]);setLocale('en');
});

report.swallowedErrors=swallowedErrors;report.finalSourceHashes=pinSources();report.snapshotUnchanged=JSON.stringify(sourceHashes)===JSON.stringify(report.finalSourceHashes);
report.finalThreeHashes={module:sha(fs.readFileSync(pins.snapshot+'/node_modules/three/build/three.module.js')),core:sha(fs.readFileSync(pins.snapshot+'/node_modules/three/build/three.core.js'))};
report.threeUnchanged=report.finalThreeHashes.module===pins.threeModuleHash&&report.finalThreeHashes.core===pins.threeCoreHash;
fs.writeFileSync(root+'/trench-perception-r4-refuter-probe-01.json',JSON.stringify(report,(_k,v)=>v&&typeof v==='object'&&v.pos?.isVector3&&Number.isInteger(v.id)?{actor:v.id,kind:v.kind??v.faction}:v,2)+'\n');
console.log(JSON.stringify({probeErrors:checks.filter(c=>c.status==='probe-error').length,swallowedErrors,snapshotUnchanged:report.snapshotUnchanged,threeUnchanged:report.threeUnchanged}));
if(checks.some(c=>c.status==='probe-error')||swallowedErrors.length||!report.snapshotUnchanged||!report.threeUnchanged)process.exitCode=1;
