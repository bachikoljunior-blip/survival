import fs from 'node:fs';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
const root='/workspace/scratch/0b7ad82bafe7',repo=root+'/survival',dest=root+'/trench-perception-r4-source',hash=b=>createHash('sha256').update(b).digest('hex');
const paths=execFileSync('git',['ls-files','src'],{cwd:repo,encoding:'utf8'}).trim().split('\n');
const sourceHashes=Object.fromEntries(paths.map(p=>[p,hash(fs.readFileSync(repo+'/'+p))]));
if(fs.existsSync(dest))throw Error('Refusing to overwrite source snapshot');
fs.mkdirSync(dest);fs.cpSync(repo+'/src',dest+'/src',{recursive:true});fs.copyFileSync(repo+'/package.json',dest+'/package.json');fs.symlinkSync(repo+'/node_modules',dest+'/node_modules','dir');
for(const p of paths){if(hash(fs.readFileSync(dest+'/'+p))!==sourceHashes[p]||hash(fs.readFileSync(repo+'/'+p))!==sourceHashes[p])throw Error('Source changed during snapshot '+p);}
const baseline='10ddee91fbf74512d3d577ba50d9dabbc987193f',changed=[];
for(const p of paths){const old=execFileSync('git',['show',baseline+':'+p],{cwd:repo});if(hash(old)!==sourceHashes[p])changed.push(p);}
fs.writeFileSync(root+'/trench-perception-r4-source-pins.json',JSON.stringify({createdAt:new Date().toISOString(),baseline,sourceHashes,changed,snapshot:dest,node:process.version,threeModuleHash:hash(fs.readFileSync(repo+'/node_modules/three/build/three.module.js')),threeCoreHash:hash(fs.readFileSync(repo+'/node_modules/three/build/three.core.js'))},null,2)+'\n');
const city=fs.readFileSync(root+'/cpu-city-fixture-v2.mjs','utf8').replaceAll('./survival/','./trench-perception-r4-source/');
fs.writeFileSync(root+'/trench-perception-r4-cpu-city-fixture.mjs',city);
let fixture=fs.readFileSync(root+'/trench-perception-fixture-v3.mjs','utf8').replaceAll('./survival/','./trench-perception-r4-source/').replace("'./cpu-city-fixture-v2.mjs'","'./trench-perception-r4-cpu-city-fixture.mjs'");
fixture=fixture.replace("const paths=execFileSync('git',['ls-files','src'],{cwd:repo,encoding:'utf8'}).trim().split('\\n');","const paths=Object.keys(JSON.parse(fs.readFileSync(root+'/trench-perception-r4-source-pins.json')).sourceHashes);");
fixture=fixture.replace("sha(fs.readFileSync(repo+'/'+p))","sha(fs.readFileSync(root+'/trench-perception-r4-source/'+p))");
fs.writeFileSync(root+'/trench-perception-r4-fixture.mjs',fixture);
let input=fs.readFileSync(root+'/trench-perception-r2-fixture-v1.mjs','utf8').replaceAll('./survival/','./trench-perception-r4-source/').replace("'./trench-perception-fixture-v3.mjs'","'./trench-perception-r4-fixture.mjs'");
fs.writeFileSync(root+'/trench-perception-r4-input-fixture.mjs',input);
console.log(JSON.stringify({changed,sourceHashes:Object.fromEntries(changed.map(p=>[p,sourceHashes[p]])),snapshot:dest}));
