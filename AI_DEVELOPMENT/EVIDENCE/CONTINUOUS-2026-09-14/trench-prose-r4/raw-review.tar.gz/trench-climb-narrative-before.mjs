import fs from 'node:fs';
import assert from 'node:assert/strict';
import {root,pinSources,makeGame,snap,place,enterTrench,inputFixture,swallowedErrors} from './trench-perception-r2-fixture-v1.mjs';
const report={createdAt:new Date().toISOString(),sourceHashes:pinSources(),scope:'Real quest climb with CPU input/physics; UI output is recorded at the actual presentation boundary, no raster/browser claim.'};
function full(g){return snap(g);}
async function check(name,fn){report.name=name;report.result={};await fn(report.result);}
await check('actual-quest-oblique-climb-segment',r=>{
  const g=makeGame(),input=inputFixture(g);enterTrench(g);r.initial=place(g,96,16);r.start=full(g);assert.equal(r.initial.overlap,null);
  const targets=[[92.75,15.3],[91.9,17.5],[90,16]],trace=[];let phase=0,maxGroundedY=-Infinity;
  for(let i=0;i<720;i++){
    if(phase===1&&g.player.grounded&&!g.player._vault&&g.player.pos.y>1.9)phase=2;
    let target=targets[phase],dx=target[0]-g.player.pos.x,dz=target[1]-g.player.pos.z,d=Math.hypot(dx,dz);
    if(phase===0&&d<.14){phase=1;target=targets[phase];dx=target[0]-g.player.pos.x;dz=target[1]-g.player.pos.z;d=Math.hypot(dx,dz);}
    input.inp.move=d>.08?{x:dx/d,y:dz/d,mag:1}:{x:0,y:0,mag:0};g.fixedUpdate(1/60);
    if(g.player.grounded&&!g.player._vault)maxGroundedY=Math.max(maxGroundedY,g.player.pos.y);
    trace.push({time:g.time,pos:g.player.pos.toArray(),grounded:g.player.grounded,state:g.player.state,vault:!!g.player._vault,phase,input:{...input.inp.move},questStep:g.state.quests.get('cinderline').step,flags:[...g.state.flags]});
    if(g.player.grounded&&!g.player._vault&&g.player.pos.y>2.4)break;
  }
  Object.assign(r,{targets,trace,maxGroundedY,final:full(g),vaults:g.events.filter(e=>e.name==='actor:vault'),notices:g.hudCalls.filter(c=>c.method==='notice'),scope:'Only supported initial position setup; later movement comes from real normal Game input/Player physics/vault/collision. No sprint. This is the final climb segment, not the complete earlier-chapter approach.'});
  assert.ok(maxGroundedY>2.4);assert.equal(r.final.quest.step,2);assert.ok(g.state.has('trench_slipped'));assert.ok(g.state.has('trench_passed'));assert.equal(g.state.has('trench_talked'),false);assert.equal(r.vaults.length,2);
});

report.swallowedErrors=swallowedErrors;fs.writeFileSync(root+'/trench-climb-narrative-before.json',JSON.stringify(report,null,2)+'\n'); console.log(JSON.stringify({flags:report.result.final.flags,alerted:report.result.final.enemies.map(e=>({kind:e.kind,aggro:e.aggro,state:e.aiState})),notices:report.result.notices,errors:swallowedErrors},null,2));
