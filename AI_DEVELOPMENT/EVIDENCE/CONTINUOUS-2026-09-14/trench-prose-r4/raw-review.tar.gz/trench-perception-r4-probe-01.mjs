import fs from 'node:fs';
import assert from 'node:assert/strict';
import {execFileSync} from 'node:child_process';
import {root,repo,sha,pinSources,makeGame,snap,place,enterTrench,inputFixture,Storage,swallowedErrors} from './trench-perception-r4-input-fixture.mjs';
import * as Story from './trench-perception-r4-source/src/content/story.js';
import {UI_JA} from './trench-perception-r4-source/src/content/locale/ja/ui.js';
import {CONTENT_JA} from './trench-perception-r4-source/src/content/locale/ja/content.js';
import {setLocale,t,missingKeys} from './trench-perception-r4-source/src/content/i18n.js';
const pins=JSON.parse(fs.readFileSync(root+'/trench-perception-r4-source-pins.json')),sourceHashes=pinSources(),checks=[];
assert.deepEqual(sourceHashes,pins.sourceHashes);
const baseline=pins.baseline,oldText=p=>execFileSync('git',['show',baseline+':'+p],{cwd:repo,encoding:'utf8'});
async function importText(text,path){const s=text.replace(/from (['"])([^'"]+)\1/g,(_m,_q,p)=>'from '+JSON.stringify(p==='three'?new URL('./trench-perception-r4-source/node_modules/three/build/three.module.js',import.meta.url).href:new URL(p,new URL('./trench-perception-r4-source/'+path,import.meta.url)).href));return import('data:text/javascript;base64,'+Buffer.from(s).toString('base64'));}
const report={round:4,createdAt:new Date().toISOString(),baseline,sourceHashes,scope:'Immutable byte-identical production snapshot. Changed prose routing, UI-call text/localization and compatibility of an original-Director save carrying trench_slipped. Actual Game/Player/City/AI path reaches notices; actual Storage/applySave/DialogueRunner/Director.finish reaches ending presentation. Rendering, output devices and input acquisition are fixture stubs; no sensory or full narrative quality verdict.',checks};
async function check(name,fn){const c={name,status:'running',result:{}};checks.push(c);try{await fn(c.result);c.status='completed';console.log(name+': completed');}catch(e){c.status='probe-error';c.error=String(e);c.stack=e.stack;console.log(name+': '+e.stack);}}
function clone(v){return JSON.parse(JSON.stringify(v));}
function climb(g){
  const input=inputFixture(g);enterTrench(g);const initial=place(g,96,16),targets=[[92.75,15.3],[91.9,17.5],[90,16]],trace=[];let phase=0;
  for(let i=0;i<720;i++){
    if(phase===1&&g.player.grounded&&!g.player._vault&&g.player.pos.y>1.9)phase=2;
    let target=targets[phase],dx=target[0]-g.player.pos.x,dz=target[1]-g.player.pos.z,d=Math.hypot(dx,dz);
    if(phase===0&&d<.14){phase=1;target=targets[phase];dx=target[0]-g.player.pos.x;dz=target[1]-g.player.pos.z;d=Math.hypot(dx,dz);}
    input.inp.move=d>.08?{x:dx/d,y:dz/d,mag:1}:{x:0,y:0,mag:0};g.fixedUpdate(1/60);
    trace.push({time:g.time,pos:g.player.pos.toArray(),phase,mode:g.mode,flags:[...g.state.flags]});
    if(g.player.grounded&&!g.player._vault&&g.player.pos.y>2.4)break;
  }
  assert.ok(g.state.has('trench_slipped'));return {initial,targets,trace,final:snap(g),notices:g.hudCalls.filter(c=>c.method==='notice')};
}
let legacySave;

await check('exact-text-only-delta-and-unchanged-content-routing',async r=>{
  const oldStory=await importText(oldText('src/content/story.js'),'src/content/story.js');
  const normalize=s=>{const out={};for(const [key,value] of Object.entries(s))out[key]=clone(value);out.ENDINGS.find(e=>e.id==='record').beats[8].text='<changed-record-beat>';out.ENDINGS.find(e=>e.id==='everybody').beats[1].text='<changed-everybody-beat>';return out;};
  assert.deepEqual(normalize(Story),normalize(oldStory));
  const oldUi=(await importText(oldText('src/content/locale/ja/ui.js'),'src/content/locale/ja/ui.js')).UI_JA;
  const oldContent=(await importText(oldText('src/content/locale/ja/content.js'),'src/content/locale/ja/content.js')).CONTENT_JA;
  const uiBefore=clone(oldUi),uiAfter=clone(UI_JA);uiBefore.hud.pastthem=uiAfter.hud.pastthem='<changed-notice>';assert.deepEqual(uiAfter,uiBefore);
  const contentBefore=clone(oldContent),contentAfter=clone(CONTENT_JA);for(const c of [contentBefore,contentAfter]){c.e.record.beats[8]='<changed-record-beat>';c.e.everybody.beats[1]='<changed-everybody-beat>';}assert.deepEqual(contentAfter,contentBefore);
  const before=oldText('src/game/director.js'),after=fs.readFileSync(root+'/trench-perception-r4-source/src/game/director.js','utf8');
  const normalized=after.replace('        // This records the route, including a climb made under pursuit. It\n        // does not establish that no guard saw Ren or that nobody was hurt.\n','').replace('<b>Over the line.</b><br>You have the high ground.','<b>Past them.</b><br>Nobody looked up.');assert.equal(normalized,before);
  r.changedFiles=pins.changed;r.directorOnlyExpectedProseAndComment=true;r.allOtherStoryExportsAndBeatFieldsIdentical=true;r.localeOnlyExpectedStringsChanged=true;r.beatConditions={record:Story.ENDINGS.find(e=>e.id==='record').beats[8].condition,everybody:Story.ENDINGS.find(e=>e.id==='everybody').beats[1].condition};
  r.beforeText={enRecord:oldStory.ENDINGS.find(e=>e.id==='record').beats[8].text,enEverybody:oldStory.ENDINGS.find(e=>e.id==='everybody').beats[1].text,jaNotice:oldUi.hud.pastthem,jaRecord:oldContent.e.record.beats[8],jaEverybody:oldContent.e.everybody.beats[1]};
});

await check('original-director-save-and-current-notice-boundaries',async r=>{
  r.runs=[];const original=(await importText(oldText('src/game/director.js'),'src/game/director.js')).Director;
  for(const [label,language,D] of [['original-director-en','en',original],['current-en','en',undefined],['current-ja','ja',undefined]]){
    setLocale(language);const g=makeGame(D);g.state.set('sol_debrief');g.state.adjustTrust('sol',20,'Explicit ending-choice prerequisite setup');
    const run=climb(g);const expected=label==='original-director-en'?'<b>Past them.</b><br>Nobody looked up.':language==='en'?'<b>Over the line.</b><br>You have the high ground.':'<b>列を越えた。</b><br>高所に出た。';
    assert.ok(run.notices.some(n=>n.args[0]===expected));assert.ok(run.final.enemies.some(e=>e.aggro));assert.equal(run.final.quest.step,2);
    if(label==='original-director-en'){assert.equal(g.director.save(true),true);legacySave=Storage.load();assert.ok(legacySave.state.flags.includes('trench_slipped'));r.legacySave=legacySave;r.writerScope='Original pre-edit Director; all other production modules come from the pinned current snapshot. Save, progression and physics sources are identical to the pre-edit revision. Story/locale differences are prose only and not saved into the route flag.';}
    r.runs.push({label,language,...run});
  }
  setLocale('en');
});

await check('legacy-flag-restoration-and-actual-ending-localization',async r=>{
  assert.ok(legacySave);r.cases=[];
  for(const language of ['en','ja'])for(const endingId of ['record','everybody'])for(const flagPresent of [true,false]){
    setLocale(language);const payload=clone(legacySave);if(!flagPresent)payload.state.flags=payload.state.flags.filter(f=>f!=='trench_slipped');
    const g=makeGame();inputFixture(g);const outputs=[],finishes=[];g.menus.showEnding=(ending,epilogue)=>outputs.push({ending:clone(ending),epilogue:clone(epilogue)});
    const original=g.director.finish;g.director.finish=function(...args){const p=original.apply(this,args);finishes.push(p);return p;};
    assert.equal(g.director.applySave(payload),true);assert.equal(g.state.has('trench_slipped'),flagPresent);const restored={flags:[...g.state.flags],quest:clone(g.state.quests.get('cinderline')),node:g.director.dialogue.node?.id};
    const flow=[],goto=endingId==='record'?'e_publish':'e_evac';
    for(let n=0;n<40&&g.director.dialogue.active;n++){
      const runner=g.director.dialogue,choices=runner.choices();flow.push({node:runner.node?.id,choices:choices?.map(c=>({goto:c.goto,locked:c.locked}))??null});
      if(choices){const i=choices.findIndex(c=>c.goto===goto&&!c.locked);assert.ok(i>=0);g.dialogueUI.onChoose(i);}else g.dialogueUI.onAdvance();
      await Promise.resolve();
    }
    await Promise.all(finishes);assert.equal(outputs.length,1);assert.equal(outputs[0].ending.id,endingId);
    const index=endingId==='record'?8:1,beat=Story.ENDINGS.find(e=>e.id===endingId).beats[index],expected=t('e.'+endingId+'.beats.'+index,beat.text),body=outputs[0].ending.text;
    assert.equal(body.includes(expected),flagPresent);assert.equal(body.split(expected).length-1,flagPresent?1:0);
    const forbidden=language==='en'?['You did not touch any of them getting in. Two of the three','Nobody ever established how you got past the line']:['三人のうち二人が証言し、どちらも私がどうやって列を抜けたのか言えず','あの朝カットで私がどうやって列を抜けたのかは、ついに誰も突き止めなかった'];
    assert.ok(forbidden.every(s=>!body.includes(s)));const saved=Storage.load();assert.ok(saved.completed);assert.equal(saved.state.flags.includes('trench_slipped'),flagPresent);
    r.cases.push({language,endingId,flagPresent,restored,flow,expectedBeat:expected,output:outputs[0],completedSave:saved,scope:'Actual applySave -> final DialogueRunner callbacks -> authored available choice -> Director.finish -> menus.showEnding. No simulation time is advanced during reading; this verifies text routing, not dialogue survival/reset behavior. Flag-absent cases are explicit condition controls, not claims of a full alternative authored journey.'});
  }
  r.missingChangedLocaleKeys=missingKeys().filter(k=>['ui.hud.pastthem','e.record.beats.8','e.everybody.beats.1'].includes(k));assert.equal(r.missingChangedLocaleKeys.length,0);setLocale('en');
});

report.swallowedErrors=swallowedErrors;report.finalSourceHashes=pinSources();report.sourceUnchanged=JSON.stringify(sourceHashes)===JSON.stringify(report.finalSourceHashes);
fs.writeFileSync(root+'/trench-perception-r4-probe-01.json',JSON.stringify(report,(_k,v)=>v&&typeof v==='object'&&v.pos?.isVector3&&Number.isInteger(v.id)?{actor:v.id,kind:v.kind??v.faction}:v,2)+'\n');
console.log(JSON.stringify({probeErrors:checks.filter(c=>c.status==='probe-error').length,swallowedErrors,sourceUnchanged:report.sourceUnchanged}));
if(checks.some(c=>c.status==='probe-error')||swallowedErrors.length||!report.sourceUnchanged)process.exitCode=1;
