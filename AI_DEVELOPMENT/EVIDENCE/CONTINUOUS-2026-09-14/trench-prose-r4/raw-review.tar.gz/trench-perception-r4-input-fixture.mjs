// Round 2 CPU fixture: reuses actual normal input/damage observers from prior independent refuter.
import {Game} from './trench-perception-r4-source/src/game/game.js';
export * from './trench-perception-r4-fixture.mjs';
export function inputFixture(g){
  const held=new Set(),pending=new Set(),enableEvents=[],calls=[];
  const inp={enabled:true,move:{x:0,y:0,mag:0},current:new Set(),
    step(){this.current=new Set(pending);pending.clear();},
    setEnabled(v){this.enabled=v;enableEvents.push({time:g.time,enabled:v,mode:g.mode});},
    clearToggle(k){held.delete(k);},on(){},takeLook(){return {x:0,y:0};},
    pressed(k){return this.enabled&&this.current.has(k);},down(k){return this.enabled&&held.has(k);}};
  g.input=inp;
  g.camera.forwardXZ=v=>v.set(-Math.sin(g.camera.yaw),0,-Math.cos(g.camera.yaw));
  g.camera.rightXZ=v=>v.set(Math.cos(g.camera.yaw),0,-Math.sin(g.camera.yaw));
  g._playerInput=function(dt){calls.push({time:g.time,mode:g.mode});return Game.prototype._playerInput.call(g,dt);};
  return {inp,held,pending,enableEvents,calls};
}
export function observeDamage(g){
  const calls=[],original=g.player.damage;
  g.player.damage=function(hit){
    const hpBefore=this.hp,result=original.call(this,hit);
    calls.push({time:g.time,mode:g.mode,source:hit.source?{id:hit.source.id,kind:hit.source.kind,faction:hit.source.faction}:null,kind:hit.kind,inputAmount:hit.amount,result,hpBefore,hpAfter:this.hp,flags:[...g.state.flags],questStep:g.state.quests.get('cinderline')?.step});
    return result;
  };
  return calls;
}
