import fs from 'node:fs';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {validateFindings} from './survival/.kit/lib/plan/findings.mjs';
const root='/workspace/scratch/0b7ad82bafe7',read=n=>JSON.parse(fs.readFileSync(root+'/'+n)),hash=b=>createHash('sha256').update(b).digest('hex');
const review=read('trench-perception-r4-review-draft.json'),independent=read('trench-perception-r4-refuter-review.json');
if(independent.findings.length)throw Error('Surviving refuter finding requires disposition');
for(const [p,h] of Object.entries(review.sourceHashes))if(hash(fs.readFileSync(review.sourceSnapshot+'/'+p))!==h)throw Error('Pinned production source changed '+p);
const integrity=[];
for(const file of ['trench-perception-artifact-manifest.json','trench-perception-r2-artifact-manifest.json','trench-perception-r3-artifact-manifest.json']){const m=read(file);for(const [p,h] of Object.entries(m.files))if(hash(fs.readFileSync(root+'/'+p))!==h)throw Error('Prior artifact changed '+p);integrity.push({manifest:file,checkedFiles:Object.keys(m.files).length,changedFiles:0});}
review.createdAt=new Date().toISOString();review.verdictMeaning='Conservative schema field only: this is not narrative-quality, blind, element or product approval. No concrete changed-prose or routing defect survives the separate narrow refutation.';
review.observedOutcome='The same route flag now presents wording consistent with an alerted climb, including after restoration of a pre-edit-Director save. Exact comparisons establish that the change contains only the intended notice, two ending paragraphs, matching Japanese strings and comment. No surviving concrete defect remains within this scope.';
review.refutation={agent:'/root/trench_perception_review/trench_refuter',independent:true,complete:true,report:'trench-perception-r4-refuter-review.json',validation:'trench-perception-r4-refuter-validation.json',survivingFindings:[],scope:'The separate refuter challenges consistency, source-only scope, save compatibility and actual localization routing. See its report for which controls were independently rerun versus inspected.'};
review.controls.find(c=>c.id==='R4-NOTICES').detail+=' Alert state is recorded at the final replay snapshot; it is not presented as a separate measurement at the precise earlier notice call.';
review.controls.find(c=>c.id==='R4-LEGACY-SAVE-ENDINGS').independentPairedControl=independent.controlsRefutation.find(c=>c.id==='R4-LEGACY-SAVE-ENDINGS').strongerPairedControl;
review.priorArtifactIntegrity=integrity;
review.rawArtifacts.push(...fs.readdirSync(root).filter(n=>n.startsWith('trench-perception-r4-refuter-')));
review.contextReading='The selected paragraph and both adjacent paragraphs were inspected in all four flag-present locale/ending bodies. The hearing paragraph remains within the hearing account; the evacuation paragraph is a retrospective route/loading account. No concrete contradiction was identified; reader preference and prose quality were not scored.';
const knownOwners=new Set(execFileSync('git',['ls-files','src'],{cwd:root+'/survival',encoding:'utf8'}).trim().split('\n'));
const validation=validateFindings(review,{strict:true,knownOwners});if(!validation.ok)throw Error(JSON.stringify(validation));
fs.writeFileSync(root+'/trench-perception-r4-review.json',JSON.stringify(review,null,2)+'\n');fs.writeFileSync(root+'/trench-perception-r4-review-validation.json',JSON.stringify(validation,null,2)+'\n');
function listFiles(dir){const out=[];for(const item of fs.readdirSync(dir,{withFileTypes:true})){const full=dir+'/'+item.name;if(item.isSymbolicLink())continue;if(item.isDirectory())out.push(...listFiles(full));else if(item.isFile())out.push(full.slice(root.length+1));}return out;}
const names=fs.readdirSync(root).filter(n=>n.startsWith('trench-perception-r4-')&&n!=='trench-perception-r4-artifact-manifest.json'&&fs.statSync(root+'/'+n).isFile());names.push(...listFiles(review.sourceSnapshot),'trench-climb-narrative-before.mjs','trench-climb-narrative-before.json');
fs.writeFileSync(root+'/trench-perception-r4-artifact-manifest.json',JSON.stringify({node:process.version,sourceHashes:review.sourceHashes,sourceSnapshot:review.sourceSnapshot,dependencies:read('trench-perception-r4-source-pins.json'),files:Object.fromEntries(names.map(n=>[n,hash(fs.readFileSync(root+'/'+n))]))},null,2)+'\n');
console.log(JSON.stringify({validation,survivingFindings:0,priorArtifactIntegrity:integrity,artifacts:names.length}));
