import fs from 'node:fs';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import assert from 'node:assert/strict';

const here=new URL('./',import.meta.url), repo=new URL('./survival/',here);
const BASE='ae50ac9b8a072ee0e91617a703a0116ee68534f7';
const sha=b=>createHash('sha256').update(b).digest('hex');
const files=['src/game/director.js','src/content/world_data.js','src/world/city.js','src/world/gas.js','src/world/nav.js','src/game/state.js','src/game/narrative.js','src/content/story.js','src/main.js','src/game/game.js','src/core/util.js'];
const bytes=Object.fromEntries(files.map(p=>[p,fs.readFileSync(new URL(p,repo))]));
const sourceHashes=Object.fromEntries(files.map(p=>[p,sha(bytes[p])]));
assert.equal(sourceHashes['src/game/director.js'],'5a9dd9aebd23227632b1609c6a26a508e26e3e0eba6adffb715d883463893f7c');
assert.equal(sourceHashes['src/content/world_data.js'],'b4610034e662b1275ba507c33bbca3c29e069e84fb10070c233386ea4f3f8fa8');
const baselineBytes=Object.fromEntries(files.map(p=>[p,execFileSync('git',['show',BASE+':'+p],{cwd:repo})]));
const baselineHashes=Object.fromEntries(files.map(p=>[p,sha(baselineBytes[p])]));
for(const p of files.filter(p=>!['src/game/director.js','src/content/world_data.js'].includes(p)))assert.equal(sourceHashes[p],baselineHashes[p],'Baseline dependency changed: '+p);
function pinnedModule(source,path) {
 const rewritten=source.toString().replace(/from\s+(['"])([^'"]+)\1/g,(full,q,spec)=>{
  const url=spec==='three'?new URL('./node_modules/three/build/three.module.js',repo):new URL(spec,new URL(path,repo));
  return 'from '+JSON.stringify(url.href);
 });
 return import('data:text/javascript;base64,'+Buffer.from(rewritten).toString('base64'));
}
const {Director:OldDirector}=await pinnedModule(baselineBytes['src/game/director.js'],'src/game/director.js');
const {buildHollisData:oldData}=await pinnedModule(baselineBytes['src/content/world_data.js'],'src/content/world_data.js');
const {Director}=await import('./survival/src/game/director.js');
const {City}=await import('./survival/src/world/city.js');
const {GameState,Storage,SAVE_KEY}=await import('./survival/src/game/state.js');
const {QuestSystem,applyEffects}=await import('./survival/src/game/narrative.js');
const {QUESTS,CONVERSATIONS}=await import('./survival/src/content/story.js');
const {MODE}=await import('./survival/src/game/game.js');
const {buildCpuCity}=await import('./cpu-city-fixture-v2.mjs');
const storage=new Map();
globalThis.localStorage={getItem:k=>storage.has(k)?storage.get(k):null,setItem:(k,v)=>storage.set(k,String(v)),removeItem:k=>storage.delete(k)};
const checks=[];
function check(name,passed,details=null){checks.push({name,passed:!!passed,details});}
const equal=(a,b)=>JSON.stringify(a)===JSON.stringify(b);
const clone=x=>structuredClone(x);
function stateComparison(f,saved){
 const restored=f.d.state.serialise();
 const differingKeys=Object.keys(saved).filter(k=>!equal(saved[k],restored[k]));
 // serialise() assigns Date.now() to top-level t on every call. It is not progress.
 return {saved,restored,differingKeys,progressionMatches:differingKeys.every(k=>k==='t')};
}
const halfID='yard_half_seep',fullID='yard_seep',west=['vent_west_1','vent_west_2','vent_west_3'];
class BaselineCity extends City {constructor(ignored,mats,tier){super(oldData(),mats,tier);}}
function fixture(old=false){
 const {city}=buildCpuCity(old?{CityConstructor:BaselineCity}:{});
 const markers=new Map(),plumes=new Map(),notices=[],flow=[];
 const game={city,gas:city.gas,nav:city.nav,world:city.collision,mode:MODE.PLAY,playTime:17,
  player:null,actors:[],ai:{clearProjectiles(){}},
  atmos:{setMarkers(){},setMarkerActive:(id,on)=>markers.set(id,on),plumes:{setAnchorActive:(id,on)=>plumes.set(id,on)}},
  hud:{notice:(...args)=>notices.push(args),showAutosave(){},hideAutosave(){},setVisible(){},showCard(){}},
  menus:{hideTitle(){flow.push('hideTitle');},async fadeOut(){flow.push('fadeOut');},async fadeIn(){flow.push('fadeIn');}},
  teleport:id=>flow.push('teleport:'+id),setMode:mode=>{game.mode=mode;flow.push('mode:'+mode);},emit(){}};
 const d=Object.create((old?OldDirector:Director).prototype);
 Object.assign(d,{game,state:new GameState(),npcs:new Map(),encounters:new Map(),currentInterior:null,crisis:null,_markerTargets:{},refreshCast(){}});
 game.director=d;game.state=d.state;
 d.ctx={game,state:d.state,hooks:d._hooks()};
 d.quests=new QuestSystem(d.state,QUESTS,d.ctx);
 return {city,game,d,markers,plumes,notices,flow};
}
function reset(f){f.game.player=null;f.game.mode=MODE.PLAY;f.d.state.reset();f.d.resetWorld();f.game.playTime=17;}
function settle(f){f.game.gas.globalScale=f.game.gas._targetScale;f.game.gas.bake();f.game.nav.applyGasCost(f.game.gas);}
function snapshot(f){
 const g=f.game.gas;
 const sources=g.sources.filter(s=>s.id).map(s=>[s.id,s.active]);
 const ids=new Map(sources);
 const samples=[[-118,1.4,26],[-104,1.4,26],[-90,1.4,26],[-112,1.4,-84]].map(p=>({point:p,ppm:g.sample(...p)}));
 return {sources,west:west.map(id=>ids.get(id)),full:ids.get(fullID),half:ids.get(halfID)??null,
   targetScale:g._targetScale,globalScale:g.globalScale,gasTime:g.time,samples,
   emitHash:sha(Buffer.from(g.emit.buffer)),baseHash:sha(Buffer.from(g.base.buffer)),costHash:sha(Buffer.from(f.game.nav.cost.buffer)),
   markerIntent:Object.fromEntries([...west,fullID,halfID].map(id=>[id,f.markers.get(id)??null])),
   plumeIntent:Object.fromEntries([...west,fullID,halfID].map(id=>[id,f.plumes.get(id)??null]))};
}
function choose(f,choice){
 const authored=CONVERSATIONS.vent_decision.nodes.start.choices.find(c=>c.effects?.some(e=>e.choice?.[1]===choice));
 assert(authored,'Unknown authored choice');
 applyEffects(authored.effects,f.d.state,f.d.ctx);
 f.d.state.set('independent_save_witness');f.d.state.give('salvage',3);
 settle(f);
}
function saveLoad(f){
 const ok=f.d.save(true),text=localStorage.getItem(SAVE_KEY),payload=Storage.load();
 assert(ok && text && payload,'Real save/load failed');
 return {ok,textSha256:sha(text),payload};
}
function expectedChoice(choice,s){
 return equal(s.west,choice==='shut'?[false,false,false]:choice==='half'?[true,false,true]:[true,true,true]) &&
   s.full===(choice==='shut') && s.half===(choice==='half');
}
const current=fixture(),baseline=fixture(true);
const authored=current.city.data.gasSources.filter(s=>s.id===halfID);
check('Exactly one authored half source exists with the requested placement and default off',authored.length===1 && equal(authored[0],{x:-112,z:-84,strength:700,radius:26,id:halfID,active:false}),authored);
check('Exactly one current runtime half source is registered and baseline has none',current.city.gas.sources.filter(s=>s.id===halfID).length===1 && !baseline.city.gas.sources.some(s=>s.id===halfID));

const newRoundTrips=[],oldRoundTrips=[];
for(const choice of ['left','half','shut']){
 reset(current);choose(current,choice);
 const before=snapshot(current),saved=saveLoad(current);
 check('New '+choice+' save includes explicit boolean half source row',saved.payload.gasSources.some(r=>equal(r,[halfID,choice==='half'])));
 current.d.resetWorld();
 const resetState=snapshot(current);
 check('New '+choice+' resetWorld switches both courtyard sources off',resetState.half===false && resetState.full===false && equal(resetState.west,[true,true,true]));
 const accepted=current.d.applySave(saved.payload),after=snapshot(current);
 check('New '+choice+' save restores valid exclusive source state',accepted && expectedChoice(choice,after) && !(after.half&&after.full));
 check('New '+choice+' save restores source rows, stabilized gas samples, emission and nav costs',equal(before.sources,after.sources) && equal(before.samples,after.samples) && before.emitHash===after.emitHash && before.baseHash===after.baseHash && before.costHash===after.costHash);
 const state=stateComparison(current,saved.payload.state);
 check('New '+choice+' save preserves unrelated progression except generated serialization time',state.progressionMatches,state.differingKeys);
 check('New '+choice+' source restore emits matching marker/plume state intents', [...west,fullID,halfID].every(id=>after.markerIntent[id]===new Map(after.sources).get(id) && after.plumeIntent[id]===new Map(after.sources).get(id)));
 newRoundTrips.push({choice,before,saved,reset:resetState,accepted,after,state});

 reset(baseline);choose(baseline,choice);
 const oldBefore=snapshot(baseline),oldSave=saveLoad(baseline);
 check('Actual ae50 '+choice+' save omits the not-yet-authored source',!oldSave.payload.gasSources.some(r=>r[0]===halfID));
 const inputCopy=clone(oldSave.payload),oldAccepted=current.d.applySave(oldSave.payload),oldAfter=snapshot(current);
 check('Actual ae50 '+choice+' save restores correct exclusive current source state',oldAccepted && expectedChoice(choice,oldAfter) && !(oldAfter.half&&oldAfter.full));
 const oldState=stateComparison(current,oldSave.payload.state);
 check('Actual ae50 '+choice+' restore preserves old explicit rows and progression except generated serialization time',oldSave.payload.gasSources.every(([id,on])=>new Map(oldAfter.sources).get(id)===on) && oldState.progressionMatches && equal(oldSave.payload,inputCopy),oldState.differingKeys);
 oldRoundTrips.push({choice,before:oldBefore,saved:oldSave,accepted:oldAccepted,after:oldAfter,state:oldState});
}

// Constructed precedence boundaries are not claimed to be reachable story choices.
const clean=clone(newRoundTrips.find(x=>x.choice==='left').saved.payload);
const cases=[
 {name:'No choice flag, missing half row',flags:[],half:null,full:false,expectedHalf:false,expectedFull:false},
 {name:'Half flag, explicit half false',flags:['vents_half'],half:false,full:false,expectedHalf:false,expectedFull:false},
 {name:'No choice flag, explicit half true',flags:[],half:true,full:false,expectedHalf:true,expectedFull:false},
 {name:'Shut flag, explicit half true and full true',flags:['vents_shut'],half:true,full:true,expectedHalf:true,expectedFull:true},
 {name:'Both flags, missing half row, shut takes fallback precedence',flags:['vents_half','vents_shut'],half:null,full:true,expectedHalf:false,expectedFull:true},
 {name:'Legacy half flags with all gas rows and intensity absent',flags:['vents_half'],omitAll:true,expectedHalf:true,expectedFull:false},
];
const precedence=[];
for(const c of cases){
 const payload=clone(clean);
 payload.state.flags=payload.state.flags.filter(x=>!x.startsWith('vents_')&&!x.startsWith('choice:vents:'));
 payload.state.flags.push(...c.flags);
 payload.state.choices=payload.state.choices.filter(x=>x[0]!=='vents');
 if(c.omitAll){delete payload.gasSources;delete payload.gasIntensity;}
 else {
  payload.gasSources=payload.gasSources.filter(r=>r[0]!==halfID&&r[0]!==fullID);
  payload.gasSources.push([fullID,c.full]);
  if(c.half!==null)payload.gasSources.push([halfID,c.half]);
 }
 const beforeInput=clone(payload),accepted=current.d.applySave(payload),after=snapshot(current);
 check(c.name,accepted&&after.half===c.expectedHalf&&after.full===c.expectedFull,after);
 check(c.name+' retains explicit input rows and does not mutate payload',(payload.gasSources||[]).every(([id,on])=>new Map(after.sources).get(id)===on)&&equal(payload,beforeInput));
 precedence.push({case:c,payload,accepted,after,reachableStoryState:!['No choice flag, explicit half true','Shut flag, explicit half true and full true','Both flags, missing half row, shut takes fallback precedence'].includes(c.name)});
}

// Actual startNewGame callback source, with presentation/actor methods substituted.
current.d.applySave(newRoundTrips.find(x=>x.choice==='half').saved.payload);
const beforeNewGame=snapshot(current);
const player={group:{visible:false},hp:1,maxHp:100,stamina:1,maxStamina:100,dead:true,lungs:{sat:.8,removeFilter(){this.filter=null;}}};
current.game.player=player;
const main=bytes['src/main.js'].toString();
const start=main.indexOf('  const startNewGame = async () => {');
const end=main.indexOf('\n    // What to say about a save',start);
assert(start>=0 && end>start);
const callbackSource=main.slice(start,end);
const startNewGame=new Function('game','MODE','t','warnStorage','let leavingTitle = false;\n'+callbackSource+'\nreturn startNewGame;')(current.game,MODE,(key,fallback)=>fallback,()=>{});
await startNewGame();
const afterNewGame=snapshot(current);
check('Actual startNewGame callback clears half/shut/left choice flags and returns courtyard sources to off',afterNewGame.half===false && afterNewGame.full===false && equal(afterNewGame.west,[true,true,true]) && !['vents_half','vents_shut','vents_left','independent_save_witness'].some(f=>current.d.state.has(f)));
check('Actual new-game callback runs both initial quests and resets the supplied player state',current.d.quests.status('arrival')==='active' && current.d.quests.status('cellarRow')==='active' && player.hp===100 && player.stamina===100 && player.lungs.sat===0 && !player.dead && current.game.mode===MODE.PLAY);
const sourceRevisionBefore=current.game.nav._gasRevision;
let navTicks=0;
do {current.game.nav.updateGasCost(current.game.gas,1/60);navTicks++;} while(current.game.nav._gasRevision!==current.game.gas.revision && navTicks<100);
const afterNewGameNav=snapshot(current);
let maxCostError=0,walkable=0;
const nav=current.game.nav;
for(let i=0;i<nav.height.length;i++){
 if(Number.isNaN(nav.height[i]))continue;
 const ppm=current.game.gas.sample(nav.xOf(i%nav.nx),nav.height[i]+1.7*.6,nav.zOf((i/nav.nx)|0));
 const expected=Math.fround(1+Math.max(0,Math.min(1,ppm/900))*5.5);
 maxCostError=Math.max(maxCostError,Math.abs(nav.cost[i]-expected));walkable++;
}
check('Reset navigation cost matches the reset gas after one complete normal bounded sweep',nav._gasRevision===current.game.gas.revision && maxCostError===0,{navTicks,walkable,maxCostError});
const afterHashes=Object.fromEntries(files.map(p=>[p,sha(fs.readFileSync(new URL(p,repo)))]));
assert.deepEqual(afterHashes,sourceHashes,'Product source changed during half-save review');
const report={checkedAt:new Date().toISOString(),baselineCommit:BASE,sourceHashes,sourceHashesAfter:afterHashes,baselineHashes,
 scope:'Actual current and ae50 Director hooks/save/resetWorld/applySave, full current and ae50-authored City/Gas/Nav, actual GameState/Storage/QuestSystem/applyEffects. Old Director and authored data are loaded from pinned git objects; unchanged dependencies use current files verified equal to ae50. In-memory localStorage, Canvas/material appearance stubs, no NPCs/hostiles, null saved player, atmosphere call-intent stubs and omitted refreshCast. Actual startNewGame callback is extracted unchanged from pinned current main.js with presentation/actor substitutes. No browser, external operation, product edit, visual judgement or blind comparison.',
 stabilization:'For save/config identity only, gas time and wind are unchanged and globalScale is set to target before actual bake+nav apply. This does not prove restoration of simulation time, wind, transient intensity or pixel appearance.',
 authoredHalfSource:authored,newRoundTrips,oldRoundTrips,precedence,
 newGame:{callbackSha256:sha(callbackSource),before:beforeNewGame,after:afterNewGame,flow:current.flow,sourceRevisionBefore,gasRevision:current.game.gas.revision,navTicks,afterNavPublication:afterNewGameNav,walkable,maxCostError},
 checks,passed:checks.every(c=>c.passed)};
const out=new URL('./gas-half-save-cpu-evidence-v2.json',here);
fs.writeFileSync(out,JSON.stringify(report,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({passed:report.passed,checks:checks.length,failed:checks.filter(c=>!c.passed),newRoundTrips:newRoundTrips.map(x=>({choice:x.choice,half:x.after.half,full:x.after.full,west:x.after.west})),oldRoundTrips:oldRoundTrips.map(x=>({choice:x.choice,oldHalf:x.before.half,half:x.after.half,full:x.after.full,oldYardPpm:x.before.samples.at(-1).ppm,currentYardPpm:x.after.samples.at(-1).ppm})),precedence:precedence.map(x=>({name:x.case.name,half:x.after.half,full:x.after.full})),newGame:{half:afterNewGame.half,full:afterNewGame.full,navTicks,maxCostError},output:out.pathname}));
if(!report.passed)process.exitCode=1;
