import fs from 'node:fs';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {buildCpuCity, THREE} from './cpu-city-fixture-v2.mjs';
import {Game,MODE} from './survival/src/game/game.js';
import {Director} from './survival/src/game/director.js';
import {Enemy} from './survival/src/game/ai.js';
const ROOT=new URL('./survival/',import.meta.url);
const sha=b=>createHash('sha256').update(b).digest('hex');
const floatHash=a=>sha(Buffer.from(a.buffer,a.byteOffset,a.byteLength));
const sourceFiles=['src/content/world_data.js','src/content/story.js','src/world/city.js','src/world/gas.js','src/world/nav.js','src/world/collision.js','src/game/game.js','src/game/director.js','src/game/ai.js','src/actors/actor.js'];
const sourceHashes=Object.fromEntries(sourceFiles.map(p=>[p,sha(fs.readFileSync(new URL(p,ROOT)))]));
const results=[],checks=[];
const check=(name,passed,detail)=>checks.push({name,passed:!!passed,detail});
const point={x:-112,y:0,z:-84};
const mats={character:()=>new THREE.MeshStandardMaterial()};
function actorFor(city){const e=new Enemy('scav',{...point,world:city.collision,gas:city.gas,mats,weapon:null,seed:17});e.placeAt(point.x,point.y,point.z);return e;}
for(const choice of ['left','half','shut']){
  const {city,data}=buildCpuCity(),effects=[];
  const initialNavCost=new Float32Array(city.nav.cost);
  const game={city,gas:city.gas,nav:city.nav,time:0,playTime:0,mode:MODE.PLAY,input:{step(){}},actors:[],systems:[],_playerInput(){},_updateZone(){},
    atmos:{setMarkerActive:(...args)=>effects.push({type:'marker',args}),plumes:{setAnchorActive:(...args)=>effects.push({type:'plume',args})}},hud:{notice:(...args)=>effects.push({type:'notice',args})}};
  if(choice!=='left')Director.prototype._hooks.call({game})[choice==='half'?'halfVents':'shutVents']();
  const publications=[];let samples=0,maxSamples=0;
  const sample=city.gas.sample;
  city.gas.sample=function(...args){samples++;return sample.apply(this,args);};
  for(let tick=1;tick<=120;tick++){
    const previous=city.nav.costRevision;samples=0;
    Game.prototype.fixedUpdate.call(game,1/60);maxSamples=Math.max(maxSamples,samples);
    if(previous!==city.nav.costRevision)publications.push({tick,time:game.time,revision:city.nav.costRevision,sourceRevision:city.nav._gasRevision});
  }
  city.gas.sample=sample;
  const sources=city.gas.sources.filter(s=>['vent_west_1','vent_west_2','vent_west_3','yard_seep','yard_half_seep'].includes(s.id)).map(s=>({...s}));
  const yard=city.gas.sample(point.x,1.4,point.z);
  const e=actorFor(city),perception=[];
  for(const distance of [18,20]){
    const target={pos:new THREE.Vector3(point.x+distance,0,point.z),height:1.7};
    e.faceTowards(target.pos.x,target.pos.z,true);
    perception.push({distance,target:target.pos.toArray(),walkable:city.nav.walkable(target.pos.x,target.pos.z,0),
      lineOfSight:city.collision.lineOfSight(e.pos.x,e.pos.y+e.height*.85,e.pos.z,target.pos.x,target.pos.y+target.height*.7,target.pos.z),
      canSee:e.canSee(target,city.collision,city.gas)});
  }
  const nav=city.nav,i=nav.nearest(point.x,point.z,point.y),navPoint=nav._pt(i);
  const navPpmNow=city.gas.sample(navPoint.x,navPoint.y+1.02,navPoint.z);
  let changed=0;for(let j=0;j<nav.cost.length;j++)if(nav.cost[j]!==initialNavCost[j])changed++;
  const search=nav.createPathSearch(-130,0,-84,-94,0,-84),steps=[];
  if(search)for(let tick=0;tick<200&&!search.done;tick++){search.step(700);steps.push(search.lastExpanded);}
  const lungs=actorFor(city),timeline=[];let firstDamageAt=null,elapsed=0;
  for(let tick=1;tick<=600*60;tick++){
    const before=lungs.hp;
    lungs._updateVitals(1/60,null);elapsed=tick/60;
    if(firstDamageAt===null&&lungs.hp<before)firstDamageAt=elapsed;
    if(tick%3600===0||lungs.dead)timeline.push({time:elapsed,hp:lungs.hp,dead:lungs.dead,saturation:lungs.lungs.sat,ambientPpm:lungs.ambientPpm,severity:lungs.lungs.severity});
    if(lungs.dead)break;
  }
  const row={choice,gasTime:city.gas.time,globalScale:city.gas.globalScale,targetScale:city.gas._targetScale,sources,effects,
    yardPpm:yard,westPpm:data.props.filter(p=>p.id?.startsWith('vent_west_')).map(p=>({id:p.id,ppm:city.gas.sample(p.x+2,1.4,p.z)})),
    placement:{point,ground:city.collision.groundUnder(point.x,point.z,.33,6,12)?.y,overlaps:!!city.collision.overlaps(point.x,.05,point.z,.33,1.7),walkable:nav.walkable(point.x,point.z,0)},
    navigation:{gridCells:nav.cost.length,changedCells:changed,costBeforeHash:floatHash(initialNavCost),costAfterHash:floatHash(nav.cost),maxSamplesPerTick:maxSamples,publications,
      yardCell:i,navPoint,liveCost:nav.cost[i],sameTimePpm:navPpmNow,sameTimeExpectedCost:1+Math.min(1,navPpmNow/900)*5.5,
      plannedRoute:{start:[-130,0,-84],goal:[-94,0,-84],done:search?.done??false,path:search?.path??null,expanded:search?.expanded??0,steps,scope:'Completed production A* path on the current cost snapshot; no physical route traversal asserted.'}},
    sight:{range:e.sightRange(city.gas),perception,scope:'Actual Enemy.canSee including native CollisionWorld line of sight and facing; no player-screen or raster visibility measurement.'},
    exposure:{firstDamageAt,elapsedSeconds:elapsed,finalHp:lungs.hp,dead:lungs.dead,finalSaturation:lungs.lungs.sat,ambientPpm:lungs.ambientPpm,timeline,
      scope:'Actual Enemy constructor and Actor._updateVitals/Lungs at rest, fixed position, gas field frozen after the matched two-second update. No AI escape, combat, renderer, or real physiological claim.'}};
  results.push(row);
  const on=id=>sources.find(s=>s.id===id)?.active;
  check(`${choice}: two yard sources are registered exactly once`,['yard_seep','yard_half_seep'].every(id=>sources.filter(s=>s.id===id).length===1));
  check(`${choice}: yard source exclusivity`,!(on('yard_seep')&&on('yard_half_seep')),{full:on('yard_seep'),half:on('yard_half_seep')});
  check(`${choice}: matched 120 fixed ticks`,Math.abs(city.gas.time-2)<1e-12);
  check(`${choice}: observer and diagnostic targets use actual clear ground`,row.placement.ground===0&&!row.placement.overlaps&&row.placement.walkable&&perception.every(p=>p.walkable&&p.lineOfSight));
  check(`${choice}: cost work remains bounded`,maxSamples<=4096,maxSamples);
  check(`${choice}: route search completes without a partial path`,search?.done&&!!search.path&&Math.hypot(search.path.at(-1).x+94,search.path.at(-1).z+84)<1e-8);
}
const [left,half,shut]=results;
check('yard concentration becomes distinct in the intended order',left.yardPpm<half.yardPpm&&half.yardPpm<shut.yardPpm,results.map(r=>[r.choice,r.yardPpm]));
check('yard nav cost differs in the intended order',left.navigation.liveCost<half.navigation.liveCost&&half.navigation.liveCost<shut.navigation.liveCost);
check('actual sight range differs in the intended order',left.sight.range>half.sight.range&&half.sight.range>shut.sight.range);
check('18 m target survives half sight but not full diversion',JSON.stringify(results.map(r=>r.sight.perception[0].canSee))==='[true,true,false]');
check('20 m target is lost by half and full diversion',JSON.stringify(results.map(r=>r.sight.perception[1].canSee))==='[true,false,false]');
check('stationary exposure burden differs in the intended order',left.exposure.finalHp>half.exposure.finalHp&&half.exposure.finalHp>shut.exposure.finalHp,results.map(r=>[r.choice,r.exposure.finalHp,r.exposure.elapsedSeconds]));
for(const [path,hash]of Object.entries(sourceHashes))if(sha(fs.readFileSync(new URL(path,ROOT)))!==hash)throw new Error('Source changed during probe: '+path);
const result={checkedAt:new Date().toISOString(),baseCommit:execFileSync('git',['rev-parse','HEAD'],{cwd:ROOT,encoding:'utf8'}).trim(),sourceHashes,
  fixture:{path:'cpu-city-fixture-v2.mjs',sha256:sha(fs.readFileSync(new URL('./cpu-city-fixture-v2.mjs',import.meta.url))),scope:'Full actual City build; Canvas/text/surface appearance substitutions only; no browser/GPU.'},
  scope:'Small half-diversion fix: three fresh actual Cities, matching actual hook/fixed updates, exact source registration, live navigation, native Enemy perception and stationary Actor/Lungs exposure. Not a reference/blind comparison or an E-13 verdict.',results,checks};
fs.writeFileSync(new URL('./gas-half-consequence-cpu-evidence.json',import.meta.url),JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify({sourceHashes,checks:checks.filter(c=>!c.passed),passed:checks.filter(c=>c.passed).length,total:checks.length,
  results:results.map(r=>({choice:r.choice,yardPpm:r.yardPpm,navCost:r.navigation.liveCost,route:r.navigation.plannedRoute.path,range:r.sight.range,canSee:r.sight.perception.map(x=>x.canSee),exposure:r.exposure}))}));
if(checks.some(c=>!c.passed))process.exitCode=1;
