import fs from 'node:fs';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {validateFindings} from './survival/.kit/lib/plan/findings.mjs';
const root='/workspace/scratch/0b7ad82bafe7';
const read=n=>JSON.parse(fs.readFileSync(root+'/'+n));
const review=read('trench-perception-r2-review-draft.json');
const refuter=read('trench-perception-r2-refuter-probe-01.json');
const routeProbe=read('trench-perception-r2-refuter-probe-02.json');
const finale=read('trench-perception-r2-probe-03.json');
for(const report of [refuter,routeProbe,finale]){
  if(!report.sourceUnchanged||report.swallowedErrors.length||report.checks.some(c=>c.status!=='completed'))throw Error('Evidence failure');
  for(const p of ['src/game/director.js','src/game/ai.js','src/world/city.js','src/world/props.js'])if(report.sourceHashes[p]!==review.sourceHashes[p])throw Error('Pin differs '+p);
}
const route=routeProbe.checks[0].result.routes[0];
const reentry=refuter.checks.find(c=>c.name==='prepoll-reentry-real-timer-and-previous-control').result;
review.createdAt=new Date().toISOString();
review.baseRepositoryRevision='6efddea15a8e7b59ffc598180a94bc65033b2934';
review.findings=review.findings.filter(f=>f.id!=='R2-HEAP-CLIMB');
review.findings[0].refutationStatus='survived separate refutation with actual unmodified poll timer; ordinary repeated applySave negative control remains constant';
review.findings[0].evidence.push('trench-perception-r2-refuter-probe-01.mjs','trench-perception-r2-refuter-probe-01.json');
review.findings[0].fix+=' The number to inspect is max(counts)-min(counts), required 0, rather than the current 6. Counts can be read with node -p "JSON.stringify(require(\'./trench-perception-r2-refuter-probe-01.json\').checks[0].result.cases.map(c=>({label:c.label,counts:c.counts})))"; use a new evidence filename for a repaired run.';
review.rejectedFindings=[{
  id:'R2-HEAP-CLIMB',
  outcome:'Removed after separate refutation',
  originalClaim:'The failed direct approaches were treated as evidence that the repaired heap had not met the playable climb target.',
  correction:'Three oblique input routes reach actual grounded height 2.6 m through two auto-vaults. One route repeated with the actual trench quest also sets trench_slipped and trench_passed and advances to step 2. The broad repair-unmet implication is false; direct-route failures remain bounded observations.',
  evidence:['trench-perception-r2-refuter-probe-01.json','trench-perception-r2-refuter-probe-02.json']
}];
review.verifiedControls.push(
  'Separate refuter reproduced a real Warden damage hit without handing over the order, then reproduced zero Warden damage for eight seconds when the imminent attack was canceled through normal interaction. This is a working damage-path negative control.',
  'Normal cinderline final dialogue stays free of Warden damage for eight seconds, then actual callbacks and the available leave choice produce CINEMATIC with a completed save; eight further seconds also have zero Warden damage. Fully passed step-2 save/applySave, repeated active-step entry and repeated spawn hook retain zero enemies.',
  'Actual quest oblique heap route starts on supported pitwall y=0.9 at (96,16), reaches grounded (90.015291,2.6,16.415701) in 2.383333 seconds using only real Player input and two auto-vaults, and advances step 1 to step 2 with trench_slipped/trench_passed and no trench_talked. The fixture only establishes this final traversal segment, not a complete approach from an earlier chapter.'
);
review.observations=review.observations.filter(o=>o.id!=='R2-AFTER-FINALE');
review.observations[0].detail+=' Source control also shows office chapter-3 progression requires collecting trenchOrder, which is a key item. No full normal no-order journey has been demonstrated.';
review.observations.push({id:'R2-HEAP-DIRECT-APPROACHES',status:'bounded observation, not retained defect',detail:'Six center-directed approaches fail to climb. Real landing-overlap rejection explains the sampled direct directions, but oblique landings succeed, so no universal impassability or mandatory geometry redesign is claimed.',evidence:['trench-perception-r2-probe-01.json','trench-perception-r2-probe-02.json','trench-perception-r2-refuter-probe-01.json']});
review.successfulClimb={start:route.start,initial:route.initial,cameraYaw:0,targets:route.targets,input:'Normal magnitude-1 movement toward each target, no sprint; camera yaw stays zero in the fixture.',phaseTransitions:['Distance to first target below 0.14 m','Grounded, not vaulting, and y above 1.9 m'],elapsedSeconds:route.final.time,finalPosition:route.final.player.pos,groundedHeight:route.maxGroundedY,vaultTimes:route.vaults.map(v=>v.time),flags:route.final.flags,quest:route.final.quest,mode:route.final.mode,rawScript:'trench-perception-r2-refuter-probe-02.mjs',sampledTrace:'trench-perception-r2-refuter-probe-02.json',scope:route.scope};
review.refutation={agent:'/root/trench_perception_review/trench_refuter',independent:true,pinDependentWorkComplete:true,retained:['R2-REENTRY'],removed:['R2-HEAP-CLIMB'],reentryCounts:reentry.cases.map(c=>({label:c.label,ordinaryApplySave:c.applyCounts,reenterActiveSteps:c.counts,afterPollStep:c.afterPoll.quest.step})),rawEvidence:['trench-perception-r2-refuter-probe-01.mjs','trench-perception-r2-refuter-probe-01.json','trench-perception-r2-refuter-probe-01.log','trench-perception-r2-refuter-probe-02.mjs','trench-perception-r2-refuter-probe-02.json','trench-perception-r2-refuter-probe-02.log']};
review.rawArtifacts.push('trench-perception-r2-probe-03.mjs','trench-perception-r2-probe-03.json','trench-perception-r2-probe-03.log',...review.refutation.rawEvidence);
review.retention='All previous drafts, failed approaches, failed earlier-round probes and source-mismatch runs are retained. This final review removes the disproved implication rather than overwriting evidence.';
const knownOwners=new Set(execFileSync('git',['ls-files','src'],{cwd:root+'/survival',encoding:'utf8'}).trim().split('\n'));
const validation=validateFindings(review,{strict:true,knownOwners});
fs.writeFileSync(root+'/trench-perception-r2-review.json',JSON.stringify(review,null,2)+'\n');
fs.writeFileSync(root+'/trench-perception-r2-review-validation.json',JSON.stringify(validation,null,2)+'\n');
if(!validation.ok)throw Error(JSON.stringify(validation));
const names=fs.readdirSync(root).filter(n=>n.startsWith('trench-perception-r2-')&&n!=='trench-perception-r2-artifact-manifest.json');
const hash=b=>createHash('sha256').update(b).digest('hex');
const manifest={node:process.version,sourceHashes:review.sourceHashes,files:Object.fromEntries(names.map(n=>[n,hash(fs.readFileSync(root+'/'+n))]))};
fs.writeFileSync(root+'/trench-perception-r2-artifact-manifest.json',JSON.stringify(manifest,null,2)+'\n');
console.log(JSON.stringify({validation,retained:review.findings.map(f=>f.id),removed:review.rejectedFindings.map(f=>f.id),artifacts:names.length}));
