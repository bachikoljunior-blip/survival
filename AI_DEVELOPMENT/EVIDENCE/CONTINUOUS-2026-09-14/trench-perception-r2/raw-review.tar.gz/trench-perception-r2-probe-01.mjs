import fs from 'node:fs';
import assert from 'node:assert/strict';
import {root,pinSources,makeGame,snap,tick,place,enterTrench,inputFixture,observeDamage,Storage,Enemy,MODE,swallowedErrors} from './trench-perception-r2-fixture-v1.mjs';
const sourceHashes=pinSources(),checks=[];
const report={round:2,createdAt:new Date().toISOString(),sourceHashes,scope:'Actual CPU input/Game/Actor/AI/Combat/Director/City. Appearance and output-device stubs as declared in fixture-v3. No perception stubs or browser/render/audio-quality claims.',checks};
async function check(name,fn){const entry={name,status:'running',result:{}};checks.push(entry);try{await fn(entry.result);entry.status='completed';console.log(name+': completed');}catch(e){entry.status='probe-error';entry.error=String(e);entry.stack=e.stack;console.log(name+': '+e.stack);}}
function full(g){return {...snap(g),enemies:g.actors.filter(a=>a instanceof Enemy).map(e=>({id:e.id,kind:e.kind,faction:e.faction,pos:e.pos.toArray(),hp:e.hp,dead:e.dead,aggro:e.aggro,awareness:e.awareness,target:e.target?.id??null,state:e.aiState,attack:e.attack?{name:e.attack.name,t:e.attack.t,windup:e.attack.windup}:null,comboWindow:e.comboWindow,comboNext:e.comboNext,guarding:e.guarding,move:{...e.moveInput},vel:e.vel.toArray(),path:e.path,gas:e.localPpm(g.gas)})),tokens:[...g.combat.attackTokens],lock:g.camera.lockTarget?.id??null};}

await check('committed-attack-order-same-tick-and-reading',r=>{
  const g=makeGame(),input=inputFixture(g);enterTrench(g);place(g,77,17.8);g.state.give('trenchOrder',1);
  const damage=observeDamage(g);let committed=null;
  for(let i=0;i<600&&!committed;i++){
    g.fixedUpdate(1/60);
    committed=g.director._raidActive.group.find(e=>e.attack&&e.attack.t>=e.attack.windup-1/30&&e.attack.t<e.attack.windup);
  }
  r.before=full(g);assert.ok(committed,'Need an actual AI-committed attack just before its active frame');
  r.committedId=committed.id;assert.ok(g.combat.attackTokens.has(committed.id));
  g.camera.lockTarget=committed; // Explicit lock bookkeeping setup only.
  const it=g.city.interactions.find(i=>i.id==='trench_talk');g.player.yaw=g.player.targetYaw=Math.atan2(g.player.pos.x-it.x,g.player.pos.z-it.z);g._updateInteractTarget();
  assert.equal(g.player.interactTarget.id,'trench_talk');const acceptedAt=g.time+1/60;
  input.pending.add('interact');g.fixedUpdate(1/60);r.accepted=full(g);r.acceptedAt=acceptedAt;
  assert.equal(g.director._raidActive,null);assert.equal(g.camera.lockTarget,null);assert.equal(g.combat.attackTokens.size,0);
  assert.ok(g.actors.filter(a=>a instanceof Enemy&&!a.dead).every(e=>e.faction==='neutral'&&!e.aggro&&!e.attack&&e.target===null));
  r.trace=tick(g,8);r.afterReading=full(g);r.damage=damage;r.events=g.events;
  r.postAcceptanceHostileHits=damage.filter(d=>d.time>=acceptedAt&&d.source?.kind==='warden'&&d.hpAfter<d.hpBefore);
  assert.equal(r.postAcceptanceHostileHits.length,0);
  assert.ok(g.actors.filter(a=>a instanceof Enemy&&a.kind==='warden').every(e=>!e.aggro&&e.aiState==='idle'&&!e.attack));
});

await check('heap-approaches-actual-player',r=>{
  r.approaches=[];
  for(const start of [[96,16],[84,16],[90,11],[90,21],[95,21],[85,21]]){
    const g=makeGame(),input=inputFixture(g);g.state.chapter=5;g.director._raisePlant();const initial=place(g,...start);
    const trace=[];let maxY=g.player.pos.y,maxGroundedY=-Infinity;
    for(let i=0;i<720;i++){
      const dx=90-g.player.pos.x,dz=16-g.player.pos.z,d=Math.hypot(dx,dz);
      input.inp.move=d>.15?{x:dx/d,y:dz/d,mag:1}:{x:0,y:0,mag:0};
      g.fixedUpdate(1/60);maxY=Math.max(maxY,g.player.pos.y);if(g.player.grounded&&!g.player._vault)maxGroundedY=Math.max(maxGroundedY,g.player.pos.y);
      if(i%6===0||g.player.state==='vault')trace.push({time:g.time,pos:g.player.pos.toArray(),grounded:g.player.grounded,state:g.player.state,vault:!!g.player._vault,hitWall:g.player.lastMove?.hitWall,hp:g.player.hp});
      if(g.player.grounded&&!g.player._vault&&g.player.pos.y>2.4)break;
    }
    r.approaches.push({start,initial,maxY,maxGroundedY,final:full(g),trace,events:g.events.filter(e=>e.name==='actor:vault'),scope:'Only initial supported placement. Thereafter actual Game input/Player movement/auto-vault/collision/gas run; no Y assignment, obstacle edits, or player motion stubs.'});
  }
  r.successCount=r.approaches.filter(a=>a.maxGroundedY>2.4).length;
});

await check('order-item-negative-control',r=>{
  const g=makeGame(),input=inputFixture(g);enterTrench(g);place(g,77,17.8);assert.equal(g.state.countItem('trenchOrder'),0);
  const it=g.city.interactions.find(i=>i.id==='trench_talk');g.player.yaw=g.player.targetYaw=Math.atan2(g.player.pos.x-it.x,g.player.pos.z-it.z);g._updateInteractTarget();
  r.selected=g.player.interactTarget?.id;r.requiresItem=it.requiresItem;r.before=full(g);
  input.pending.add('interact');g.fixedUpdate(1/60);r.after=full(g);r.itemCount=g.state.countItem('trenchOrder');r.events=g.events;
});

report.swallowedErrors=swallowedErrors;report.finalSourceHashes=pinSources();report.sourceUnchanged=JSON.stringify(sourceHashes)===JSON.stringify(report.finalSourceHashes);
fs.writeFileSync(root+'/trench-perception-r2-probe-01.json',JSON.stringify(report,(_k,v)=>v&&typeof v==='object'&&v.pos?.isVector3&&Number.isInteger(v.id)?{actor:v.id,kind:v.kind??v.faction}:v,2)+'\n');
console.log(JSON.stringify({probeErrors:checks.filter(c=>c.status==='probe-error').length,swallowedErrors,sourceUnchanged:report.sourceUnchanged}));
if(checks.some(c=>c.status==='probe-error')||swallowedErrors.length||!report.sourceUnchanged)process.exitCode=1;
