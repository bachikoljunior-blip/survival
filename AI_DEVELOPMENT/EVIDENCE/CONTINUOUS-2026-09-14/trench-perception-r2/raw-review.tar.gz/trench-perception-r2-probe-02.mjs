import fs from 'node:fs';
import {execFileSync} from 'node:child_process';
import assert from 'node:assert/strict';
import {root,repo,baseline,sha,pinSources,makeGame,snap,tick,place,enterTrench,inputFixture,observeDamage,Storage,Enemy,MODE,swallowedErrors} from './trench-perception-r2-fixture-v1.mjs';
import {ChunkBuilder} from './survival/src/world/geom.js';
import * as Props from './survival/src/world/props.js';
import {Rng} from './survival/src/core/rng.js';
const sourceHashes=pinSources(),checks=[];
const report={round:2,createdAt:new Date().toISOString(),sourceHashes,scope:'Actual CPU production methods. Explicit supported setup positions and input devices; no perception or Player movement stubs. Some lifecycle checks omit the active finale quest to isolate normal return-to-play/autosave behavior; they do not claim a 90-second post-ending game flow.',checks};
async function check(name,fn){const entry={name,status:'running',result:{}};checks.push(entry);try{await fn(entry.result);entry.status='completed';console.log(name+': completed');}catch(e){entry.status='probe-error';entry.error=String(e);entry.stack=e.stack;console.log(name+': '+e.stack);}}
async function loadSource(text,path){const transformed=text.replace(/from (['"])([^'"]+)\1/g,(_m,_q,p)=>'from '+JSON.stringify(p==='three'?new URL('./survival/node_modules/three/build/three.module.js',import.meta.url).href:new URL(p,new URL('./survival/'+path,import.meta.url)).href));return import('data:text/javascript;base64,'+Buffer.from(transformed).toString('base64'));}
const factionSnapshot=g=>g.actors.filter(a=>a instanceof Enemy).map(a=>({id:a.id,kind:a.kind,faction:a.faction,aggro:a.aggro,awareness:a.awareness,state:a.aiState,target:a.target?.id??null,attack:a.attack?.name??null,pos:a.pos.toArray(),hp:a.hp,dead:a.dead,sat:a.lungs.sat,ppm:a.localPpm(g.gas)}));
function accept(g,input){const it=g.city.interactions.find(i=>i.id==='trench_talk');g.player.yaw=g.player.targetYaw=Math.atan2(g.player.pos.x-it.x,g.player.pos.z-it.z);g._updateInteractTarget();assert.equal(g.player.interactTarget.id,it.id);input.pending.add('interact');g.fixedUpdate(1/60);}

await check('legacy-rubble-default-geometry-and-rng',async r=>{
  const oldText=execFileSync('git',['show',baseline+':src/world/props.js'],{cwd:repo,encoding:'utf8'});r.baselinePropsSha256=sha(oldText);
  const old=await loadSource(oldText,'src/world/props.js');r.cases=[];
  for(const [x,z,radius,height,seed] of [[0,0,3,1.5,'a'],[90,16,8,2.6,'plant'],[-94,-66,1.2,.5,'scatter']]){
    const a=new ChunkBuilder(),b=new ChunkBuilder(),ra=new Rng(seed),rb=new Rng(seed);
    old.rubblePile(a,x,z,radius,height,ra);Props.rubblePile(b,x,z,radius,height,rb);
    const arrays=c=>[...c.groups].map(([k,v])=>({key:k,pos:v.pos,nrm:v.nrm,uv:v.uv,col:v.col,idx:v.idx,shadowFaces:v.shadowFaces}));
    assert.deepEqual(arrays(a),arrays(b));const next=[ra.f(),rb.f()];assert.equal(...next);
    r.cases.push({x,z,radius,height,seed,stats:a.stats,geometryHash:sha(JSON.stringify(arrays(a))),sameArrays:true,nextRandom:next});
  }
});

await check('vault-failure-real-obstacle-landing',r=>{
  r.approaches=[];
  for(const start of [[90,21],[96,16]]){
    const g=makeGame(),input=inputFixture(g);g.director._raisePlant();place(g,...start);const attempts=[],original=g.player.tryVault;
    g.player.tryVault=function(){
      const fx=-Math.sin(this.yaw),fz=-Math.cos(this.yaw),ox=this.pos.x+fx*(this.radius+.22),oz=this.pos.z+fz*(this.radius+.22);
      const obstacle=this.world.overlaps(ox,this.pos.y+.1,oz,.24,.5);
      const lx=this.pos.x+fx*(this.radius+1.15),lz=this.pos.z+fz*(this.radius+1.15);
      const land=obstacle?this.world.groundUnder(lx,lz,this.radius*.8,obstacle.y1+.4,2.4):null;
      const blocked=land?this.world.overlaps(lx,land.y+.15,lz,this.radius*.85,this.height-.3):null;
      const out=original.call(this);
      if(attempts.length<16)attempts.push({time:g.time,pos:this.pos.toArray(),obstacle:obstacle?{tag:obstacle.tag,top:obstacle.y1}:null,landing:land?{x:lx,z:lz,y:land.y,tag:land.box.tag}:null,landingBlockedBy:blocked?{tag:blocked.tag,top:blocked.y1}:null,result:out});
      return out;
    };
    for(let i=0;i<360;i++){const dx=90-g.player.pos.x,dz=16-g.player.pos.z,d=Math.hypot(dx,dz);input.inp.move={x:dx/d,y:dz/d,mag:1};g.fixedUpdate(1/60);}
    r.approaches.push({start,attempts,final:snap(g)});
  }
});

await check('neutral-line-excluded-from-real-warden-call',r=>{
  const g=makeGame(),input=inputFixture(g);enterTrench(g);place(g,77,17.8);g.state.give('trenchOrder',1);const line=[...g.director._raidActive.group];accept(g,input);
  const source=g.spawnEnemy('warden',76,22),hostile=g.spawnEnemy('warden',80,24),ally=g.spawnEnemy('warden',81,24,{faction:g.player.faction});
  const calls=[],original=g.ai._alertNearby;g.ai._alertNearby=function(game,from,radius){const before=factionSnapshot(g);const result=original.call(this,game,from,radius);calls.push({time:g.time,source:from.id,radius,before,after:factionSnapshot(g)});return result;};
  r.before=factionSnapshot(g);r.trace=tick(g,2);r.after=factionSnapshot(g);r.calls=calls;r.ids={line:line.map(e=>e.id),source:source.id,hostile:hostile.id,ally:ally.id};
  assert.ok(calls.some(c=>c.source===source.id));assert.ok(hostile.aggro);assert.equal(ally.aggro,false);
  assert.ok(line.every(e=>!e.aggro&&e.faction==='neutral'&&e.target===null&&!e.attack));
  const scav=line.find(e=>e.kind==='scav');assert.equal(scav.aiState,'flee');
});

await check('accepted-prepoll-save-repeated-reentry',async r=>{
  const previousText=fs.readFileSync(root+'/trench-perception-reviewed-director-current.js','utf8');const previous=(await loadSource(previousText,'src/game/director.js')).Director;r.previousDirectorSha256=sha(previousText);r.cases=[];
  for(const [label,D] of [['current',undefined],['previous-reviewed',previous]]){
    const g=makeGame(D),input=inputFixture(g);enterTrench(g);place(g,77,17.8);g.state.give('trenchOrder',1);g.director._reachTimer=.25;
    accept(g,input);const before=snap(g);assert.equal(g.state.quests.get('cinderline').step,1);assert.ok(g.state.has('trench_talked'));assert.equal(g.state.has('trench_passed'),false);
    assert.equal(g.director.save(true),true);const save=Storage.load();assert.equal(g.director.applySave(save),true);const once=factionSnapshot(g);
    g.quests.reenterActiveSteps();const twice=factionSnapshot(g);g.quests.reenterActiveSteps();const thrice=factionSnapshot(g);
    r.cases.push({label,before,save,once,twice,thrice,counts:[once.length,twice.length,thrice.length],interactionCount:g.city.interactions.filter(i=>i.id==='trench_talk').length});
  }
});

await check('read-completion-and-90-second-autosave-lifecycle',r=>{
  const g=makeGame(),input=inputFixture(g);g.state.chapter=5;g.director._raisePlant();g.director.ctx.hooks.spawnTrenchLine();place(g,77,17.8);g.state.give('trenchOrder',1);
  const damage=observeDamage(g);accept(g,input);r.accepted=snap(g);let advances=0;
  while(g.mode===MODE.DIALOGUE&&g.dialogueUI.onAdvance&&advances<12){g.dialogueUI.onAdvance();g.fixedUpdate(1/60);advances++;}
  r.afterRead=snap(g);r.advances=advances;assert.equal(g.mode,MODE.PLAY);assert.equal(g.director._raidActive,null);
  r.postReadTrace=tick(g,8);assert.equal(damage.filter(d=>d.source?.kind==='warden'&&d.hpAfter<d.hpBefore).length,0);
  g.director._checkTrenchPassed(); // No finale quest in this lifecycle control.
  place(g,40,55);const saveCalls=[],original=g.director.save;g.director.save=function(...args){const out=original.apply(this,args);saveCalls.push({time:g.time,mode:g.mode,raid:!!this._raidActive,result:out});return out;};
  g.director._autosaveTimer=90;const start=g.time;tick(g,90.1,{sampleEvery:15});
  r.saveCalls=saveCalls;r.elapsed=g.time-start;r.final=snap(g);r.saved=Storage.load();r.damage=damage;
  assert.ok(saveCalls.some(c=>c.result&&c.mode===MODE.PLAY&&!c.raid&&Math.abs(c.time-start-90)<.04));
  const n=g.actors.filter(a=>a instanceof Enemy).length;g.director.ctx.hooks.spawnTrenchLine();g.director.ctx.hooks.spawnTrenchLine();assert.equal(g.actors.filter(a=>a instanceof Enemy).length,n);
  r.scope='Actual topic read-to-end and normal 90-second autosave policy, with finale quest omitted so the control can stay in PLAY. A single explicit relocation after the 8-second post-read interval avoids unrelated gas death during the timer check. This is not evidence of a 90-second normal post-ending PLAY scene.';
});

await check('runtime-removal-restores-collision',r=>{
  const g=makeGame();const support=()=>g.world.groundUnder(90,16,.34,6,12)?.y;const before={boxes:g.world.boxes.length,support:support(),lights:g.city.lightMarkers.length};g.director._raisePlant();
  const group=g.city._runtimeGroups.get('trenchplant'),ids=new Set(group.userData.boxes.map(b=>b.id));r.before=before;r.raised={boxes:g.world.boxes.length,support:support(),lights:g.city.lightMarkers.length,added:ids.size};
  assert.ok(r.raised.support>2.4);assert.equal(g.city.removeRuntimeProps('trenchplant'),true);
  const query=[];g.world.query(90,16,35,query);r.removed={boxes:g.world.boxes.length,support:support(),lights:g.city.lightMarkers.length,remainingIds:query.filter(b=>ids.has(b.id)).map(b=>b.id),inMap:g.city._runtimeGroups.has('trenchplant')};
  assert.equal(r.removed.boxes,before.boxes);assert.equal(r.removed.support,before.support);assert.equal(r.removed.lights,before.lights);assert.equal(r.removed.remainingIds.length,0);assert.equal(r.removed.inMap,false);
});

report.swallowedErrors=swallowedErrors;report.finalSourceHashes=pinSources();report.sourceUnchanged=JSON.stringify(sourceHashes)===JSON.stringify(report.finalSourceHashes);
fs.writeFileSync(root+'/trench-perception-r2-probe-02.json',JSON.stringify(report,(_k,v)=>v&&typeof v==='object'&&v.pos?.isVector3&&Number.isInteger(v.id)?{actor:v.id,kind:v.kind??v.faction}:v,2)+'\n');
console.log(JSON.stringify({probeErrors:checks.filter(c=>c.status==='probe-error').length,swallowedErrors,sourceUnchanged:report.sourceUnchanged}));
if(checks.some(c=>c.status==='probe-error')||swallowedErrors.length||!report.sourceUnchanged)process.exitCode=1;
