import fs from 'node:fs';
import assert from 'node:assert/strict';
import {root,pinSources,makeGame,snap,tick,place,enterTrench,inputFixture,observeDamage,Storage,Enemy,MODE,swallowedErrors} from './trench-perception-r2-fixture-v1.mjs';
const sourceHashes=pinSources(),checks=[];
const report={round:2,createdAt:new Date().toISOString(),sourceHashes,scope:'Normal cinderline input handoff, final dialogue callbacks, ending and actual step-2 save/reentry. CPU fixture output-device/appearance/UI acquisition stubs only. No perception, combat or player movement stubs.',checks};
async function check(name,fn){const entry={name,status:'running',result:{}};checks.push(entry);try{await fn(entry.result);entry.status='completed';console.log(name+': completed');}catch(e){entry.status='probe-error';entry.error=String(e);entry.stack=e.stack;console.log(name+': '+e.stack);}}
function accept(g,input){const it=g.city.interactions.find(i=>i.id==='trench_talk');g.player.yaw=g.player.targetYaw=Math.atan2(g.player.pos.x-it.x,g.player.pos.z-it.z);g._updateInteractTarget();assert.equal(g.player.interactTarget?.id,'trench_talk');input.pending.add('interact');g.fixedUpdate(1/60);}
function enemies(g){return g.actors.filter(a=>a instanceof Enemy).map(e=>({id:e.id,kind:e.kind,faction:e.faction,state:e.aiState,target:e.target?.id??null,aggro:e.aggro,attack:!!e.attack}));}

await check('normal-final-dialogue-ending-and-passed-save-reentry',async r=>{
  const g=makeGame(),input=inputFixture(g);enterTrench(g);place(g,77,17.8);g.state.give('trenchOrder',1);const damage=observeDamage(g);
  accept(g,input);r.accepted=snap(g);r.readTrace=tick(g,8);r.afterReadWait=snap(g);r.lineAfterRead=enemies(g);
  assert.equal(g.state.quests.get('cinderline').step,2);assert.equal(g.director.dialogue.convo.id,'final');assert.equal(g.mode,MODE.DIALOGUE);
  assert.equal(g.director.save(true),true);const step2save=Storage.load();r.step2Save=step2save;
  const savedGame=makeGame(),savedInput=inputFixture(savedGame);assert.equal(savedGame.director.applySave(step2save),true);
  r.loadedStep2={snapshot:snap(savedGame),enemies:enemies(savedGame),convo:savedGame.director.dialogue.convo?.id};
  savedGame.quests.reenterActiveSteps();savedGame.quests.reenterActiveSteps();savedGame.director.ctx.hooks.spawnTrenchLine();savedGame.director.ctx.hooks.spawnTrenchLine();
  r.reenteredStep2={snapshot:snap(savedGame),enemies:enemies(savedGame),convo:savedGame.director.dialogue.convo?.id};assert.equal(enemies(savedGame).length,0);
  r.flow=[];
  for(let n=0;n<32&&g.director.dialogue.active;n++){
    const runner=g.director.dialogue,choices=runner.choices();r.flow.push({time:g.time,mode:g.mode,node:runner.node?.id,choices:choices?.map(c=>({goto:c.goto,locked:c.locked,ci:c.ci}))??null});
    if(choices){const i=choices.findIndex(c=>c.goto==='e_leave'&&!c.locked);assert.ok(i>=0,'Expected authored available leave choice');g.dialogueUI.onChoose(i);}else g.dialogueUI.onAdvance();
    g.fixedUpdate(1/60);await Promise.resolve();
  }
  await Promise.resolve();await Promise.resolve();
  r.afterEnding={snapshot:snap(g),enemies:enemies(g),ending:g.state.ending,active:g.director.dialogue.active,completedSave:Storage.load()};
  assert.equal(g.mode,MODE.CINEMATIC);assert.equal(g.director.dialogue.active,false);assert.ok(r.afterEnding.completedSave.completed);
  r.afterEndingTrace=tick(g,8);r.final=snap(g);r.damage=damage;r.hostileHits=damage.filter(d=>d.source?.kind==='warden'&&d.hpAfter<d.hpBefore);r.events=g.events;
  assert.equal(r.hostileHits.length,0);assert.ok(enemies(g).every(e=>e.faction==='neutral'&&!e.aggro&&!e.attack&&!e.target));
  r.scope='Actual final dialogue and authored available leave choice produce CINEMATIC with completed save. Eight seconds before choosing and eight seconds after ending show zero Warden damage. UI callbacks are called directly, while DialogueRunner and Game mode/event/actor systems are real. No extended normal post-ending PLAY or rendered ending claim.';
});

report.swallowedErrors=swallowedErrors;report.finalSourceHashes=pinSources();report.sourceUnchanged=JSON.stringify(sourceHashes)===JSON.stringify(report.finalSourceHashes);
fs.writeFileSync(root+'/trench-perception-r2-probe-03.json',JSON.stringify(report,(_k,v)=>v&&typeof v==='object'&&v.pos?.isVector3&&Number.isInteger(v.id)?{actor:v.id,kind:v.kind??v.faction}:v,2)+'\n');
console.log(JSON.stringify({probeErrors:checks.filter(c=>c.status==='probe-error').length,swallowedErrors,sourceUnchanged:report.sourceUnchanged}));
if(checks.some(c=>c.status==='probe-error')||swallowedErrors.length||!report.sourceUnchanged)process.exitCode=1;
