// Round 2 separate hostile refutation. Fresh evidence; no product edits.
import fs from 'node:fs';
import {execFileSync} from 'node:child_process';
import assert from 'node:assert/strict';
import {root,repo,baseline,sha,pinSources,makeGame,snap,tick,place,enterTrench,inputFixture,observeDamage,Storage,Enemy,MODE,swallowedErrors} from './trench-perception-r2-fixture-v1.mjs';
import {ChunkBuilder} from './survival/src/world/geom.js';
import * as Props from './survival/src/world/props.js';
import {Rng} from './survival/src/core/rng.js';
const expected={
 'src/game/director.js':'0ca1755de0ca76bbe18b48cba1753ff2ba107aaea3b4ff7c89a2bc9d139ebd22',
 'src/game/ai.js':'dd3a37e8681a1d728c574db86e875be91807f7c75589494162e1f63cbe056597',
 'src/world/city.js':'81acdf64d65c087b9db556091896e4de0fb0fa4d60ed1d2d20e47d491c7efa4b',
 'src/world/props.js':'6044093c5bf49b66b6e8f90f012ad2bee0746bdb79bbddb7b338d6c98b8c5f38'
};
const sourceHashes=pinSources(),checks=[];
for(const [p,h] of Object.entries(expected))assert.equal(sourceHashes[p],h);
const report={createdAt:new Date().toISOString(),sourceHashes,expected,scope:'Independent source-labelled CPU refutation. Real City/Player/Actor movement and collision, Game input mapping, AI/perception, Combat/Director/QuestSystem/Storage. Appearance, input acquisition, UI, camera/post outputs and WebAudio device are fixture stubs. No browser, renderer, listening, product pass or blind comparison.',checks};
async function check(name,fn){const entry={name,status:'running',result:{}};checks.push(entry);try{await fn(entry.result);entry.status='completed';console.log(name+': completed');}catch(e){entry.status='probe-error';entry.error=String(e);entry.stack=e.stack;console.log(name+': '+e.stack);}}
async function loadSource(text,path){const transformed=text.replace(/from (['"])([^'"]+)\1/g,(_m,_q,p)=>'from '+JSON.stringify(p==='three'?new URL('./survival/node_modules/three/build/three.module.js',import.meta.url).href:new URL(p,new URL('./survival/'+path,import.meta.url)).href));return import('data:text/javascript;base64,'+Buffer.from(transformed).toString('base64'));}
const factionSnapshot=g=>g.actors.filter(a=>a instanceof Enemy).map(a=>({id:a.id,kind:a.kind,faction:a.faction,aggro:a.aggro,awareness:a.awareness,state:a.aiState,target:a.target?.id??null,attack:a.attack?{name:a.attack.name,t:a.attack.t,windup:a.attack.windup}:null,comboNext:a.comboNext,comboWindow:a.comboWindow,pos:a.pos.toArray(),dead:a.dead,ppm:a.localPpm(g.gas)}));
const full=g=>({...snap(g),enemies:factionSnapshot(g),tokens:[...g.combat.attackTokens],lock:g.camera.lockTarget?.id??null,reachTimer:g.director._reachTimer});
function accept(g,input){const it=g.city.interactions.find(i=>i.id==='trench_talk');g.player.yaw=g.player.targetYaw=Math.atan2(g.player.pos.x-it.x,g.player.pos.z-it.z);g._updateInteractTarget();assert.equal(g.player.interactTarget.id,it.id);assert.equal(g.state.countItem('trenchOrder'),1);input.pending.add('interact');g.fixedUpdate(1/60);}
const briefBox=b=>b?{id:b.id,tag:b.tag,x:b.x,z:b.z,hw:b.hw,hd:b.hd,y0:b.y0,y1:b.y1}:null;

await check('prepoll-reentry-real-timer-and-previous-control',async r=>{
 const previousText=fs.readFileSync(root+'/trench-perception-reviewed-director-current.js','utf8');
 r.previousDirectorSha256=sha(previousText);assert.equal(r.previousDirectorSha256,'eb347f5eed42b31ed5db61dd8d3e3a6d8ff9ea400fe874e356fe78cde6aaef61');
 const previous=(await loadSource(previousText,'src/game/director.js')).Director;r.cases=[];
 for(const [label,D] of [['current',undefined],['previous-reviewed',previous]]){
  const g=makeGame(D),input=inputFixture(g);enterTrench(g);
  g.fixedUpdate(1/60); // Let the actual Director reset its normal poll timer.
  place(g,77,17.8);g.state.give('trenchOrder',1);r.timerBeforeInteraction=g.director._reachTimer;
  accept(g,input);const accepted=full(g);
  assert.equal(accepted.quest.step,1);assert.ok(g.state.has('trench_talked'));assert.equal(g.state.has('trench_passed'),false);
  assert.equal(g.director.save(true),true);const save=Storage.load();assert.ok(save);
  const applyCounts=[];for(let i=0;i<3;i++){assert.equal(g.director.applySave(save),true);applyCounts.push(factionSnapshot(g).length);}
  assert.deepEqual(applyCounts,[3,3,3]);const once=full(g);
  g.quests.reenterActiveSteps();const twice=full(g);g.quests.reenterActiveSteps();const thrice=full(g);
  const counts=[once.enemies.length,twice.enemies.length,thrice.enemies.length];
  assert.deepEqual(counts,label==='current'?[3,6,9]:[3,3,3]);
  tick(g,.35);const afterPoll=full(g);assert.equal(afterPoll.quest.step,2);assert.ok(g.state.has('trench_passed'));
  r.cases.push({label,accepted,save,applyCounts,once,twice,thrice,counts,afterPoll,interactionCount:g.city.interactions.filter(i=>i.id==='trench_talk').length,scope:'No timer mutation. Repeated reenterActiveSteps calls are explicit contract probes; ordinary applySave calls reset the world and remain constant.'});
 }
});

await check('heap-direct-and-oblique-input-refutation',r=>{
 r.routes=[];
 const routes=[
  {name:'east-direct',start:[96,16],targets:[[90,16]],seconds:6},
  {name:'south-direct',start:[90,21],targets:[[90,16]],seconds:6},
  {name:'east-oblique-a',start:[96,16],targets:[[92.75,15.3],[91.9,17.5],[90,16]],seconds:12},
  {name:'east-oblique-b',start:[96,16],targets:[[92.75,15.6],[91.95,17.25],[90,16]],seconds:12},
  {name:'east-oblique-c',start:[96,16],targets:[[92.7,15.55],[91.95,17.3],[90,16]],seconds:12}
 ];
 for(const route of routes){
  const g=makeGame(),input=inputFixture(g);g.state.chapter=5;g.director._raisePlant();const initial=place(g,...route.start),trace=[],attempts=[];
  assert.equal(initial.overlap,null);let phase=0,maxGroundedY=-Infinity;
  const original=g.player.tryVault;
  g.player.tryVault=function(){
   const pre={time:g.time,pos:this.pos.toArray(),grounded:this.grounded,state:this.state,move:{...this.moveInput},yaw:this.yaw,phase};
   const fx=-Math.sin(this.yaw),fz=-Math.cos(this.yaw);
   const obstacle=this.world.overlaps(this.pos.x+fx*(this.radius+.22),this.pos.y+.1,this.pos.z+fz*(this.radius+.22),.24,.5);
   const lx=this.pos.x+fx*(this.radius+1.15),lz=this.pos.z+fz*(this.radius+1.15);
   const land=obstacle?this.world.groundUnder(lx,lz,this.radius*.8,obstacle.y1+.4,2.4):null;
   const blocked=land?this.world.overlaps(lx,land.y+.15,lz,this.radius*.85,this.height-.3):null;
   const result=original.call(this);
   if(attempts.length<40)attempts.push({...pre,obstacle:briefBox(obstacle),landing:land?{x:lx,z:lz,y:land.y,box:briefBox(land.box)}:null,landingBlockedBy:briefBox(blocked),result});return result;
  };
  for(let i=0;i<route.seconds*60;i++){
   if(route.targets.length>1&&phase===1&&g.player.grounded&&!g.player._vault&&g.player.pos.y>1.9)phase=2;
   let target=route.targets[phase],dx=target[0]-g.player.pos.x,dz=target[1]-g.player.pos.z,d=Math.hypot(dx,dz);
   if(phase===0&&route.targets.length>1&&d<.14){phase=1;target=route.targets[phase];dx=target[0]-g.player.pos.x;dz=target[1]-g.player.pos.z;d=Math.hypot(dx,dz);}
   input.inp.move=d>.08?{x:dx/d,y:dz/d,mag:1}:{x:0,y:0,mag:0};g.fixedUpdate(1/60);
   if(g.player.grounded&&!g.player._vault)maxGroundedY=Math.max(maxGroundedY,g.player.pos.y);
   if(i%3===0||g.player._vault)trace.push({time:g.time,pos:g.player.pos.toArray(),grounded:g.player.grounded,state:g.player.state,vault:!!g.player._vault,phase,input:{...input.inp.move},hp:g.player.hp});
   if(g.player.grounded&&!g.player._vault&&g.player.pos.y>2.4)break;
  }
  r.routes.push({...route,initial,maxGroundedY,trace,attempts,final:full(g),vaults:g.events.filter(e=>e.name==='actor:vault'),scope:'One supported setup. All later displacement and Y changes come from actual Player physics/vaulting driven only by normal Game input. Waypoint switches use position or grounded height feedback; no obstacle/AI edits and no later position assignment.'});
 }
 r.successCount=r.routes.filter(v=>v.maxGroundedY>2.4).length;
});

await check('committed-attack-cancel-and-natural-hit-control',r=>{
 r.cases=[];
 for(const doAccept of [false,true]){
  const g=makeGame(),input=inputFixture(g);enterTrench(g);place(g,77,17.8);g.state.give('trenchOrder',1);const damage=observeDamage(g);let committed=null;
  for(let i=0;i<600&&!committed;i++){g.fixedUpdate(1/60);committed=g.director._raidActive.group.find(e=>e.attack&&e.attack.t>=e.attack.windup-1/30&&e.attack.t<e.attack.windup);}
  assert.ok(committed);const before=full(g);assert.ok(g.combat.attackTokens.has(committed.id));g.camera.lockTarget=committed;
  const at=g.time+1/60;if(doAccept)accept(g,input);else g.fixedUpdate(1/60);
  const afterTick=full(g),trace=tick(g,doAccept?8:1.2),hits=damage.filter(d=>d.time>=at&&d.source?.kind==='warden'&&d.hpAfter<d.hpBefore);
  if(doAccept){assert.equal(hits.length,0);assert.equal(g.director._raidActive,null);assert.equal(g.camera.lockTarget,null);assert.equal(g.combat.attackTokens.size,0);assert.ok(factionSnapshot(g).every(e=>e.faction==='neutral'&&!e.aggro&&e.target===null&&!e.attack));}
  else assert.ok(hits.length>0,'Negative control must reach genuine attack damage without acceptance');
  r.cases.push({doAccept,before,at,afterTick,trace,hits,damage,after:full(g)});
 }
});

await check('neutral-reinforcement-exclusion-with-hostile-positive',r=>{
 const g=makeGame(),input=inputFixture(g);enterTrench(g);place(g,77,17.8);g.state.give('trenchOrder',1);const line=[...g.director._raidActive.group];accept(g,input);
 const source=g.spawnEnemy('warden',76,22),hostile=g.spawnEnemy('warden',80,24),ally=g.spawnEnemy('warden',81,24,{faction:g.player.faction});
 const calls=[],original=g.ai._alertNearby;g.ai._alertNearby=function(game,from,radius){const before=factionSnapshot(g);const result=original.call(this,game,from,radius);calls.push({time:g.time,source:from.id,radius,before,after:factionSnapshot(g)});return result;};
 r.before=factionSnapshot(g);r.trace=tick(g,2);r.calls=calls;r.after=factionSnapshot(g);r.ids={line:line.map(e=>e.id),source:source.id,hostile:hostile.id,ally:ally.id};
 assert.ok(calls.some(c=>c.source===source.id));assert.ok(hostile.aggro);assert.equal(ally.aggro,false);assert.ok(line.every(e=>e.faction==='neutral'&&!e.aggro&&e.target===null&&!e.attack));assert.equal(line.find(e=>e.kind==='scav').aiState,'flee');
});

await check('legacy-rubble-identity-and-runtime-cleanup',async r=>{
 const text=execFileSync('git',['show',baseline+':src/world/props.js'],{cwd:repo,encoding:'utf8'}),old=await loadSource(text,'src/world/props.js');r.baselinePropsSha256=sha(text);r.legacy=[];
 for(const [x,z,radius,height,seed] of [[0,0,3,1.5,'refuter'],[90,16,8,2.6,'plant']]){
  const a=new ChunkBuilder(),b=new ChunkBuilder(),ra=new Rng(seed),rb=new Rng(seed);old.rubblePile(a,x,z,radius,height,ra);Props.rubblePile(b,x,z,radius,height,rb);
  const arrays=c=>[...c.groups].map(([k,v])=>({key:k,pos:v.pos,nrm:v.nrm,uv:v.uv,col:v.col,idx:v.idx,shadowFaces:v.shadowFaces}));
  assert.deepEqual(arrays(a),arrays(b));const next=[ra.f(),rb.f()];assert.equal(next[0],next[1]);r.legacy.push({x,z,radius,height,seed,stats:a.stats,geometryHash:sha(JSON.stringify(arrays(a))),sameArrays:true,nextRandom:next});
 }
 const g=makeGame(),center=()=>g.world.groundUnder(90,16,.34,6,12)?.y;
 r.before={boxes:g.world.boxes.length,support:center(),lights:g.city.lightMarkers.length};g.director._raisePlant();const group=g.city._runtimeGroups.get('trenchplant'),ids=new Set(group.userData.boxes.map(b=>b.id));
 r.raised={boxes:g.world.boxes.length,support:center(),lights:g.city.lightMarkers.length,added:ids.size,children:group.children.length};assert.ok(r.raised.support>2.4);
 assert.equal(g.city.removeRuntimeProps('trenchplant'),true);const query=[];g.world.query(90,16,35,query);
 r.removed={boxes:g.world.boxes.length,support:center(),lights:g.city.lightMarkers.length,remainingIds:query.filter(b=>ids.has(b.id)).map(b=>b.id),inMap:g.city._runtimeGroups.has('trenchplant')};
 assert.equal(r.removed.boxes,r.before.boxes);assert.equal(r.removed.support,r.before.support);assert.equal(r.removed.lights,r.before.lights);assert.equal(r.removed.remainingIds.length,0);assert.equal(r.removed.inMap,false);
});

report.swallowedErrors=swallowedErrors;report.finalSourceHashes=pinSources();report.sourceUnchanged=JSON.stringify(sourceHashes)===JSON.stringify(report.finalSourceHashes);
fs.writeFileSync(root+'/trench-perception-r2-refuter-probe-01.json',JSON.stringify(report,(_k,v)=>v&&typeof v==='object'&&v.pos?.isVector3&&Number.isInteger(v.id)?{actor:v.id,kind:v.kind??v.faction}:v,2)+'\n');
console.log(JSON.stringify({probeErrors:checks.filter(c=>c.status==='probe-error').length,swallowedErrors,sourceUnchanged:report.sourceUnchanged}));
if(checks.some(c=>c.status==='probe-error')||swallowedErrors.length||!report.sourceUnchanged)process.exitCode=1;
