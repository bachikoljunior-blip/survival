// Actual UI, Director and Runner contracts on pinned source. No browser/socket.
import fs from 'node:fs';
import assert from 'node:assert/strict';
import {makeGame,MODE,swallowedErrors} from './dialogue-lifecycle-r3-repair-game-fixture.mjs';
import {DialogueUI} from './dialogue-lifecycle-r3-repair-source/src/ui/screens.js';
import {installDOM,tap} from './dialogue-lifecycle-r1-dom-fixture.mjs';
const out=new URL('./dialogue-lifecycle-r3-repair-contract-probe.json',import.meta.url);assert(!fs.existsSync(out));
const checks=[];
function fixture(){const root=installDOM(),g=makeGame();g.audio.voiceTick=()=>{};g.dialogueUI=new DialogueUI(g,root);return g;}
const summary=g=>({mode:g.mode,ui:{visible:g.dialogueUI.visible,full:g.dialogueUI.full,typing:g.dialogueUI.typing,pendingChoices:g.dialogueUI._pendingChoices,onAdvance:g.dialogueUI.onAdvance,onChoose:g.dialogueUI.onChoose},runner:{active:g.director.dialogue.active,convo:g.director.dialogue.convo?.id??null,node:g.director.dialogue.node?.id??null,history:[...g.director.dialogue.history],listenerKeys:[...g.director.dialogue._m.keys()]},flags:[...g.state.flags],pendingTrade:g.director._pendingTrade??false,talkNpc:g.director._talkNpc?.npcId??null});
function cleared(g){const s=summary(g);assert(!s.ui.visible);assert.equal(s.ui.full,'');assert.equal(s.ui.typing,false);assert.equal(s.ui.pendingChoices,null);assert.equal(s.ui.onAdvance,null);assert.equal(s.ui.onChoose,null);assert.equal(s.runner.active,false);assert.equal(s.runner.convo,null);assert.equal(s.runner.node,null);assert.deepEqual(s.runner.history,[]);assert.deepEqual(s.runner.listenerKeys,[]);return s;}
function run(name,f){try{checks.push({name,passed:true,...f()});}catch(error){checks.push({name,passed:false,error:String(error),stack:error.stack});}}
run('Authored vent decision still commits the chosen effect and ends through real UI callbacks',()=>{
 const g=fixture(),d=g.director;let ended=0;d.startConversation(d.conversations.vent_decision,null,()=>ended++);
 tap(g.dialogueUI.box);assert.equal(g.dialogueUI.choicesNode.children.length,3);tap(g.dialogueUI.choicesNode.children[2]);
 assert(g.state.has('vents_half'));assert(g.state.chose('vents','half'));
 const vent=g.gas.sources.find(s=>s.id==='vent_west_2');assert.equal(vent.active,false);assert.equal(ended,0);
 tap(g.dialogueUI.box);tap(g.dialogueUI.box);assert.equal(ended,1);assert.equal(g.mode,MODE.PLAY);assert.equal(g.dialogueUI.visible,false);assert.equal(g.dialogueUI.onAdvance,null);assert.equal(g.dialogueUI.onChoose,null);
 return {ended,choice:'half',effectFlag:g.state.has('vents_half'),vent2Active:vent.active,final:summary(g)};
});
run('Cancellation before a choice does not select it; delayed release on its removed node is inert while hidden',()=>{
 const g=fixture(),d=g.director;let ended=0;d.startConversation(d.conversations.vent_decision,null,()=>ended++);tap(g.dialogueUI.box);
 const oldChoice=g.dialogueUI.choicesNode.children[2];oldChoice.dispatch('pointerdown');const beforeFlags=[...g.state.flags];
 d.cancelDialogue();const afterCancel=cleared(g);oldChoice.dispatch('pointerup');tap(g.dialogueUI.box);g.dialogueUI.update(20);d.dialogue.advance();
 assert.equal(ended,0);assert.deepEqual([...g.state.flags],beforeFlags);assert.equal(g.state.has('vents_half'),false);assert.deepEqual(summary(g),afterCancel);
 return {ended,choiceNotCommitted:true,hiddenLateInputInert:true,final:afterCancel};
});
run('Diagnostic onEnd effects and callback distinguish cancel from ordinary completion',()=>{
 const g=fixture(),d=g.director;let ended=0;
 const control={id:'cpu_cancel_onend_control',start:'start',onEnd:[{flag:'cpu_cancel_finished'},{bump:['honest',7]}],nodes:{start:{speaker:'system',text:'Diagnostic lifecycle contract.',next:'end'}}};
 d.startConversation(control,null,()=>ended++);d.cancelDialogue();cleared(g);assert.equal(g.state.has('cpu_cancel_finished'),false);assert.equal(g.state.count('honest'),0);assert.equal(ended,0);d.dialogue.finish();assert.equal(ended,0);
 const cancelled={effect:g.state.has('cpu_cancel_finished'),counter:g.state.count('honest'),ended};
 d.startConversation(control,null,()=>ended++);tap(g.dialogueUI.box);tap(g.dialogueUI.box);assert(g.state.has('cpu_cancel_finished'));assert.equal(g.state.count('honest'),7);assert.equal(ended,1);d.dialogue.finish();assert.equal(g.state.count('honest'),7);assert.equal(ended,1);
 return {conversationIsDiagnostic:true,cancelled,completed:{effect:g.state.has('cpu_cancel_finished'),counter:g.state.count('honest'),ended}};
});
run('Cancellation preserves an already committed authored choice without calling the end callback',()=>{
 const g=fixture(),d=g.director;let ended=0;d.startConversation(d.conversations.vent_decision,null,()=>ended++);tap(g.dialogueUI.box);tap(g.dialogueUI.choicesNode.children[2]);assert(g.state.has('vents_half'));
 d.cancelDialogue();cleared(g);assert(g.state.has('vents_half'));assert(g.state.chose('vents','half'));assert.equal(g.gas.sources.find(s=>s.id==='vent_west_2').active,false);assert.equal(ended,0);
 return {effectPreserved:true,choicePreserved:true,ended};
});
run('Director cancellation stops actual talking NPC action and clears deferred trade',()=>{
 const g=fixture(),d=g.director,npc=d.spawnNPC('sol');assert(npc);let stops=[];const stop=npc.animator.stopAction;npc.animator.stopAction=function(fade){stops.push(fade);return stop.call(this,fade);};
 d.startConversation(d.conversations.sol_first,npc);assert.equal(d._talkNpc,npc);d._pendingTrade=true;d.cancelDialogue();cleared(g);assert.equal(d._talkNpc,null);assert.equal(d._pendingTrade,false);assert.deepEqual(stops,[.1]);
 return {stopActionFades:stops,pendingTrade:false,talkNpc:null};
});
run('Actual resetWorld cancels the reading and runner without completing the diagnostic conversation',()=>{
 const g=fixture(),d=g.director;let ended=0;const convo={id:'cpu_reset_cancel_control',onEnd:[{flag:'cpu_reset_finished'}],nodes:{start:{speaker:'system',text:'Diagnostic world replacement.',next:'end'}}};
 d.startConversation(convo,null,()=>ended++);d._pendingTrade=true;d.resetWorld();const final=cleared(g);assert.equal(g.state.has('cpu_reset_finished'),false);assert.equal(ended,0);assert.equal(d._pendingTrade,false);
 return {ended,completionEffect:false,final};
});
const result={checkedAt:new Date().toISOString(),sourceManifest:'dialogue-lifecycle-r3-repair-source.json',scope:'Pinned source UI/Director/Runner contract tests. Real authored vent decision and Sol data are used where noted. Diagnostic conversations exist only inside this CPU probe to make onEnd effects observable. Minimal DOM, portrait drawing and input acquisition are inert, synthetic and untrusted. No game content was edited; no rendered/browser/smartphone result is claimed.',checks,total:checks.length,passed:checks.filter(c=>c.passed).length,swallowedErrors};
fs.writeFileSync(out,JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify({passed:result.passed,total:result.total,failures:checks.filter(c=>!c.passed),swallowedErrors}));if(result.passed!==result.total||swallowedErrors.length)process.exitCode=1;
