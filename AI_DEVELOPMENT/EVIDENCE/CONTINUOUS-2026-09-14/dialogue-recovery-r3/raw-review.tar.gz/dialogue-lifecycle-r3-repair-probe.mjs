import fs from 'node:fs';
import assert from 'node:assert/strict';
import {makeGame,Game,MODE,Storage,swallowedErrors,repo} from './dialogue-lifecycle-r3-repair-game-fixture.mjs';
import {DialogueUI,Menus} from './dialogue-lifecycle-r3-repair-source/src/ui/screens.js';
import {Emitter} from './dialogue-lifecycle-r3-repair-source/src/core/util.js';
import {SAVE_STATUS} from './dialogue-lifecycle-r3-repair-source/src/game/state.js';
import {t} from './dialogue-lifecycle-r3-repair-source/src/content/i18n.js';
import {installDOM,tap} from './dialogue-lifecycle-r1-dom-fixture.mjs';
const out=new URL('./dialogue-lifecycle-r3-repair-probe.json',import.meta.url);assert(!fs.existsSync(out));
globalThis.__DEV__=false;globalThis.__BUILD_ID__='CPU-10ddee9';
const nativeTimeout=globalThis.setTimeout,nativeClearTimeout=globalThis.clearTimeout;
const timers=[];let nextTimer=1;
globalThis.setTimeout=(fn,ms,...args)=>{const r={id:nextTimer++,fn:()=>fn(...args),ms,done:false};timers.push(r);if(ms!==1400)queueMicrotask(()=>{if(!r.done){r.done=true;r.fn();}});return r.id;};
globalThis.clearTimeout=id=>{const r=timers.find(x=>x.id===id);if(r)r.done=true;};
function deliverDeathTimer(){const r=timers.find(x=>!x.done&&x.ms===1400);assert(r);r.done=true;r.fn();return r.ms;}
class CpuMenus extends Menus {
 _buildStatusPanel(p){this.statusPanel=p;} _buildInventoryPanel(){} _buildJournalPanel(){} _buildMapPanel(){} _buildSettingsPanel(){} _buildAboutPanel(){}
 refreshStatus(){}refreshInventory(){}refreshJournal(){}refreshMap(){}refreshSettings(){}_flushSettings(){}
}
const main=fs.readFileSync(repo+'/src/main.js','utf8');
const start=main.indexOf('  let leavingTitle = false;'),end=main.indexOf("  game.on('ui:newgame', startNewGame);",start);assert(start>=0&&end>start);
const runs=[];
for(const choice of ['retry','newgame','continue','complete']){
 const root=installDOM(),g=makeGame(),transitions=[],held=new Set(),edges=new Set();
 const storage=new Map();globalThis.localStorage={getItem:k=>storage.get(k)??null,setItem:(k,v)=>storage.set(k,String(v)),removeItem:k=>storage.delete(k)};
 g.hud=new Proxy({visible:true,setVisible(v){this.visible=!!v;}},{get:(o,k)=>k in o?o[k]:()=>{}});
 g.audio.voiceTick=()=>{};
 g.dialogueUI=new DialogueUI(g,root);g.menus=new CpuMenus(g,root);g.engine=Object.assign(new Emitter(),{addPause(){},removePause(){}});
 g.input={enabled:true,move:{x:0,y:0,mag:0},current:new Set(),step(){this.current=new Set(edges);edges.clear();},setEnabled(v){this.enabled=v;},clearToggle:k=>held.delete(k),on(){},takeLook:()=>({x:0,y:0}),pressed(k){return this.enabled&&this.current.has(k);},down(k){return this.enabled&&held.has(k);}};
 g.camera.forwardXZ=v=>v.set(-Math.sin(g.camera.yaw),0,-Math.cos(g.camera.yaw));g.camera.rightXZ=v=>v.set(Math.cos(g.camera.yaw),0,-Math.sin(g.camera.yaw));g._playerInput=Game.prototype._playerInput;
 const guard=g._guard;g._guard=function(p,fallback){const r=guard.call(this,p,fallback);if(r?.then)transitions.push(r);return r;};g._wireUI();
 const functions=new Function('game','MODE','t','Storage','SAVE_STATUS','warnStorage',main.slice(start,end)+'\nreturn {startNewGame,continueGame};')(g,MODE,t,Storage,SAVE_STATUS,()=>{});
 g.on('ui:newgame',()=>{const p=functions.startNewGame();transitions.push(p);return p;});g.on('ui:continue',()=>{const p=functions.continueGame();transitions.push(p);return p;});
 const settle=async()=>{while(transitions.length)await Promise.all(transitions.splice(0));};
 const tick=()=>{g.fixedUpdate(1/60);g.dialogueUI.update(1/60);};
 const state=label=>({label,time:g.time,mode:g.mode,hp:g.player.hp,dead:g.player.dead,position:g.player.pos.toArray(),interior:g.director.currentInterior,ambientPpm:g.player.ambientPpm,sat:g.player.lungs.sat,dialogueVisible:g.dialogueUI.visible,full:g.dialogueUI.full,onAdvance:typeof g.dialogueUI.onAdvance,onChoose:typeof g.dialogueUI.onChoose,runnerActive:g.director.dialogue.active,runnerConvo:g.director.dialogue.convo?.id??null,title:g.menus.titleNode.classList.contains('on'),deathScreen:g.menus.deathNode.classList.contains('on'),hasSave:Storage.hasSave(),deaths:g.state.deaths});
 const trace=[];let stage='start';
 try{
  g.menus.showTitle(false);g.setMode(MODE.TITLE);tap(g.menus.titleButtons.new);await settle();trace.push(state('new game via actual title button'));
  // Starting location is staged at the authored, unlocked cellar exterior.
  // Health, progression and gas remain the actual fresh new-game values.
  const sp=g.city.spawns.get('cellar_out');g.player.placeAt(sp.x,sp.y+.05,sp.z,0);g.camera.yaw=0;g._updateInteractTarget();
  assert.equal(g.player.interactTarget?.id,'door_cellar');trace.push({...state('staged at authored door exterior'),interaction:{...g.player.interactTarget}});
  if(choice==='continue'){
   edges.add('menu');tick();assert.equal(g.mode,MODE.MENU);tap(g.menus.saveButton);assert(Storage.hasSave());
   tap(g.menus.pauseNode.walk().find(n=>n.classList.contains('btn')&&n.textContent==='RESUME'));assert.equal(g.mode,MODE.PLAY);trace.push(state('saved with real menu button'));
  }
  stage='door';g._updateInteractTarget();edges.add('interact');tick();await settle();assert.equal(g.director.currentInterior,'cellar');assert.equal(g.interiorPpm,1600);trace.push(state('entered actual unlocked cellar door'));
  stage='walk';const walk=[];
  for(const [x,z]of [[857.3,3.05],[859.5,3.05],[861.9,2.65]]){
   const from=g.player.pos.toArray();let n=0;
   for(;n<360;n++){
    const dx=x-g.player.pos.x,dz=z-g.player.pos.z,len=Math.hypot(dx,dz);if(len<.13)break;
    // Camera yaw0 maps positive move.x to +X and positive move.y to +Z.
    g.input.move={x:dx/len,y:dz/len,mag:1};tick();
   }
   walk.push({target:[x,z],from,to:g.player.pos.toArray(),ticks:n});
  }
  g.input.move={x:0,y:0,mag:0};tick();
  const it=g.city.interactions.find(i=>i.id==='cellar_floor');assert(it);
  g.player.yaw=Math.atan2(g.player.pos.x-it.x,g.player.pos.z-it.z);g.camera.yaw=g.player.yaw;g._updateInteractTarget();trace.push({...state('walked to the cellar text'),walk,selected:g.player.interactTarget?.id??null,target:{...it}});
  assert.equal(g.player.interactTarget?.id,'cellar_floor');
  stage='examine';edges.add('interact');tick();assert.equal(g.mode,MODE.DIALOGUE);assert(g.dialogueUI.visible);trace.push(state('real interact opened authored examine text'));
  if(choice==='complete'){
    let taps=0;const paragraphs=[];
    while(g.dialogueUI.visible&&taps<30){paragraphs.push(g.dialogueUI.full);tap(g.dialogueUI.box);taps++;}
    assert(!g.dialogueUI.visible);assert.equal(g.mode,MODE.PLAY);assert.equal(g.dialogueUI.onAdvance,null);assert.equal(g.dialogueUI.onChoose,null);
    trace.push({...state('ordinary examine completed using actual box pointer handlers'),taps,paragraphs:[...new Set(paragraphs)]});
    runs.push({choice,confirmed:true,normalCompletion:true,trace});continue;
  }
  const textBefore=g.dialogueUI.full,startTime=g.time;
  stage='natural gas death';let n=0;for(;n<18000&&!g.player.dead;n++)tick();assert(g.player.dead);assert.equal(g.player.lastDeathCause,'gas');assert.equal(g.mode,MODE.DEAD);
  assert.equal(g.dialogueUI.visible,false);assert.equal(g.dialogueUI.onAdvance,null);assert.equal(g.dialogueUI.onChoose,null);
  trace.push({...state('natural gas death cancelled the reading'),elapsedReading:g.time-startTime,ticks:n});
  const delay=deliverDeathTimer();assert(g.menus.deathNode.classList.contains('on'));trace.push({...state('actual death UI callback delivered'),configuredDelayMs:delay});
  const button=label=>g.menus.deathNode.walk().find(n=>n.classList.contains('btn')&&n.textContent===label);
  stage='recovery';
  if(choice==='retry'){tap(button('GET UP'));await settle();}
  else{tap(button('TITLE'));await settle();trace.push(state('actual TITLE death-button transition'));tap(g.menus.titleButtons[choice==='newgame'?'new':'continue']);await settle();}
  assert.equal(g.mode,MODE.PLAY);assert(!g.player.dead);trace.push(state('returned to play via user button'));
  const oldTextStillVisible=g.dialogueUI.visible&&g.dialogueUI.full===textBefore;
  assert.equal(oldTextStillVisible,false);assert.equal(g.dialogueUI.visible,false);assert.equal(g.dialogueUI.full,'');
  assert.equal(g.dialogueUI.onAdvance,null);assert.equal(g.dialogueUI.onChoose,null);assert.equal(g.dialogueUI.typing,false);assert.equal(g.dialogueUI._pendingChoices,null);
  const beforeHidden=JSON.stringify({state:state('hidden-input-control'),flags:[...g.state.flags]});
  tap(g.dialogueUI.box);tap(g.dialogueUI.box);g.dialogueUI.update(10);
  const afterHidden=JSON.stringify({state:state('hidden-input-control'),flags:[...g.state.flags]});assert.equal(afterHidden,beforeHidden);
  trace.push(state('old hidden box tap and typing update are inert'));
  runs.push({choice,confirmed:true,oldTextStillVisible,callbacksCleared:true,hiddenInputInert:true,trace});
 }catch(error){runs.push({choice,stage,error:String(error),stack:error.stack,trace});}
}
globalThis.setTimeout=nativeTimeout;globalThis.clearTimeout=nativeClearTimeout;
const result={checkedAt:new Date().toISOString(),baseCommit:'10ddee91fbf74512d3d577ba50d9dabbc987193f',sourceManifest:'dialogue-lifecycle-r3-repair-source.json',sourceState:'Uncommitted repair; no build or browser result',scope:'Pinned live repair source with real Game/Director/Actor/Lungs/DialogueUI/Menus and actual source-bound pointer callback functions. Initial position is staged at the authored unlocked cellar exterior; the door, inside walking, reading, natural full-health gas death and recovery use actual game methods. Menu panel contents, DOM storage/layout/hit-testing, canvas drawing, input device acquisition and wall-clock timers are fixtures. No browser, rendered frame, physical/smartphone input or blind comparison is measured.',inputTrust:false,initialHealthAndGasUnmodified:true,priorDialogueType:'Director._examine closure; not DialogueRunner',runs,swallowedErrors};
fs.writeFileSync(out,JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify({runs:runs.map(r=>({choice:r.choice,confirmed:r.confirmed,stage:r.stage,error:r.error,last:r.trace.at(-1)})),swallowedErrors}));if(runs.some(r=>r.error))process.exitCode=1;
