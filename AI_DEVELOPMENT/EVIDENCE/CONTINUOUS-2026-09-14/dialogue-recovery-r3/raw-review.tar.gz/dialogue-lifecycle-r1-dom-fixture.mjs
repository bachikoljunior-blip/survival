// Minimal DOM contract for actual UI class state and pointer callbacks only.
// It has no layout, CSS cascade, hit-testing, browser events or rendered pixels.
export class Node {
  constructor(tag='div'){this.tagName=tag.toUpperCase();this.children=[];this.parentNode=null;this.listeners=new Map();this.style={setProperty(k,v){this[k]=v;}};this._classes=new Set();this._html='';this._text='';this.scrollHeight=0;this.clientHeight=0;this.scrollTop=0;this.classList={add:(...s)=>s.forEach(x=>this._classes.add(x)),remove:(...s)=>s.forEach(x=>this._classes.delete(x)),contains:s=>this._classes.has(s),toggle:(s,force)=>{const on=force===undefined?!this._classes.has(s):!!force;if(on)this._classes.add(s);else this._classes.delete(s);return on;}};}
  set className(s){this._classes=new Set(String(s).split(/\s+/).filter(Boolean));} get className(){return [...this._classes].join(' ');}
  set innerHTML(s){this._html=String(s);this._text='';this.children=[];}get innerHTML(){return this._html;}
  set textContent(s){this._text=String(s);this._html='';this.children=[];}get textContent(){return this._text||this._html.replace(/<[^>]+>/g,'')||this.children.map(c=>c.textContent).join('');}
  appendChild(n){if(n.parentNode)n.parentNode.removeChild(n);this.children.push(n);n.parentNode=this;return n;}
  removeChild(n){const i=this.children.indexOf(n);if(i>=0)this.children.splice(i,1);n.parentNode=null;return n;}
  addEventListener(name,fn){if(!this.listeners.has(name))this.listeners.set(name,new Set());this.listeners.get(name).add(fn);}
  removeEventListener(name,fn){this.listeners.get(name)?.delete(fn);}
  dispatch(type,extra={}){const e={type,pointerId:1,clientX:10,clientY:10,isTrusted:false,stopPropagation(){},preventDefault(){},...extra};for(const f of this.listeners.get(type)??[])f(e);}
  setPointerCapture(){}getContext(){return new Proxy({getImageData:()=>({data:new Uint8ClampedArray(4)}),measureText:()=>({width:1})},{get:(t,k)=>k in t?t[k]:()=>{}});}
  walk(){return [this,...this.children.flatMap(c=>c.walk())];}
  querySelectorAll(selector){return this.walk().filter(n=>selector.startsWith('.')?n.classList.contains(selector.slice(1)):selector.startsWith('#')?n.id===selector.slice(1):n.tagName.toLowerCase()===selector.toLowerCase());}
  querySelector(selector){return this.querySelectorAll(selector)[0]??null;}
}
export function installDOM(){const root=new Node();root.id='ui';globalThis.document={createElement:tag=>new Node(tag),getElementById:id=>root.walk().find(n=>n.id===id),documentElement:new Node('html'),body:new Node('body')};const listeners=new Map();globalThis.window={innerWidth:667,innerHeight:375,addEventListener:(k,f)=>{if(!listeners.has(k))listeners.set(k,new Set());listeners.get(k).add(f);},removeEventListener:(k,f)=>listeners.get(k)?.delete(f)};globalThis.requestAnimationFrame=f=>{queueMicrotask(f);return 1;};return root;}
export function tap(node){if(!node)throw Error('UI node missing');node.dispatch('pointerdown');node.dispatch('pointerup');}
