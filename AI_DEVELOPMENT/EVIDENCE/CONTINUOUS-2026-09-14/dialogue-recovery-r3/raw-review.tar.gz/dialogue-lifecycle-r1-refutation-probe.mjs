import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import { buildHollisData } from './survival/src/content/world_data.js';
import { Game, MODE } from './survival/src/game/game.js';
import { Actor, STATE } from './survival/src/actors/actor.js';
import { Lungs } from './survival/src/world/gas.js';
import { GameState } from './survival/src/game/state.js';
import { DialogueRunner } from './survival/src/game/narrative.js';
import { Emitter } from './survival/src/core/util.js';
import { validateFindings } from './survival/.kit/lib/plan/findings.mjs';

const baseCommit = '10ddee91fbf74512d3d577ba50d9dabbc987193f';
const hash = bytes => createHash('sha256').update(bytes).digest('hex');
const repo = '/workspace/scratch/0b7ad82bafe7/survival';
const paths = ['src/main.js', 'src/ui/screens.js', 'src/game/game.js', 'src/game/director.js',
  'src/game/state.js', 'src/game/narrative.js', 'src/content/world_data.js',
  'src/actors/actor.js', 'src/world/gas.js', 'src/core/util.js', 'styles.css'];
const source = {}, sources = {};
for (const path of paths) {
  const bytes = execFileSync('git', ['show', `${baseCommit}:${path}`], { cwd: repo });
  source[path] = bytes.toString(); sources[path] = { sha256: hash(bytes), bytes: bytes.length };
  const target = `dialogue-lifecycle-r1-refutation-sources/${path}`;
  mkdirSync(target.slice(0, target.lastIndexOf('/')), { recursive: true });
  writeFileSync(target, bytes, { flag: 'wx' });
}
for (const path of ['src/content/world_data.js', 'src/game/game.js', 'src/actors/actor.js',
  'src/world/gas.js', 'src/game/state.js', 'src/game/narrative.js', 'src/core/util.js']) {
  assert.equal(hash(readFileSync(`${repo}/${path}`)), sources[path].sha256,
    `Imported actual module differs from reviewed base: ${path}`);
}
const noop = () => {};
const checks = [];
const run = async (name, fn) => checks.push({ name, ...await fn() });
const method = (text, start, end, globals = {}) => {
  const startAt = text.indexOf(start), endAt = text.indexOf(end, startAt + start.length);
  assert.ok(startAt >= 0 && endAt > startAt);
  const exact = text.slice(startAt, endAt).trim();
  const name = start.match(/(?:async )?(\w+)\(/)[1];
  return vm.runInNewContext(`({${exact}}).${name}`, globals);
};
const timers = [];
const directorSource = source['src/game/director.js'];
const examine = method(directorSource, '  _examine(spec) {', '  _ventInteract()',
  { MODE, t: (_key, fallback) => fallback });
const onDeath = method(directorSource, '  onPlayerDeath(p) {', '  async retry()',
  { MODE, setTimeout: (fn, ms) => { timers.push({ fn, ms }); return timers.length; } });
const retry = method(directorSource, '  async retry() {', '  // ------------------------------------------------------------------- save',
  { MODE, STATE, Enemy: class UnusedEnemy {}, Storage: { load: () => null } });
const uiSource = source['src/ui/screens.js'];
const tap = method(uiSource, '  _tap() {', '  show(node, choices)');
const hide = method(uiSource, '  hide() {', '  get visible()');
const uiUpdate = method(uiSource, '  update(dt) {', '  _render()');

const world = buildHollisData(), cellar = world.interiors.find(x => x.id === 'cellar');
const door = world.interactions.find(x => x.id === 'door_cellar');
const gauge = cellar.interactions.find(x => x.id === 'cellar_gauge');
const floor = cellar.interactions.find(x => x.id === 'cellar_floor');
await run('Authored cellar door and both examine interactions have no key or chapter gate', async () => {
  for (const spec of [door, gauge, floor]) {
    assert.ok(spec);
    assert.equal(spec.locked, undefined); assert.equal(spec.requiresItem, undefined);
    assert.equal(spec.unlockIf, undefined); assert.equal(spec.chapter, undefined);
  }
  assert.equal(door.target, 'cellar_in'); assert.equal(door.interiorId, 'cellar');
  assert.equal(cellar.ppm, 1600);
  return { passed: true, door, examine: [gauge, floor], interiorPpm: cellar.ppm,
    scope: 'Authored gate absence, not a measured navigation path or trusted input.' };
});

function classList() {
  const set = new Set();
  return { add: x => set.add(x), remove: x => set.delete(x), contains: x => set.has(x) };
}
function fixture() {
  const ui = {
    node: { classList: classList() }, choiceWrap: { classList: classList() }, choicesNode: { innerHTML: '' },
    typing: false, full: '', shown: 0, choiceList: null, onAdvance: null, onChoose: null,
    _portraitFor: null, speed: 46, _render: noop, _afterType: noop,
    show(node) { this.node.classList.add('on'); this.full = node.text; this.shown = 0; this.typing = true; },
    hide, _tap: tap, update: uiUpdate,
  };
  const player = Object.assign(Object.create(Actor.prototype), {
    dead: false, hp: 120, maxHp: 120, stamina: 100, maxStamina: 100, staminaRegen: 12,
    poise: 100, poiseCurrent: 100, _poiseHold: 0, _staminaHold: 0,
    guardCurrent: 100, guardHealth: 100, grounded: true, guarding: false,
    state: STATE.IDLE, wantSprint: false, moveInput: { mag: 0 }, gasImmune: false,
    gas: { sample: () => cellar.ppm }, lungs: new Lungs(), events: [],
    height: 1.8, pos: { x: 856.6, y: 0.05, z: -0.6 }, vel: { set: noop },
    animator: { play: noop, stopAction: noop }, lastCough: 0,
    update(dt, ctx) { this._updateVitals(dt, ctx); }, setMove: noop,
  });
  const state = new GameState();
  const g = Object.assign(new Emitter(), {
    player, state, dialogueUI: ui, mode: MODE.PLAY, time: 0, playTime: 0,
    input: { step: noop, setEnabled: noop, clearToggle: noop }, gas: { update: noop },
    actors: [player], systems: [], _updateZone: noop, _playerInput: noop,
    _drainEvents: Game.prototype._drainEvents, setMode: Game.prototype.setMode,
    interiorPpm: cellar.ppm, hud: { setVisible: noop },
    menus: { showDeath: noop, hideDeath: noop, fadeOut: async () => {}, fadeIn: async () => {} },
    ai: { clearProjectiles: noop }, teleport: noop,
  });
  ui.game = g;
  const d = { game: g, state, dialogue: new DialogueRunner(state, {}),
    quests: { start: noop, reenterActiveSteps: noop }, _examine: examine, onPlayerDeath: onDeath, retry };
  g.director = d;
  g.on('actor:death', a => { if (a === player) d.onPlayerDeath(a); });
  return { g, d, ui, player, state };
}
let deathFixture;
await run('The cellar examine opens a local advance closure without starting DialogueRunner', async () => {
  const f = fixture(); f.d._examine(gauge);
  assert.equal(f.g.mode, MODE.DIALOGUE); assert.equal(f.ui.node.classList.contains('on'), true);
  assert.equal(typeof f.ui.onAdvance, 'function'); assert.equal(f.ui.onChoose, null);
  assert.equal(f.d.dialogue.active, false); assert.equal(f.d.dialogue.convo, null);
  deathFixture = f;
  return { passed: true, topic: gauge.topic, chapter: f.state.chapter, mode: f.g.mode,
    runnerActive: f.d.dialogue.active, runnerConvo: f.d.dialogue.convo,
    conclusion: 'This particular route cannot establish a stale active conversation runner or old-choice progression effects.' };
});
await run('Natural authored gas can kill the stationary unmasked player while the examine remains open', async () => {
  const f = deathFixture, callback = f.ui.onAdvance, dt = 1 / 60;
  let ticks = 0;
  while (!f.player.dead && ticks < 60 * 1200) {
    Game.prototype.fixedUpdate.call(f.g, dt);
    f.ui.update(dt);
    ticks++;
  }
  assert.equal(f.player.dead, true); assert.equal(f.player.lastDeathCause, 'gas');
  assert.equal(f.g.mode, MODE.DEAD); assert.equal(f.ui.node.classList.contains('on'), true);
  assert.equal(f.ui.onAdvance, callback); assert.equal(f.ui.typing, false);
  assert.equal(timers.at(-1).ms, 1400); timers.at(-1).fn();
  assert.equal(f.ui.node.classList.contains('on'), true);
  return { passed: true, ticks, simulationSeconds: ticks * dt, hp: f.player.hp, sat: f.player.lungs.sat,
    actualDeathCause: f.player.lastDeathCause, mode: f.g.mode, dialogueOn: true,
    advanceClosurePreserved: true, textFinishedTypingButDidNotAutoAdvance: true,
    scope: 'Actual fixedUpdate mode branch, Actor vitals/kill, Lungs and event drain. Motion, world sampling, rendering, DOM acquisition and delayed death display are bounded fixtures.' };
});
await run('No-save retry returns to play but preserves the examine; normal taps can close it', async () => {
  const f = deathFixture, callback = f.ui.onAdvance;
  await f.d.retry();
  assert.equal(f.player.dead, false); assert.equal(f.g.mode, MODE.PLAY);
  assert.equal(f.ui.node.classList.contains('on'), true); assert.equal(f.ui.onAdvance, callback);
  let taps = 0;
  while (f.ui.node.classList.contains('on') && taps < 20) { f.ui._tap(); taps++; }
  assert.equal(f.ui.node.classList.contains('on'), false);
  assert.equal(f.ui.onAdvance, null); assert.equal(f.ui.onChoose, null);
  assert.equal(f.g.mode, MODE.PLAY);
  return { passed: true, staleAfterRetry: true, recoveredWithExistingTapCount: taps,
    afterDismissal: { dialogueOn: false, onAdvance: null, onChoose: null, mode: f.g.mode },
    scope: 'Direct actual retry handler with a missing-save boundary, followed by actual DialogueUI._tap/examine completion. This does not measure clicking GET UP in a browser.' };
});
await run('Pausing through ordinary menu events is not a direct escape from dialogue', async () => {
  const wire = source['src/game/game.js'].match(/this\.on\('ui:menu',[\s\S]*?this\.on\('ui:map'/)[0];
  assert.match(wire, /this\.mode === MODE\.PLAY/); assert.match(wire, /this\.mode === MODE\.MENU/);
  assert.equal(wire.includes('MODE.DIALOGUE'), false);
  return { passed: true, sourceExcerpt: wire,
    consequence: 'A direct pause-menu-to-title route while dialogue is open is not established. The death-screen route is materially different.' };
});
await run('Death and title overlays outrank the dialogue but hiding them does not clear dialogue state', async () => {
  const css = source['styles.css'];
  const dialogRule = css.match(/#dlg \{[\s\S]*?\n\}/)[0];
  assert.equal(dialogRule.includes('z-index'), false);
  assert.match(css, /\.dead \{[^}]*z-index: 50/);
  assert.match(css, /#title \{[^}]*z-index: 40/);
  assert.match(uiSource, /hideDeath\(\) \{ this\.deathNode\.classList\.remove\('on'\); \}/);
  return { passed: true, dialogRule, deathZ: 50, titleZ: 40,
    scope: 'CSS stacking/source inference, not computed style, hit testing or a screenshot.',
    consequence: 'The existing overlays can conceal the stale dialogue, but this does not remove its on class or callback.' };
});
await run('Fresh-page construction resets in-memory dialogue; persisted progression does not restore its closure', async () => {
  const state = new GameState(), serialised = state.serialise();
  assert.equal(Object.hasOwn(serialised, 'dialogue'), false);
  assert.equal(Object.hasOwn(serialised, 'convo'), false);
  assert.match(source['src/main.js'], /const game = new Game\(canvas\);/);
  assert.match(source['src/game/game.js'], /this\.dialogueUI = new DialogueUI\(this, ui\);/);
  assert.match(source['src/game/game.js'], /this\.director = new Director\(this\);/);
  assert.match(uiSource, /this\.onAdvance = null;\n    this\.onChoose = null;/);
  const runner = new DialogueRunner(state, {});
  assert.equal(runner.active, false); assert.equal(runner.convo, null);
  return { passed: true, persistedStateKeys: Object.keys(serialised), freshRunnerActive: false,
    conclusion: 'A full page reload is a credible reset of this in-memory leak. A persisted-save corruption claim is not supported by the examine evidence.',
    scope: 'Construction and serialisation inference; no page reload was executed.' };
});

const raw = { checkedAt: new Date().toISOString(), baseCommit, sources,
  reviewer: '/root/acquisition_path_review/acquisition_refutation', checks,
  scope: 'Independent user-reachability/severity refutation for the authored cellar-examine death path. Product files were not changed. Only new scratch evidence files were written.',
  limits: ['No browser, server, socket, actual touchscreen, screenshot, full navigation walk or reload was run.',
    'The gas CPU fixture delegates only vitals to Actor.update; normal locomotion/rendering are not measured.',
    'The exact base Director methods are extracted from git show. Unchanged imported product modules are SHA-checked against that base.',
    'TITLE -> NEW GAME/CONTINUE with the actual Menus/DOM fixture belongs to the parent review; it is not independently re-measured here.'],
};
writeFileSync('dialogue-lifecycle-r1-refutation-probe.json', JSON.stringify(raw, null, 2) + '\n', { flag: 'wx' });
const review = {
  verdict: 'FAIL', score: 85, round: 'dialogue-lifecycle-r1-independent-refutation',
  profile: 'Authored cellar examine: reachability and severity', tier: 'Source and bounded CPU', nativeResolution: '0x0',
  blindComparison: 'No blind comparison was performed. The source is known, and no actual rendered image, trusted input, reference preference or product quality element is judged by these source/CPU results.',
  checkedAt: raw.checkedAt, baseCommit, reviewer: raw.reviewer, scope: raw.scope, sources,
  verdictScope: 'A stale examine presentation/advance closure survives the natural-gas-death and no-save retry path. Broader active-runner corruption, permanent lockout and persisted-save damage claims are not established by this route.',
  findings: [{ severity: 'minor', owner: 'src/game/director.js',
    shot: 'dialogue-lifecycle-r1-refutation-probe.json: natural gas death and no-save retry',
    problem: 'After the authored cellar examine remains open through natural gas death, the actual retry handler returns to PLAY while the old examine on state and advance closure still remain.',
    why: 'The death and retry lifecycle does not terminate the examine presentation; the local show closure retains its remaining lines across the respawn.',
    fix: 'Cancel the prior dialogue presentation and its callbacks on lifecycle transitions. The death and retry controls in this probe must show dialogueOn=false and onAdvance/onChoose=null without completing remaining story lines as a side effect.',
    hypothesis: 'The missing cancellation mechanism is source-supported and reproduced at the bounded CPU API boundary. The exact rendered overlap and browser control path require the separate parent/mobile validation.',
    severityRationale: 'For this narrow examine-only route the old text can be dismissed with existing taps, after which PLAY remains usable; this is not evidence of a permanent lockout or old conversation-choice effects.',
  }],
  refutedOrLimitedClaims: [
    { claim: 'Cellar interaction is locked behind a key or chapter.', result: 'Refuted for the recorded authored door and both examine specs; the production dispatch contains only explicit requiresItem/locked checks, absent here. Navigation has not been fully walked in this review.' },
    { claim: 'Dialogue automatically finishes or pauses natural gas death.', result: 'Refuted by actual fixedUpdate/vitals/Lungs CPU execution and the typing updater. Text finishes typing but does not advance; death occurs while the closure remains.' },
    { claim: 'The cited cellar examine leaves an active DialogueRunner.', result: 'Refuted for this route: _examine does not start the runner. Its local advance closure is a distinct surviving object.' },
    { claim: 'The stale examine makes the run permanently unusable.', result: 'Not supported: normal UI tap logic dismisses the remaining text. Other active conversation routes need their own evidence.' },
    { claim: 'A full page reload necessarily carries the same stale callback back.', result: 'Refuted by construction/serialisation reasoning. It creates new Game/DialogueUI/Director objects, and the save does not serialise this closure or current runner. Actual reload is not measured.' },
    { claim: 'The death/title overlay would prevent reaching the recovery controls.', result: 'Source stacking has death/title above the dialogue, which argues against that blocker. This is not computed hit-test evidence.' },
  ],
  evidenceFiles: ['dialogue-lifecycle-r1-refutation-probe.mjs', 'dialogue-lifecycle-r1-refutation-probe.json', 'dialogue-lifecycle-r1-refutation-sources/'],
  limitations: raw.limits,
};
review.validation = validateFindings(review, { strict: true, knownOwners: new Set(['src/game/director.js']) });
assert.equal(review.validation.ok, true, JSON.stringify(review.validation));
writeFileSync('dialogue-lifecycle-r1-refutation.json', JSON.stringify(review, null, 2) + '\n', { flag: 'wx' });
console.log(JSON.stringify({ checks: checks.length, passed: checks.every(x => x.passed), naturalGas: checks[2], validation: review.validation,
  path: 'dialogue-lifecycle-r1-refutation.json' }));
