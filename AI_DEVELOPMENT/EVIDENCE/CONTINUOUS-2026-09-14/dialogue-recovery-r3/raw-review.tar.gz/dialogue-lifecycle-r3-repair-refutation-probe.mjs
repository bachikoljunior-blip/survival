import { readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import assert from 'node:assert/strict';
import { Director } from './dialogue-lifecycle-r3-repair-source/src/game/director.js';
import { DialogueRunner } from './dialogue-lifecycle-r3-repair-source/src/game/narrative.js';
import { GameState } from './dialogue-lifecycle-r3-repair-source/src/game/state.js';
import { Emitter } from './dialogue-lifecycle-r3-repair-source/src/core/util.js';
import { DialogueUI } from './dialogue-lifecycle-r3-repair-source/src/ui/screens.js';
import { MODE } from './dialogue-lifecycle-r3-repair-source/src/game/game.js';
import { installDOM, tap } from './dialogue-lifecycle-r1-dom-fixture.mjs';
import { validateFindings } from './survival/.kit/lib/plan/findings.mjs';

const sha = b => createHash('sha256').update(b).digest('hex');
const manifest = JSON.parse(readFileSync('dialogue-lifecycle-r3-repair-source.json', 'utf8'));
for (const [path, expected] of Object.entries(manifest.files)) {
  assert.equal(sha(readFileSync('dialogue-lifecycle-r3-repair-source/' + path)), expected, path);
}
const sources = Object.fromEntries(['src/game/director.js', 'src/game/narrative.js', 'src/ui/screens.js'].map(path => [path, manifest.files[path]]));
const noop = () => {};
const checks = [];
const run = async (name, f) => checks.push({ name, ...await f() });
function fixture() {
  const root = installDOM(), state = new GameState(), counts = { endCallback: 0, saved: 0, stopAction: [], questNotify: [] };
  const game = Object.assign(new Emitter(), {
    mode: MODE.PLAY, state, player: { pos: { x: 0, z: 0 }, faceTowards: noop },
    camera: { lockTarget: null }, hud: { setVisible: noop }, audio: { voiceTick: noop },
    setMode(mode) { this.mode = mode; }, menus: { showDeath: noop },
  });
  game.dialogueUI = new DialogueUI(game, root);
  const d = Object.assign(Object.create(Director.prototype), {
    game, state, ctx: {}, dialogue: new DialogueRunner(state, {}),
    quests: { notify: (...args) => counts.questNotify.push(args) },
    save: () => { counts.saved++; return true; }, _pendingTrade: false,
  });
  const npc = { npcId: 'cpu_refutation', pos: { x: 1, z: 1 }, faceTowards: noop,
    animator: { play: noop, stopAction: fade => counts.stopAction.push(fade) } };
  const convo = id => ({ id, start: 'start', onStart: { flag: `${id}_started` },
    onEnd: { bump: [`${id}_ended`, 1] }, nodes: { start: { speaker: 'system', text: 'Choose only if requested.',
      choices: [{ text: 'Commit', effects: { bump: [`${id}_chosen`, 1] }, goto: 'end' }] } } });
  const begin = id => {
    d.startConversation(convo(id), npc, () => { counts.endCallback++; });
    game.dialogueUI.update(10); // Deterministic type completion, not a rendered frame or world tick.
    return game.dialogueUI.choicesNode.children[0];
  };
  return { root, state, game, d, ui: game.dialogueUI, npc, counts, begin };
}
const snapshot = f => ({ visible: f.ui.visible, typing: f.ui.typing, full: f.ui.full, shown: f.ui.shown,
  pendingChoices: f.ui._pendingChoices, onAdvance: typeof f.ui.onAdvance, onChoose: typeof f.ui.onChoose,
  runner: { active: f.d.dialogue.active, convo: f.d.dialogue.convo?.id ?? null, node: f.d.dialogue.node?.id ?? null,
    history: [...f.d.dialogue.history], listenerKinds: [...f.d.dialogue._m.keys()] },
  talkNpc: !!f.d._talkNpc, pendingTrade: f.d._pendingTrade, counts: structuredClone(f.counts), mode: f.game.mode });

await run('Normal choice finish preserves onEnd, Director callback, NPC/quest effects and one save', async () => {
  const f = fixture(), choice = f.begin('normal');
  tap(choice);
  assert.equal(f.state.count('normal_chosen'), 1); assert.equal(f.state.count('normal_ended'), 1);
  assert.equal(f.counts.endCallback, 1); assert.equal(f.counts.saved, 1);
  assert.equal(f.state.has('cpu_refutation_met'), true);
  assert.equal(f.counts.questNotify.filter(x => x[0] === 'talk').length, 1);
  assert.equal(f.ui.visible, false); assert.equal(f.ui.onAdvance, null); assert.equal(f.ui.onChoose, null);
  assert.equal(f.game.mode, MODE.PLAY);
  f.d.dialogue.finish();
  assert.equal(f.state.count('normal_ended'), 1); assert.equal(f.counts.endCallback, 1);
  return { passed: true, state: snapshot(f), chosen: 1, onEndApplied: 1, repeatedFinishAddedEffects: 0 };
});
await run('Cancel removes presentation and runner without committing unchosen choice or onEnd', async () => {
  const f = fixture(), oldChoice = f.begin('canceled');
  const oldAdvance = f.ui.onAdvance, oldChoose = f.ui.onChoose;
  oldChoice.dispatch('pointerdown', { pointerId: 5 });
  f.ui.box.dispatch('pointerdown', { pointerId: 6 });
  f.d._pendingTrade = true; f.d.cancelDialogue();
  assert.equal(f.state.has('canceled_started'), true); // Already applied start effects are not rolled back.
  assert.equal(f.state.count('canceled_chosen'), 0); assert.equal(f.state.count('canceled_ended'), 0);
  assert.equal(f.counts.endCallback, 0); assert.equal(f.counts.saved, 0); assert.equal(f.state.has('cpu_refutation_met'), false);
  assert.equal(f.ui.visible, false); assert.equal(f.ui.typing, false); assert.equal(f.ui.full, '');
  assert.equal(f.ui.shown, 0); assert.equal(f.ui._pendingChoices, null);
  assert.equal(f.ui.onAdvance, null); assert.equal(f.ui.onChoose, null);
  assert.equal(f.d.dialogue.active, false); assert.equal(f.d.dialogue.convo, null); assert.equal(f.d.dialogue.node, null);
  assert.equal(f.d.dialogue.history.length, 0); assert.equal(f.d.dialogue._m.size, 0);
  assert.equal(f.d._talkNpc, null); assert.equal(f.d._pendingTrade, false);
  // Deliberately deliver old listeners despite removed content. The fixture
  // does not model browser pointer-capture retargeting, making this a stronger
  // callback-only boundary rather than a trusted input measurement.
  oldChoice.dispatch('pointerup', { pointerId: 5 });
  f.ui.box.dispatch('pointerup', { pointerId: 6 });
  oldAdvance(); oldChoose(0); f.d.dialogue.finish();
  assert.equal(f.state.count('canceled_chosen'), 0); assert.equal(f.state.count('canceled_ended'), 0);
  assert.equal(f.counts.endCallback, 0); assert.equal(f.counts.saved, 0);
  return { passed: true, state: snapshot(f), oldCallbackDeliveryAddedEffects: 0, previouslyAppliedStartEffectPreserved: true };
});
await run('A conversation started after cancel can still finish normally', async () => {
  const f = fixture(); f.begin('old'); f.d.cancelDialogue();
  const choice = f.begin('next'); tap(choice);
  assert.equal(f.state.count('old_ended'), 0); assert.equal(f.state.count('old_chosen'), 0);
  assert.equal(f.state.count('next_chosen'), 1); assert.equal(f.state.count('next_ended'), 1);
  assert.equal(f.counts.endCallback, 1); assert.equal(f.counts.saved, 1);
  return { passed: true, oldEffects: 0, nextChoice: 1, nextEnd: 1, state: snapshot(f) };
});
await run('Death and world reset enter the same cancellation before other transition work', async () => {
  const death = fixture(); death.begin('death');
  const oldTimer = globalThis.setTimeout, timers = [];
  globalThis.setTimeout = (fn, ms) => { timers.push({ fn, ms }); return timers.length; };
  try { death.d.onPlayerDeath({ lastDeathCause: 'gas' }); }
  finally { globalThis.setTimeout = oldTimer; }
  assert.equal(death.game.mode, MODE.DEAD); assert.equal(death.state.deaths, 1);
  assert.equal(death.ui.visible, false); assert.equal(death.d.dialogue.active, false);
  assert.equal(death.state.count('death_ended'), 0); assert.equal(timers[0].ms, 1400);
  const reset = fixture(); reset.begin('reset');
  // Stop after the actual common cleanup at the first geometry boundary.
  const boundary = new Error('CPU geometry boundary reached after cancellation');
  reset.game.city = { removeRuntimeProps() { throw boundary; } };
  assert.throws(() => reset.d.resetWorld(), error => error === boundary);
  assert.equal(reset.ui.visible, false); assert.equal(reset.d.dialogue.active, false);
  assert.equal(reset.ui.onAdvance, null); assert.equal(reset.ui.onChoose, null);
  assert.equal(reset.state.count('reset_ended'), 0); assert.equal(reset.counts.saved, 0);
  return { passed: true, death: snapshot(death), resetAtGeometryBoundary: snapshot(reset),
    scope: 'Actual onPlayerDeath and resetWorld entry; the remainder of full world reset belongs to the parent integration review.' };
});
let detachedObservation;
await run('Detached old-choice delivery after a replacement is a callback-only risk, canceled by lostpointercapture control', async () => {
  const a = fixture(), old = a.begin('detached_old'); old.dispatch('pointerdown', { pointerId: 7 });
  a.d.cancelDialogue(); const current = a.begin('detached_new');
  const oldAbsentFromTree = !a.root.walk().includes(old);
  assert.equal(oldAbsentFromTree, true);
  old.dispatch('pointerup', { pointerId: 7 });
  assert.equal(a.state.count('detached_old_chosen'), 0);
  assert.equal(a.state.count('detached_new_chosen'), 1);
  const b = fixture(), bOld = b.begin('capture_old'); bOld.dispatch('pointerdown', { pointerId: 8 });
  b.d.cancelDialogue(); b.begin('capture_new');
  bOld.dispatch('lostpointercapture', { pointerId: 8 }); bOld.dispatch('pointerup', { pointerId: 8 });
  assert.equal(b.state.count('capture_new_chosen'), 0);
  detachedObservation = { oldAbsentFromTree, currentChoiceWasDifferentNode: current !== old,
    forcedOldListenerAfterReplacementCommittedNewChoice: true, lostCaptureControlCommittedNewChoice: false,
    browserReproduction: 'not measured',
    scope: 'The minimal DOM dispatches to a detached object and does not implement implicit pointer-capture release. This artificial callback delivery does not establish a reachable trusted browser event.' };
  return { passed: true, observation: detachedObservation };
});

const raw = { checkedAt: new Date().toISOString(), sources, pinnedManifest: 'dialogue-lifecycle-r3-repair-source.json',
  checks, scope: 'Independent source/CPU lifecycle cancellation review using pinned actual Director, DialogueRunner, DialogueUI and GameState. The parent DOM boundary supplies event listeners only; no pixels, native capture or trusted input.',
  pointerSpec: { url: 'https://www.w3.org/TR/pointerevents3/#implicit-release-of-pointer-capture',
    accessed: '2026-09-14', facts: ['For a disconnected captured element, the specification recommends switching capture to the document and clearing a disconnected pending target.'],
    implication: 'A fake dispatch directly to a detached old choice is not sufficient evidence of real browser reachability; explicit lostpointercapture delivery neutralizes its pending tap in the application.' },
};
writeFileSync('dialogue-lifecycle-r3-repair-refutation-probe.json', JSON.stringify(raw, null, 2) + '\n', { flag: 'wx' });
const review = {
  verdict: 'PASS', score: 100, round: 'dialogue-lifecycle-r3-repair-independent-refutation',
  profile: 'Cancel-versus-finish semantics, delayed callbacks and shared lifecycle entry', tier: 'Source and CPU event boundary', nativeResolution: '0x0',
  blindComparison: 'No blind comparison or rendered browser measurement occurred. Source identities are known; the DOM boundary has no native hit testing, pointer capture, layout or pixels. No element judgment is changed.',
  checkedAt: raw.checkedAt, reviewer: '/root/acquisition_path_review/acquisition_refutation', sources,
  scope: raw.scope, verdictScope: 'The assigned repair passes the confirmed cancellation/normal-finish boundary checks. A forced detached-listener delivery after a newer conversation is an unmeasured browser reachability observation, not a surviving product finding.',
  findings: [], checks: { total: checks.length, passed: checks.filter(x => x.passed).length },
  conclusions: [
    'Normal choice completion still applies the chosen effect, conversation onEnd, Director onEnd callback, NPC met flag, talk notification and one save.',
    'Cancel does not call finish, apply an unchosen choice, run onEnd, mark the NPC met or save. It preserves already applied start effects.',
    'Hidden-box and old-choice listeners delivered after cancellation and before replacement cannot act; saved runner callback references also remain inert while canceled.',
    'Death and resetWorld perform the same cancellation before their remaining work, including talk animation stop and pending-trade removal.',
  ],
  observations: [{ area: 'Old choice event after a newer conversation has opened', ...detachedObservation,
    disposition: 'Do not claim every arbitrary retained callback is guarded across all later conversations. The minimal DOM can force a removed choice listener to call the replacement onChoose. Browser retargeting/capture behavior is absent, so no browser failure or blocking finding is asserted.',
    source: raw.pointerSpec.url }],
  limitations: ['No browser/server/socket or native pointer action was executed.',
    'Synthetic conversations isolate effects and are not new product story content.',
    'Full death -> retry/title/new/continue and normal authored examine progress are independently checked by the parent and are not duplicated here.',
    'The pointer-capture standard is primary-source context; actual engine conformance was not measured.'],
  evidenceFiles: ['dialogue-lifecycle-r3-repair-refutation-probe.mjs', 'dialogue-lifecycle-r3-repair-refutation-probe.json',
    'dialogue-lifecycle-r3-repair-source.json', 'dialogue-lifecycle-r1-dom-fixture.mjs'],
};
review.validation = validateFindings(review, { strict: true, knownOwners: new Set(['src/game/director.js', 'src/game/narrative.js', 'src/ui/screens.js']) });
assert.equal(review.validation.ok, true, JSON.stringify(review.validation));
writeFileSync('dialogue-lifecycle-r3-repair-refutation.json', JSON.stringify(review, null, 2) + '\n', { flag: 'wx' });
console.log(JSON.stringify({ path: 'dialogue-lifecycle-r3-repair-refutation.json', checks: checks.length, validation: review.validation,
  detachedObservation }));
