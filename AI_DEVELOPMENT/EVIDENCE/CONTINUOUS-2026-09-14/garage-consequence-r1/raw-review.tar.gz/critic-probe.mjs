import assert from 'node:assert/strict';
import { readFileSync, writeFileSync, existsSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { dirname, resolve } from 'node:path';
import { CONVERSATIONS, EPILOGUE_BEATS, ENDINGS } from './critic-source/src/content/story.js';
import { DialogueRunner, testCondition } from './critic-source/src/game/narrative.js';
import { Director } from './critic-source/src/game/director.js';
import { GameState, Storage, SAVE_KEY } from './critic-source/src/game/state.js';
import { setLocale, t, missingKeys, has } from './critic-source/src/content/i18n.js';

const base = dirname(fileURLToPath(import.meta.url));
const out = resolve(base, 'critic-raw.json');
assert.equal(existsSync(out), false, 'Preserve previous evidence; use a new revision.');
const before = await import('data:text/javascript;base64,' + Buffer.from(readFileSync(resolve(base, 'story-before.js'))).toString('base64'));
const hash = x => createHash('sha256').update(x).digest('hex');
const slots = new Map();
globalThis.localStorage = { getItem: k => slots.get(k) ?? null, setItem: (k,v) => slots.set(k,String(v)), removeItem: k => slots.delete(k) };
const old = [];
const records = [];
const bounded = [];
const checks = [];
function check(name, detail, fn) { fn(); checks.push({ name, detail, ok: true }); }
function complete(runner) {
  let budget = 20;
  while (runner.active) { assert.ok(budget-- > 0, 'Conversation bounded completion'); assert.equal(runner.choices(), null, 'Do not skip an unresolved choice'); runner.advance(); }
}
function choose(runner, target) {
  const cs = runner.choices(); assert.ok(cs, 'Choice list exists');
  const i = cs.findIndex(c => c.goto === target); assert.ok(i >= 0, `Actual offered choice ${target}`); assert.equal(!!cs[i].locked, false);
  runner.choose(i);
}
function act(story, gaveFilter, vent, shop, language) {
  setLocale(language); const state = new GameState(); const hooks = [];
  const runner = new DialogueRunner(state, { hooks: { shutVents: () => hooks.push('shutVents'), halfVents: () => hooks.push('halfVents') } });
  const nodes=[]; runner.on('node', (n, cs) => nodes.push({ id:n.id, text:n.text, choiceTargets:cs?.map(c=>c.goto) ?? [] }));
  runner.start(story.garage); assert.equal(runner.node.id, 'start'); runner.advance();
  choose(runner, gaveFilter ? 'g_filter' : 'g_air'); complete(runner);
  assert.equal(state.countItem('filter'), gaveFilter ? 0 : 1); assert.equal(state.has('met_garage'), true);
  runner.start(story.vent_decision); choose(runner, `v_${vent}`); complete(runner);
  assert.deepEqual(hooks, vent === 'leave' ? [] : [vent === 'shut' ? 'shutVents' : 'halfVents']);
  if (shop) {
    // This is an explicit node-entry fixture, not a claim of reaching the later scene from a new game.
    runner.start({ id:'nessa_truth', nodes:story.nessa_truth.nodes }, 'nt_shop'); complete(runner);
  }
  return { state, nodes, hooks };
}
const oracle = {
  'false/leave': { family:'garage_died', shop:'nessa_shop_bereaved', survivors:3 },
  'false/shut': { family:'garage_lived', shop:'nessa_shop', survivors:4 },
  'false/half': { family:'garage_lived_half', shop:'nessa_shop', survivors:4, authoredCost:'workshop livelihood lost' },
  'true/leave': { family:'garage_lived', shop:'nessa_shop', survivors:4 },
  'true/shut': { family:'garage_lived', shop:'nessa_shop', survivors:4 },
  'true/half': { family:'garage_lived', shop:'nessa_shop', survivors:4 },
};
const endingOracle = { publish:'record', cut:'cut', deal:'westward', evacuate:'everybody', leave:'nothing' };
const byId = new Map(EPILOGUE_BEATS.flatMap(b=>[b,...(b.variants || [])]).map(b=>[b.id,b]));
const translated = id => t(`ep.${id}`, byId.get(id).text);

try {
  for (const x of [{ filter:true,vent:'leave',shop:false },{ filter:false,vent:'half',shop:false },{ filter:false,vent:'leave',shop:true }]) {
    const { state, nodes } = act(before.CONVERSATIONS,x.filter,x.vent,x.shop,'en');
    const beats = before.EPILOGUE_BEATS.filter(b=>testCondition(b.condition,state));
    old.push({ ...x, flags:[...state.flags], choices:[...state.choices], dialogue:nodes, selected:beats.map(b=>({id:b.id,text:b.text})) });
  }
  check('Old actual choices select mutually contradictory family beats', old[0].selected.map(b=>b.id), ()=>assert.deepEqual(old[0].selected.filter(b=>b.id.startsWith('garage_')).map(b=>b.id),['garage_lived','garage_died']));
  check('Old half/no-filter choices produce no family consequence', old[1].selected.map(b=>b.id), ()=>assert.equal(old[1].selected.filter(b=>b.id.startsWith('garage_')).length,0));
  check('Old death plus shop-told selects weekly living-wife visit text', old[2].selected.map(b=>b.id), ()=>{
    assert.ok(old[2].selected.some(b=>b.id==='garage_died'));
    assert.ok(old[2].selected.some(b=>b.id==='nessa_shop' && b.text.includes('every week since')));
  });
  check('Original structural counts preserved', {oldBeats:before.EPILOGUE_BEATS.length,newBeats:EPILOGUE_BEATS.length,oldEndings:before.ENDINGS.length,newEndings:ENDINGS.length},()=>{
    assert.equal(before.EPILOGUE_BEATS.length,8);assert.equal(EPILOGUE_BEATS.length,8);assert.equal(before.ENDINGS.length,5);assert.equal(ENDINGS.length,5);
  });
  for (const language of ['en','ja']) for (const gaveFilter of [false,true]) for (const vent of ['leave','shut','half']) for (const final of ['publish','cut','deal','evacuate','leave']) for (const restored of [false,true]) {
    slots.clear();
    // For restored cases construct choices in the other offered locale, then round-trip actual Storage and display in the target locale.
    const inputLanguage = restored ? (language === 'en' ? 'ja' : 'en') : language;
    let {state,nodes,hooks} = act(CONVERSATIONS,gaveFilter,vent,true,inputLanguage);
    state.record('final',final); // Explicit final-intention fixture; no full final-quest route claim.
    const flagsBefore=[...state.flags];const choicesBefore=[...state.choices];const inventoryBefore=[...state.inventory];
    if (restored) {
      assert.equal(Storage.save(state,null,{completed:false}),true);
      const loaded=Storage.load(); assert.ok(loaded?.state,'Actual Storage.load accepts its serialized envelope');
      state=new GameState();assert.equal(state.deserialise(loaded.state),true);
      assert.deepEqual([...state.flags],flagsBefore);assert.deepEqual([...state.choices],choicesBefore);assert.deepEqual([...state.inventory],inventoryBefore);
    }
    setLocale(language);let shown;const boundary=[];
    const game={ player:null,setMode:x=>boundary.push(['mode',x]),hud:{setVisible:x=>boundary.push(['hud',x])},emit:(...x)=>boundary.push(x),
      menus:{fadeOut:async()=>boundary.push(['fadeOut']),fadeIn:async()=>boundary.push(['fadeIn']),showEnding:(e,p)=>{shown={ending:e,paragraphs:p};boundary.push(['showEnding']);}} };
    await Director.prototype.finish.call({game,state});
    assert.ok(shown);const expected=oracle[`${gaveFilter}/${vent}`];
    const familyIds=['garage_lived','garage_lived_half','garage_died'];const shopIds=['nessa_shop','nessa_shop_bereaved'];
    assert.equal(shown.paragraphs.filter(p=>familyIds.map(translated).includes(p)).length,1);
    assert.equal(shown.paragraphs.filter(p=>shopIds.map(translated).includes(p)).length,1);
    assert.ok(shown.paragraphs.includes(translated(expected.family)));assert.ok(shown.paragraphs.includes(translated(expected.shop)));
    assert.equal(shown.ending.id,endingOracle[final]);assert.equal(state.ending,endingOracle[final]);
    if(language==='ja') {assert.equal(has(`ep.${expected.family}`),true);assert.equal(has(`ep.${expected.shop}`),true);}
    const persisted=JSON.parse(slots.get(SAVE_KEY));
    assert.equal(persisted.completed,true);assert.equal(persisted.state.ending,shown.ending.id);
    assert.deepEqual(persisted.state.flags,flagsBefore);assert.deepEqual(persisted.state.choices,choicesBefore);assert.deepEqual(persisted.state.inventory,inventoryBefore);
    records.push({language,inputLanguage,gaveFilter,vent,final,restored,ending:shown.ending.id,familyId:expected.family,shopId:expected.shop,survivorsAuthored:expected.survivors,
      familyText:translated(expected.family),shopText:translated(expected.shop),flags:flagsBefore,choices:choicesBefore,hooks,boundary,
      dialogueTextSha256:hash(JSON.stringify(nodes)),endingBodySha256:hash(shown.ending.text),paragraphSha256:shown.paragraphs.map(hash),persistedCompleted:persisted.completed});
  }
  check('120 independent actual narrative/storage/ending cases', {cases:records.length,restoredAcrossLocales:records.filter(r=>r.restored).length,expectedEndings:[...new Set(records.map(r=>r.ending))]},()=>assert.equal(records.length,120));
  check('No missing localization for changed epilogue passage keys',missingKeys().filter(k=>k.startsWith('ep.')),()=>assert.deepEqual(missingKeys().filter(k=>k.startsWith('ep.')),[]));
  const sourcePins=JSON.parse(readFileSync(resolve(base,'critic-source-pins.json'),'utf8'));
  for(const p of sourcePins.files) assert.equal(hash(readFileSync(resolve(base,'critic-source',p.path))),p.sha256,p.path);
  const result={checkedAt:new Date().toISOString(),ok:true,nodeVersion:process.version,scope:'Independent CPU actual GameState, DialogueRunner, testCondition, Director.finish and Storage with in-memory localStorage; rendered menus/fades/world vent hooks replaced at boundaries. No browser, server, full-route, smartphone, gas measurement or blind quality claim.',
    sourcePinsSha256:hash(readFileSync(resolve(base,'critic-source-pins.json'))),probeSha256:hash(readFileSync(fileURLToPath(import.meta.url))),checks,before:old,records,bounded,
    inventionBoundary:'Half-measure loss of workshop livelihood and eventual four-person relocation are newly authored future consequences, not physical measurements or gas-derived inference. This review assesses internal state/prose consistency only.',
    remainingLimit:'nt_shop entry and final-intention flags are deliberate fixtures. This does not establish world traversal, complete Nessa/final quest reachability, rendered chronology, actual storage/browser compatibility or blinded literary quality.'};
  writeFileSync(out,JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify({ok:true,checks:checks.length,cases:records.length,beforeCases:old.length,out,sha256:hash(readFileSync(out))}));
} catch(error) {
  const failure={checkedAt:new Date().toISOString(),ok:false,error:{name:error.name,message:error.message,stack:error.stack},checks,before:old,completedCases:records.length,records};
  const failOut=resolve(base,'critic-probe-failure.json');if(!existsSync(failOut))writeFileSync(failOut,JSON.stringify(failure,null,2)+'\n');throw error;
} finally {delete globalThis.localStorage;setLocale('en');}
