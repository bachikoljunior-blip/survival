import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,existsSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {fileURLToPath} from 'node:url';
import {dirname,join} from 'node:path';
import {spawnSync} from 'node:child_process';
import {CONVERSATIONS,EPILOGUE_BEATS} from './critic-source/src/content/story.js';
import {DialogueRunner,testCondition} from './critic-source/src/game/narrative.js';
import {Director} from './critic-source/src/game/director.js';
import {GameState,Storage,SAVE_KEY} from './critic-source/src/game/state.js';
import {setLocale,t,has} from './critic-source/src/content/i18n.js';
const BASE=dirname(fileURLToPath(import.meta.url));
const OUT=join(BASE,'raw-source-probes.json');assert.equal(existsSync(OUT),false,'Preserve existing independent probes.');
const hash=b=>createHash('sha256').update(b).digest('hex');
const pins=JSON.parse(readFileSync(join(BASE,'critic-source-pins.json')));
const raw=JSON.parse(readFileSync(join(BASE,'critic-raw.json')));
const preBytes=readFileSync(join(BASE,'critic-pre-refutation.json'));
const familyIds=['garage_lived','garage_lived_half','garage_died'],shopIds=['nessa_shop','nessa_shop_bereaved'];
const passages=new Map(EPILOGUE_BEATS.flatMap(b=>[b,...(b.variants||[])]).map(b=>[b.id,b.text]));
const slots=new Map();globalThis.localStorage={getItem:k=>slots.get(k)??null,setItem:(k,v)=>slots.set(k,String(v)),removeItem:k=>slots.delete(k)};
const checks=[],records=[];
const check=async(name,fn)=>{try{checks.push({name,status:'PASS',detail:await fn()});}catch(e){checks.push({name,status:'FAIL',error:String(e.stack||e)});}};
function verifyPins(){for(const p of pins.files)assert.equal(hash(readFileSync(join(BASE,'critic-source',p.path))),p.sha256,p.path);return pins.files.length;}
function walk(r){let n=40;while(r.active&&!r.choices()){assert(n-->0);r.advance();}}
function pick(r,target){const cs=r.choices();assert(cs);const i=cs.findIndex(c=>c.goto===target);assert(i>=0,target);assert.equal(Boolean(cs[i].locked),false);r.choose(i);}
function finishDialogue(r){walk(r);assert.equal(r.active,false,'Do not skip a pending choice.');}
function runner(state){return new DialogueRunner(state,{hooks:{shutVents(){},halfVents(){}}});}
function garage(state,give){const r=runner(state);r.start(CONVERSATIONS.garage);walk(r);if(r.active){pick(r,give?'g_filter':'g_air');finishDialogue(r);}return r;}
function vent(state,target){
 state.set('found_venting');state.set('sol_vent_talked'); // explicit upstream interaction prerequisites
 let opened=0,r;const notices=[];
 const ctx={state,game:{hud:{notice:(...args)=>notices.push(args)}},quests:{notify(){}},save(){},
  startConversation(convo,npc,done){opened++;r=runner(state);r.on('end',done);r.start(convo);}};
 Director.prototype._ventInteract.call(ctx);assert.equal(opened,1);
 pick(r,'v_'+target);finishDialogue(r);
 Director.prototype._ventInteract.call(ctx);assert.equal(opened,1,'Actual repeat-interaction guard must refuse a second vent choice');
 return {opened,repeatNotice:!!notices.length};
}
function clone(state){const d=state.serialise(),s=new GameState();assert.equal(s.deserialise(d),true);return s;}
async function emitted(state,lang){
 setLocale(lang);const copy=clone(state);copy.record('final','publish');let shown;
 const game={player:null,setMode(){},hud:{setVisible(){}},emit(){},menus:{fadeOut:async()=>{},fadeIn:async()=>{},showEnding:(e,p)=>shown={e,p}}};
 await Director.prototype.finish.call({game,state:copy});
 const ids=[...familyIds,...shopIds].filter(id=>shown.p.includes(t('ep.'+id,passages.get(id))));
 for(const id of ids)if(lang==='ja')assert.equal(has('ep.'+id),true);
 return {family:ids.filter(id=>familyIds.includes(id)),shop:ids.filter(id=>shopIds.includes(id)),paragraphs:ids.map(id=>({id,text:t('ep.'+id,passages.get(id))}))};
}
function restored(state,legacy){
 slots.clear();assert.equal(Storage.save(state,null,{completed:false}),true);
 if(legacy){const old=JSON.parse(slots.get(SAVE_KEY));delete old.v;old.state.v=1;slots.set(SAVE_KEY,JSON.stringify(old));}
 const loaded=Storage.load();assert(loaded);const result=new GameState();assert.equal(result.deserialise(loaded.state),true);
 assert.deepEqual([...result.flags],[...state.flags]);assert.deepEqual([...result.choices],[...state.choices]);assert.deepEqual([...result.inventory],[...state.inventory]);
 return {state:result,status:Storage.lastResult.status};
}
await check('fixed input SHA and all frozen source pins match',()=>{
 assert.equal(hash(preBytes),'764041e81c0105117096113cec76ea0b83f00395d725c789aeae54f5d4a01607');return {sourceFiles:verifyPins(),preRefutationSha256:hash(preBytes)};
});
await check('120 records have stated dimensions and narrower encountered/notified completed-choice scope',()=>{
 const rs=raw.records;assert.equal(rs.length,120);
 const keys=rs.map(r=>JSON.stringify([r.language,r.gaveFilter,r.vent,r.final,r.restored]));assert.equal(new Set(keys).size,120);
 assert.equal(rs.filter(r=>r.restored).length,60);
 assert(rs.every(r=>r.flags.includes('met_garage')&&r.flags.includes('nessa_shop_told')));
 assert(rs.filter(r=>r.restored).every(r=>r.inputLanguage!==r.language));
 return {records:120,uniqueCartesianCases:120,restoredCrossLocale:60,allMetGarage:true,allShopTold:true,
  limitation:'Does not itself cover no-meeting/no-notification gates, alternate conversation order, historical v1 bytes or full route reachability. The original review discloses node/final fixtures and full-route exclusions.'};
});
await check('no meeting/no notification and actual shop-choice gate resist leakage',async()=>{
 const details=[];
 for(const choice of ['leave','half','shut']){
  const s=new GameState();vent(s,choice);
  const before=await emitted(s,'en');assert.deepEqual(before.family,[]);assert.deepEqual(before.shop,[]);
  garage(s,false);const after=await emitted(s,'ja');assert.equal(after.family.length,1);assert.deepEqual(after.shop,[]);
  details.push({vent:choice,unmet:before.family,unnotified:after.shop});
 }
 const partial=new GameState(),r=runner(partial);r.start(CONVERSATIONS.garage);walk(r);pick(r,'g_filter');
 assert.equal(partial.has('gave_garage_filter'),true);assert.equal(partial.has('met_garage'),false);
 const checkpoint=restored(partial,true);assert.equal(checkpoint.status,'migrated');assert.deepEqual((await emitted(checkpoint.state,'en')).family,[]);
 finishDialogue(r);assert.equal(partial.has('met_garage'),true);
 const notify=async(known)=>{
  const s=new GameState();garage(s,false);vent(s,'leave');s.set('nessa_met');s.set('has_log'); // explicit upstream scene prerequisites
  if(known)garage(s,false); // real repeat branch sets ostrowski_bek
  const q=runner(s);q.start(CONVERSATIONS.nessa_truth);walk(q);pick(q,'nt_tell');walk(q);
  const offered=q.choices().map(c=>c.goto);assert.equal(offered.includes('nt_shop'),known);
  pick(q,known?'nt_shop':'nt_yours');finishDialogue(q);
  assert.equal(s.has('nessa_shop_told'),known);
  const text=await emitted(s,'ja');assert.deepEqual(text.shop,known?['nessa_shop_bereaved']:[]);
  return {known,offered,shop:text.shop,metGarage:s.has('met_garage')};
 };
 details.push({partialFilterBeforeMet:{legacyLoad:checkpoint.status,family:[]}});
 details.push(await notify(false),await notify(true));return details;
});
await check('targeted legal conversation order and restored v1/v2 state do not duplicate family endings in English or Japanese',async()=>{
 const cases=[
  {order:'vent-first',give:true,vent:'leave'},
  {order:'garage-first',give:true,vent:'leave'},
  {order:'garage-first',give:false,vent:'half'},
  {order:'vent-first',give:false,vent:'half'},
  {order:'vent-first',give:false,vent:'leave'},
  {order:'vent-first',give:false,vent:'shut'}
 ];
 for(const c of cases){
  const s=new GameState();
  if(c.order==='vent-first'){vent(s,c.vent);garage(s,c.give);}else{garage(s,c.give);vent(s,c.vent);}
  const expected=c.give||c.vent==='shut'?'garage_lived':c.vent==='half'?'garage_lived_half':'garage_died';
  for(const legacy of [false,true]){
   const rr=restored(s,legacy);assert.equal(rr.status,legacy?'migrated':'ok');
   for(const lang of ['en','ja']){
    const out=await emitted(rr.state,lang);assert.deepEqual(out.family,[expected]);assert.deepEqual(out.shop,[]);
    records.push({...c,legacy,loadStatus:rr.status,language:lang,family:out.family,shop:out.shop});
   }
  }
 }
 return {endingQueries:records.length,sourceConversationSequences:6,storageVariants:['current v2','constructed v1-shaped envelope'],
  limitation:'Uses actual offered choices and repeat-interaction guard with explicit upstream prerequisites; not full world routes. Legacy envelopes are constructed from actual resulting state, not claimed recovered historical user saves.'};
});
await check('observed old contradiction state and mixed-flag boundary restore to at most one family passage',async()=>{
 const original=JSON.parse(readFileSync(join(BASE,'before-reproduction.json')));
 const s=new GameState();s.flags=new Set(original.flags);s.choices=new Map(original.choices);s.inventory.set('filter',original.finalFilterCount);
 const rr=restored(s,true);const out=await emitted(rr.state,'en');assert.deepEqual(out.family,['garage_lived']);
 const mixed=clone(s);mixed.set('vents_shut');mixed.set('vents_half');const mr=restored(mixed,true);
 assert.deepEqual((await emitted(mr.state,'ja')).family,['garage_lived']);
 const impossible=new GameState();impossible.set('nessa_shop_told');const synthetic=await emitted(restored(impossible,false).state,'en');
 assert.deepEqual(synthetic.family,[]);assert.deepEqual(synthetic.shop,['nessa_shop']);
 return {observedOldRelevantState:{loadStatus:rr.status,family:out.family},mixedFlags:{family:['garage_lived'],reachableClaim:false},
  syntheticShopWithoutMeeting:{family:synthetic.family,shop:synthetic.shop,meaning:'A hand-constructed schema-valid inconsistent state activates the shop paragraph from its notification flag. It is not a legitimate source-sequence counterexample: the tested actual notification choice requires the shop-knowledge flag obtained after a met_garage-gated repeat visit.'}};
});
await check('reader evidence hashes and alternative variant negative controls sustain only reader coverage',()=>{
 const evidence=JSON.parse(readFileSync(join(BASE,'critic-reader-checks.json')));
 for(const r of evidence.records)for(const log of r.logs){const bytes=readFileSync(join(BASE,log.path));assert.equal(bytes.length,log.bytes);assert.equal(hash(bytes),log.sha256);}
 const controls=[
  {name:'validator-other-variant',code:"const {EPILOGUE_BEATS}=await import('./critic-source/src/content/story.js'); EPILOGUE_BEATS.find(b=>b.id==='nessa_shop').variants[0].condition={flag:'refuter_variant_never_set'}; await import('./critic-source/tools/validate.mjs');",status:1,needle:'refuter_variant_never_set'},
  {name:'locale-other-variant',code:"const {JA}=await import('./critic-source/src/content/locale/ja.js'); delete JA.ep.nessa_shop_bereaved; process.argv=[process.execPath,'tools/i18n_report.mjs','ja','--all']; await import('./critic-source/tools/i18n_report.mjs');",status:0,needle:'ep.nessa_shop_bereaved'}
 ];
 const outcomes=[];
 for(const c of controls){
  const r=spawnSync(process.execPath,['--input-type=module','-e',c.code],{cwd:BASE,encoding:'utf8'});
  writeFileSync(join(BASE,'refuter-'+c.name+'-stdout.log'),r.stdout||'');writeFileSync(join(BASE,'refuter-'+c.name+'-stderr.log'),r.stderr||'');
  assert.equal(r.error,undefined);assert.equal(r.status,c.status);assert((r.stdout+r.stderr).includes(c.needle));
  outcomes.push({name:c.name,exitCode:r.status,reported:c.needle});
 }
 return {originalEvidenceLogsVerified:8,independentControls:outcomes,
  limitation:'Unknown-condition-flag and missing-key readers are demonstrated. These controls do not prove mutual exclusion, outcome completeness, semantic translation quality, or game reachability. Locale-report zero is not a missing-translation gate pass.'};
});
verifyPins();assert.equal(hash(readFileSync(join(BASE,'critic-pre-refutation.json'))),hash(preBytes));
const result={scope:'Independent bounded garage refutation using fixed critic-source only; no product/source/original edits, no browser/server/CI, no additional agents.',checks,records,passed:checks.filter(c=>c.status==='PASS').length,failed:checks.filter(c=>c.status==='FAIL').length,
 authorshipBoundary:'New half-measure relocation/livelihood loss and revised shop visits are authored fictional consequences. These probes measure consistency of selected data with state; they do not turn that writing into measured gas behavior, historical fact or literary-quality approval.'};
writeFileSync(OUT,JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify({out:OUT,passed:result.passed,failed:result.failed,checks:checks.map(({name,status,error})=>({name,status,error})),queries:records.length},null,2));
delete globalThis.localStorage;setLocale('en');process.exitCode=result.failed?1:0;

