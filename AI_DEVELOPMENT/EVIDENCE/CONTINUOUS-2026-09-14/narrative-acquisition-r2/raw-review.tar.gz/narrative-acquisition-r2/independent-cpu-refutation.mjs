import assert from 'node:assert/strict';
import vm from 'node:vm';
import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {pathToFileURL} from 'node:url';
const P='/workspace/scratch/0b7ad82bafe7/narrative-acquisition-r2', S=P+'/source';
const read=p=>readFileSync(p,'utf8'), hash=b=>createHash('sha256').update(b).digest('hex');
const checks=[];const check=async(name,fn)=>{try{checks.push({name,status:'PASS',evidence:await fn()});}catch(e){checks.push({name,status:'FAIL',error:String(e.stack||e)});}};
const play=read(S+'/tools/playthrough.mjs'),driver=read(S+'/tools/driver.js'),screens=read(S+'/src/ui/screens.js');
const manifest=JSON.parse(read(P+'/source-manifest.json'));
await check('frozen target and bundle bytes match manifest; index names hashed bundle',()=>{
 const names=['tools/playthrough.mjs','tools/driver.js','.github/workflows/gates.yml','src/ui/screens.js','src/content/i18n.js','dist/index.html','dist/cinderline.1.0.0.js'];
 for(const n of names){const b=readFileSync(S+'/'+n);assert.equal(b.length,manifest.files[n].bytes);assert.equal(hash(b),manifest.files[n].sha256);}
 assert.match(read(S+'/dist/index.html'),/src="cinderline\.1\.0\.0\.js"/);
 return {verifiedFiles:names,bundleSha256:manifest.files['dist/cinderline.1.0.0.js'].sha256};
});
for(const lang of ['en','ja'])await check('independent log/base64/file UTF-8 identity '+lang,()=>{
 const lines=read(P+'/cpu-log-'+lang+'.txt').split('\n');
 const metas=lines.filter(l=>l.startsWith('[story-transcript] '));assert.equal(metas.length,1);
 const meta=JSON.parse(metas[0].slice('[story-transcript] '.length));
 const chunks=lines.filter(l=>l.startsWith('[story-transcript-data] ')).map(l=>{const m=l.match(/^\[story-transcript-data\] (\d+) ([A-Za-z0-9+/=]+)$/);assert(m);return {offset:+m[1],text:m[2]};});
 let offset=0;for(const c of chunks){assert.equal(c.offset,offset);offset+=c.text.length;}
 const bytes=Buffer.from(chunks.map(c=>c.text).join(''),'base64'), file=readFileSync(P+'/cpu-payload-'+lang+'.json');
 assert.deepEqual(bytes,file);assert.equal(bytes.length,meta.bytes);assert.equal(hash(bytes),meta.sha256);assert.equal(bytes.at(-1),10);
 const body=JSON.parse(new TextDecoder('utf-8',{fatal:true}).decode(bytes));
 if(lang==='ja')for(const token of ['𠮷','🔥','e\u0301'])assert(body.events.some(e=>e.text?.includes(token)));
 return {chunks:chunks.length,bytes:bytes.length,sha256:hash(bytes),newline:true};
});
const marker='if (TRANSCRIPT) await page.evaluate(() => {',a=play.indexOf(marker)+marker.length,b=play.indexOf('\n});',a);
assert(a>=marker.length&&b>a);
const instrument=G=>{const window={CINDERLINE:{game:G}};vm.runInNewContext('(()=>{'+play.slice(a,b)+'})()',{window});return window;};
await check('both wrappers preserve exact receiver, every argument, result and thrown object',()=>{
 const originals=[],value=Symbol('return'),args=[{x:1},[{text:'visible'}],{third:3},Symbol('extra')];
 const G={dialogueUI:{show:function(...xs){originals.push({receiver:this,args:xs});return value;}},menus:{showEnding:function(...xs){originals.push({receiver:this,args:xs});return value;}}};
 const w=instrument(G),dr={who:{textContent:'name'},full:'full'},er={endTitle:{textContent:'end'},endBody:{children:[{textContent:'paragraph'}]}};
 assert.equal(G.dialogueUI.show.apply(dr,args),value);assert.equal(G.menus.showEnding.apply(er,args),value);assert.equal(originals.length,2);
 for(let i=0;i<2;i++){assert.equal(originals[i].receiver,[dr,er][i]);assert.equal(originals[i].args.length,args.length);originals[i].args.forEach((v,j)=>assert.equal(v,args[j]));}
 assert.equal(w.__CLTranscript.length,2);
 const thrown={identity:'original error'},bad=instrument({dialogueUI:{show(){throw thrown;}},menus:{showEnding(){throw thrown;}}});
 for(const fn of [bad.CINDERLINE.game.dialogueUI.show,bad.CINDERLINE.game.menus.showEnding])assert.throws(()=>fn(),e=>e===thrown);
 assert.equal(bad.__CLTranscript.length,0);
 return {originalCalls:2,allArgumentsPreserved:true,exceptionIdentity:true,scope:'Valid current UI receiver shapes; recording can itself throw if its assumptions are broken.'};
});
const loc=await import(pathToFileURL(S+'/src/content/i18n.js').href),{JA}=await import(pathToFileURL(S+'/src/content/locale/ja.js').href);
const flat=new Map();function flatten(o,p=''){for(const [k,v]of Object.entries(o)){const key=p?p+'.'+k:k;if(typeof v==='string')flat.set(key,v);else if(v&&typeof v==='object')flatten(v,key);}}flatten(JA);
await check('actual localization/UI outputs and filtered-list choice index agree',async()=>{
 loc.setLocale('ja');
 const choiceKey=[...flat.keys()].find(k=>/^c\.[^.]+\.[^.]+\.choices\.[1-9]\d*$/.test(k));assert(choiceKey);
 const [,convo,nodeId,,ci]=choiceKey.split('.');
 const authored=[{text:'AUTHORED_CHOICE',ci:+ci,locked:false}],L=loc.localiseNode(convo,{id:nodeId,speaker:'ren',text:'AUTHORED_NODE'},authored);
 assert.equal(L.choices[0].text,flat.get(choiceKey));assert.equal(L.choices[0].ci,+ci);
 const extract=(name,end,globals)=>{const i=screens.indexOf('  '+name+'('),j=screens.indexOf(end,i);assert(i>=0&&j>i);return vm.runInNewContext('({'+screens.slice(i,j)+'}).'+name,globals);};
 const who={style:{},textContent:'',set innerHTML(v){this.textContent=v.replace(/<[^>]*>/g,'');}};
 const ui={node:{classList:{add(){}}},who,_drawPortrait(){},choicesNode:{innerHTML:''},next:{style:{}},_render(){}};
 ui.show=extract('show','\n  _afterType()',{CAST:{},isCJK:loc.isCJK,castName:loc.castName});
 const menus={fadeNode:{classList:{remove(){}}},endTitle:{textContent:''},endBody:{children:[],set innerHTML(v){this.children=[];}},endNode:{classList:{add(){}}}};
 menus.showEnding=extract('showEnding','\n  hideEnding()',{isCJK:loc.isCJK,el:(tag,cls,parent)=>{const n={style:{},textContent:''};parent.children.push(n);return n;}});
 const G={dialogueUI:ui,menus,mode:'D',fixedUpdate(){},director:{dialogue:{node:{},convo:{id:convo},choices:()=>authored}}},w=instrument(G);
 ui.show(L.node,L.choices);
 assert.equal(w.__CLTranscript[0].text,L.node.text.replace(/\n(?!\n)/g,'').replace(/ {2,}/g,' ').trim());
 assert.equal(w.__CLTranscript[0].choices[0].text,flat.get(choiceKey));assert.equal(w.__CLTranscript[0].speaker,loc.castName('ren','REN'));
 const endingTitleKey=[...flat.keys()].find(k=>/^e\.[^.]+\.title$/.test(k));assert(endingTitleKey);
 const endingPrefix=endingTitleKey.slice(0,-5),bodyKey=[...flat.keys()].find(k=>k.startsWith(endingPrefix)&&k!==endingTitleKey);assert(bodyKey);
 menus.showEnding({title:loc.t(endingTitleKey,'SOURCE'),text:loc.t(bodyKey,'SOURCE')},['追加\n段落']);
 assert.equal(w.__CLTranscript[1].title,flat.get(endingTitleKey));assert.equal(w.__CLTranscript[1].paragraphs.at(-1),'追加段落');
 const calls=[];ui._afterType=()=>{ui.choiceList=ui._pendingChoices;};ui.onChoose=function(i){assert.equal(this,ui);calls.push(i);G.mode='P';};
 w.CINDERLINE.MODE={DIALOGUE:'D',PLAY:'P'};
 vm.runInNewContext(driver,{window:w,setTimeout:fn=>{fn();return 0;},Date});
 await w.__CLDriver.converse(cs=>{assert.equal(cs,authored);return 0;});
 assert.deepEqual(calls,[0]);const e=w.__CLTranscript.at(-1);assert.equal(e.index,0);assert.equal(e.text,flat.get(choiceKey));assert.notEqual(e.index,+ci);
 loc.setLocale('en');
 return {choiceTranslationKey:choiceKey,originalCi:+ci,recordedFilteredIndex:e.index,endingTitleKey,endingBodyKey:bodyKey,scope:'Real localizer and UI methods under DOM stubs; not director ending-condition integration or browser rendering.'};
});
await check('frozen acquisition predicates separate driver, browser and incomplete events; count boundary retained',()=>{
 const s=play.indexOf('    const captureErrors = [];'),e=play.indexOf('    const transcript =',s);assert(s>=0&&e>s);
 const evaluate=vm.runInNewContext('(events,r,errors)=>{const path="publish",transcriptFailures=[];'+play.slice(s,e)+';return {captureErrors,executionSucceeded,transcriptFailures};}');
 const base=[{kind:'dialogue',text:'nonempty',choices:[{text:'offered'}]},{kind:'choice',index:0,text:'offered'},{kind:'ending',title:'ending',paragraphs:['body']}],ok={reachedEnding:true,errors:[]};
 const isFail=vm.runInNewContext('(results,errors,transcriptFailures)=>'+play.match(/const failed = (.+);/)[1]);
 const cases=[
  ['driver',base,{...ok,errors:['driver failure']},[]],
  ['browser',base,ok,['browser failure']],
  ['no events',[],ok,[]],
  ['no ending',base.slice(0,2),ok,[]],
  ['duplicate ending',[...base,base[2]],ok,[]],
  ['no choice',base.filter(x=>x.kind!=='choice'),ok,[]],
  ['empty ending',[...base.slice(0,2),{kind:'ending',title:'',paragraphs:[]}],ok,[]]
 ];
 const out=[];for(const [name,events,r,errors]of cases){const v=evaluate(events,r,errors);assert.equal(isFail([r],errors,v.transcriptFailures),true);out.push({name,executionSucceeded:v.executionSucceeded,captureErrors:[...v.captureErrors]});}
 const wrong=evaluate([base[0],{kind:'choice',index:99,text:'unoffered'},base[2]],ok,[]);
 assert.equal(wrong.executionSucceeded,true);assert.equal(wrong.captureErrors.length,0);
 assert.match(play,/captureSucceeded: executionSucceeded && captureErrors\.length === 0/);
 assert.match(play,/process\.exitCode = failed \? 1 : 0/);
 return {negativeCases:out,boundary:'A same-count unoffered choice passes these basic predicates. This demonstrates the disclosed absence of event identity/order verification, not a full host or browser run.'};
});
const result={method:'Independent frozen-source-only CPU checks; no browser/server, mutable root, original-review edits, or product edits.',checks,passed:checks.filter(x=>x.status==='PASS').length,failed:checks.filter(x=>x.status==='FAIL').length};
writeFileSync(P+'/independent-cpu-results.json',JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify(result,null,2));process.exitCode=result.failed?1:0;
