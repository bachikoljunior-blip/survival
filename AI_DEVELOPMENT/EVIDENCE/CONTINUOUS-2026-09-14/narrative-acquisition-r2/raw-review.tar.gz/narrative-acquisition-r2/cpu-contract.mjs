import assert from 'node:assert/strict';
import vm from 'node:vm';
import { readFileSync, writeFileSync, mkdirSync, readdirSync, copyFileSync, existsSync } from 'node:fs';
import { join, dirname, basename } from 'node:path';
import { createHash } from 'node:crypto';
import { pathToFileURL, fileURLToPath } from 'node:url';
import { execFileSync } from 'node:child_process';

const ROOT='/workspace/scratch/0b7ad82bafe7/survival';
const OUT='/workspace/scratch/0b7ad82bafe7/narrative-acquisition-r2';
const SNAP=join(OUT,'source');
mkdirSync(SNAP,{recursive:true});
const files=['tools/playthrough.mjs','tools/driver.js','.github/workflows/gates.yml','src/ui/screens.js','src/content/i18n.js','src/content/locale/ja.js','src/game/narrative.js','src/game/director.js','build.mjs','dist/index.html'];
for (const name of readdirSync(join(ROOT,'src/content/locale/ja'))) if (name.endsWith('.js')) files.push('src/content/locale/ja/'+name);
const bundles=readdirSync(join(ROOT,'dist')).filter(n=>/^cinderline\..+\.js$/.test(n));
assert.equal(bundles.length,1);
files.push('dist/'+bundles[0]);
const hash=b=>createHash('sha256').update(b).digest('hex');
const manifest={scope:'Frozen acquisition-method source and CPU-only contract fixtures; no browser/server or actual gameplay execution',head:execFileSync('git',['rev-parse','HEAD'],{cwd:ROOT,encoding:'utf8'}).trim(),files:{}};
for(const rel of files){
 const src=join(ROOT,rel), dst=join(SNAP,rel); mkdirSync(dirname(dst),{recursive:true});if (!existsSync(dst)) copyFileSync(src,dst);
 const bytes=readFileSync(dst); manifest.files[rel]={bytes:bytes.length,sha256:hash(bytes)};
}
writeFileSync(join(SNAP,'package.json'),JSON.stringify({type:'module'}));
writeFileSync(join(OUT,'source-manifest.json'),JSON.stringify(manifest,null,2)+'\n');
if (!existsSync(join(OUT,'reviewed.diff'))) writeFileSync(join(OUT,'reviewed.diff'),execFileSync('git',['diff','--','tools/playthrough.mjs','tools/driver.js','.github/workflows/gates.yml'],{cwd:ROOT}));
const play=readFileSync(join(SNAP,'tools/playthrough.mjs'),'utf8');
const driver=readFileSync(join(SNAP,'tools/driver.js'),'utf8');
const screens=readFileSync(join(SNAP,'src/ui/screens.js'),'utf8');
const results=[];
const check=async(name,fn)=>{try{const detail=await fn();results.push({name,status:'PASS',detail:detail??null});}catch(e){results.push({name,status:'FAIL',error:String(e.stack||e)});}};
const start=play.indexOf('if (TRANSCRIPT) await page.evaluate(() => {');
assert(start>=0);
const innerStart=start+'if (TRANSCRIPT) await page.evaluate(() => {'.length;
const innerEnd=play.indexOf('\n});',innerStart);
const installSource='(() => {'+play.slice(innerStart,innerEnd)+'})()';
const install=G=>{const window={CINDERLINE:{game:G}};vm.runInNewContext(installSource,{window});return window;};
const dialogueShape=()=>({who:{textContent:''},full:''});
const endingShape=()=>({endTitle:{textContent:''},endBody:{children:[]}});
await check('wrappers preserve exact receiver, arguments, return and original exceptions',()=>{
 const calls=[]; const returned={sentinel:true};
 const G={dialogueUI:{show:function(...args){calls.push({kind:'show',receiver:this,args});this.who.textContent='実際の表示名';this.full='実際の表示全文';return returned;}},menus:{showEnding:function(...args){calls.push({kind:'ending',receiver:this,args});this.endTitle.textContent='結末';this.endBody.children=[{textContent:'第一段落'},{textContent:'第二段落'}];return returned;}}};
 const window=install(G); const receiver=dialogueShape();const node={text:'AUTHORED SOURCE'}, choices=[{text:'画面の選択',locked:true,why:'理由',tag:'条件'}],extra={more:true};
 assert.equal(G.dialogueUI.show.call(receiver,node,choices,extra),returned);
 assert.equal(calls[0].receiver,receiver);assert.equal(calls[0].args[0],node);assert.equal(calls[0].args[1],choices);assert.equal(calls[0].args[2],extra);
 assert.equal(window.__CLTranscript[0].text,'実際の表示全文');assert.equal(window.__CLTranscript[0].speaker,'実際の表示名');
 const er=endingShape();const ep=['source paragraph'];
 assert.equal(G.menus.showEnding.call(er,node,ep,extra),returned);assert.equal(calls[1].receiver,er);assert.equal(calls[1].args[1],ep);
 assert.deepEqual(Array.from(window.__CLTranscript[1].paragraphs),['第一段落','第二段落']);
 const error=new Error('original exception');
 const bad=install({dialogueUI:{show(){throw error;}},menus:{showEnding(){throw error;}}});
 assert.throws(()=>bad.CINDERLINE.game.dialogueUI.show(),e=>e===error);assert.throws(()=>bad.CINDERLINE.game.menus.showEnding(),e=>e===error);assert.equal(bad.__CLTranscript.length,0);
 return 'Two wrappers called the original once with exact identity; original exceptions propagated without invented events.';
});
const loc=await import(pathToFileURL(join(SNAP,'src/content/i18n.js')).href);
const {JA}=await import(pathToFileURL(join(SNAP,'src/content/locale/ja.js')).href);
const method=(name,end,globals)=>{const a=screens.indexOf('  '+name+'('),b=screens.indexOf(end,a);assert(a>=0&&b>a);return vm.runInNewContext('({'+screens.slice(a,b)+'}).'+name,globals);};
await check('actual UI methods after actual Japanese localization produce normalized full text and DOM ending paragraphs',()=>{
 loc.setLocale('ja');
 const globals={CAST:{},isCJK:loc.isCJK,castName:loc.castName};
 const show=method('show','\n  _afterType()',globals);
 const who={style:{},set innerHTML(v){this.textContent=v.replace(/<[^>]*>/g,'');},textContent:''};
 const ui={node:{classList:{add(){}}},who,_drawPortrait(){},choicesNode:{innerHTML:''},next:{style:{}},_render(){}};
 const localized=loc.localiseNode('sol_first',{id:'start',speaker:'ren',text:'AUTHORED SOURCE'},null);
 assert.notEqual(localized.node.text,'AUTHORED SOURCE');
 const endingGlobals={isCJK:loc.isCJK,el:(tag,cls,parent)=>{const n={style:{},textContent:''};parent.children.push(n);return n;}};
 const showEnding=method('showEnding','\n  hideEnding()',endingGlobals);
 const menus={fadeNode:{classList:{remove(){}}},endTitle:{textContent:''},endBody:{children:[],set innerHTML(v){this.children=[];}},endNode:{classList:{add(){}}},showEnding};
 ui.show=show;
 const window=install({dialogueUI:ui,menus});
 ui.show(localized.node,localized.choices);
 const e=window.__CLTranscript[0];
 assert.equal(e.text,localized.node.text.replace(/\n(?!\n)/g,'').replace(/ {2,}/g,' ').trim());
 assert.equal(e.speaker,loc.castName('ren','REN'));
 menus.showEnding({title:'結末の見出し',text:'第一段落\n改行\n\n第二段落'},['追記\n全文']);
 assert.deepEqual(Array.from(window.__CLTranscript[1].paragraphs),['第一段落改行','第二段落','追記全文']);
 loc.setLocale('en');
 return 'Actual UI show/showEnding and production Japanese localizer were exercised with CPU DOM stubs; this is a method contract, not a browser capture.';
});
await check('driver records localized selected choice while choosing by authored index; preserves baseline calls',async()=>{
 const execute=async(enabled,picked=1)=>{
  const authored=[{text:'source A',locked:false},{text:'source B',locked:false}];
  const local=[{text:'選択肢あ',locked:false},{text:'選択肢い',locked:false}];
  const calls=[];
  const G={mode:'D',fixedUpdate(){},director:{dialogue:{choices:()=>authored,node:{},convo:{id:'cpu'}}}};
  const ui=G.dialogueUI={full:'表示全文',choiceList:local,_render(){},_afterType(){},onChoose(i){assert.equal(this,ui);calls.push(i);G.mode='P';}};
  const window={CINDERLINE:{game:G,MODE:{DIALOGUE:'D',PLAY:'P'}}};
  if(enabled)window.__CLTranscript=[];
  vm.runInNewContext(driver,{window,setTimeout:(fn)=>{fn();return 0;},Date});
  await window.__CLDriver.converse(list=>{assert.equal(list,authored);return picked;});
  return {calls,events:window.__CLTranscript};
 };
 const off=await execute(false),on=await execute(true);assert.deepEqual(on.calls,off.calls);assert.equal(on.events[0].index,1);assert.equal(on.events[0].text,'選択肢い');
 return {baselineCalls:off.calls,recordedCalls:on.calls,localizedChoiceRecorded:true};
});
const hostSource=play.replace(/^#!.*\n/,'').replace(/^import[^\n]*\n/gm,'').replaceAll('import.meta.url',JSON.stringify(pathToFileURL(join(ROOT,'tools/playthrough.mjs')).href));
const driverResult=path=>({path,chapter:5,ending:path==='deal'?'desk':'record',reachedEnding:true,questsDone:1,questsTotal:1,steps:1,trust:[],choices:[],flags:0,journal:0,errors:[],log:[]});
async function host({lang='en',events=true,pageError=false,driverError=false,bundleNames=bundles,flag=true,select=true,emitEnding=true,duplicateEnding=false,emptyEnding=false}={}){
 const writes=new Map(),logs=[],handlers={};let serverCalls=0,browserCalls=0;
 const G={dialogueUI:{...dialogueShape(),show(node,choices){this.who.textContent=lang==='ja'?'レン':'REN';this.full=node.text;}},menus:{...endingShape(),settings:{},showEnding(ending,paras){this.endTitle.textContent=ending.title;this.endBody.children=paras.map(textContent=>({textContent}));}},applySettings(){},emit(){}};
 const window={CINDERLINE:{game:G},__CLDriver:{run:async path=>{
  if(events){G.dialogueUI.show({text:lang==='ja'?'これは日本語の全文です。𠮷と絵文字🔥と結合e\u0301。\n'.repeat(150):'Full displayed English line. '.repeat(170)},[{text:lang==='ja'?'進む':'Continue',locked:false}]);if(select && window.__CLTranscript) window.__CLTranscript.push({kind:'choice',index:0,text:lang==='ja'?'進む':'Continue'}); if(emitEnding) G.menus.showEnding({title:emptyEnding?'':(lang==='ja'?'結末':'Ending')},emptyEnding?[]:[lang==='ja'?'第一段落。':'First paragraph.']); if(duplicateEnding) G.menus.showEnding({title:'Duplicate'},['Duplicate']);}
  if(pageError)handlers.pageerror(new Error('CPU injected page failure'));
  const r=driverResult(path);if(driverError)r.errors.push('CPU injected driver failure');return r;
 }}};
 const page={on(type,fn){handlers[type]=fn;},goto:async()=>{},waitForFunction:async()=>{},evaluate:async(fn,arg)=>typeof fn==='string'?undefined:fn(arg),screenshot:async()=>{}};
 const processFake={argv:['node','tools/playthrough.mjs','--path','publish',...(lang==='ja'?['--lang','ja']:[]),...(flag?['--transcript']:[])],exitCode:undefined,exit(c){throw Object.assign(new Error('early exit'),{exitCode:c});}};
 const context={window,document:{documentElement:{getAttribute:()=>lang}},process:processFake,console:{log:(...xs)=>logs.push(xs.join(' ')),error:(...xs)=>logs.push(xs.join(' '))},Buffer,createHash,join,dirname,fileURLToPath,
  mkdirSync(){},readdirSync:()=>bundleNames,
  readFileSync:(p,encoding)=>p.endsWith('driver.js')?driver:readFileSync(join(SNAP,'dist',basename(p)),encoding),
  writeFileSync:(p,data)=>writes.set(p,Buffer.from(data)),
  serveStatic:async()=>{serverCalls++;return {origin:'http://cpu.invalid',close:async()=>{}};},
  chromium:{launch:async()=>{browserCalls++;return {newContext:async()=>({newPage:async()=>page}),close:async()=>{}};}}};
 let thrown=null;try{await vm.runInNewContext('(async()=>{'+hostSource+'\n})()',context);}catch(e){thrown=String(e);}
 return {writes,logs,exitCode:processFake.exitCode,thrown,stubCalls:{serverCalls,browserCalls}};
}
const runs={};
await check('new exitCode path is present and transcript-disabled run creates no transcript',async()=>{
 assert.match(play,/process\.exitCode\s*=\s*failed\s*\?\s*1\s*:\s*0/);
 const r=await host({flag:false});assert.equal(r.exitCode,0);assert.equal([...r.writes.keys()].some(k=>k.includes('transcript-')),false);
 return 'No transcript event storage or file when optional flag is absent; final path assigns exitCode rather than forcing exit.';
});
await check('reported bundle SHA matches exact frozen bundle and multiple matches fail before launch',async()=>{
 const r=await host();const tr=JSON.parse([...r.writes].find(([k])=>k.includes('transcript-'))[1]);
 assert.equal(tr.bundleSha256,manifest.files['dist/'+bundles[0]].sha256);
 const index=readFileSync(join(SNAP,'dist/index.html'),'utf8');assert(index.includes('src="'+bundles[0]+'"'));
 const bad=await host({bundleNames:[...bundles,'cinderline.extra.js']});assert.match(bad.thrown,/Expected one actual game bundle/);assert.equal(bad.stubCalls.serverCalls,0);assert.equal(bad.stubCalls.browserCalls,0);
 return {bundle:bundles[0],sha256:tr.bundleSha256,multipleMatchesRejectedBeforeStubLaunch:true};
});
for(const lang of ['en','ja'])await check('lossless base64 payload and byte/hash roundtrip '+lang,async()=>{
 const r=await host({lang});runs[lang]=r;
 assert.equal(r.exitCode,0);assert.equal(r.thrown,null);
 const meta=JSON.parse(r.logs.find(x=>x.startsWith('[story-transcript] ')).slice('[story-transcript] '.length));
 const chunks=r.logs.filter(x=>x.startsWith('[story-transcript-data] ')).map(x=>{const m=x.match(/^\[story-transcript-data\] (\d+) (.*)$/);return {offset:+m[1],data:m[2]};});
 let next=0;for(const c of chunks){assert.equal(c.offset,next);next+=c.data.length;}
 const payload=Buffer.from(chunks.map(c=>c.data).join(''),'base64');
 const artifact=[...r.writes].find(([k])=>k.includes('transcript-'))[1];
 assert.equal(payload.length,meta.bytes);assert.equal(hash(payload),meta.sha256);assert.deepEqual(JSON.parse(payload),JSON.parse(artifact));
 assert.equal(artifact.length,payload.length);assert.equal(artifact.at(-1),10);assert.deepEqual(payload,artifact);
 writeFileSync(join(OUT,'cpu-log-'+lang+'.txt'),r.logs.join('\n')+'\n');
 writeFileSync(join(OUT,'cpu-payload-'+lang+'.json'),payload);
 return {chunks:chunks.length,payloadBytes:payload.length,artifactBytes:artifact.length,payloadSha256:meta.sha256,artifactSha256:hash(artifact),jsonValuesIdentical:true,byteIdenticalToArtifact:true,newlineIncludedInBoth:true};
});
await check('negative control: driver failure remains overall failure',async()=>{
 const r=await host({driverError:true});assert.equal(r.exitCode,1);assert(r.logs.some(x=>x==='\\nPLAYTHROUGH FAILED'||x.includes('PLAYTHROUGH FAILED')));
 const tr=JSON.parse([...r.writes].find(([k])=>k.includes('transcript-'))[1]);assert.equal(tr.execution.errors.length,1);
 return {exitCode:r.exitCode,driverErrors:tr.execution.errors};
});
await check('incomplete-capture negative controls fail acquisition without changing raw driver result',async()=>{
 const cases=[{name:'no events',options:{events:false}},{name:'no ending',options:{emitEnding:false}},{name:'duplicate ending',options:{duplicateEnding:true}},{name:'no selected event',options:{select:false}},{name:'empty ending title and paragraphs',options:{emptyEnding:true}}];
 const outcomes=[];
 for(const c of cases){
  const r=await host(c.options);const tr=JSON.parse([...r.writes].find(([k])=>k.includes('transcript-'))[1]);
  assert.equal(r.exitCode,1);assert.equal(tr.execution.reachedEnding,true);assert.equal(tr.execution.errors.length,0);assert.equal(tr.executionSucceeded,true);assert.equal(tr.captureSucceeded,false);assert(tr.captureErrors.length>0);assert.equal(tr.browserErrors.length,0);
  outcomes.push({case:c.name,exitCode:r.exitCode,captureErrors:tr.captureErrors,rawDriverReachedEnding:tr.execution.reachedEnding});
 }
 writeFileSync(join(OUT,'cpu-incomplete-capture-cases.json'),JSON.stringify(outcomes,null,2)+'\n');return outcomes;
});
await check('browser-error negative control exports explicit failure despite successful raw driver result',async()=>{
 const r=await host({pageError:true});const tr=JSON.parse([...r.writes].find(([k])=>k.includes('transcript-'))[1]);
 const report=JSON.parse([...r.writes].find(([k])=>k.endsWith('/playthrough.json'))[1]);
 assert.equal(r.exitCode,1);assert.equal(tr.execution.errors.length,0);assert.equal(report.errors.length,1);assert.equal(tr.browserErrors.length,1);assert.equal(tr.executionSucceeded,false);assert.equal(tr.captureSucceeded,false);assert.equal(tr.captureErrors.length,0);
 writeFileSync(join(OUT,'cpu-pageerror-case.json'),JSON.stringify({logs:r.logs,exitCode:r.exitCode,transcript:tr,report},null,2)+'\n');
 return {overallExitCode:r.exitCode,transcriptRawDriverErrors:tr.execution.errors.length,browserErrors:tr.browserErrors.length,executionSucceeded:tr.executionSucceeded,captureSucceeded:tr.captureSucceeded,interpretation:'Raw driver result is retained; aggregate browser/acquisition failure is explicit and process fails.'};
});
const result={method:'CPU-only execution of frozen source with explicit browser/server/DOM stubs. No real game playthrough or browser/server was started.',sourceManifest:join(OUT,'source-manifest.json'),checks:results,passed:results.filter(r=>r.status==='PASS').length,failed:results.filter(r=>r.status==='FAIL').length};
writeFileSync(join(OUT,'cpu-contract-results.json'),JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify(result,null,2));
process.exitCode=result.failed?1:0;
