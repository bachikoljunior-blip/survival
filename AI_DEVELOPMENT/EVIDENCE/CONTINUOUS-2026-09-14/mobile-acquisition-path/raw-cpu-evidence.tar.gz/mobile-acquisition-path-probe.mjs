// CPU-only execution of the actual gate body at mocked external boundaries.
// Browser imports are removed before evaluation; no browser process or server
// is launched, and no request is made. This proves routing/failure propagation,
// not MediaRecorder, rendered content, mobile behavior or audio quality.
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';

const repo = fileURLToPath(new URL('./survival/', import.meta.url));
const sourcePath = path.join(repo, 'tools/test-iphone-webkit.mjs');
const bytes = fs.readFileSync(sourcePath);
const sha = b => createHash('sha256').update(b).digest('hex');
const source = bytes.toString().replace(/^#![^\n]*\n/, '')
  .replace(/^import\s[\s\S]*?;\n/gm, '')
  .replaceAll('import.meta.url', JSON.stringify(new URL('./survival/tools/test-iphone-webkit.mjs', import.meta.url).href));
const cases = [];

for (const fixture of [
  {name:'complete audio capture', mode:true, clips:3, status:'captured', pass:true},
  {name:'incomplete audio capture', mode:true, clips:2, status:'captured', pass:false},
  {name:'missing capture capability', mode:true, clips:0, status:'not measured', pass:false},
  {name:'capture helper throws', mode:true, throws:true, pass:false},
  {name:'capture has a failed content check', mode:true, clips:3, status:'captured', failCheck:true, pass:false},
  {name:'page error during capture', mode:true, clips:3, status:'captured', pageError:true, pass:false},
  {name:'default retains full WebKit surface branch', mode:false, pass:false},
]) {
  const calls = [], handlers = {}, writes = {}, logs = [];
  let exitCode = 0;
  const device = {viewport:{width:667,height:375},dpr:2,maxTouchPoints:5,coarse:true,
    landscape:true,ready:true,running:true,canvas:{x:0,y:0,width:667,height:375},
    audio:{unlocked:false,contextCreated:false}};
  const page = {
    setDefaultTimeout(){}, on:(event,handler)=>{handlers[event]=handler;},
    goto:async()=>({status:()=>200}), waitForFunction:async()=>{},
    evaluate:async fn=>{
      if(fn.toString().includes('const canvas = document.getElementById')) return device;
      if(fn.toString().includes('game.menus.titleButtons')) {
        calls.push('complete-surface-entered'); throw new Error('CPU_ONLY_STOP_AT_FULL_SURFACE');
      }
      throw new Error('Unexpected page evaluation in source probe: '+fn.toString());
    },
    close:async()=>{calls.push('page-close');},
  };
  const context = {
    tracing:{start:async()=>{calls.push('trace-start');},stop:async()=>{calls.push('trace-stop');}},
    newPage:async()=>page, close:async()=>{calls.push('context-close');},
  };
  const fakeBrowser = {newContext:async()=>context,close:async()=>{calls.push('browser-close');}};
  const browserStub = name => ({launch:async()=>{calls.push(name+'-stub');return fakeBrowser;}});
  const env = {CINDERLINE_TEST_URL:'https://cpu-only.invalid/never-requested'};
  if(fixture.mode) Object.assign(env,{CINDERLINE_AUDIO_ONLY:'1',CINDERLINE_BROWSER:'chromium',CINDERLINE_WEBKIT_OUTPUT:'test-results/mobile-audio'});
  const scope = {
    ...path,fileURLToPath,
    createServer:()=>{throw new Error('Local server forbidden in source probe');},
    mkdirSync(){},writeFileSync:(p,body)=>{writes[p]=body;},readFileSync:()=>{throw new Error('Unexpected file read');},existsSync:()=>false,copyFileSync:()=>{throw new Error('Unexpected copy');},
    process:{env,exit:code=>{exitCode=code;}},
    console:{log:(...a)=>logs.push(a.join(' ')),error:(...a)=>logs.push(a.join(' '))},
    chromium:browserStub('chromium'),webkit:browserStub('webkit'),
    devices:{'iPhone SE (3rd gen) landscape':{viewport:{width:667,height:375},deviceScaleFactor:2,hasTouch:true,isMobile:true}},
    captureMobileAudio:async({check,report})=>{
      calls.push('capture-helper');
      if(fixture.throws) throw new Error('CPU_RECORDING_FAILURE');
      if(fixture.pageError) handlers.pageerror(new Error('CPU_PAGE_ERROR'));
      report.audioCapture={status:fixture.status,clips:Array.from({length:fixture.clips}),capabilities:{fixture:true}};
      if(fixture.failCheck) check(false,'CPU actual-content-check failure');
    },
  };
  await vm.runInNewContext('(async()=>{'+source+'})()', scope, {filename:sourcePath});
  const reportPath = path.join(repo,fixture.mode?'test-results/mobile-audio/report.json':'test-results/iphone-webkit/report.json');
  const report = JSON.parse(writes[reportPath]);
  assert.equal(report.status,fixture.pass?'passed':'failed');
  assert.equal(exitCode,fixture.pass?0:1);
  assert.equal(report.browser,fixture.mode?'chromium':'webkit');
  assert.equal(calls.filter(x=>x==='capture-helper').length,fixture.mode?1:0);
  assert.equal(calls.includes('complete-surface-entered'),!fixture.mode);
  assert.deepEqual(calls.slice(-4),['trace-stop','page-close','context-close','browser-close']);
  if(fixture.mode) {
    assert(report.scope.includes('acquisition only'));
    assert.equal(report.layout,null);assert.equal(report.visualRegression,null);
    assert.equal(report.persistence,null);assert.equal(report.soak,null);
  } else assert(report.failures.some(s=>s.includes('CPU_ONLY_STOP_AT_FULL_SURFACE')));
  cases.push({name:fixture.name,expectedStatus:fixture.pass?'passed':'failed',exitCode,calls,report,logs});
}
assert.equal(sha(fs.readFileSync(sourcePath)),sha(bytes),'Source changed during probe');
const result = {checkedAt:new Date().toISOString(),source:{path:'tools/test-iphone-webkit.mjs',sha256:sha(bytes)},
  scope:'Actual gate source body executed with mocked Playwright, capture and IO boundaries. No browser, server, network, image or audio execution. Default full branch stops at an intentional marker; only its routing is verified.',
  passed:cases.length,total:cases.length,cases};
fs.writeFileSync(new URL('./mobile-acquisition-path-probe.json',import.meta.url),JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify({passed:cases.length,total:cases.length,source:result.source}));
