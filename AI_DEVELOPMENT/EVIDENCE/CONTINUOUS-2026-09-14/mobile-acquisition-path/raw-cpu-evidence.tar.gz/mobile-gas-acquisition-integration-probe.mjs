// Executes the unmodified acquisition helper callbacks against real CPU City,
// narrative, gas, nav and save implementations. UI/appearance, browser calls,
// frame scheduling and screenshots are stubs; no image is generated or claimed.
import fs from 'node:fs';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
import {buildCpuCity,THREE} from './cpu-city-fixture-v2.mjs';
import {Game,MODE} from './survival/src/game/game.js';
import {Director} from './survival/src/game/director.js';
import {GameState} from './survival/src/game/state.js';
import {QuestSystem,DialogueRunner} from './survival/src/game/narrative.js';
import {QUESTS} from './survival/src/content/story.js';
import {Enemy} from './survival/src/game/ai.js';
import {exerciseGasConsequences} from './survival/tools/mobile_gas_consequences.mjs';

const repo=new URL('./survival/',import.meta.url),hash=b=>createHash('sha256').update(b).digest('hex');
const files=['tools/mobile_gas_consequences.mjs','src/main.js','src/game/director.js','src/game/state.js','src/game/narrative.js','src/content/story.js','src/content/world_data.js','src/world/city.js','src/world/gas.js','src/world/nav.js','src/game/game.js'];
const hashes=Object.fromEntries(files.map(p=>[p,hash(fs.readFileSync(new URL(p,repo)))]));
const {city}=buildCpuCity(),checks=[],flow=[],storage=new Map();
globalThis.localStorage={getItem:k=>storage.get(k)??null,setItem:(k,v)=>storage.set(k,String(v)),removeItem:k=>storage.delete(k)};
const noop=()=>{};
const game={city,gas:city.gas,nav:city.nav,world:city.collision,time:0,playTime:0,mode:MODE.PLAY,actors:[],systems:[],
  input:{step:noop},_playerInput:noop,_updateZone:noop,
  ai:{clearProjectiles:noop},camera:{},
  atmos:{setMarkers:noop,setMarkerActive:noop,plumes:{setAnchorActive:noop}},
  hud:{notice:noop,showAutosave:noop,hideAutosave:noop,setVisible:noop,showCard:noop},
  menus:{hideTitle:noop,fadeOut:async()=>{},fadeIn:async()=>{}},dialogueUI:{show:noop,hide:noop},
  setMode:m=>{game.mode=m;},emit:noop,
  teleport:id=>{const p=city.spawns.get(id);assert(p,'Unknown spawn');game.player.placeAt(p.x,p.y,p.z,p.rot);return true;},
};
game.player=new Enemy('scav',{x:0,y:0,z:0,world:city.collision,gas:city.gas,mats:{character:()=>new THREE.MeshStandardMaterial()},weapon:null,seed:17});
const d=Object.create(Director.prototype);
Object.assign(d,{game,state:new GameState(),npcs:new Map(),encounters:new Map(),currentInterior:null,crisis:null,_markerTargets:{},refreshCast:noop});
game.director=d;game.state=d.state;d.ctx={game,state:d.state,hooks:d._hooks()};
d.quests=new QuestSystem(d.state,QUESTS,d.ctx);d.dialogue=new DialogueRunner(d.state,d.ctx);
const main=fs.readFileSync(new URL('src/main.js',repo),'utf8');
const start=main.indexOf('  const startNewGame = async () => {'),end=main.indexOf('    // What to say about a save',start);
assert(start>=0&&end>start);
const actualStart=new Function('game','MODE','t','warnStorage','let leavingTitle = false;\n'+main.slice(start,end)+'\nreturn startNewGame;')(game,MODE,(_k,f)=>f,noop);
globalThis.window={CINDERLINE:{game,city,startNewGame:async()=>{flow.push({type:'new-game-start',flags:[...d.state.flags]});await actualStart();flow.push({type:'new-game-finished',flags:[...d.state.flags]});}}};
const page={evaluate:async(fn,arg)=>fn(arg),screenshot:async({path})=>flow.push({type:'screenshot-stub-no-file',path})};
const report={browser:'CPU fixture; no browser',checks};
await exerciseGasConsequences({page,root:repo.pathname.replace(/\/$/,''),output:'/cpu-fixture/no-screenshots',
  check:(passed,name,detail)=>{checks.push({passed:!!passed,name,detail});return !!passed;},report,
  waitFrames:async(_page,count)=>{for(let i=0;i<count;i++)Game.prototype.fixedUpdate.call(game,1/60);},
});
assert.equal(flow.filter(r=>r.type==='new-game-finished').length,3);
for(const p of files)assert.equal(hash(fs.readFileSync(new URL(p,repo))),hashes[p],'Source changed: '+p);
const result={checkedAt:new Date().toISOString(),sourceHashes:hashes,
  scope:'Unmodified helper evaluated in Node with actual City, source-extracted startNewGame closure, Director.startConversation, DialogueRunner.choose, Game.fixedUpdate, Storage.save and Director.applySave. Canvas/text, UI, browser methods and screenshots are stubs. Forty requested frames become exactly forty 1/60-second CPU ticks; this is not the browser scheduler. No physical render/audio/touch/quality result.',
  filesCreatedByScreenshotStub:0,passed:checks.filter(r=>r.passed).length,total:checks.length,flow,report};
fs.writeFileSync(new URL('./mobile-gas-acquisition-integration-probe.json',import.meta.url),JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify({passed:result.passed,total:result.total,failures:checks.filter(r=>!r.passed),
  yardFull:report.gasConsequences.after.points[3],yardHalf:report.gasConsequences.half.after.points[3]}));
if(checks.some(r=>!r.passed))process.exitCode=1;
