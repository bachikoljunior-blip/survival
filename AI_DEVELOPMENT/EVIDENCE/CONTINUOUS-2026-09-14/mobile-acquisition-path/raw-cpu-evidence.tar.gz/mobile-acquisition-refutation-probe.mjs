import { readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import { GasField } from './survival/src/world/gas.js';
import { Director } from './survival/src/game/director.js';
import { GameState } from './survival/src/game/state.js';
import { DialogueRunner } from './survival/src/game/narrative.js';
import { CONVERSATIONS } from './survival/src/content/story.js';

const root = new URL('./survival/', import.meta.url);
const files = ['tools/test-iphone-webkit.mjs', '.github/workflows/gates.yml',
  'tools/mobile_gas_consequences.mjs', 'tools/mobile_audio_capture.mjs',
  'src/main.js', 'src/game/director.js', 'src/game/narrative.js',
  'src/game/state.js', 'src/game/game.js', 'src/content/story.js',
  'src/world/gas.js', 'src/content/world_data.js'];
const sources = Object.fromEntries(files.map(path => {
  const bytes = readFileSync(new URL(path, root));
  return [path, {sha256: createHash('sha256').update(bytes).digest('hex'), bytes: bytes.length}];
}));
const rows = [];
function verify(name, f) {
  const detail=f(); rows.push({name, passed:true, detail});
}

const surface = readFileSync(new URL(files[0], root), 'utf8');
const workflow = readFileSync(new URL(files[1], root), 'utf8');
const checkFunction = surface.slice(surface.indexOf('function check('), surface.indexOf('\nfunction quantile('));
verify('Exact check function rejects absent capability and fewer than three clips', () => {
  const outcomes=[];
  for (const [status,count] of [['not measured',0],['captured',2],['captured',3]]) {
    const sandbox={report:{checks:[],failures:[],audioCapture:{status,clips:Array(count).fill({})}}};
    vm.runInNewContext(`${checkFunction}\ncheck(report.audioCapture.status === 'captured' && report.audioCapture.clips.length === 3, 'acquisition');`,sandbox);
    const failures=sandbox.report.failures.length;
    assert.equal(failures,status==='captured'&&count===3?0:1);
    outcomes.push({status,count,failures});
  }
  return outcomes;
});
verify('Earlier soft audio checks cannot be erased by successful three-clip check', () => {
  const sandbox={report:{checks:[],failures:[],audioCapture:{status:'captured',clips:[{},{},{}]}}};
  vm.runInNewContext(`${checkFunction}\ncheck(false,'audio clock did not advance');check(report.audioCapture.status === 'captured' && report.audioCapture.clips.length === 3,'acquisition');`,sandbox);
  assert.equal(sandbox.report.failures.length,1);
  assert.match(surface,/report\.status = report\.failures\.length \? 'failed' : 'passed'/);
  assert.match(surface,/if \(report\.failures\.length\) process\.exit\(1\)/);
  return {failures:sandbox.report.failures,globalFailureAssignment:true,nonzeroExitPredicate:true};
});
verify('Full WebKit workflow step retains complete-default mode; only later Chromium step opts into acquisition', () => {
  const full=workflow.slice(workflow.indexOf('      - name: Exercise the iPhone SE 3 WebKit surface'),workflow.indexOf('      - name: Preserve WebKit'));
  const audio=workflow.slice(workflow.indexOf('      - name: Capture production sound and video in Chromium'),workflow.indexOf('      - name: Preserve original production'));
  assert.match(full,/CINDERLINE_REQUIRE_BASELINE: "1"/);
  assert.doesNotMatch(full,/CINDERLINE_AUDIO_ONLY|CINDERLINE_BROWSER/);
  assert.match(audio,/CINDERLINE_BROWSER: chromium/);
  assert.match(audio,/CINDERLINE_AUDIO_ONLY: "1"/);
  assert.doesNotMatch(workflow,/continue-on-error:/);
  assert.equal((workflow.match(/CINDERLINE_AUDIO_ONLY:/g)||[]).length,1);
  assert.match(surface,/const AUDIO_ONLY = process\.env\.CINDERLINE_AUDIO_ONLY === '1'/);
  return {fullStep:full,audioStep:audio,continueOnError:false};
});

// Host stubs provide only the non-reviewed rendering/UI/services needed to run
// actual GameState, DialogueRunner, Director hooks/reset/_restoreGas and GasField.
// This is a CPU control-state probe, not a browser, full City, save I/O or gas-quality measurement.
const gas = new GasField(-160,-140,-60,-40,4);
for(let i=1;i<=3;i++) gas.addSource(-150+i*10,-120,100,4,`vent_west_${i}`,true);
gas.addSource(-112,-84,1100,26,'yard_seep',false);
gas.addSource(-112,-84,700,26,'yard_half_seep',false);
const noop=()=>{};
const g={gas,city:{removeRuntimeProps:noop,lightMarkers:[],interactions:[],data:{
  gasSources:[{id:'yard_seep',active:false},{id:'yard_half_seep',active:false}],
  props:[1,2,3].map(i=>({id:`vent_west_${i}`,kind:'vent'}))}},
  atmos:{setMarkers:noop,setMarkerActive:noop,plumes:{setAnchorActive:noop}},
  actors:[],ai:{clearProjectiles:noop},hud:{notice:noop}};
const d={game:g,state:new GameState(),npcs:new Map()};
const runner = new DialogueRunner(d.state,{hooks:Director.prototype._hooks.call(d)});
const current=()=>new Map(gas.sources.map(s=>[s.id,s.active]));
const acceptsHalf=s=>s.get('vent_west_1')===true&&s.get('vent_west_2')===false&&s.get('vent_west_3')===true
  &&s.get('yard_half_seep')===true&&s.get('yard_seep')===false;

verify('Actual visible choice index 2 calls halfVents and rejects deliberately inherited full-closure world', () => {
  runner.start(CONVERSATIONS.vent_decision);assert.equal(runner.choices().length,3);runner.choose(0);
  assert.equal(d.state.has('vents_shut'),true);
  runner.start(CONVERSATIONS.vent_decision);runner.choose(2);
  assert.equal(d.state.choices.get('vents'),'half');
  assert.equal(d.state.has('vents_half'),true);
  assert.equal(acceptsHalf(current()),false);
  return {fixture:'Deliberately omitted state.reset and resetWorld before actual choice 2',sources:[...current()],halfAssertion:false};
});
verify('Actual state.reset and resetWorld remove the full-closure contamination before choice 2', () => {
  d.state.reset();Director.prototype.resetWorld.call(d);
  assert.equal(d.state.has('vents_shut'),false);
  runner.start(CONVERSATIONS.vent_decision);runner.choose(2);
  assert.equal(d.state.has('vents_shut'),false);
  assert.equal(d.state.has('vents_half'),true);
  assert.equal(acceptsHalf(current()),true);
  return {sources:[...current()],halfFlag:true,shutFlag:false};
});
verify('Actual _restoreGas rebuilds omitted half rows; stale shut flag is detectable by the same source assertions', () => {
  const oldShape={gasSources:[...current()].filter(([id])=>!id.startsWith('vent_west_')&&id!=='yard_half_seep'),gasIntensity:1.15};
  Director.prototype.resetWorld.call(d);
  Director.prototype._restoreGas.call(d,oldShape);
  assert.equal(acceptsHalf(current()),true);
  const valid=[...current()];
  d.state.set('vents_shut',true);
  Director.prototype.resetWorld.call(d);
  Director.prototype._restoreGas.call(d,oldShape);
  assert.equal(acceptsHalf(current()),false);
  return {syntheticOmittedRows:oldShape,validSources:valid,deliberatelyStaleFlagSources:[...current()],staleFlagAccepted:false};
});

const result={scope:'Independent CPU and source refutation of acquisition dispatch, failure accounting and middle-choice contamination; no browser, recordings or full City were launched/measured.',sources,checks:rows};
writeFileSync(new URL('./mobile-acquisition-refutation-probe.json', import.meta.url),JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify({checks:rows.length,passed:rows.every(r=>r.passed)}));
