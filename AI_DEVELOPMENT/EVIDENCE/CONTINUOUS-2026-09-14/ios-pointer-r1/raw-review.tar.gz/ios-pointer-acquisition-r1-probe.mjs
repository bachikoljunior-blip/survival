import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import vm from 'node:vm';
import assert from 'node:assert/strict';
import { nativePointerActions } from './ios-pointer-acquisition-r1-source/tools/ios-pointer-coordinates.mjs';

const root = process.cwd();
const snapshot = path.join(root, 'ios-pointer-acquisition-r1-source');
const original = fs.readFileSync(path.join(snapshot, 'tools/test-ios-safari.mjs'), 'utf8');
const source = original.replace(/^#!.*\n/, '').replace(/^import .*;\n/gm, '').replaceAll('import.meta.url', JSON.stringify(`file://${snapshot}/tools/test-ios-safari.mjs`));
const hash = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
const png = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+/l2kAAAAASUVORK5CYII=', 'base64');

async function run(config) {
  let clock = 0, calibrationPending = false, readyAfterCalibration = false;
  let calibrationCount = 0, injected = false, exitCode = null;
  const calls = [], logs = [], files = new Map();
  const calibration = {offsetX:8,offsetY:24,pixelRatioX:2,pixelRatioY:2};
  const failureState = {mode:'title',ready:true,frame:31,input:[],viewport:{width:667,height:375}};
  const expectedImage = config.oversize ? Buffer.alloc(1500001, 97) : png;
  const newGame = {name:'new',x:100,y:140,width:240,height:48};
  function execute(script) {
    calls.push({kind:'execute',script:script.slice(0,160)});
    if (script === 'mobile: calibrateWebToRealCoordinatesTranslation') {
      assert.equal(injected,false,'calibration precedes instrumentation');
      calibrationCount++; calibrationPending = true;
      return calibration;
    }
    if (script.includes('CINDERLINE.ready === true')) {
      if (calibrationPending) { calibrationPending = false; return false; }
      if (calibrationCount) readyAfterCalibration = true;
      return true;
    }
    if (script.includes('localStorage.clear()')) return true;
    if (script.includes('window.__cinderlineIosErrors = []')) {
      assert.equal(readyAfterCalibration,true); injected = true; return true;
    }
    if (script.includes("var canvas = document.getElementById('gl')")) {
      assert.equal(injected,true);
      return {viewport:{width:667,height:375},visualViewport:{width:667,height:375},dpr:2,maxTouchPoints:5,
        userAgent:'CPU boundary Mobile/1 Safari/1',platform:'CPU',coarse:true,landscape:true,ready:true,running:true,
        build:'CPU fixture, not product measurement',canvas:{x:0,y:0,width:667,height:375}};
    }
    if (script.includes('var buttons = window.CINDERLINE.game.menus.titleButtons')) {
      return {documentWidth:667,viewportWidth:667,buttons:[newGame,{name:'settings',x:100,y:190,width:240,height:48},{name:'credits',x:100,y:240,width:240,height:48}]};
    }
    if (script === 'return {innerWidth,innerHeight,outerWidth,outerHeight};') {
      return {innerWidth:667,innerHeight:375,outerWidth:667,outerHeight:375};
    }
    if (script.includes('game.mode === window.CINDERLINE.MODE.PLAY')) return false;
    if (script.includes('mode:C && C.game.mode')) {
      if (config.diagnosticsFail) throw new Error('CPU failure-state boundary unavailable');
      return failureState;
    }
    throw new Error(`Unmodeled CPU boundary: ${script.slice(0,120)}`);
  }
  const context = vm.createContext({
    Buffer, URL, nativePointerActions, createHash:crypto.createHash,
    dirname:path.dirname, extname:path.extname, join:path.join, normalize:path.normalize, resolve:path.resolve,
    fileURLToPath: url => new URL(url).pathname,
    mkdirSync: () => {},
    writeFileSync: (file, bytes) => { files.set(file,Buffer.from(bytes)); },
    readFileSync: file => { assert(files.has(file),`fixture file exists: ${file}`); return files.get(file); },
    createServer: () => { throw new Error('CPU guard: no local server may start'); },
    fetch: async url => { calls.push({kind:'http-reachability-stub',url:String(url)}); return {status:200}; },
    Date: class extends Date { constructor(...args) { super(...(args.length ? args : [Date.parse('2026-09-14T00:00:00Z')+clock])); } static now() { return clock; } },
    setTimeout: (done, ms) => { clock += ms; queueMicrotask(done); },
    console:{log:(...args)=>logs.push(args.join(' ')),error:(...args)=>logs.push(args.join(' '))},
    process:{env:{CINDERLINE_TEST_URL:'https://cpu-fixture.invalid/',IOS_SIMULATOR_UDID:config.missingUdid?'':'cpu-fixture',IOS_SIMULATOR_PLATFORM_VERSION:'18.5'},exit:code=>{exitCode=code;}},
    requestWebDriver: async (url, options={}) => {
      const name = url.pathname, method = options.method || 'POST';
      calls.push({kind:'webdriver-stub',path:name,method});
      if(name==='/session') return {sessionId:'cpu-fixture'};
      if(name.endsWith('/execute/sync')) return execute(options.body.script);
      if(name.endsWith('/orientation') || name.endsWith('/url') || name.endsWith('/refresh')) return null;
      if(name.endsWith('/actions')) {
        if(method==='POST') {
          assert.equal(calibrationCount,1); assert.equal(injected,true);
          assert.deepEqual(JSON.parse(JSON.stringify(options.body.actions[0].actions[0])),
            {type:'pointerMove',duration:0,x:228,y:188,origin:'viewport'});
        }
        return null;
      }
      if(name.endsWith('/screenshot')) {
        if(config.diagnosticsFail) throw new Error('CPU screenshot boundary unavailable');
        return expectedImage.toString('base64');
      }
      if(name==='/session/cpu-fixture' && method==='DELETE') {
        if(config.diagnosticsFail) throw new Error('CPU cleanup boundary unavailable');
        return null;
      }
      throw new Error(`Unmodeled WebDriver boundary: ${method} ${name}`);
    },
  });
  await new vm.Script(`(async()=>{\n${source}\n})()`,{filename:'pinned-test-ios-safari.mjs'}).runInContext(context);
  const reportEntry = [...files].find(([n])=>n.endsWith('/report.json'));
  assert(reportEntry); const report = JSON.parse(reportEntry[1].toString());
  const reportLog = logs.find(line=>line.startsWith('[ios-safari-report] '));
  assert.deepEqual(JSON.parse(reportLog.slice('[ios-safari-report] '.length)),report);
  assert.equal(report.status,'failed'); assert.equal(exitCode,1);
  assert.equal(report.failures.length,1,'diagnostic errors cannot erase/add a different primary failure');
  if(config.missingUdid) {
    assert.equal(report.checks.length,0); assert(report.failures[0].includes('IOS_SIMULATOR_UDID is required'));
    assert.equal(calls.length,0);
  } else {
    assert.equal(report.checks.length,9); assert(report.checks.every(x=>x.passed));
    assert(report.failures[0].includes('Safari condition timed out: return window.CINDERLINE.game.mode'));
    assert.equal(report.inputCalibration.length,1); assert.equal(report.inputActions.length,1);
    assert.equal(clock,30250,'fake clock measures the polling path, not actual iOS latency');
  }
  const header = logs.find(line=>line.startsWith('[ios-safari-image] '));
  let imageRoundTrip = null;
  if(!config.missingUdid && !config.diagnosticsFail) {
    assert.deepEqual(report.failureState,failureState);
    if(config.oversize) assert.equal(header,undefined,'over-cap image omitted from log while report remains');
    else {
      const meta=JSON.parse(header.slice('[ios-safari-image] '.length));
      let accumulated='';
      for(const line of logs.filter(x=>x.startsWith('[ios-safari-image-data] '))) {
        const [,offset,data]=line.match(/^\[ios-safari-image-data\] (\d+) (.*)$/);
        assert.equal(Number(offset),accumulated.length); assert(data.length<=4000); accumulated+=data;
      }
      const recovered=Buffer.from(accumulated,'base64'); assert.deepEqual(recovered,expectedImage);
      assert.equal(hash(recovered),meta.sha256); assert.equal(recovered.length,meta.bytes);
      imageRoundTrip={bytes:meta.bytes,sha256:meta.sha256};
    }
  }
  if(config.diagnosticsFail) {
    assert.equal(header,undefined); assert.equal(report.errors.length,3);
    assert(report.errors.some(x=>x.startsWith('failure state:')));
    assert(report.errors.some(x=>x.startsWith('failure screenshot:')));
    assert(report.errors.some(x=>x.startsWith('session cleanup:')));
  }
  return {name:config.name,passed:true,checksBeforeFailure:report.checks.length,primaryFailure:report.failures[0].split('\n')[0],
    diagnostics:report.errors,calibrationCount,readyAfterCalibration,injected,exitCode,imageRoundTrip,
    boundedImageSkipped:Boolean(config.oversize),reportLogExactlyMatchesFile:true,calls,report};
}

const checks=[];
for(const config of [
  {name:'Original first-tap timeout retains calibration/actions, diagnosis and exact report/PNG'},
  {name:'Diagnostic state, screenshot and cleanup failure preserve original failure and report',diagnosticsFail:true},
  {name:'Over-cap image stays on disk and is omitted from ordinary log without losing report',oversize:true},
  {name:'Pre-session failure still writes and prints original failure report',missingUdid:true},
]) checks.push(await run(config));

const callOccurrences=[...original.matchAll(/await calibratePointerCoordinates\(\);/g)].map(m=>m.index);
assert.equal(callOccurrences.length,2);
assert(callOccurrences[0] > original.indexOf("await execute('localStorage.clear(); return true;');"));
assert(callOccurrences[0] < original.indexOf('const device = await execute'));
assert(callOccurrences[1] > original.indexOf('const errorsBeforeReload = await execute'));
assert(callOccurrences[1] < original.indexOf('const continueButton = await execute'));
assert(original.slice(original.indexOf('const errorsBeforeReload = await execute'),callOccurrences[1]).includes("webdriver(sessionPath('/refresh')"));
const workflow=fs.readFileSync(path.join(snapshot,'.github/workflows/mobile-simulator.yml'),'utf8');
assert(workflow.includes("- 'tools/ios-pointer-coordinates.mjs'"));
assert(workflow.includes('appium driver install xcuitest@12.1.3'));
const output={checkedAt:new Date().toISOString(),sourceManifest:'ios-pointer-acquisition-r1-source.json',
  scope:'Actual pinned acquisition script executed with stubbed fs, HTTP, WebDriver and clock boundaries. No server, socket, browser, DOM rendering, trusted native event or actual iOS run. Good device/layout values and screenshot bytes are diagnostic fixtures, not game evidence.',
  sourceHash:hash(original),checks,staticChecks:{twoCalibrationCallsBeforeTitleAndContinue:true,refreshBeforeContinueCalibration:true,workflowIncludesHelperTrigger:true,pinnedDriverMatches:true},
  total:checks.length+1,passed:checks.length+1};
fs.writeFileSync('ios-pointer-acquisition-r1-probe.json',JSON.stringify(output,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({total:output.total,passed:output.passed,checks:checks.map(({name,passed,checksBeforeFailure,calibrationCount,imageRoundTrip,diagnostics})=>({name,passed,checksBeforeFailure,calibrationCount,imageRoundTrip,diagnostics}))},null,2));
