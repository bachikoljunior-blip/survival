import {readFileSync, writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import {nativePointerActions} from './ios-pointer-acquisition-r1-source/tools/ios-pointer-coordinates.mjs';
import {validateFindings} from './survival/.kit/lib/plan/findings.mjs';
const hash = b => createHash('sha256').update(b).digest('hex');
const manifest = JSON.parse(readFileSync('ios-pointer-acquisition-r1-source.json','utf8'));
for (const [path, sha] of Object.entries(manifest.files)) assert.equal(hash(readFileSync('ios-pointer-acquisition-r1-source/'+path)),sha,path);
for (const [path, sha] of Object.entries(manifest.upstreamAndOriginalLog)) assert.equal(hash(readFileSync(path)),sha,path);
const gate=readFileSync('ios-pointer-acquisition-r1-source/tools/test-ios-safari.mjs','utf8');
const web=readFileSync('appium-12.1.3-web.ts','utf8');
const gesture=readFileSync('appium-12.1.3-gesture.ts','utf8');
const checks=[];
const run=(name,f)=>checks.push({name,...f()});
const branch=web.slice(web.indexOf('    const shouldApplyPixelRatio ='),web.indexOf('  } else {',web.indexOf('    const shouldApplyPixelRatio =')));
assert.match(branch,/innerWidth > wvDims.outerWidth \|\| wvDims.innerHeight > wvDims.outerHeight/);
const driverPoint=Function('calibration','wvDims','x','y','const {offsetX,offsetY,pixelRatioX,pixelRatioY}=calibration;\n'+branch);
const calibration={offsetX:8,offsetY:21,pixelRatioX:0.73,pixelRatioY:1.21};
const action=(x,y)=>[{type:'pointer',id:'cpu',parameters:{pointerType:'touch'},actions:[{type:'pointerMove',origin:'viewport',duration:0,x,y},{type:'pointerDown',button:0},{type:'pause',duration:1},{type:'pointerUp',button:0}]}];
run('Helper follows both axes of the pinned OR branch with integer endpoint rounding',()=>{
  const results=[];
  for(const dims of [
    {name:'equal',innerWidth:667,innerHeight:375,outerWidth:667,outerHeight:375},
    {name:'neither exceeds',innerWidth:650,innerHeight:320,outerWidth:667,outerHeight:375},
    {name:'width only exceeds',innerWidth:700,innerHeight:320,outerWidth:667,outerHeight:375},
    {name:'height only exceeds',innerWidth:650,innerHeight:400,outerWidth:667,outerHeight:375},
    {name:'both exceed',innerWidth:700,innerHeight:400,outerWidth:667,outerHeight:375},
  ]) {
    const x=31.4,y=57.8,expected=driverPoint(calibration,dims,x,y);
    const point=nativePointerActions(action(x,y),calibration,dims)[0].actions[0];
    assert.equal(point.x,Math.round(expected.x));assert.equal(point.y,Math.round(expected.y));
    assert.ok(Math.abs(point.x-expected.x)<=0.5);assert.ok(Math.abs(point.y-expected.y)<=0.5);
    results.push({dims,driverFloat:expected,helperInteger:{x:point.x,y:point.y}});
  }
  const dims={innerWidth:667,innerHeight:375,outerWidth:667,outerHeight:375};
  const negative=nativePointerActions(action(1,2),{...calibration,offsetX:-3,offsetY:-4},dims)[0].actions[0];
  assert.equal(negative.x,-2);assert.equal(negative.y,-2);
  return {passed:true,results,negativeOffsetsAllowed:true,meaning:'Helper adds integer rounding to the calibrated driver branch. This is not bit-identical floating output or a measured native tap.'};
});
run('Missing or malformed calibration, viewport and pointer origin fail before dispatch',()=>{
  const dims={innerWidth:667,innerHeight:375,outerWidth:667,outerHeight:375}, rejected=[];
  const cases=[
    ['missing calibration',null,dims], ['missing viewport',calibration,null],
    ...['offsetX','offsetY','pixelRatioX','pixelRatioY'].map(k=>[`nonfinite ${k}`,{...calibration,[k]:NaN},dims]),
    ...['pixelRatioX','pixelRatioY'].flatMap(k=>[0,-1,Infinity,'1'].map(v=>[`${k}=${v}`,{...calibration,[k]:v},dims])),
    ...['innerWidth','innerHeight','outerWidth','outerHeight'].map(k=>[`${k}=0`,calibration,{...dims,[k]:0}]),
  ];
  for(const [name,c,v] of cases){assert.throws(()=>nativePointerActions(action(30,40),c,v));rejected.push(name);}
  for(const a of [
    {...action(30,40)[0].actions[0],origin:'pointer'},
    {...action(30,40)[0].actions[0],origin:{ELEMENT:'native'}},
    {...action(30,40)[0].actions[0],x:'30'},
    {...action(30,40)[0].actions[0],y:Infinity},
  ])assert.throws(()=>nativePointerActions([{type:'pointer',actions:[a]}],calibration,dims));
  return {passed:true,rejectedCalibrationAndViewportCases:rejected,invalidPointerCases:4};
});
run('Conversion preserves original arrays, action values and nonmove ticks',()=>{
  const original=action(30.2,40.3),before=JSON.stringify(original);
  const freeze=o=>{if(o&&typeof o==='object'){for(const v of Object.values(o))freeze(v);Object.freeze(o);}};freeze(original);
  const out=nativePointerActions(original,calibration,{innerWidth:800,innerHeight:375,outerWidth:667,outerHeight:375});
  assert.equal(JSON.stringify(original),before);assert.notEqual(out,original);assert.notEqual(out[0],original[0]);assert.notEqual(out[0].actions,original[0].actions);
  for(let i=0;i<out[0].actions.length;i++)assert.notEqual(out[0].actions[i],original[0].actions[i]);
  assert.deepEqual(out[0].actions.slice(1),original[0].actions.slice(1));
  return {passed:true,originalPreserved:true,newActionObjects:true,nonmoveValuesPreserved:true,
    note:'Nested metadata such as source.parameters is shared but is not mutated by this helper; it is not advertised as an independent deep clone.'};
});
const defs=gate.slice(gate.indexOf('function finger('),gate.indexOf('async function tap('));
const sequenceStart=gate.indexOf('  await performActions([\n    finger(\'move-thumb\'');
assert.ok(sequenceStart>=0);
const sequence=gate.slice(sequenceStart+'  await performActions('.length,gate.indexOf('\n  ]);',sequenceStart)+'\n  ]'.length);
const ctx=vm.createContext({attackX:590,attackY:280});
vm.runInContext(defs+'\nglobalThis.sequences='+sequence+';',ctx);
const actions=JSON.parse(JSON.stringify(ctx.sequences));
const preprocessing=gesture.slice(gesture.indexOf('  const preprocessedActions = actions'),gesture.indexOf('  this.log.debug(`Preprocessed actions:'));
const jsPreprocessing=preprocessing.replace(' as any;',';');
const preprocess=Function('actions','structuredClone',jsPreprocessing+'\nreturn preprocessedActions;');
function timelines(sources,sharedTicks){
  const active=new Set(),events=[],intervals=[];
  if(sharedTicks){
    let t=0;
    for(let i=0;i<Math.max(...sources.map(s=>s.actions.length));i++){
      const duration=Math.max(0,...sources.map(s=>s.actions[i]?.duration??0));
      for(const s of sources){const a=s.actions[i];if(a?.type==='pointerDown')active.add(s.id);if(a?.type==='pointerUp')active.delete(s.id);}
      if(active.size>=2&&duration>0)intervals.push({start:t,end:t+duration});
      events.push({tick:i,start:t,duration,active:[...active]});t+=duration;
    }
  }else{
    const edges=[];
    for(const s of sources){let t=0;for(const a of s.actions){if(a.type==='pointerDown'||a.type==='pointerUp')edges.push({t,id:s.id,down:a.type==='pointerDown'});t+=a.duration??0;}}
    edges.sort((a,b)=>a.t-b.t);
    for(let i=0;i<edges.length;i++){const e=edges[i];if(e.down)active.add(e.id);else active.delete(e.id);const end=edges[i+1]?.t??e.t;if(active.size>=2&&end>e.t)intervals.push({start:e.t,end});events.push({...e,active:[...active]});}
  }
  return {events,overlapMs:intervals.reduce((n,x)=>n+x.end-x.start,0),intervals};
}
run('Actual gate placeholders survive the pinned driver zero-pause filter and contact intervals overlap',()=>{
  assert.deepEqual(actions.map(s=>s.actions.length),[8,8]);
  assert.ok(actions.flatMap(s=>s.actions).filter(a=>a.type==='pause').every(a=>a.duration>0));
  const after=preprocess(actions,structuredClone);assert.deepEqual(after.map(s=>s.actions.length),[8,8]);
  const zeroControl=actions.map(s=>({...s,actions:s.actions.map(a=>a.type==='pause'&&a.duration===1?{...a,duration:0}:a)}));
  assert.deepEqual(preprocess(zeroControl,structuredClone).map(s=>s.actions.length),[6,6]);
  const tickModel=timelines(after,true),perSourceDurationModel=timelines(after,false);
  assert.ok(tickModel.overlapMs>0);assert.ok(perSourceDurationModel.overlapMs>0);
  return {passed:true,actions,preprocessed:after,zeroPauseControlLengths:[6,6],tickModel,perSourceDurationModel,
    scope:'Action schedule arithmetic under two timing interpretations, not native WDA execution. Both retain positive overlap; actual trusted contacts must still pass the instrumented gate.'};
});
function conditionFor(label,prefix){const s=gate.indexOf('check('+prefix);const e=gate.indexOf("'"+label+"'",s);assert.ok(s>=0&&e>s);return gate.slice(s+6,e).trim().replace(/,$/,'').trim();}
const titleCondition=conditionFor('trusted Mobile Safari tap starts a new game','titleInput.some');
const overlapCondition=conditionFor('two trusted touch contacts overlap in Safari','twoThumbInput.some');
const titlePass=Function('titleInput','newGame','return '+titleCondition);
const overlapPass=Function('twoThumbInput','return '+overlapCondition);
const scriptStart=gate.indexOf('  await execute(`',gate.indexOf('async function injectErrorCapture()'));
const captureScript=gate.slice(scriptStart+'  await execute(`'.length,gate.indexOf('`);',scriptStart));
function recorder(){
  const listeners=new Map(),window={addEventListener(){}};
  const context=vm.createContext({window,document:{addEventListener(type,fn){listeners.set(type,fn);}}});
  vm.runInContext('(function(){'+captureScript+'}).call(window);',context);
  return {window,event(type,id,{trusted=true,touch=true,x=20,y=30}={}){listeners.get(type)({type,pointerId:id,isTrusted:trusted,pointerType:touch?'touch':'mouse',clientX:x,clientY:y,target:{tagName:'DIV',id:'cpu',className:'btn',textContent:'CPU'}});},log(){return JSON.parse(JSON.stringify(window.__cinderlineIosInput));}};
}
run('Actual trusted-title predicate rejects untrusted, wrong-type and misplaced touch-up traces',()=>{
  const button={x:10,y:20,width:44,height:44},results=[];
  for(const [name,opts,want] of [['trusted inside',{},true],['untrusted',{trusted:false},false],['mouse',{touch:false},false],['outside',{x:100},false]]){
    const r=recorder();r.event('pointerdown',1,opts);r.event('pointerup',1,opts);
    const value=titlePass(r.log(),button);assert.equal(value,want);results.push({name,value,trace:r.log()});
  }
  return {passed:true,results,scope:'Predicate/recorder CPU test with explicitly supplied trust fields. This generates no trusted browser input; the separate PLAY wait and actual title-tap dispatch are reviewed by the parent.'};
});
run('Actual recorder and overlap predicate reject sequential, duplicate-id, untrusted and mouse contacts',()=>{
  const results=[];
  for(const [name,sequence,want] of [
    ['two trusted touch ids',[['pointerdown',1,{}],['pointerdown',2,{}]],true],
    ['sequential',[['pointerdown',1,{}],['pointerup',1,{}],['pointerdown',2,{}]],false],
    ['duplicate id',[['pointerdown',1,{}],['pointerdown',1,{}]],false],
    ['untrusted',[['pointerdown',1,{trusted:false}],['pointerdown',2,{trusted:false}]],false],
    ['mouse',[['pointerdown',1,{touch:false}],['pointerdown',2,{touch:false}]],false],
    ['cancel clears contact',[['pointerdown',1,{}],['pointercancel',1,{}],['pointerdown',2,{}]],false],
  ]){
    const r=recorder();for(const args of sequence)r.event(...args);
    const value=overlapPass(r.log());assert.equal(value,want);results.push({name,value,trace:r.log()});
  }
  return {passed:true,results,scope:'Actual capture script/condition executed at a fake event boundary; all generated events are CPU fixtures, not claims of native input.'};
});
const raw={checkedAt:new Date().toISOString(),scope:'Independent bounded review of pinned coordinate conversion, pause preservation/contact schedule and trust predicates. No product edit, browser, socket, server, actual iOS or new CI.',
  manifest:'ios-pointer-acquisition-r1-source.json',sources:manifest.files,upstreamSources:manifest.upstreamAndOriginalLog,
  driverCalibratedBranch:branch,driverPreprocessing:preprocessing,transformedPreprocessingSha256:hash(jsPreprocessing),
  transformations:['Removed only the TypeScript `as any` suffix from the exact driver preprocessing block before CPU execution.','Wrapped the exact calibrated branch in a function receiving recorded dimensions/calibration.','The recorder execute script is wrapped in a function, matching WebDriver script execution semantics; an initial bare-VM attempt rejected its top-level return before the trust cases ran. This was a probe harness correction, not a product defect.'],
  checks,titleCondition,overlapCondition};
writeFileSync('ios-pointer-acquisition-r1-refutation-probe.json',JSON.stringify(raw,null,2)+'\n',{flag:'wx'});
const review={verdict:'PASS',score:100,round:'ios-pointer-acquisition-r1-independent-refutation',profile:'Coordinate source conformance, action timing and trust-negative controls',tier:'Source and CPU only',nativeResolution:'0x0',
  blindComparison:'No blind comparison or actual iOS input measurement occurred. The source identities are known. CPU boundary values do not count as trusted browser events, a rendered quality result or satisfied product elements.',
  checkedAt:raw.checkedAt,reviewer:'/root/acquisition_path_review/acquisition_refutation',scope:raw.scope,
  verdictScope:'No concrete finding survived this bounded review of the pinned implementation. Actual Safari coordinate calibration, contact overlap and gameplay remain subject to the real gate.',
  sources:manifest.files,upstreamSources:manifest.upstreamAndOriginalLog,findings:[],
  conclusions:['The helper uses the pinned calibrated OR condition: either exceeding dimension activates both pixel ratios; equal or smaller dimensions use only offsets.',
    'Native integer output equals Math.round of the pinned branch for each tested axis; extra quantization is acknowledged rather than called identical floating-point translation.',
    'Malformed supplied calibration/viewport and unsupported/nonfinite pointer coordinates throw; negative offsets remain allowed.',
    'The helper leaves frozen input arrays and action values unchanged. Nested metadata sharing is harmless within the current nonmutating use but is not a deep-clone guarantee.',
    'All actual placeholder pauses are positive and survive the pinned driver filter. The preserved eight-tick two-finger schedules overlap under both checked timing interpretations.',
    'The actual recorder/predicates reject untrusted/wrong-type/outside new-game traces and nonoverlapping, repeated-id, untrusted or mouse-only two-contact traces.'],
  checks:{total:checks.length,passed:checks.filter(x=>x.passed).length},
  limitations:['CPU schedule arithmetic is not native WDA timing and cannot establish actual simultaneous touches.',
    'This review does not test display geometry, Safari chrome offsets, rotation/calibration reload order, full gate execution, report/PNG failure transport or original CI diagnosis; those are the parent scope.',
    'Trust booleans are supplied only to exercise the exact predicate truth table; no input was represented as actually trusted.',
    'The source calibration command rounds returned offsets while the internal driver stores floating offsets; this helper follows the public returned data with final integer rounding. Actual tap placement remains unmeasured.'],
  evidenceFiles:['ios-pointer-acquisition-r1-refutation-probe.mjs','ios-pointer-acquisition-r1-refutation-probe.json','ios-pointer-acquisition-r1-source.json']};
review.validation=validateFindings(review,{strict:true,knownOwners:new Set(Object.keys(manifest.files))});
assert.equal(review.validation.ok,true,JSON.stringify(review.validation));
writeFileSync('ios-pointer-acquisition-r1-refutation.json',JSON.stringify(review,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({path:'ios-pointer-acquisition-r1-refutation.json',checks:checks.length,validation:review.validation}));
