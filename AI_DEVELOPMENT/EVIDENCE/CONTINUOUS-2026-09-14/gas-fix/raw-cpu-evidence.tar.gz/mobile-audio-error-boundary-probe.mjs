import fs from 'node:fs';
import vm from 'node:vm';
import path from 'node:path';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {createRequire} from 'node:module';
const require=createRequire(import.meta.url);
const {serializeError,parseError}=require('./survival/node_modules/playwright-core/lib/server/errors.js');

// Reuse the explicitly fake API fixture, with a distinct refutation lens:
// every page.evaluate exception crosses the installed Playwright serializer.
// Add failing key release/settings restoration to verify later finalizers.
const harnessPath=new URL('./mobile-audio-capture-source-probe.mjs',import.meta.url);
const harness=fs.readFileSync(harnessPath,'utf8');
const end=harness.indexOf('\nconst results=[];');
assert.ok(end>0);
let prefix=harness.slice(0,end).replace(/^import .*;\n/gm,'');
function replaceExact(before,after){assert.equal(prefix.split(before).length,2,`missing or repeated fixture marker: ${before}`);prefix=prefix.replace(before,after);}
replaceExact('evaluate:async(fn,arg)=>fn(arg),','evaluate:async(fn,arg)=>{try{return await fn(arg);}catch(error){throw __parseError(__serializeError(error));}},');
replaceExact('up:async k=>keys.delete(k)','up:async k=>{events.push("release-key:"+k);if(faults.has("keyboard-release"))throw new Error("injected keyboard release");keys.delete(k);}');
replaceExact('applySettings(s){this.settings={...s};','applySettings(s){if(s.quality==="high"){events.push("restore-settings-attempt");if(faults.has("settings-restore")){restores++;throw new Error("injected settings restore");}}this.settings={...s};');
const outer=vm.createContext({fs,vm,createHash,path,Blob,Uint8Array,Buffer,btoa,setTimeout,clearTimeout,
  __serializeError:serializeError,__parseError:parseError});
vm.runInContext(prefix+'\nthis.runProbe=probe;',outer,{filename:'boundary-instrumented-fixture'});
const faults=[
  'recording-wait+disconnect','recorder-error+disconnect','recorder-start+disconnect',
  'recording-wait+keyboard-release','recording-wait+keyboard-release+settings-restore',
  'recorder-start+disconnect+keyboard-release+settings-restore',
];
const summaries=[];
for(const fault of faults){
  const row=await outer.runProbe(fault);
  const expected=[
    fault.includes('recording-wait')?'injected recording wait failure':fault.includes('recorder-error')?'injected asynchronous recorder error':'injected MediaRecorder.start',
    ...fault.includes('disconnect')?['injected comp.disconnect']:[],
    ...fault.includes('keyboard-release')?['injected keyboard release']:[],
    ...fault.includes('settings-restore')?['injected settings restore']:[],
  ];
  assert.ok(expected.every(message=>row.error.includes(message)),`${fault} lost a required diagnostic: ${row.error}`);
  const serialized=serializeError(new Error(row.error));
  const finalText=parseError(serialized).stack;
  assert.ok(expected.every(message=>finalText.includes(message)),`${fault} lost final report text`);
  assert.equal(row.recordingHandleRetained,false);assert.equal(row.originalAudibleConnectionPreserved,true);
  assert.equal(row.liveTracks.length,0);assert.ok(row.events.includes('restore-settings-attempt'));
  assert.ok(row.events.includes('stop-audio')&&row.events.includes('stop-video'));
  assert.equal(row.writes.length,0);
  summaries.push({fault,error:row.error,allRequiredMessagesPreserved:true,
    finalSerializedStackPreservesMessages:true,liveTracks:row.liveTracks,
    recordingHandleRetained:row.recordingHandleRetained,
    originalAudibleConnectionPreserved:row.originalAudibleConnectionPreserved,
    releaseKeyAttempts:row.events.filter(e=>e==='release-key:w').length,
    settingsRestorationAttempted:true,settingsRestored:row.settingsRestored,
    mediaFilesWritten:0});
}
const helper=fs.readFileSync(new URL('./survival/tools/mobile_audio_capture.mjs',import.meta.url),'utf8');
const evidence={sourceHash:createHash('sha256').update(helper).digest('hex'),
  scope:'Node VM fixture only. Exact helper callbacks run with fake APIs; every page.evaluate exception uses installed Playwright serializeError/parseError, then final stack-only reporting is checked. No browser, AudioContext, canvas, real MediaRecorder or media file is created.',
  fixtureSource:harnessPath.pathname,results:summaries};
fs.writeFileSync(new URL('./mobile-audio-error-boundary-probe.json',import.meta.url),JSON.stringify(evidence,null,2)+'\n');
console.log(JSON.stringify(evidence,null,2));
