import fs from 'node:fs';
import {createHash} from 'node:crypto';
import {buildCpuCity, THREE} from './cpu-city-fixture-v2.mjs';
import {Game, MODE} from './survival/src/game/game.js';
import {Director} from './survival/src/game/director.js';
import {Enemy, AISystem, AI_STATE} from './survival/src/game/ai.js';
import {NavGrid} from './survival/src/world/nav.js';
import {GasField} from './survival/src/world/gas.js';
import {CollisionWorld, Box, LAYER} from './survival/src/world/collision.js';
const sha=b=>createHash('sha256').update(b).digest('hex');
const floatHash=a=>sha(Buffer.from(a.buffer,a.byteOffset,a.byteLength));
const paths=['src/world/city.js','src/world/gas.js','src/world/nav.js','src/world/collision.js','src/game/game.js','src/game/ai.js','src/game/director.js','src/actors/actor.js','src/content/world_data.js'];
const sourceHashes=Object.fromEntries(paths.map(p=>[p,sha(fs.readFileSync(new URL('./survival/'+p,import.meta.url)))]));
const mats={character:()=>new THREE.MeshStandardMaterial()};
const dt=1/60;
function gameFor(world,gas,nav){return {time:0,playTime:0,mode:MODE.PLAY,input:{step(){}},world,gas,nav,actors:[],systems:[],_playerInput(){},_updateZone(){},_drainEvents:Game.prototype._drainEvents,emit(){}};}

function travel({world,nav,gas,kind='scav'},start,goal,maxSeconds=15,{forceSteering=false}={}){
  const game=gameFor(world,gas,nav);
  const actor=new Enemy(kind,{x:start.x,y:start.y,z:start.z,world,gas,mats,weapon:null,offhand:null,seed:17});
  actor.placeAt(start.x,start.y,start.z);
  actor.patrol=[{x:goal.x,z:goal.z},{x:start.x,z:start.z}];actor.aiState=AI_STATE.PATROL;actor.think=0;
  const ai=new AISystem(game),events=[];
  game.player={pos:new THREE.Vector3(1000,0,1000),height:1.7,dead:true,setMove(){}};
  game.actors=[actor];game.emit=(name,a,d)=>{if(name==='actor:gaspanic')events.push({time:game.time,name,data:d});};
  game.systems=forceSteering?[{update(){ai._moveTowards(actor,goal.x,goal.z,game,.42);}}]:[ai];
  const originalPath=nav.findPath,pathCalls=[];
  nav.findPath=function(...args){const p=originalPath.apply(this,args);pathCalls.push({time:game.time,start:args.slice(0,3),target:args.slice(3,6),budget:args[6],success:!!p,path:p});return p;};
  const trajectory=[];let distanceTravelled=0,previous=actor.pos.clone(),reached=false;
  try{for(let n=1;n<=maxSeconds*60;n++){
    Game.prototype.fixedUpdate.call(game,dt);
    distanceTravelled+=actor.pos.distanceTo(previous);previous.copy(actor.pos);
    const distance=Math.hypot(actor.pos.x-goal.x,actor.pos.z-goal.z);
    trajectory.push({tick:n,time:game.time,position:actor.pos.toArray(),velocity:actor.vel.toArray(),distance,
      ppm:actor.localPpm(gas),hp:actor.hp,state:actor.aiState,grounded:actor.grounded,move:{...actor.moveInput}});
    if(distance<1.4){reached=true;break;}
    if(actor.dead)break;
  }}finally{nav.findPath=originalPath;}
  return {kind,setup:{start,goal,maxSeconds,forceSteering},reached,distanceTravelled,final:trajectory.at(-1),
    maxPpm:Math.max(...trajectory.map(x=>x.ppm)),zRange:[Math.min(...trajectory.map(x=>x.position[2])),Math.max(...trajectory.map(x=>x.position[2]))],
    pathCalls,gasPanicEvents:events,trajectory};
}
const cases=[];
for(const requestedBudget of [null,10000]){
 const {city}=buildCpuCity();
 const start={x:-99.975,y:0,z:-73.92500000000001},goal={x:-89.625,y:0,z:-65.875};
 const original=city.nav.findPath;
 const path700=original.call(city.nav,start.x,start.y,start.z,goal.x,goal.y,goal.z,700);
 const path10000=original.call(city.nav,start.x,start.y,start.z,goal.x,goal.y,goal.z,10000);
 if(requestedBudget)city.nav.findPath=function(...args){args[6]=requestedBudget;return original.apply(this,args);};
 const motion=travel({world:city.collision,nav:city.nav,gas:city.gas,kind:'scav'},start,goal,120);
 cases.push({requestedBudget,path700,path10000,motion});
}
for(const [p,h]of Object.entries(sourceHashes))if(sha(fs.readFileSync(new URL('./survival/'+p,import.meta.url)))!==h)throw new Error('Source changed during city prefix probe: '+p);
const result={checkedAt:new Date().toISOString(),sourceHashes,
 scope:'Actual fresh City, authored gas, real Game/AISystem/Actor physics/collision/vitals. Raid-adjacent start is a native walkable nav cell, target is diagnostic patrol endpoint; player is inactive/dead out of range. 10000 override is isolated diagnostic and is not shipped behavior. No browser/GPU/reference comparison.',cases};
fs.writeFileSync(new URL('./gas-city-prefix-fix-cpu-evidence.json',import.meta.url),JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify({sourceHashes,cases:cases.map(({requestedBudget,path700,path10000,motion:m})=>({requestedBudget,path700,path10000,reached:m.reached,travelled:m.distanceTravelled,final:m.final,pathCalls:m.pathCalls.length,nullPaths:m.pathCalls.filter(p=>!p.success).length,panic:m.gasPanicEvents}))}));
