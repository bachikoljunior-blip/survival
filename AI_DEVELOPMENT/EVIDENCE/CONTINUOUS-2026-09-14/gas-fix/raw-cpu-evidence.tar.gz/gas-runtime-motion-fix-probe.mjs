import fs from 'node:fs';
import {createHash} from 'node:crypto';
import {buildCpuCity, THREE} from './cpu-city-fixture-v2.mjs';
import {Game, MODE} from './survival/src/game/game.js';
import {Director} from './survival/src/game/director.js';
import {Enemy, AISystem, AI_STATE} from './survival/src/game/ai.js';
import {NavGrid} from './survival/src/world/nav.js';
import {GasField} from './survival/src/world/gas.js';
import {CollisionWorld, Box, LAYER} from './survival/src/world/collision.js';
const sha=b=>createHash('sha256').update(b).digest('hex');
const floatHash=a=>sha(Buffer.from(a.buffer,a.byteOffset,a.byteLength));
const paths=['src/world/city.js','src/world/gas.js','src/world/nav.js','src/world/collision.js','src/game/game.js','src/game/ai.js','src/game/director.js','src/actors/actor.js','src/content/world_data.js'];
const sourceHashes=Object.fromEntries(paths.map(p=>[p,sha(fs.readFileSync(new URL('./survival/'+p,import.meta.url)))]));
const mats={character:()=>new THREE.MeshStandardMaterial()};
const dt=1/60;
function gameFor(world,gas,nav){return {time:0,playTime:0,mode:MODE.PLAY,input:{step(){}},world,gas,nav,actors:[],systems:[],_playerInput(){},_updateZone(){},_drainEvents:Game.prototype._drainEvents,emit(){}};}

const {city,data}=buildCpuCity();
const game=gameFor(city.collision,city.gas,city.nav);game.city=city;
game.atmos={setMarkerActive(){},plumes:{setAnchorActive(){}}};game.hud={notice(){}};
const originalCost=new Float32Array(city.nav.cost);
const costTicks=[];let samples=0;
const sample=city.gas.sample;
city.gas.sample=function(...args){samples++;return sample.apply(this,args);};
Director.prototype._hooks.call({game}).shutVents();
for(let n=1;n<=180;n++){
  if(n===70)city.gas.setIntensity(2);
  samples=0;
  const previous=city.nav.cost,revision=city.nav.costRevision,hash=floatHash(previous);
  Game.prototype.fixedUpdate.call(game,dt);
  costTicks.push({tick:n,time:game.time,samples,gasRevision:city.gas.revision,scale:city.gas.globalScale,
    costRevision:city.nav.costRevision,published:revision!==city.nav.costRevision,cursor:city.nav._gasCursor,
    changedBeforePublication:revision===city.nav.costRevision&&hash!==floatHash(city.nav.cost),
    swappedBuffer:previous!==city.nav.cost,costHash:floatHash(city.nav.cost)});
}
city.gas.sample=sample;
const nav=city.nav;
const liveCost=new Float32Array(nav.cost);
let changed=0;for(let i=0;i<nav.cost.length;i++)if(nav.cost[i]!==originalCost[i])changed++;

function flat(hot,kind='scav'){
  const world=new CollisionWorld(6);world.add(new Box(6.5,-1,4.5,13,1,9,0,LAYER.PLATFORM,'floor'));
  const nav=new NavGrid(world,{minX:0,minZ:0,maxX:13,maxZ:9},1).bake(2,.33,1.7);
  const gas=new GasField(0,0,13,9,.5);if(hot)gas.addSource(6.5,4.5,9000,1.4,'test');gas.bake();nav.applyGasCost(gas);
  return {world,nav,gas,kind};
}
function travel({world,nav,gas,kind='scav'},start,goal,maxSeconds=15,{forceSteering=false}={}){
  const game=gameFor(world,gas,nav);
  const actor=new Enemy(kind,{x:start.x,y:start.y,z:start.z,world,gas,mats,weapon:null,offhand:null,seed:17});
  actor.placeAt(start.x,start.y,start.z);
  actor.patrol=[{x:goal.x,z:goal.z},{x:start.x,z:start.z}];actor.aiState=AI_STATE.PATROL;actor.think=0;
  const ai=new AISystem(game),events=[];
  game.player={pos:new THREE.Vector3(1000,0,1000),height:1.7,dead:true,setMove(){}};
  game.actors=[actor];game.emit=(name,a,d)=>{if(name==='actor:gaspanic')events.push({time:game.time,name,data:d});};
  game.systems=forceSteering?[{update(){ai._moveTowards(actor,goal.x,goal.z,game,.42);}}]:[ai];
  const originalPath=nav.findPath,pathCalls=[];
  nav.findPath=function(...args){const p=originalPath.apply(this,args);pathCalls.push({time:game.time,start:args.slice(0,3),target:args.slice(3,6),budget:args[6],success:!!p,path:p});return p;};
  const trajectory=[];let distanceTravelled=0,previous=actor.pos.clone(),reached=false;
  try{for(let n=1;n<=maxSeconds*60;n++){
    Game.prototype.fixedUpdate.call(game,dt);
    distanceTravelled+=actor.pos.distanceTo(previous);previous.copy(actor.pos);
    const distance=Math.hypot(actor.pos.x-goal.x,actor.pos.z-goal.z);
    trajectory.push({tick:n,time:game.time,position:actor.pos.toArray(),velocity:actor.vel.toArray(),distance,
      ppm:actor.localPpm(gas),hp:actor.hp,state:actor.aiState,grounded:actor.grounded,move:{...actor.moveInput}});
    if(distance<1.4){reached=true;break;}
    if(actor.dead)break;
  }}finally{nav.findPath=originalPath;}
  return {kind,setup:{start,goal,maxSeconds,forceSteering},reached,distanceTravelled,final:trajectory.at(-1),
    maxPpm:Math.max(...trajectory.map(x=>x.ppm)),zRange:[Math.min(...trajectory.map(x=>x.position[2])),Math.max(...trajectory.map(x=>x.position[2]))],
    pathCalls,gasPanicEvents:events,trajectory};
}
const start={x:4.5,y:0,z:4.5},goal={x:8.5,y:0,z:4.5};
const flatMotion=[travel(flat(false),start,goal),travel(flat(true),start,goal),travel(flat(true,'warden'),start,goal)];

// Real City candidate search: actual raid starting coordinates, reachable same-region
// targets at 12..40 metres. Targets are diagnostic placement, not an authored patrol.
const starts=[['scav',-100,-74],['scav',-96,-88],['scav',74,24],['warden',70,14],['warden',78,16]];
const budgetCases=[];let attempts=0;
for(const [kind,x,z]of starts){
  const a=nav.nearest(x,z,0);if(a<0)continue;const p=nav._pt(a),ignore=kind==='warden';
  for(const distance of [12,20,28,36,40])for(let angle=0;angle<16;angle++){
    const b=nav.nearest(p.x+Math.cos(angle*Math.PI/8)*distance,p.z+Math.sin(angle*Math.PI/8)*distance,p.y);
    if(b<0||nav.region[a]!==nav.region[b])continue;const q=nav._pt(b);attempts++;
    if(nav.findPath(p.x,p.y,p.z,q.x,q.y,q.z,700,ignore))continue;
    const large=nav.findPath(p.x,p.y,p.z,q.x,q.y,q.z,10000,ignore);
    if(large){budgetCases.push({kind,start:p,goal:q,pathAt700:null,pathAt10000:large,
      startPpm:city.gas.sample(p.x,p.y+1.36,p.z),distance:Math.hypot(q.x-p.x,q.z-p.z),
      lineOfSight:city.collision.lineOfSight(p.x,p.y+1.4,p.z,q.x,q.y+1.4,q.z,LAYER.SOLID)});}
  }
}
const selected=budgetCases.find(p=>p.kind==='scav'&&p.startPpm<620)||budgetCases[0];
const budgetMotion=selected?travel({world:city.collision,nav,gas:city.gas,kind:selected.kind},selected.start,selected.goal,3,{forceSteering:true}):null;
for(const [p,h]of Object.entries(sourceHashes))if(sha(fs.readFileSync(new URL('./survival/'+p,import.meta.url)))!==h)throw new Error('Source changed during probe: '+p);
const result={checkedAt:new Date().toISOString(),sourceHashes,
  scope:'Actual City, GasField, NavGrid, Game.fixedUpdate, Enemy/AISystem, Actor movement/animation/vitals and collision. Canvas surface appearance is stubbed. No browser, GPU, visual verdict, physical timing or reference comparison.',
  runtimeRefresh:{cells:nav.cost.length,maxSamplesPerTick:Math.max(...costTicks.map(t=>t.samples)),
    firstPublicationTick:costTicks.find(t=>t.published)?.tick,changedBeforePublication:costTicks.some(t=>t.changedBeforePublication),changedCells:changed,
    beforeHash:floatHash(originalCost),afterHash:floatHash(liveCost),ticks:costTicks},flatMotion,
  budget:{attempts,reachableAt10000ButNot700:budgetCases.length,cases:budgetCases,selected,budgetMotion,
    scope:'Candidate targets are diagnostic placements. forceSteering uses real _moveTowards and Actor physics but omits perception/state transitions for the isolated failure control; no normal pursuit/playthrough claim.'}};
fs.writeFileSync(new URL('./gas-runtime-motion-fix-cpu-evidence.json',import.meta.url),JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify({runtimeRefresh:{cells:result.runtimeRefresh.cells,maxSamplesPerTick:result.runtimeRefresh.maxSamplesPerTick,firstPublicationTick:result.runtimeRefresh.firstPublicationTick,changedCells:changed,partial:result.runtimeRefresh.changedBeforePublication},flatMotion:flatMotion.map(({trajectory,pathCalls,...rest})=>({...rest,pathCount:pathCalls.length,pathFailures:pathCalls.filter(p=>!p.success).length})),budget:{attempts,cases:budgetCases.length,selected,budgetMotion:budgetMotion?{final:budgetMotion.final,pathCount:budgetMotion.pathCalls.length,pathFailures:budgetMotion.pathCalls.filter(p=>!p.success).length,distanceTravelled:budgetMotion.distanceTravelled}:null}}));
