import fs from 'node:fs';
import {createHash} from 'node:crypto';
import * as THREE from './survival/node_modules/three/build/three.module.js';
import {Game,MODE} from './survival/src/game/game.js';
import {Enemy,AISystem,AI_STATE} from './survival/src/game/ai.js';
import {NavGrid} from './survival/src/world/nav.js';
import {GasField} from './survival/src/world/gas.js';
import {CollisionWorld,Box,LAYER} from './survival/src/world/collision.js';
const sha=b=>createHash('sha256').update(b).digest('hex');
const files=['src/world/nav.js','src/world/gas.js','src/game/ai.js','src/game/game.js','src/world/collision.js','src/actors/actor.js'];
const sourceHashes=Object.fromEntries(files.map(p=>[p,sha(fs.readFileSync(new URL('./survival/'+p,import.meta.url)))]));
const cases=[];
for(const setup of [{hot:false,budget:null},{hot:true,budget:null},{hot:true,budget:10000}]){
  const world=new CollisionWorld(6);world.add(new Box(50,-1,50,100,1,100,0,LAYER.PLATFORM,'floor'));
  const nav=new NavGrid(world,{minX:0,minZ:0,maxX:100,maxZ:100},1).bake(2,.33,1.7);
  const gas=new GasField(0,0,100,100,1);if(setup.hot)gas.addSource(50,50,400,80,'test');gas.bake();nav.applyGasCost(gas);
  const actor=new Enemy('scav',{x:20.5,y:0,z:50.5,world,gas,mats:{character:()=>new THREE.MeshStandardMaterial()},weapon:null,seed:17});
  actor.placeAt(20.5,0,50.5);actor.patrol=[{x:40.5,z:50.5},{x:20.5,z:50.5}];actor.aiState=AI_STATE.PATROL;actor.think=0;
  const events=[],game={time:0,playTime:0,mode:MODE.PLAY,input:{step(){}},world,gas,nav,actors:[actor],
    player:{pos:new THREE.Vector3(1000,0,1000),height:1.7,dead:true,setMove(){}},
    _playerInput(){},_updateZone(){},_drainEvents:Game.prototype._drainEvents,
    emit(name,a,d){if(name==='actor:gaspanic')events.push({time:this.time,name,data:d});}};
  game.systems=[new AISystem(game)];
  const paths={at700:nav.findPath(20.5,0,50.5,40.5,0,50.5,700),at10000:nav.findPath(20.5,0,50.5,40.5,0,50.5,10000)};
  const original=nav.findPath,calls=[],trajectory=[];
  nav.findPath=function(...args){if(setup.budget)args[6]=setup.budget;const p=original.apply(this,args);calls.push({time:game.time,budget:args[6],success:!!p});return p;};
  for(let i=0;i<180;i++){
    Game.prototype.fixedUpdate.call(game,1/60);
    trajectory.push({tick:i+1,time:game.time,position:actor.pos.toArray(),hp:actor.hp,ppm:actor.localPpm(gas),saturation:actor.lungs.sat,
      state:actor.aiState,move:{...actor.moveInput},grounded:actor.grounded,pathTime:actor.pathTime,stuckTimer:actor.stuckTimer});
  }
  nav.findPath=original;
  cases.push({setup,paths,calls,events,trajectory,final:trajectory.at(-1),displacement:Math.hypot(actor.pos.x-20.5,actor.pos.z-50.5)});
}
for(const [p,h]of Object.entries(sourceHashes))if(sha(fs.readFileSync(new URL('./survival/'+p,import.meta.url)))!==h)throw new Error('Source changed during probe: '+p);
const result={checkedAt:new Date().toISOString(),sourceHashes,
  scope:'Constructed 100×100 m CPU floor and actual diffuse GasField source, actual Game.fixedUpdate/AISystem/Enemy/Actor physics and vitals. Diagnostic patrol endpoints, no other active actor, no browser or GPU. 10000-node wrapper is a counterfactual, not shipped behavior.',
  setup:{floor:[0,0,100,100],navCell:1,gasCell:1,source:{x:50,z:50,strength:400,radius:80},start:[20.5,0,50.5],goal:[40.5,0,50.5],seconds:3},cases};
fs.writeFileSync(new URL('./gas-budget-motion-fix-cpu-evidence.json',import.meta.url),JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify({sourceHashes,cases:cases.map(({setup,paths,calls,events,final,displacement})=>({setup,paths,calls:calls.length,failures:calls.filter(c=>!c.success).length,events,final,displacement}))}));
