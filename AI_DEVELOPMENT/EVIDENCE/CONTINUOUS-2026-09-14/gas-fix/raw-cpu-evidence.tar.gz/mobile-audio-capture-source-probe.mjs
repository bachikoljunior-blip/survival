import fs from 'node:fs';
import vm from 'node:vm';
import {createHash} from 'node:crypto';
import path from 'node:path';
const filename='/workspace/scratch/0b7ad82bafe7/survival/tools/mobile_audio_capture.mjs';
const source=fs.readFileSync(filename,'utf8');
const evaluatedSource=source.replace(/^import .*;\n/gm,'').replace('export async function captureMobileAudio','async function captureMobileAudio')+'\nthis.captureMobileAudio=captureMobileAudio;';

async function probe(fault){
  const faults=new Set(fault.split("+"));
  const tracks=[],checks=[],writes=[],connections=new Set(['normal-audible-destination']),keys=new Set(),events=[];
  let created=0,clock=0,restores=0,recorder,recordingWaits=0;
  class Track{
    constructor(kind){this.kind=kind;this.readyState='live';tracks.push(this);}
    stop(){events.push('stop-'+this.kind);if(faults.has('track-stop')&&this.kind==='video')throw new Error('injected track.stop');this.readyState='ended';}
    getSettings(){return this.kind==='video'?{width:1147,height:645}:{sampleRate:48000,channelCount:2};}
  }
  const smallStream=tt=>({getTracks:()=>tt,getVideoTracks:()=>tt.filter(t=>t.kind==='video'),getAudioTracks:()=>tt.filter(t=>t.kind==='audio')});
  const audio={ready:true,unlocked:true,ambienceState:'camp',musicState:'explore',_voiceList:[],
    masterGain:{gain:{value:0.85}},musicGain:{gain:{value:0.7}},sfxGain:{gain:{value:1}},
    ctx:{state:'running',currentTime:0,sampleRate:48000,destination:{channelCount:2},
      createMediaStreamDestination(){events.push('create-destination');if(faults.has('destination-create'))throw new Error('injected destination constructor');return {id:++created,stream:smallStream([new Track('audio')])};}},
    comp:{connect(destination){events.push('connect-recording');if(faults.has('connect'))throw new Error('injected comp.connect');connections.add(destination);},
      disconnect(destination){events.push('disconnect-recording');if(faults.has('disconnect'))throw new Error('injected comp.disconnect');if(!connections.has(destination))throw new Error('InvalidAccessError: no such connection');connections.delete(destination);}},
  };
  const player={pos:{values:[0,0,0],toArray(){return [...this.values];}},hp:100,dead:false};
  const originalSettings={quality:'high',masterVolume:0.85,musicVolume:0.7,sfxVolume:1};
  const C={engine:{frame:1,time:0,tier:{name:'high'}},city:{interactions:[{id:'door_arcade',kind:'door',target:'arcade_in',interiorId:'arcade'}]},
    game:{audio,player,mode:'play',settings:{...originalSettings},
      applySettings(s){this.settings={...s};C.engine.tier.name=s.quality;if(s.quality==='high')restores++;},
      teleport(spawn){player.pos.values=spawn==='arcade_in'?[588,0.1,4.2]:spawn==='ventfield'?[82,0.1,-60]:[-112,0.1,-84];return true;},
      director:{currentInterior:null,async enterDoor(door){events.push('enter-'+door.id);C.game.teleport(door.target);this.currentInterior=door.interiorId;}},
    },async startNewGame(){this.game.director.currentInterior=null;this.game.teleport('start');},
  };
  const canvas={width:1147,height:645,captureStream(){events.push('capture-canvas');if(faults.has('canvas-capture'))throw new Error('injected canvas.captureStream');return smallStream([new Track('video')]);}};
  if(faults.has('no-canvas-capture'))delete canvas.captureStream;
  class Stream{
    constructor(tt){events.push('combine-stream');if(faults.has('stream-constructor'))throw new Error('injected MediaStream constructor');this.tt=tt;}
    getTracks(){return this.tt;}
    getVideoTracks(){return this.tt.filter(t=>t.kind==='video');}
    getAudioTracks(){return this.tt.filter(t=>t.kind==='audio');}
  }
  class Recorder{
    static isTypeSupported(){return fault!=='no-mime';}
    constructor(stream,{mimeType}){events.push('create-recorder');if(faults.has('recorder-constructor'))throw new Error('injected MediaRecorder constructor');this.stream=stream;this.mimeType=mimeType;this.state='inactive';recorder=this;}
    start(){events.push('start-recorder');if(faults.has('recorder-start'))throw new Error('injected MediaRecorder.start');this.state='recording';}
    stop(){events.push('stop-recorder');if(faults.has('recorder-stop'))throw new Error('injected MediaRecorder.stop');if(this.state==='inactive')throw new Error('InvalidStateError: already inactive');this.state='inactive';if(faults.has('missing-onstop'))return;this.ondataavailable?.({data:new Blob(['MOCK-UNIT-BYTES-NOT-AUDIO'],{type:this.mimeType})});this.onstop?.();}
  }
  const page={
    evaluate:async(fn,arg)=>fn(arg),
    touchscreen:{tap:async()=>events.push('trusted-tap-mocked')},
    keyboard:{down:async k=>keys.add(k),up:async k=>keys.delete(k)},
    waitForTimeout:async ms=>{
      recordingWaits++;
      if(faults.has('recording-wait')&&recordingWaits===1)throw new Error('injected recording wait failure');
      clock+=ms;audio.ctx.currentTime+=ms/1000;C.engine.time+=ms/1000;C.engine.frame+=Math.floor(ms/16);
      if(keys.has('w'))player.pos.values[2]-=2.5;
      if(faults.has('recorder-error')&&recordingWaits===1)recorder.onerror?.({error:new Error('injected asynchronous recorder error')});
    },
  };
  const context=vm.createContext({window:{CINDERLINE:C},document:{getElementById:()=>canvas},MediaStream:Stream,
    MediaRecorder:faults.has('no-recorder')?undefined:Recorder,Blob,Uint8Array,Buffer,btoa,
    performance:{now:()=>clock},setTimeout:fn=>setTimeout(fn,1),clearTimeout,
    createHash,join:path.join,writeFileSync:(p,bytes)=>writes.push({path:p,byteLength:bytes.length,fixtureOnly:true})});
  vm.runInContext(evaluatedSource,context,{filename});
  const report={browser:faults.has('chromium')?'chromium':'webkit'};let error=null,errorTree=null;
  try{await context.captureMobileAudio({page,root:'/fixture-root',output:'/fixture-root/output',report,
    check:(condition,name,detail)=>{checks.push({passed:Boolean(condition),name,detail});return Boolean(condition);},
    waitFrames:async(_page,n)=>{C.engine.frame+=n;}});}catch(e){error=e.message;const describe=x=>({name:x.name,message:x.message,errors:x.errors?[...x.errors].map(describe):[]});errorTree=describe(e);}
  return {fault,error,errorTree,status:report.audioCapture?.status??null,clips:report.audioCapture?.clips?.length??0,
    declaredBrowser:report.browser,browserLabelMismatch:report.browser==='chromium'&&/actual webkit/i.test(report.audioCapture?.scope??''),
    failedChecks:checks.filter(c=>!c.passed),liveTracks:tracks.filter(t=>t.readyState==='live').map(t=>t.kind),
    recordingConnections:[...connections].filter(c=>c!=='normal-audible-destination').length,
    originalAudibleConnectionPreserved:connections.has('normal-audible-destination'),
    recordingHandleRetained:!!C.__audioRecording,recorderState:recorder?.state??null,
    settingsRestored:JSON.stringify(C.game.settings)===JSON.stringify(originalSettings),restores,heldKeys:[...keys],
    writes,events};
}

const results=[];
for(const fault of ['normal','chromium','no-recorder','no-mime','no-canvas-capture','destination-create','canvas-capture','stream-constructor','recorder-constructor','recorder-start','connect','recorder-stop','disconnect','track-stop','recording-wait','missing-onstop','recorder-error','recording-wait+disconnect','recorder-error+disconnect','recorder-start+disconnect'])results.push(await probe(fault));
const evidence={sourceHash:createHash('sha256').update(source).digest('hex'),scope:'Node vm execution of the exact helper body with deterministic API/track stubs and injected faults. No browser, audio context, canvas context, MediaRecorder implementation or media file was created. writeFileSync is a recorder spy; unit bytes are not media.',results};
fs.writeFileSync('/workspace/scratch/0b7ad82bafe7/mobile-audio-capture-source-probe.json',JSON.stringify(evidence,null,2)+'\n');
console.log(JSON.stringify({sourceHash:evidence.sourceHash,scope:evidence.scope,results:results.map(({writes,events,...r})=>r)},null,2));
