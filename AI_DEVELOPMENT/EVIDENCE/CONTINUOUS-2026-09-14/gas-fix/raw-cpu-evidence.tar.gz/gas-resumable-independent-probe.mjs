import fs from 'node:fs';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';

// A version-pinned, CPU-only refutation probe. No product or old evidence writes.
const root = new URL('./', import.meta.url);
const sha = b => createHash('sha256').update(b).digest('hex');
const expected = {
  'src/world/nav.js':'0331e0fd05d503ee1f7d83c5c78d575b44b077c480a9817327aab74c76836234',
  'src/game/ai.js':'349821330229e32653cdb362e5331bde535fbfd5340fb8faafa7562bff844e7b',
  'src/world/collision.js':'72c0378ef6bf5bdb0cb164e920bd05f449eefffa3d176b47ca389abc52637a04',
};
const sourceHashes = Object.fromEntries(Object.keys(expected).map(p => [p, sha(fs.readFileSync(new URL('./survival/'+p, root)))]));
assert.deepEqual(sourceHashes, expected, 'Probe is pinned to the reviewed resumable implementation');
const {NavGrid} = await import('./survival/src/world/nav.js');
const {CollisionWorld,Box,LAYER} = await import('./survival/src/world/collision.js');
const {AISystem, ARCHETYPES} = await import('./survival/src/game/ai.js');
const checks = [];
function check(name, passed, details = null) { checks.push({name,passed:!!passed,details}); }
const equal = (a,b) => JSON.stringify(a) === JSON.stringify(b);
const floatsHash = a => sha(Buffer.from(a.buffer,a.byteOffset,a.byteLength));
const gas = (ppm,revision) => ({revision,sample:typeof ppm === 'function' ? ppm : () => ppm});
function grid(w=100,d=100,wall=true) {
  const world=new CollisionWorld(6);
  world.add(new Box(w/2,-1,d/2,w,1,d,0,LAYER.PLATFORM,'diagnostic-floor'));
  if(wall) world.add(new Box(50,0,50,1,3,50,0,LAYER.SOLID,'diagnostic-wall'));
  const nav=new NavGrid(world,{minX:0,minZ:0,maxX:w,maxZ:d},1).bake(2,.33,1.7);
  nav.applyGasCost(gas(14,200));
  return {world,nav};
}
function finish(job,budget=700) {
  const steps=[];
  for(let i=0;!job.done && i<1000;i++) {job.step(budget);steps.push(job.lastExpanded);}
  assert(job.done,'Bounded fixture search did not finish');
  return {done:job.done,path:job.path,expanded:job.expanded,steps,costRevision:job.costRevision,sourceRevision:job.sourceRevision};
}
function publish(nav,field) {
  let calls=0;
  do {nav.updateGasCost(field,calls===0?.51:0,4096);calls++;} while(nav._gasCursor>=0 && calls<100);
  assert.equal(nav._gasCursor,-1);
  return calls;
}

// Two real planner jobs on the same collision-derived grid, interleaved at 700 nodes.
const {nav:shared}=grid();
const queryA=[45.5,0,50.5,55.5,0,50.5], queryB=[55.5,0,45.5,45.5,0,55.5];
const aloneA=finish(shared.createPathSearch(...queryA));
const aloneB=finish(shared.createPathSearch(...queryB));
const a=shared.createPathSearch(...queryA), b=shared.createPathSearch(...queryB);
check('Concurrent jobs own different nodes/open/cost objects',a.nodes!==b.nodes && a.open!==b.open && a.cost!==b.cost && a.cost!==shared.cost && b.cost!==shared.cost);
const interleavedStepsA=[],interleavedStepsB=[];
for(let n=0;(!a.done||!b.done)&&n<1000;n++) {
  if(!a.done){a.step(700);interleavedStepsA.push(a.lastExpanded);}
  if(!b.done){b.step(700);interleavedStepsB.push(b.lastExpanded);}
}
const summaryA={done:a.done,path:a.path,expanded:a.expanded,steps:interleavedStepsA,costRevision:a.costRevision,sourceRevision:a.sourceRevision};
const summaryB={done:b.done,path:b.path,expanded:b.expanded,steps:interleavedStepsB,costRevision:b.costRevision,sourceRevision:b.sourceRevision};
check('Interleaved A exactly matches isolated path, endpoint, expansions and completion',equal(summaryA,aloneA));
check('Interleaved B exactly matches isolated path, endpoint, expansions and completion',equal(summaryB,aloneB));
check('Both concurrent jobs exercise more than one step',interleavedStepsA.length>1 && interleavedStepsB.length>1);
check('Every isolated/interleaved step expands at most 700 nodes',[...aloneA.steps,...aloneB.steps,...interleavedStepsA,...interleavedStepsB].every(n=>n<=700));

// An unfinished search must use its copied costs through both expansion and smoothing.
const {nav:snapNav}=grid(13,9,false);
const hazard=gas((x,y,z)=>x>=4 && x<9 && z>=2 && z<7 ? 900 : 14,301);
snapNav.applyGasCost(hazard);
const snapQuery=[.5,0,4.5,12.5,0,4.5];
const baseline=finish(snapNav.createPathSearch(...snapQuery));
const pending=snapNav.createPathSearch(...snapQuery);
pending.step(1);
check('Snapshot test changes live costs while the job is still pending',!pending.done);
const initialSnapshotHash=floatsHash(pending.cost), originalLive=snapNav.cost;
const clear=gas(14,302);
snapNav.updateGasCost(clear,0,7);
check('Partial gas sweep does not change published live grid or job snapshot',snapNav.cost===originalLive && floatsHash(snapNav.cost)===initialSnapshotHash && floatsHash(pending.cost)===initialSnapshotHash && snapNav._gasCursor===7);
while(snapNav._gasCursor>=0) snapNav.updateGasCost(clear,0,7);
const cleared=finish(snapNav.createPathSearch(...snapQuery));
check('Published clear grid produces a different path from the hazard snapshot',!equal(cleared.path,baseline.path));
const afterFirstPublish={costRevision:snapNav.costRevision,sourceRevision:snapNav._gasRevision,costHash:floatsHash(snapNav.cost)};
publish(snapNav,gas(400,303));
check('Second publish reuses and changes original live storage without mutating copied job costs',snapNav.cost===originalLive && floatsHash(originalLive)!==initialSnapshotHash && floatsHash(pending.cost)===initialSnapshotHash);
const resumed=finish(pending);
check('Resumed old job retains exact old path and expansion count after two live publications',equal(resumed.path,baseline.path) && resumed.expanded===baseline.expanded && resumed.done);
check('Snapshot records its original source and cost revisions',resumed.sourceRevision===301 && resumed.costRevision===baseline.costRevision && snapNav._gasRevision===303 && snapNav.costRevision>resumed.costRevision);

// Actual AISystem method at its steering seam. No Actor physics/perception claims.
function steeringFixture() {
  const {nav,world}=grid();
  const jobs=[];
  const original=nav.createPathSearch;
  nav.createPathSearch=function(...args){const search=original.apply(this,args);jobs.push({args,search});return search;};
  const moves=[];
  const enemy={arch:ARCHETYPES.scav,pos:{x:45.5,y:0,z:50.5},path:null,pathIndex:0,pathTime:0,
    setMove(x,z,speed){moves.push({x,z,speed});}};
  const game={nav,world};
  const steer=(x=55.5,z=50.5)=>AISystem.prototype._moveTowards.call({},enemy,x,z,game,.42);
  return {nav,world,jobs,moves,enemy,steer};
}
function jobRecord(j) {return {args:j.args,expanded:j.search?.expanded,done:j.search?.done,path:j.search?.path,costRevision:j.search?.costRevision,sourceRevision:j.search?.sourceRevision};}
const sourceCase=steeringFixture();sourceCase.steer();
const oldSourceJob=sourceCase.jobs[0].search, oldSourceExpanded=oldSourceJob.expanded;
const sourceOldCostRevision=sourceCase.nav.costRevision;
publish(sourceCase.nav,gas(14,201));
check('Source-only publication can change source revision without cost revision',sourceCase.nav.costRevision===sourceOldCostRevision && sourceCase.nav._gasRevision===201);
sourceCase.steer();
check('AI cancels pending job and immediately restarts on published source revision',sourceCase.jobs.length===2 && sourceCase.jobs[1].search!==oldSourceJob && oldSourceJob.expanded===oldSourceExpanded && sourceCase.jobs[1].search.sourceRevision===201);

const goalCase=steeringFixture();goalCase.steer();
const oldGoalJob=goalCase.jobs[0].search,oldGoalExpanded=oldGoalJob.expanded;
goalCase.steer(55.5,54.5);
check('AI cancels pending job and targets moved goal when displacement is 4 m',goalCase.jobs.length===2 && oldGoalJob.expanded===oldGoalExpanded && equal(goalCase.jobs[1].args.slice(3,6),[55.5,0,54.5]) && equal(goalCase.enemy.pathGoal,{x:55.5,z:54.5}));

const smallGoalCase=steeringFixture();smallGoalCase.steer();
smallGoalCase.steer(55.5,53.5);
check('Goal displacement of 3 m retains original job under explicit 3.5 m threshold',smallGoalCase.jobs.length===1 && equal(smallGoalCase.enemy.pathGoal,{x:55.5,z:50.5}) && smallGoalCase.jobs[0].search.done);

const costCase=steeringFixture();costCase.steer();
const oldCostJob=costCase.jobs[0].search, oldCostSnapshotHash=floatsHash(oldCostJob.cost);
publish(costCase.nav,gas(400,200));
costCase.steer();
const costAfterCompletion={jobs:costCase.jobs.length,path:costCase.enemy.path,pathCostRevision:costCase.enemy.pathCostRevision,liveCostRevision:costCase.nav.costRevision,sourceRevision:costCase.nav._gasRevision,lastMove:costCase.moves.at(-1)};
check('Cost-only change preserves pending snapshot until completion',costCase.jobs.length===1 && oldCostJob.done && costCase.enemy.path!==null && floatsHash(oldCostJob.cost)===oldCostSnapshotHash && costCase.enemy.pathCostRevision<costCase.nav.costRevision);
costCase.steer();
check('Next steering call starts fresh search against new live cost revision',costCase.jobs.length===2 && costCase.jobs[1].search.costRevision===costCase.nav.costRevision && costCase.jobs[1].search.sourceRevision===200);

const sourceHashesAfter=Object.fromEntries(Object.keys(expected).map(p=>[p,sha(fs.readFileSync(new URL('./survival/'+p,root)))]));
assert.deepEqual(sourceHashesAfter,sourceHashes,'Source changed during independent probe');
const result={checkedAt:new Date().toISOString(),sourceHashes,sourceHashesAfter,
  scope:'CPU-only actual NavGrid/CollisionWorld and actual AISystem._moveTowards method at a plain-enemy steering seam. Synthetic gas sampler provides controlled ppm/revision. No browser, physical motion, visual quality, reference comparison or whole-element verdict.',
  interleaving:{queries:[queryA,queryB],grid:{bounds:[0,0,100,100],cell:1,wall:[50,0,50,1,3,50]},aloneA,aloneB,interleavedA:summaryA,interleavedB:summaryB},
  snapshots:{baseline,cleared,resumed,initialSnapshotHash,afterFirstPublish,afterSecondPublish:{costRevision:snapNav.costRevision,sourceRevision:snapNav._gasRevision,costHash:floatsHash(snapNav.cost)}},
  ai:{sourceOnly:{jobs:sourceCase.jobs.map(jobRecord),moves:sourceCase.moves},goal4m:{jobs:goalCase.jobs.map(jobRecord),pathGoal:goalCase.enemy.pathGoal},goal3m:{jobs:smallGoalCase.jobs.map(jobRecord),pathGoal:smallGoalCase.enemy.pathGoal},costOnly:{jobs:costCase.jobs.map(jobRecord),afterCompletion:costAfterCompletion}},
  checks,passed:checks.every(c=>c.passed)};
const out=new URL('./gas-resumable-independent-cpu-evidence.json',root);
fs.writeFileSync(out,JSON.stringify(result,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({passed:result.passed,checks:checks.length,failed:checks.filter(c=>!c.passed),aloneA:aloneA.steps,aloneB:aloneB.steps,snapshotPaths:{hazard:baseline.path,cleared:cleared.path},sourceJobs:sourceCase.jobs.map(jobRecord),goalJobs:goalCase.jobs.map(jobRecord),costAfterCompletion,output:out.pathname}));
if(!result.passed)process.exitCode=1;
