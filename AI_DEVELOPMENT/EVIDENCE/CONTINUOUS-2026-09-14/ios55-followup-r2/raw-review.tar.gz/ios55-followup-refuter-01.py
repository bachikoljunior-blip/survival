import base64
import gzip
import hashlib
import json
import pathlib
import struct
import subprocess
import traceback
import zlib

ROOT = pathlib.Path('/workspace/scratch/0b7ad82bafe7')
OUT = ROOT / 'ios55-followup-refuter-01.json'
DIR = ROOT / 'ios55-followup-refuter-fixtures-01'
assert not OUT.exists() and not DIR.exists(), 'Preserve every prior attempt.'
DIR.mkdir()
report = {'scope': 'Independent CPU-only source, actual helper boundary and real Node stdout-pipe refutation. No browser/server/iOS execution or product edits.', 'checks': [], 'errors': [], 'runs': []}
sha = lambda b: hashlib.sha256(b).hexdigest()
snapshot = ROOT / 'ios55-followup-source'
pins = json.loads((ROOT / 'ios55-followup-pins.json').read_text())
tracked = [ROOT / s['snapshot'] for s in pins['sources']] + [ROOT / pins['baseline_helper']['path'], snapshot / 'wda-v16-FBBaseActionsSynthesizer.m', snapshot / 'test-ios-safari-r2.mjs']
report['sources_before'] = {str(p.relative_to(ROOT)): sha(p.read_bytes()) for p in tracked}
for s in pins['sources']:
    assert sha((ROOT / s['snapshot']).read_bytes()) == s['sha256']
old = (snapshot / 'test-ios-safari-before.mjs').read_text()
current = (snapshot / 'test-ios-safari.mjs').read_text()
r2 = (snapshot / 'test-ios-safari-r2.mjs').read_text()
assert sha(r2.encode()) == 'b85b83ec116fe0187af82eca847c7d6ecb14db3e18498dcb96c228e43d285a2d'
assert r2.replace('// Let the pipe drain so a failed run preserves the full report and PNG bytes.\n', '', 1).replace('if (report.failures.length) process.exitCode = 1;', 'if (report.failures.length) process.exit(1);', 1) == current
report['actual_r2_delta_only_exit_and_comment'] = True
git_old = subprocess.check_output(['git', 'show', pins['head'] + ':tools/test-ios-safari.mjs'], cwd=ROOT / 'survival')
assert git_old == old.encode()
ci_log = (snapshot / 'ios55-job.log').read_text()
ci = json.loads(next(line.split('[ios-safari-report] ', 1)[1] for line in ci_log.splitlines() if '[ios-safari-report] ' in line))


def check(name, fn):
    try:
        report['checks'].append({'name': name, 'result': fn()})
    except Exception:
        report['errors'].append({'name': name, 'traceback': traceback.format_exc()})


def ci_and_payload():
    assert ci['status'] == 'failed' and len(ci['checks']) == 12 and all(c['passed'] for c in ci['checks'])
    assert ci['failureState']['mode'] == 'play'
    assert any(e['type'] == 'pointerup' and e['trusted'] and e['pointerType'] == 'touch' for e in ci['interaction']['titleInput'])
    assert any('action item must be preceded by pointerMove item' in f and 'duration = 1;' in f for f in ci['failures'])
    assert '[ios-safari-image]' not in ci_log
    script = ROOT / 'ios55-followup-refuter-actions-01.mjs'
    script.write_text('''import fs from 'node:fs';
import vm from 'node:vm';
import {nativePointerActions} from './ios55-followup-source/ios-pointer-coordinates.mjs';
const ci=JSON.parse(fs.readFileSync(new URL('./ios55-followup-ci-report.json',import.meta.url),'utf8'));
const attack=ci.layout.controls.find(x=>x.name==='attack');
const viewport=ci.inputActions[1].viewport;
const results=[];
for(const name of ['test-ios-safari-before.mjs','test-ios-safari.mjs']){
 const s=fs.readFileSync(new URL('./ios55-followup-source/'+name,import.meta.url),'utf8');
 const defs=s.slice(s.indexOf('function finger('),s.indexOf('async function tap('));
 const perform=s.slice(s.indexOf('async function performActions('),s.indexOf('async function calibratePointerCoordinates('));
 const a=s.indexOf("  await performActions([\\n    finger('move-thumb'");
 const call=s.slice(a,s.indexOf('\\n  ]);',a)+7);
 const report={inputActions:[]},requests=[];
 await vm.runInNewContext('(async()=>{'+defs+perform+call+'})()',{
  nativePointerActions,pointerCalibration:ci.inputCalibration[0],report,
  attackX:attack.x+attack.width/2,attackY:attack.y+attack.height/2,
  sessionPath:p=>p,execute:async()=>viewport,webdriver:async(p,options)=>requests.push({p,options})
 });
 results.push({name,report,requests});
}
console.log(JSON.stringify(results));
''')
    run = subprocess.run(['node', str(script)], capture_output=True, timeout=20)
    (DIR / 'actions.stdout.json').write_bytes(run.stdout)
    (DIR / 'actions.stderr.log').write_bytes(run.stderr)
    assert run.returncode == 0, run.stderr.decode()
    result = json.loads(run.stdout)
    assert result[0]['report']['inputActions'][0] == ci['inputActions'][1]
    parent = json.loads((ROOT / 'ios55-followup-actions.json').read_text())
    native = result[1]['report']['inputActions'][0]['native']
    assert native == parent['current']['captured'][0]['native']
    assert [r['p'] for r in result[1]['requests']] == ['/actions', '/actions']
    assert result[1]['requests'][1]['options']['method'] == 'DELETE'
    assert all(c['actions'][0]['type'] == 'pointerMove' for c in native)
    assert [[a.get('duration', 0) for a in c['actions']] for c in native] == [[0, 0, 350, 550, 0], [350, 0, 150, 0]]
    return {'baseline_equals_git_object': True, 'baseline_payload_equals_actual_ci': True, 'current_payload_equals_parent': True, 'ci_passed_checks': 12, 'ci_mode': ci['failureState']['mode'], 'current_native': native, 'transport': 'VM records boundary payload; no WebDriver requests executed.'}


def png_validate(b):
    assert b[:8] == b'\x89PNG\r\n\x1a\n'
    offset, chunks, compressed = 8, [], b''
    while offset < len(b):
        n = struct.unpack('>I', b[offset:offset+4])[0]
        kind = b[offset+4:offset+8]
        data = b[offset+8:offset+8+n]
        crc = struct.unpack('>I', b[offset+8+n:offset+12+n])[0]
        assert crc == zlib.crc32(kind + data)
        if kind == b'IHDR':
            assert struct.unpack('>IIBBBBB', data) == (1, 1, 8, 6, 0, 0, 0)
        if kind == b'IDAT':
            compressed += data
        chunks.append(kind.decode())
        offset += n + 12
    assert offset == len(b) and chunks[0] == 'IHDR' and chunks[-1] == 'IEND'
    assert chunks in [['IHDR', 'IDAT', 'IEND'], ['IHDR', 'tEXt', 'IDAT', 'IEND']]
    assert zlib.decompress(compressed) == bytes([0, 7, 11, 13, 255])
    return {'width': 1, 'height': 1, 'rgba': [7, 11, 13, 255], 'chunks': chunks, 'crc_valid': True}


images = []


def boundary_logs():
    raw = gzip.decompress((ROOT / 'ios55-followup-image-boundaries.log.gz').read_bytes())
    before = gzip.decompress((ROOT / 'ios55-followup-image-boundaries-before.log.gz').read_bytes())
    summary = json.loads((ROOT / 'ios55-followup-image-boundaries.json').read_text())
    assert len(raw) == summary['rawLogBytes'] and sha(raw) == summary['rawLogSha256']
    line0, *lines = raw.decode().splitlines()
    parsed = json.loads(line0.removeprefix('[ios-safari-report] '))
    assert parsed['checks'] == ci['checks'] and parsed['failures'] == ci['failures']
    assert parsed['unicode'] == '改行\n日本語\x00<>\\'
    image = None
    for line in lines:
        if line.startswith('[ios-safari-image] '):
            image = {**json.loads(line.split(' ', 1)[1]), 'parts': []}
            images.append(image)
        elif line.startswith('[ios-safari-image-data] '):
            _, offset, text = line.split(' ', 2)
            assert image and image['included'] and int(offset) == sum(map(len, image['parts']))
            assert len(text) <= 4000
            image['parts'].append(text)
        else:
            raise AssertionError(line[:120])
    assert [im['bytes'] for im in images] == [70, 1500001, 7999999, 8000000, 8000001]
    assert [im['included'] for im in images] == [True, True, True, True, False]
    decoded = []
    for im in images:
        if im['included']:
            b = base64.b64decode(''.join(im['parts']), validate=True)
            assert len(b) == im['bytes'] and sha(b) == im['sha256']
            assert base64.b64encode(b).decode() == ''.join(im['parts'])
            im['buffer'] = b
            decoded.append({'bytes': len(b), 'sha256': sha(b), **png_validate(b)})
        else:
            assert not im['parts']
    # Independently reconstruct the omitted valid fixture from the 70-byte PNG
    # and the exact authored uncompressed tEXt padding; check its metadata hash.
    small = images[0]['buffer']
    n = images[-1]['bytes'] - len(small) - 12
    text = b'Comment\x00' + b'x' * (n-8)
    chunk = struct.pack('>I', len(text)) + b'tEXt' + text + struct.pack('>I', zlib.crc32(b'tEXt' + text))
    omitted = small[:33] + chunk + small[33:]
    assert len(omitted) == images[-1]['bytes'] and sha(omitted) == images[-1]['sha256']
    images[-1]['buffer'] = omitted
    decoded.append({'bytes': len(omitted), 'sha256': sha(omitted), **png_validate(omitted)})
    assert before.count(b'[ios-safari-image] ') == 1
    return {'decoded': decoded, 'report_unicode_and_ci_roundtrip': True, 'current_metadata_count': len(images), 'old_metadata_count': 1, 'scope': 'Synthetic valid PNG logger fixtures, never native/game captures. VM-generated full logs are format controls, not stdout drain proof.'}


def footer_pipes():
    assert images
    variants = {'current': current, 'actual-r2': r2, 'before': old}
    for count in [70, 1500001, 8000000, 8000001]:
        im = next(im for im in images if im['bytes'] == count)
        png = DIR / ('fixture-' + str(count) + '.png')
        png.write_bytes(im['buffer'])
        actual_report = {**ci, 'screenshots': {'failure': png.name}, 'fixture': 'Independent synthetic PNG test, not an iOS capture.'}
        report_path = DIR / ('report-' + str(count) + '.json')
        report_path.write_text(json.dumps(actual_report, ensure_ascii=False))
        for kind in (['current', 'actual-r2', 'before'] if count in [1500001, 8000000] else ['current']):
            text = variants[kind]
            footer = text[text.index('console.log(`[ios-safari]'):]
            preamble = "import {readFileSync} from 'node:fs';\nimport {resolve} from 'node:path';\nimport {createHash} from 'node:crypto';\n"
            child = DIR / (kind + '-' + str(count) + '.mjs')
            child.write_text(preamble + 'const ROOT=' + json.dumps(str(DIR)) + ';\nconst report=JSON.parse(readFileSync(' + json.dumps(str(report_path)) + ",'utf8'));\n" + footer)
            # Python drains real OS pipes via communicate; no mocked console.
            run = subprocess.run(['node', str(child)], stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=20)
            (DIR / (child.stem + '.stdout.log.gz')).write_bytes(gzip.compress(run.stdout))
            (DIR / (child.stem + '.stderr.log')).write_bytes(run.stderr)
            lines = run.stdout.decode().splitlines()
            metadata_lines = [l for l in lines if l.startswith('[ios-safari-image] ')]
            meta = json.loads(metadata_lines[0].split(' ', 1)[1]) if metadata_lines else None
            parts = [l.split(' ', 2)[2] for l in lines if l.startswith('[ios-safari-image-data] ')]
            joined = ''.join(parts)
            # Truncation can cut the final base64 quartet as well as whole lines.
            decoded = base64.b64decode(joined[:len(joined)//4*4])
            report_lines = [l for l in lines if l.startswith('[ios-safari-report] ')]
            report_complete = bool(report_lines) and json.loads(report_lines[0].split(' ', 1)[1]) == actual_report
            item = {'variant': kind, 'fixture_bytes': count, 'args': ['node', str(child)], 'footer_sha256': sha(footer.encode()), 'exit_status': run.returncode, 'stdout_bytes': len(run.stdout), 'stdout_sha256': sha(run.stdout), 'stderr_bytes': len(run.stderr), 'report_complete': report_complete, 'metadata': meta, 'received_base64_characters': len(joined), 'decoded_bytes': len(decoded), 'image_exact': decoded == im['buffer']}
            report['runs'].append(item)
            assert run.returncode == 1
            if kind == 'actual-r2':
                assert item['image_exact'] and report_complete and meta['included']
            if kind == 'before':
                assert meta is None and not parts
            if count == 70:
                assert item['image_exact']
            if count == 8000001:
                assert meta['included'] is False and meta['bytes'] == count and meta['sha256'] == im['sha256'] and not parts
    failures = [r for r in report['runs'] if r['variant'] == 'current' and r['fixture_bytes'] in [1500001, 8000000] and not r['image_exact']]
    assert failures, 'No stdout truncation reproduced in this attempt; keep the evidence.'
    return {'current_truncations': len(failures), 'actual_r2_preserves_exit_1_and_exact_images': True, 'baseline_omits_newly_supported_sizes': True, 'node_version': subprocess.check_output(['node', '--version']).decode().strip(), 'note': 'Dropped byte counts depend on process/pipe scheduling. These local CPU results do not measure the macOS CI stream.'}


check('actual_ci_and_helper_payload', ci_and_payload)
check('independent_png_and_log_boundaries', boundary_logs)
check('real_stdout_pipe_and_exit_causality', footer_pipes)
report['sources_after'] = {str(p.relative_to(ROOT)): sha(p.read_bytes()) for p in tracked}
report['sources_unchanged'] = report['sources_before'] == report['sources_after']
OUT.write_text(json.dumps(report, indent=2, ensure_ascii=False, allow_nan=False) + '\n')
print(json.dumps({'checks': [c['name'] for c in report['checks']], 'errors': report['errors'], 'runs': [{k:r[k] for k in ['variant','fixture_bytes','exit_status','decoded_bytes','image_exact']} for r in report['runs']], 'sources_unchanged': report['sources_unchanged']}, indent=2))
raise SystemExit(bool(report['errors']))
