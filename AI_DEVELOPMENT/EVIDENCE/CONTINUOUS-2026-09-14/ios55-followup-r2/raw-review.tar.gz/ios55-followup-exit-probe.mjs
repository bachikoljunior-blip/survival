import fs from 'node:fs';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {gunzipSync,gzipSync} from 'node:zlib';
import {spawnSync} from 'node:child_process';
const root='/workspace/scratch/0b7ad82bafe7';const sourceDir=path.join(root,'ios55-followup-source');
const sha=b=>createHash('sha256').update(b).digest('hex');
const outdir=path.join(root,'ios55-followup-exit-fixtures');fs.mkdirSync(outdir);
const raw=gunzipSync(fs.readFileSync(path.join(root,'ios55-followup-image-boundaries.log.gz'))).toString();
const images=[];let current=null;
for(const line of raw.split('\n')){if(line.startsWith('[ios-safari-image] ')){current={...JSON.parse(line.slice(19)),parts:[]};images.push(current);}else if(line.startsWith('[ios-safari-image-data] '))current.parts.push(line.split(' ').slice(2).join(' '));}
const ci=JSON.parse(fs.readFileSync(path.join(root,'ios55-followup-ci-report.json'),'utf8'));
const variants=[['before','test-ios-safari-before.mjs',false],['current','test-ios-safari.mjs',false],['exitCode-candidate','test-ios-safari.mjs',true]];
const result={scope:'Actual Node child-process stdout pipe, exact helper footer. No browser/server/iOS execution. Synthetic PNG buffers reconstructed from the prior CPU fixture log. ExitCode candidate is scratch only.',runs:[]};
for(const bytes of [70,1500001,8000000]){
 const im=images.find(i=>i.bytes===bytes);const b=Buffer.from(im.parts.join(''),'base64');if(b.length!==bytes||sha(b)!==im.sha256)throw Error('fixture mismatch');
 const png=path.join(outdir,`fixture-${bytes}.png`);fs.writeFileSync(png,b);
 const report={...ci,screenshots:{failure:path.basename(png)},fixture:'Synthetic logger test; not a native game screenshot.'};
 const reportfile=path.join(outdir,`report-${bytes}.json`);fs.writeFileSync(reportfile,JSON.stringify(report));
 for(const [name,filename,exitCode] of variants){
  const s=fs.readFileSync(path.join(sourceDir,filename),'utf8');let footer=s.slice(s.indexOf('console.log(`[ios-safari]'));
  if(exitCode){if(!footer.includes('if (report.failures.length) process.exit(1);'))throw Error('footer anchor missing');footer=footer.replace('if (report.failures.length) process.exit(1);','if (report.failures.length) process.exitCode = 1;');}
  const harness=`import {readFileSync} from 'node:fs';\nimport {resolve} from 'node:path';\nimport {createHash} from 'node:crypto';\nconst ROOT=${JSON.stringify(outdir)};\nconst report=JSON.parse(readFileSync(${JSON.stringify(reportfile)},'utf8'));\n${footer}`;
  const script=path.join(outdir,`${name}-${bytes}.mjs`);fs.writeFileSync(script,harness);
  const p=spawnSync(process.execPath,[script],{maxBuffer:32*1024*1024,timeout:20000});
  const stdout=p.stdout??Buffer.alloc(0),stderr=p.stderr??Buffer.alloc(0);
  fs.writeFileSync(path.join(outdir,`${name}-${bytes}.stdout.log.gz`),gzipSync(stdout));fs.writeFileSync(path.join(outdir,`${name}-${bytes}.stderr.log`),stderr);
  const lines=stdout.toString().split('\n');const metaLine=lines.find(l=>l.startsWith('[ios-safari-image] '));let meta=null;try{if(metaLine)meta=JSON.parse(metaLine.slice(19));}catch{}
  const parts=lines.filter(l=>l.startsWith('[ios-safari-image-data] ')).map(l=>l.split(' ').slice(2).join(' '));const decoded=Buffer.from(parts.join(''),'base64');
  const reportLine=lines.find(l=>l.startsWith('[ios-safari-report] '));let reportComplete=false;try{reportComplete=JSON.stringify(JSON.parse(reportLine.slice(20)))===JSON.stringify(report);}catch{}
  result.runs.push({variant:name,fixtureBytes:bytes,sourceFooterSha256:sha(footer),command:[process.execPath,script],exitStatus:p.status,signal:p.signal,error:p.error?.message??null,stdoutBytes:stdout.length,stdoutSha256:sha(stdout),stderrBytes:stderr.length,reportComplete,metadata:meta,receivedBase64Characters:parts.join('').length,decodedBytes:decoded.length,decodedMatchesOriginal:decoded.equals(b)});
 }
}
fs.writeFileSync(path.join(root,'ios55-followup-exit-probe.json'),JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify(result,null,2));
