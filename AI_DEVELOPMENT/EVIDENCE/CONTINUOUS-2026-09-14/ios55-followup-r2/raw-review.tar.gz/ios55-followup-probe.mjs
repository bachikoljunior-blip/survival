import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import {createHash} from 'node:crypto';
import {deflateSync,gzipSync,gunzipSync,inflateSync} from 'node:zlib';
import {nativePointerActions} from './ios55-followup-source/ios-pointer-coordinates.mjs';
const root='/workspace/scratch/0b7ad82bafe7';
const file=n=>path.join(root,n);
const snapshot=file('ios55-followup-source');
const source=fs.readFileSync(path.join(snapshot,'test-ios-safari.mjs'),'utf8');
const oldSource=fs.readFileSync(path.join(snapshot,'test-ios-safari-before.mjs'),'utf8');
const wda=fs.readFileSync(path.join(snapshot,'wda16-FBW3CActionsSynthesizer.m'),'utf8');
const sha=b=>createHash('sha256').update(b).digest('hex');
const report={scope:'CPU boundary execution of exact helper excerpts and source-grounded WDA timing interpretation. No browser, server, simulator, product rendering or iOS measurement.',sourceSha256:sha(source),wdaSha256:sha(wda),checks:[],errors:[]};
const check=async(name,fn)=>{try{const result=await fn();report.checks.push({name,result});console.log(name+': confirmed');}catch(e){report.errors.push({name,message:e.message,stack:e.stack});console.log(name+': FAILED '+e.message);}};
const ciLog=fs.readFileSync(path.join(snapshot,'ios55-job.log'),'utf8');
const recordLine=ciLog.split('\n').find(l=>l.includes('[ios-safari-report] '));assert(recordLine);
const ci=JSON.parse(recordLine.slice(recordLine.indexOf('[ios-safari-report] ')+20));
fs.writeFileSync(file('ios55-followup-ci-report.json'),JSON.stringify(ci,null,2)+'\n');
function excerpt(s,start,end){const a=s.indexOf(start);assert(a>=0,start);const b=s.indexOf(end,a);assert(b>a,end);return s.slice(a,b);}
async function actionsFrom(s){
 const defs=excerpt(s,'function finger(','async function tap(');
 const perform=excerpt(s,'async function performActions(','async function calibratePointerCoordinates(');
 const begin=s.indexOf("  await performActions([\n    finger('move-thumb'");assert(begin>=0);
 const end=s.indexOf('\n  ]);',begin);assert(end>begin);const call=s.slice(begin,end+7);
 const attack=ci.layout.controls.find(c=>c.name==='attack');
 const viewport=ci.inputActions[1].viewport;const calibration=ci.inputCalibration[0];
 const post=[];const fixtureReport={inputActions:[]};
 const ctx=vm.createContext({nativePointerActions,pointerCalibration:calibration,report:fixtureReport,
  attackX:attack.x+attack.width/2,attackY:attack.y+attack.height/2,
  sessionPath:s=>'/fixture-session'+s,
  execute:async script=>{assert.equal(script,'return {innerWidth,innerHeight,outerWidth,outerHeight};');return viewport;},
  webdriver:async(route,opt)=>{post.push({route,opt});return null;}
 });
 await vm.runInContext(`(async()=>{${defs}\n${perform}\n${call}\n})()`,ctx);
 return {excerptSha256:sha(defs+perform+call),captured:JSON.parse(JSON.stringify(fixtureReport.inputActions)),requests:JSON.parse(JSON.stringify(post))};
}
// A deliberately limited interpretation of the pinned Objective-C branches.
// It does not execute XCTest or claim native events were delivered.
function interpretWda(chain){
 let offset=0,previous=null,currentPath=null;const paths=[],items=[];
 for(let i=0;i<chain.actions.length;i++){
  const a=chain.actions[i],duration=a.duration??0;
  assert(Number.isFinite(duration)&&duration>=0);
  if(a.type!=='pointerMove'&&!previous)return {rejected:true,index:i,message:'action item must be preceded by pointerMove item',paths:[]};
  const position=a.type==='pointerMove'?{x:a.x,y:a.y}:previous.position;
  const item={index:i,type:a.type,offsetMs:offset,durationMs:duration,position,event:'none'};
  if(a.type==='pointerMove'){
   if(!currentPath){currentPath={contactStartMs:offset+duration,events:[],contactEndMs:null};paths.push(currentPath);item.event='contact-created';}
   else item.event='move';
   currentPath.events.push({type:item.event,atMs:offset+duration,position});
  }else if(a.type==='pointerDown'){
   if(currentPath&&i===1&&previous.type==='pointerMove')item.event='suppressed-initial-down';
   else {currentPath={contactStartMs:offset,events:[{type:'contact-created',atMs:offset,position}],contactEndMs:null};paths.push(currentPath);item.event='contact-created';}
  }else if(a.type==='pointerUp'){
   assert(currentPath);currentPath.contactEndMs=offset;currentPath.events.push({type:'lift',atMs:offset,position});item.event='lift';
  }else assert.equal(a.type,'pause');
  items.push(item);offset+=duration;previous=item;
 }
 return {id:chain.id,rejected:false,durationMs:offset,items,paths};
}
await check('real-CI-boundary',async()=>{
 assert.equal(ci.status,'failed');assert.equal(ci.checks.length,12);assert(ci.checks.every(c=>c.passed));assert.equal(ci.failureState.mode,'play');
 assert(ci.interaction.titleInput.some(e=>e.type==='pointerup'&&e.trusted&&e.pointerType==='touch'));
 assert(ci.failures.some(f=>f.includes('action item must be preceded by pointerMove item')));
 assert(!ci.interaction.simultaneousMoveAttack);assert(ci.screenshots.failure);assert(!ciLog.includes('[ios-safari-image]'));
 return {ciLogSha256:sha(ciLog),passedChecks:12,mode:'play',twoThumbRejected:true,noScreenshotMetadataInOldLog:true,screenshotByteCountKnown:false};
});
let current;
await check('actual-helper-native-payload',async()=>{
 const before=await actionsFrom(oldSource);current=await actionsFrom(source);
 assert.deepEqual(before.captured[0],ci.inputActions[1]);
 assert.equal(current.requests.length,2);assert.equal(current.requests[0].route,'/fixture-session/actions');assert.equal(current.requests[1].opt.method,'DELETE');
 const native=current.captured[0].native;
 assert.deepEqual(current.requests[0].opt.body.actions,native);
 assert(native.every(c=>c.actions[0].type==='pointerMove'));
 assert(native.every(c=>c.actions.every(a=>a.type!=='pause'||a.duration>0)));
 assert.deepEqual(native.map(c=>c.actions.map(a=>a.duration??0)),[[0,0,350,550,0],[350,0,150,0]]);
 assert.equal(native[1].actions[0].x,619);assert.equal(native[1].actions[0].y,330);
 fs.writeFileSync(file('ios55-followup-actions.json'),JSON.stringify({before,current},null,2)+'\n');
 return {beforeMatchesActualCI:true,currentExcerptSha256:current.excerptSha256,native,transportStub:'Records exact POST/DELETE payload only; no Appium request.'};
});
await check('WDA-source-timing-and-negative-controls',async()=>{
 for(const s of ['self.durationOffset += ((FBBaseGestureItem *)item).duration;','currentItemIndex == 1','FBMillisToSeconds(self.offset + self.duration)','[eventPath liftUpAtOffset:FBMillisToSeconds(self.offset)]','FBW3CGestureItemsChain *chain = [[FBW3CGestureItemsChain alloc] init]'])assert(wda.includes(s),s);
 const original=ci.inputActions[1].native.map(interpretWda);assert(original[1].rejected);assert.equal(original[1].index,0);
 const derived=current.captured[0].native.map(interpretWda);
 assert.deepEqual(derived.map(d=>d.paths.map(p=>[p.contactStartMs,p.contactEndMs])),[[[0,900]],[[350,500]]]);
 assert.equal(derived.reduce((n,d)=>n+d.paths.length,0),2);
 assert(derived.every(d=>d.items[1].event==='suppressed-initial-down'));
 const overlap=Math.min(900,500)-Math.max(0,350);assert.equal(overlap,150);
 const leadingPause=structuredClone(current.captured[0].native[1]);leadingPause.actions.unshift({type:'pause',duration:1});assert(interpretWda(leadingPause).rejected);
 const extraDown=structuredClone(current.captured[0].native[1]);extraDown.actions.splice(1,0,{type:'pause',duration:1});assert.equal(interpretWda(extraDown).paths.length,2);
 const raw={mode:'Source interpretation, not Objective-C/XCTest execution',derived,overlapMs:overlap,negativeControls:{originalLeadingPauseRejects:original[1],injectedLeadingPauseRejects:interpretWda(leadingPause),separatedInitialDownCreatesExtraPath:interpretWda(extraDown)}};
 fs.writeFileSync(file('ios55-followup-wda-timeline.json'),JSON.stringify(raw,null,2)+'\n');return raw;
});
const crcTable=Array.from({length:256},(_,n)=>{let c=n;for(let k=0;k<8;k++)c=(c&1)?0xedb88320^(c>>>1):c>>>1;return c>>>0;});
function crc(b){let c=0xffffffff;for(const v of b)c=crcTable[(c^v)&255]^(c>>>8);return (c^0xffffffff)>>>0;}
function chunk(type,data){const h=Buffer.alloc(8),tail=Buffer.alloc(4);h.writeUInt32BE(data.length);h.write(type,4);tail.writeUInt32BE(crc(Buffer.concat([Buffer.from(type),data])));return Buffer.concat([h,data,tail]);}
function png(size){const sig=Buffer.from([137,80,78,71,13,10,26,10]);const h=Buffer.alloc(13);h.writeUInt32BE(1,0);h.writeUInt32BE(1,4);h[8]=8;h[9]=6;const head=chunk('IHDR',h),idat=chunk('IDAT',deflateSync(Buffer.from([0,7,11,13,255]))),end=chunk('IEND',Buffer.alloc(0));let parts=[sig,head,idat,end];if(size){const base=parts.reduce((n,p)=>n+p.length,0);const text=Buffer.alloc(size-base-12,120);Buffer.from('Comment\0').copy(text);parts=[sig,head,chunk('tEXt',text),idat,end];}const b=Buffer.concat(parts);if(size)assert.equal(b.length,size);return b;}
function validatePng(b){assert.equal(b.subarray(0,8).toString('hex'),'89504e470d0a1a0a');let o=8,idat=[];while(o<b.length){const n=b.readUInt32BE(o),t=b.subarray(o+4,o+8).toString(),d=b.subarray(o+8,o+8+n);assert.equal(b.readUInt32BE(o+8+n),crc(b.subarray(o+4,o+8+n)));if(t==='IDAT')idat.push(d);o+=12+n;}assert.equal(o,b.length);assert.equal(inflateSync(Buffer.concat(idat)).toString('hex'),'00070b0dff');return true;}
await check('lossless-screenshot-and-log-boundaries',async()=>{
 const fixtures=[{name:'small.png',b:png()},...[1500001,7999999,8000000,8000001].map(n=>({name:`bytes-${n}.png`,b:png(n)}))];fixtures.forEach(f=>validatePng(f.b));
 const fixtureRoot='/cpu-fixture-only';const files=new Map(fixtures.map(f=>[path.resolve(fixtureRoot,f.name),f.b]));
 const fixtureReport={...ci,diagnosticFixture:'Synthetic valid1x1 PNG boundaries. These are not captured game/native screenshots.',screenshots:Object.fromEntries(fixtures.map((f,i)=>[String(i),f.name])),unicode:'改行\n日本語\u0000<>\\'};
 const beforeShot=excerpt(source,'async function screenshot(','async function injectErrorCapture(');const written=[];
 const shotCtx=vm.createContext({webdriver:async()=>fixtures[0].b.toString('base64'),sessionPath:s=>s,writeFileSync:(p,b)=>written.push({p,b}),Buffer});
 await vm.runInContext(`(async()=>{${beforeShot}\nawait screenshot('raw-PNG-fixture.png');})()`,shotCtx);assert.equal(written.length,1);assert(written[0].b.equals(fixtures[0].b));
 const emit=excerpt(source,'console.log(`[ios-safari-report]','for (const failure of report.failures)');
 const oldEmit=excerpt(oldSource,'console.log(`[ios-safari-report]','for (const failure of report.failures)');
 function emitLog(code){const lines=[];const ctx=vm.createContext({report:fixtureReport,ROOT:fixtureRoot,resolve:path.resolve,readFileSync:p=>{assert(files.has(p));return files.get(p);},createHash,console:{log:s=>lines.push(String(s))}});vm.runInContext(code,ctx);return lines;}
 const lines=emitLog(emit);const oldLines=emitLog(oldEmit);assert.equal(oldLines.filter(l=>l.startsWith('[ios-safari-image]')).length,1);
 const raw=Buffer.from(lines.join('\n')+'\n');const gz=gzipSync(raw);fs.writeFileSync(file('ios55-followup-image-boundaries.log.gz'),gz);assert(gunzipSync(gz).equals(raw));
 const oldRaw=Buffer.from(oldLines.join('\n')+'\n');fs.writeFileSync(file('ios55-followup-image-boundaries-before.log.gz'),gzipSync(oldRaw));
 const parsed=JSON.parse(lines[0].slice('[ios-safari-report] '.length));assert.deepEqual(parsed,fixtureReport);
 const decoded=[];let currentImage=null;
 for(const line of lines.slice(1)){
  if(line.startsWith('[ios-safari-image] ')){currentImage={...JSON.parse(line.slice('[ios-safari-image] '.length)),parts:[],offset:0};decoded.push(currentImage);}
  else{assert(line.startsWith('[ios-safari-image-data] '));assert(currentImage?.included);const m=line.match(/^\[ios-safari-image-data\] (\d+) (.*)$/);assert(m);assert.equal(Number(m[1]),currentImage.offset);assert(m[2].length<=4000);currentImage.parts.push(m[2]);currentImage.offset+=m[2].length;}
 }
 assert.equal(decoded.length,fixtures.length);
 for(let i=0;i<decoded.length;i++){const d=decoded[i],f=fixtures[i];assert.equal(d.path,f.name);assert.equal(d.bytes,f.b.length);assert.equal(d.sha256,sha(f.b));assert.equal(d.included,f.b.length<=8000000);if(d.included){const b=Buffer.from(d.parts.join(''),'base64');assert(b.equals(f.b));validatePng(b);}else assert.equal(d.parts.length,0);}
 const summary={scope:'Actual logger/screenshot byte handling executed with synthetic valid PNG buffers, no original CI PNG available locally.',emitterSha256:sha(emit),reportRoundTripDeepEqual:true,screenshotBase64WriteExact:true,rawLogSha256:sha(raw),rawLogBytes:raw.length,compressedLogBytes:gz.length,allPngCRCAndPixelsPreserved:true,images:decoded.map(({parts,offset,...d})=>({...d,chunks:parts.length,base64Characters:offset})),oldLoggerMetadataImages:1,oldLoggerOmittedWithoutMetadata:fixtures.length-1};
 fs.writeFileSync(file('ios55-followup-image-boundaries.json'),JSON.stringify(summary,null,2)+'\n');return summary;
});
fs.writeFileSync(file('ios55-followup-probe.json'),JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({checks:report.checks.length,errors:report.errors.length}));
if(report.errors.length)process.exitCode=1;
