import fs from 'node:fs';
import vm from 'node:vm';
import {nativePointerActions} from './ios55-followup-source/ios-pointer-coordinates.mjs';
const ci=JSON.parse(fs.readFileSync(new URL('./ios55-followup-ci-report.json',import.meta.url),'utf8'));
const attack=ci.layout.controls.find(x=>x.name==='attack');
const viewport=ci.inputActions[1].viewport;
const results=[];
for(const name of ['test-ios-safari-before.mjs','test-ios-safari.mjs']){
 const s=fs.readFileSync(new URL('./ios55-followup-source/'+name,import.meta.url),'utf8');
 const defs=s.slice(s.indexOf('function finger('),s.indexOf('async function tap('));
 const perform=s.slice(s.indexOf('async function performActions('),s.indexOf('async function calibratePointerCoordinates('));
 const a=s.indexOf("  await performActions([\n    finger('move-thumb'");
 const call=s.slice(a,s.indexOf('\n  ]);',a)+7);
 const report={inputActions:[]},requests=[];
 await vm.runInNewContext('(async()=>{'+defs+perform+call+'})()',{
  nativePointerActions,pointerCalibration:ci.inputCalibration[0],report,
  attackX:attack.x+attack.width/2,attackY:attack.y+attack.height/2,
  sessionPath:p=>p,execute:async()=>viewport,webdriver:async(p,options)=>requests.push({p,options})
 });
 results.push({name,report,requests});
}
console.log(JSON.stringify(results));
