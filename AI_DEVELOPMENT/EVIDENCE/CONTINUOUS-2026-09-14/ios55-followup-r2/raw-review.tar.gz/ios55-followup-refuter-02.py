import base64
import gzip
import hashlib
import json
import pathlib
import subprocess
import time

ROOT = pathlib.Path('/workspace/scratch/0b7ad82bafe7')
OUT = ROOT / 'ios55-followup-refuter-02.json'
DIR = ROOT / 'ios55-followup-refuter-fixtures-02'
assert not OUT.exists() and not DIR.exists()
DIR.mkdir()
sha = lambda b: hashlib.sha256(b).hexdigest()
source_dir = ROOT / 'ios55-followup-source'
pins = {n: sha((source_dir / n).read_bytes()) for n in ['test-ios-safari.mjs', 'test-ios-safari-r2.mjs']}
assert pins['test-ios-safari.mjs'] == 'db769c26dcb7447a0183f9733981cd0ade6d8487373863da7f8ac41b9766c64b'
assert pins['test-ios-safari-r2.mjs'] == 'b85b83ec116fe0187af82eca847c7d6ecb14db3e18498dcb96c228e43d285a2d'
original = (ROOT / 'ios55-followup-refuter-fixtures-01/fixture-8000000.png').read_bytes()
expected_report = json.loads((ROOT / 'ios55-followup-refuter-fixtures-01/report-8000000.json').read_text())
report = {'scope': 'Controlled stdout-pipe backpressure after promptly drained probe 01 did not reproduce truncation. Real Node child processes execute exact original and actual r2 footers. No console/stream mocks, no browser/server/iOS execution.', 'reader_delay_seconds': 0.15, 'node_version': subprocess.check_output(['node', '--version']).decode().strip(), 'source_pins': pins, 'runs': []}
for kind in ['current', 'actual-r2']:
    script = ROOT / ('ios55-followup-refuter-fixtures-01/' + kind + '-8000000.mjs')
    source_name = 'test-ios-safari.mjs' if kind == 'current' else 'test-ios-safari-r2.mjs'
    source = (source_dir / source_name).read_text()
    footer = source[source.index('console.log(`[ios-safari]'):]
    assert script.read_text().endswith(footer)
    proc = subprocess.Popen(['node', str(script)], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    # Hold the reader for 150 ms, then drain with communicate. Both variants
    # receive the identical bounded delay. This is a declared local control,
    # not a claim about the timing or buffer sizes of the macOS CI consumer.
    time.sleep(report['reader_delay_seconds'])
    stdout, stderr = proc.communicate(timeout=20)
    (DIR / (kind + '.stdout.log.gz')).write_bytes(gzip.compress(stdout))
    (DIR / (kind + '.stderr.log')).write_bytes(stderr)
    lines = stdout.decode().splitlines()
    report_complete, metadata = False, None
    for line in lines:
        try:
            if line.startswith('[ios-safari-report] '):
                report_complete = json.loads(line.split(' ', 1)[1]) == expected_report
            if line.startswith('[ios-safari-image] '):
                metadata = json.loads(line.split(' ', 1)[1])
        except json.JSONDecodeError:
            pass
    parts = []
    for line in lines:
        if line.startswith('[ios-safari-image-data] '):
            fields = line.split(' ', 2)
            if len(fields) == 3:
                parts.append(fields[2])
    encoded = ''.join(parts)
    decoded = base64.b64decode(encoded[:len(encoded)//4*4])
    report['runs'].append({'variant': kind, 'args': ['node', str(script)], 'child_source_sha256': sha(script.read_bytes()), 'footer_sha256': sha(footer.encode()), 'exit_status': proc.returncode, 'stdout_bytes': len(stdout), 'stdout_sha256': sha(stdout), 'stderr_bytes': len(stderr), 'report_complete': report_complete, 'metadata': metadata, 'decoded_bytes': len(decoded), 'decoded_sha256': sha(decoded), 'image_exact': decoded == original})
report['sources_unchanged'] = pins == {n: sha((source_dir / n).read_bytes()) for n in pins}
report['current_truncation_reproduced'] = not report['runs'][0]['image_exact']
report['actual_r2_complete_and_exit_1'] = report['runs'][1]['image_exact'] and report['runs'][1]['report_complete'] and report['runs'][1]['exit_status'] == 1
OUT.write_text(json.dumps(report, indent=2, ensure_ascii=False, allow_nan=False) + '\n')
print(json.dumps(report, indent=2))
assert report['sources_unchanged']
assert all(r['exit_status'] == 1 for r in report['runs'])
assert report['current_truncation_reproduced'] and report['actual_r2_complete_and_exit_1']
