import {readFileSync} from 'node:fs';
import {resolve} from 'node:path';
import {createHash} from 'node:crypto';
const ROOT="/workspace/scratch/0b7ad82bafe7/ios55-followup-exit-fixtures";
const report=JSON.parse(readFileSync("/workspace/scratch/0b7ad82bafe7/ios55-followup-exit-fixtures/report-1500001.json",'utf8'));
console.log(`[ios-safari] ${report.status.toUpperCase()}: ${report.failures.length} failure(s)`);
// Keep the exact report and bounded, lossless images readable through the
// ordinary job log as well as the artifact; never substitute them for video.
console.log(`[ios-safari-report] ${JSON.stringify(report)}`);
for (const relative of Object.values(report.screenshots)) {
  const bytes = readFileSync(resolve(ROOT, relative));
  if (bytes.length > 1500000) continue;
  const data = bytes.toString('base64'), sha256 = createHash('sha256').update(bytes).digest('hex');
  console.log(`[ios-safari-image] ${JSON.stringify({path:relative,bytes:bytes.length,sha256})}`);
  for (let offset = 0; offset < data.length; offset += 4000) {
    console.log(`[ios-safari-image-data] ${offset} ${data.slice(offset, offset + 4000)}`);
  }
}
for (const failure of report.failures) console.error(`- ${failure}`);
if (report.failures.length) process.exit(1);
