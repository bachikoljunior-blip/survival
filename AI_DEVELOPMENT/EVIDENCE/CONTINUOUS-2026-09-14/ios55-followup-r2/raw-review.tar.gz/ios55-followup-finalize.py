import pathlib,json,hashlib
root=pathlib.Path('/workspace/scratch/0b7ad82bafe7')
r=json.loads((root/'ios55-followup-review-draft.json').read_text());ref=json.loads((root/'ios55-followup-refuter-02.json').read_text())
assert ref['sources_unchanged'] and ref['current_truncation_reproduced'] and ref['actual_r2_complete_and_exit_1']
r['refutationStatus']='COMPLETE_SEPARATE_REFUTER'
r['independentRefutation']={'agent':'/root/trench_perception_review/trench_refuter','raw':['ios55-followup-refuter-01.json','ios55-followup-refuter-02.json'],'result':'Timing/contact/PNG-boundary claims survived. Truncation is conditional: promptly read stdout completed, while150ms delayed reading retained only36000 of8000000 old PNG bytes. Under the same delay the actual updated footer preserved8000000 bytes/hash and exit1. The retained first probe assertion failure prevents a deterministic-truncation claim.','openActionableFindings':0}
r['resolvedFindings'][0]['refutation']={'status':'confirmed conditional mechanism; actualr2 fix independently verified','evidence':'ios55-followup-refuter-02.json','oldDecodedBytes':36000,'expectedAndFixedDecodedBytes':8000000,'readerDelayMs':150,'exitStatusBeforeAndAfter':1,'fastReaderCounterexample':'ios55-followup-refuter-01.json'}
r['verifiedControls'].append({'id':'DRIVER-WRAPPER','evidence':'ios55-followup-driver-wrapper.json','result':'Pinned v12.1.3 driver converts pointers to touch and removes zero pauses only; current payload already satisfies both conditions so its durations are unchanged. DELETE releaseActions is a no-op. Contact endings are justified by the explicit pointerUp events, not DELETE.'})
r['rawEvidence'] += ['ios55-followup-refuter-01.py','ios55-followup-refuter-01.json','ios55-followup-refuter-01.log','ios55-followup-refuter-02.py','ios55-followup-refuter-02.json','ios55-followup-refuter-02.log','ios55-followup-driver-wrapper.json','ios55-followup-integrity.json']
p=root/'ios55-followup-source/appium-12.1.3-gesture.ts';r['sourcePins'].append({'path':str(p.relative_to(root)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
for n in ['ios55-followup-refuter-review.json','ios55-followup-refuter-validation.json']:
 if (root/n).exists():r['rawEvidence'].append(n)
(root/'ios55-followup-review.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps({'review':'ios55-followup-review.json','openFindings':0,'resolvedFindings':len(r['resolvedFindings']),'refutation':r['refutationStatus']}))
