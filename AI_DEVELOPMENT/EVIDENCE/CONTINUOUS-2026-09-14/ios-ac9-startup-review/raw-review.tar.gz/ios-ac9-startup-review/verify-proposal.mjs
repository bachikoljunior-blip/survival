import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import zlib from 'node:zlib';
const root = path.dirname(new URL(import.meta.url).pathname);
const sha = b => crypto.createHash('sha256').update(b).digest('hex');
const candidate = path.join(root, 'proposed-startup-log-export.mjs');
const cap = 4 * 1024 * 1024;
const outcomes = [];
for (const [name, length] of [['small', 7193], ['at-cap', cap], ['over-cap', cap + 1]]) {
  const cwd = path.join(root, 'raw', `fixture-${name}`);
  const dir = path.join(cwd, 'test-results/ios-safari');
  fs.mkdirSync(dir, { recursive: true });
  const data = Buffer.alloc(length);
  for (let i = 0; i < data.length; i++) data[i] = (i * 73 + 17) % 256;
  Buffer.from('::warning::CPU FIXTURE ONLY\n日本語\u0000\xff').copy(data);
  fs.writeFileSync(path.join(dir, 'appium.log'), data);
  fs.writeFileSync(path.join(dir, 'simulator-selection.json'), '{"fixture":true,"platformVersion":"18.5"}\n');
  fs.writeFileSync(path.join(dir, 'xcode-version.txt'), 'CPU fixture, no actual Xcode\n');
  fs.writeFileSync(path.join(dir, 'xcode-path.txt'), 'CPU fixture, no actual Xcode path\n');
  // Missing simulator-sdk-version.txt verifies explicit missing-file metadata.
  const child = spawn(process.execPath, [candidate], { cwd, stdio: ['ignore', 'pipe', 'pipe'] });
  let stdout = '', stderr = '';
  child.stderr.setEncoding('utf8'); child.stderr.on('data', b => { stderr += b; });
  // Delay consumption briefly to exercise actual OS stdout backpressure.
  child.stdout.pause();
  await new Promise(resolve => setTimeout(resolve, 150));
  child.stdout.setEncoding('utf8'); child.stdout.on('data', b => { stdout += b; }); child.stdout.resume();
  const exitCode = await new Promise((resolve, reject) => { child.on('error', reject); child.on('close', resolve); });
  fs.writeFileSync(path.join(root, 'raw', `export-${name}.stdout.log.gz`), zlib.gzipSync(stdout));
  fs.writeFileSync(path.join(root, 'raw', `export-${name}.stderr.txt`), stderr);
  assert.equal(exitCode, 0); assert.equal(stderr, '');
  const entries = stdout.trim().split('\n').map(line => {
    const [, kind, text] = line.match(/^\[ios-startup-log-(meta|chunk|end|error)\] (.*)$/) || [];
    assert(kind, 'Every line is prefixed and structured, including raw workflow-command fixture text.');
    return { kind, ...JSON.parse(text) };
  });
  const meta = entries.find(x => x.kind === 'meta' && x.file === 'appium.log');
  assert(meta); assert.equal(meta.bytes, length); assert.equal(meta.sha256, sha(data));
  assert.equal(meta.complete, length <= cap); assert.equal(meta.stableDuringRead, true);
  assert(entries.some(x => x.kind === 'end' && x.file === 'appium.log' && x.sha256 === sha(data)));
  const chunks = entries.filter(x => x.kind === 'chunk' && x.file === 'appium.log');
  let byteCount = 0;
  for (const chunk of chunks) {
    const bytes = Buffer.from(chunk.base64, 'base64');
    assert(bytes.equals(data.subarray(chunk.offset, chunk.offset + bytes.length)));
    byteCount += bytes.length;
  }
  assert.equal(byteCount, Math.min(length, cap));
  for (const [start, end] of meta.ranges) {
    let offset = start;
    for (const chunk of chunks.filter(x => x.offset >= start && x.offset < end)) {
      assert.equal(chunk.offset, offset); offset += Buffer.from(chunk.base64, 'base64').length;
    }
    assert.equal(offset, end);
  }
  assert(entries.some(x => x.kind === 'error' && x.file === 'simulator-sdk-version.txt' && x.code === 'ENOENT'));
  outcomes.push({ name, bytes: length, sha256: sha(data), decodedIncludedBytes: byteCount, complete: meta.complete, ranges: meta.ranges, delayedReaderMs: 150, stdoutBytes: Buffer.byteLength(stdout), exitCode, exactBytesForEveryIncludedRange: true, missingFileReported: true, noWorkflowCommandInRawLines: true });
}
const source = fs.readFileSync(candidate, 'utf8');
const original = fs.readFileSync(path.join(root, 'source/current-.github_workflows_mobile-simulator.yml'), 'utf8');
const step = '      - name: Emit startup diagnostics in ordinary CI log\n        if: always()\n        shell: bash\n        run: |\n          node --input-type=module <<\'NODE\'\n' + source.split('\n').map(l => '          ' + l).join('\n') + '\n          NODE\n';
const marker = '      - name: Preserve Safari screenshots, video, logs and report\n';
assert.equal(original.split(marker).length, 2);
const proposal = original.replace(marker, step + marker);
fs.writeFileSync(path.join(root, 'proposed-mobile-simulator.yml'), proposal);
fs.writeFileSync(path.join(root, 'raw/proposal-verification.json'), JSON.stringify({ scope: 'CPU file/log transport only; synthetic inputs; no native measurement', candidateSha256: sha(source), originalWorkflowSha256: sha(original), proposedWorkflowSha256: sha(proposal), insertedSteps: 1, changedCapabilities: 0, changedTimeouts: 0, sourceExporterIsExactInlineStep: true, outcomes }, null, 2) + '\n');
console.log(JSON.stringify(outcomes, null, 2));
