import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import vm from 'node:vm';

const root = path.dirname(new URL(import.meta.url).pathname);
const read = p => fs.readFileSync(path.join(root, p), 'utf8');
const sha = b => crypto.createHash('sha256').update(b).digest('hex');
const numbered = (text, pattern) => text.split('\n').flatMap((line, i) => pattern.test(line) ? [{ line: i + 1, text: line }] : []);
const reportFrom = raw => {
  const entries = raw.split('\n').filter(l => l.includes('[ios-safari-report] '));
  assert.equal(entries.length, 1);
  const line = entries[0];
  return { emittedAt: line.match(/\d{4}-\d\d-\d\dT\S+Z/)[0], data: JSON.parse(line.split('[ios-safari-report] ')[1]) };
};
const sessionSnippet = source => {
  const start = source.indexOf("  const created = await webdriver('session', {");
  const end = source.indexOf("  sessionId = created?.sessionId", start);
  assert(start >= 0 && end > start);
  return source.slice(start, end);
};
const versions = ['55fa8fe', 'ac9cd44', 'current'];
const payloads = {};
const snippets = {};
for (const v of versions) {
  const source = read(`source/${v}-tools_test-ios-safari.mjs`);
  const snippet = sessionSnippet(source);
  let count = 0;
  const context = vm.createContext({
    UDID: '22A3039C-6A45-47F4-82D4-80C58CA94379', PLATFORM_VERSION: '18.5',
    webdriver: async (endpoint, args) => {
      count++;
      assert.equal(endpoint, 'session');
      payloads[v] = JSON.parse(JSON.stringify(args.body));
      return { sessionId: 'CPU_CAPTURE_ONLY_NO_REQUEST' };
    },
  });
  await new vm.Script(`(async () => { ${snippet}\nreturn created; })()`).runInContext(context);
  assert.equal(count, 1);
  snippets[v] = { sha256: sha(snippet), bytes: Buffer.byteLength(snippet), firstLine: source.slice(0, source.indexOf(snippet)).split('\n').length };
}
assert.deepEqual(payloads['55fa8fe'], payloads.ac9cd44);
assert.deepEqual(payloads.current, payloads.ac9cd44);
assert.equal(snippets['55fa8fe'].sha256, snippets.ac9cd44.sha256);
const previousRaw = read('raw/ios55-job.log');
const currentRaw = read('raw/mobile-ac9cd44_ios-job.log');
const previous = reportFrom(previousRaw), current = reportFrom(currentRaw);
assert.equal(current.data.checks.length, 0);
assert.equal(previous.data.checks.length, 12);
assert(previous.data.checks.every(c => c.passed));
assert.equal(previous.data.failureState.mode, 'play');
assert.equal(current.data.inputActions.length, 0);
assert.equal(current.data.device, null);
assert.match(current.data.failures[0], /^Error: WebDriver POST \/session: The remote debugger did not return any connected web applications after 43484ms\./);
assert.match(current.data.failures[0], /webdriver-request\.mjs:33:18/);
const currentSource = read('source/current-tools_test-ios-safari.mjs');
const firstExplicitGameNavigation = currentSource.indexOf("await webdriver(sessionPath('/url'), { body: { url: baseUrl } });");
assert(firstExplicitGameNavigation > currentSource.indexOf("if (!sessionId) throw new Error('Appium did not return a session id')"));
assert.equal(current.data.transport.sessionRequestTimeoutMs, 900000);
const errorLine = numbered(currentRaw, /- Error: WebDriver POST \/session: The remote debugger/)[0];
const errorAt = errorLine.text.match(/\d{4}-\d\d-\d\dT\S+Z/)[0];
const elapsed = Date.parse(errorAt) - Date.parse(current.data.checkedAt);
assert(elapsed < 900000);
const workflowPaths = ['.github_workflows_mobile-simulator.yml', '.github_workflows_pages.yml'];
const unchanged = workflowPaths.concat(['tools_webdriver-request.mjs', 'tools_select-ios-simulator.mjs']).map(p => {
  const before = read(`source/55fa8fe-${p}`), after = read(`source/ac9cd44-${p}`), actual = read(`source/current-${p}`);
  assert.equal(before, after); assert.equal(after, actual);
  return { snapshotName: p, sha256: sha(actual), bytes: Buffer.byteLength(actual), identicalAcrossThreeSnapshots: true };
});
const result = {
  scope: 'Read-only source payload evaluation and parsing actual CI logs. No HTTP request, browser, server, simulator, or iOS execution.',
  cpuRuntime: { node: process.version, platform: process.platform, arch: process.arch },
  snippets, sessionPayload: payloads.current, unchanged,
  previous: { checkedAt: previous.data.checkedAt, reportAt: previous.emittedAt, checks: previous.data.checks.length, allRecordedChecksPassed: true, wholeJobStatus: previous.data.status, failureStateMode: previous.data.failureState.mode, failure: previous.data.failures[0] },
  current: { checkedAt: current.data.checkedAt, errorAt, reportAt: current.emittedAt, reportInitializationToErrorMs: elapsed, remoteDebuggerReportedIntervalMs: 43484, exactPostSessionDurationKnown: false, requestBudgetMs: 900000, checks: 0, inputActions: 0, device: null, status: current.data.status, failure: current.data.failures[0] },
  boundaries: { sessionCreationFailed: true, clientTotalBudgetDidNotExpire: true, explicitGameUrlNavigationNotReached: true, titleAndTouchChecksNotReached: true, appiumProcessAliveEnoughToReturnSessionError: true, safariOrWdaReadinessEstablishedByHttpStatusAlone: false },
  sourceEvidence: numbered(currentSource, /SESSION_REQUEST_TIMEOUT|const created =|sessionId = created|did not return a session id|sessionPath\('\/url'\)/),
  logEvidence: {
    current: numbered(currentRaw, /Image: |Version: 20260907|15\.7\.9|43484ms|isTerminal=YES|IOS_SIMULATOR_PLATFORM_VERSION:|IOS_SIMULATOR_UDID:|11 files uploaded|SHA256 digest of uploaded artifact|\/dev\/null 2>&1/),
    previous: numbered(previousRaw, /Image: |Version: 20260907|15\.7\.9|isTerminal=YES|IOS_SIMULATOR_PLATFORM_VERSION:|IOS_SIMULATOR_UDID:/),
  },
  limits: ['Same selected UDID does not imply the same live simulator instance across fresh hosted workers.', 'The ordinary CI logs do not contain actual Xcode-version file contents or Appium remote-debugger/WDA startup trace.', 'Report initialization precedes HTTP readiness checks and the POST; 583847 ms is not an exact POST duration.', 'The 12 previous checks and play state are actual recorded observations, not a whole-job or element pass.', 'The captured session payload is source evidence only; the stub does not emulate Appium or iOS.'],
};
fs.writeFileSync(path.join(root, 'raw/startup-analysis.json'), JSON.stringify(result, null, 2) + '\n');
fs.writeFileSync(path.join(root, 'raw/ac9-original-report.json'), JSON.stringify(current.data, null, 2) + '\n');
fs.writeFileSync(path.join(root, 'raw/55fa-original-report.json'), JSON.stringify(previous.data, null, 2) + '\n');
console.log(JSON.stringify({ checks: 'source/parse assertions completed', exactSameSessionSnippet: snippets.current, reportInitializationToErrorMs: elapsed, previousRecordedChecks: 12, currentRecordedChecks: 0, unchanged }, null, 2));
