import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { validateFindings } from '../survival/.kit/lib/plan/findings.mjs';
const root = path.dirname(new URL(import.meta.url).pathname);
const read = p => JSON.parse(fs.readFileSync(path.join(root, p), 'utf8'));
const review = read('review-draft.json');
const refuter = read('refuter-review.json');
const owners = new Set(execFileSync('git', ['ls-files', 'tools', '.github/workflows'], { cwd: path.join(root, '../survival'), encoding: 'utf8' }).trim().split('\n'));
const refuterValidation = validateFindings(refuter, { strict: true, knownOwners: owners });
assert(refuterValidation.ok, JSON.stringify(refuterValidation));
assert.equal(refuter.findings.length, 0, 'Resolve independent actionable findings before finalizing.');
review.refutationStatus = 'COMPLETE_SEPARATE_REFUTER';
review.independentRefutation = {
  agent: '/root/trench_perception_review/trench_refuter', review: 'refuter-review.json', script: 'refuter-01.py', raw: ['refuter-01.json', 'refuter-01.log'],
  result: 'Startup classification, unchanged checked source and the diagnostic-gap finding survived. The separate refuter found no concrete defect in the proposed single CI observation step, while retaining unknown root cause and file-snapshot limits.',
};
review.findings[0].refutation = { status: 'SURVIVED', evidence: 'refuter-review.json', limits: 'Diagnosis remains unknown; the proposal obtains evidence and is not a measured startup repair.' };
review.comparativeControl.sameLoggedEnvironment.node = 'v22.23.2';
review.comparativeControl.sameLoggedEnvironment.npm = '10.9.8';
review.comparativeControl.environmentEvidence = 'raw/environment-comparison.json';
review.actualObservation.firstLoggedErrorAt = review.actualObservation.firstErrorAt;
delete review.actualObservation.firstErrorAt;
review.actualObservation.reportInitializationToLoggedErrorMs = review.actualObservation.reportInitializationToErrorMs;
delete review.actualObservation.reportInitializationToErrorMs;
review.proposedArtifacts.applicablePatch = 'proposed-mobile-simulator.patch';
review.proposedArtifacts.patchCheck = { command: 'git -C survival apply --check ../ios-ac9-startup-review/proposed-mobile-simulator.patch', exitCode: 0, raw: ['raw/patch-check.stdout.txt', 'raw/patch-check.stderr.txt'], applied: false };
review.findings[0].fix = review.findings[0].fix.replace('up to4194304', 'up to 4194304').replace('up to65536', 'up to 65536').replace('Read node /workspace/scratch/0b7ad82bafe7/ios-ac9-startup-review/analyze-startup.mjs and raw/proposal-verification-r3.json:', 'Read python -m json.tool /workspace/scratch/0b7ad82bafe7/ios-ac9-startup-review/raw/proposal-verification-r3.json and raw/startup-analysis.json:').replace('remain97', 'remain 97').replace('and4194305', 'and 4194305');
const validation = validateFindings(review, { strict: true, knownOwners: owners });
assert(validation.ok, JSON.stringify(validation));
fs.writeFileSync(path.join(root, 'review.json'), JSON.stringify(review, null, 2) + '\n');
fs.writeFileSync(path.join(root, 'validation.json'), JSON.stringify({ review: validation, refuter: refuterValidation }, null, 2) + '\n');
const files = [];
function walk(dir) {
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, e.name);
    if (e.isDirectory()) walk(p);
    else if (e.isFile() && !['manifest.json', 'finalize-review.stdout.txt', 'finalize-review.stderr.txt'].includes(e.name)) {
      const b = fs.readFileSync(p);
      files.push({ path: path.relative(root, p), bytes: b.length, sha256: crypto.createHash('sha256').update(b).digest('hex') });
    }
  }
}
walk(root);
fs.writeFileSync(path.join(root, 'manifest.json'), JSON.stringify({ root, artifactCount: files.length, files }, null, 2) + '\n');
console.log(JSON.stringify({ strictValidation: validation, separateRefuterValidation: refuterValidation, files: files.length, reviewSha256: files.find(f => f.path === 'review.json').sha256, refuterSha256: files.find(f => f.path === 'refuter-review.json').sha256, helperSha256: 'b85b83ec116fe0187af82eca847c7d6ecb14db3e18498dcb96c228e43d285a2d', patchSha256: files.find(f => f.path === 'proposed-mobile-simulator.patch').sha256 }, null, 2));
