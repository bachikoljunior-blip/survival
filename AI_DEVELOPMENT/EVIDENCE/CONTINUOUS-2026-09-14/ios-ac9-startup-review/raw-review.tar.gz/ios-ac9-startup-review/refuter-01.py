import base64
import datetime
import gzip
import hashlib
import json
import pathlib
import re
import subprocess
import time
import traceback

import yaml

ROOT = pathlib.Path('/workspace/scratch/0b7ad82bafe7/ios-ac9-startup-review')
OUT = ROOT / 'refuter-01.json'
FIXTURES = ROOT / 'refuter-fixtures-01'
assert not OUT.exists() and not FIXTURES.exists(), 'Preserve prior attempts.'
FIXTURES.mkdir()
sha = lambda b: hashlib.sha256(b).hexdigest()
pins = json.loads((ROOT / 'pins.json').read_text())
tracked = [ROOT / f['snapshot'] for f in pins['files']] + [ROOT / 'proposed-startup-log-export.mjs', ROOT / 'proposed-mobile-simulator.yml']
report = {'scope': 'Independent parsing, exact workflow/source comparison, and real CPU stdout-pipe execution of the proposed inline export only. No product/helper/workflow edits, native execution, network or server.', 'checks': [], 'errors': []}
report['source_hashes_before'] = {str(p.relative_to(ROOT)): sha(p.read_bytes()) for p in tracked}
for f in pins['files']:
    assert sha((ROOT / f['snapshot']).read_bytes()) == f['sha256']


def check(name, fn):
    try:
        report['checks'].append({'name': name, 'result': fn()})
    except Exception:
        report['errors'].append({'name': name, 'traceback': traceback.format_exc()})


def source_and_ci():
    outputs, snippets = {}, {}
    for label, filename in [('ac9', 'raw/mobile-ac9cd44_ios-job.log'), ('55fa', 'raw/ios55-job.log')]:
        raw = (ROOT / filename).read_text()
        lines = [line for line in raw.splitlines() if '[ios-safari-report] ' in line]
        assert len(lines) == 1
        record = json.loads(lines[0].split('[ios-safari-report] ', 1)[1])
        outputs[label] = {'report': record, 'report_line': lines[0]}
    ac9 = outputs['ac9']['report']
    previous = outputs['55fa']['report']
    assert ac9 == json.loads((ROOT / 'raw/ac9-original-report.json').read_text())
    assert previous == json.loads((ROOT / 'raw/55fa-original-report.json').read_text())
    assert len(ac9['checks']) == len(ac9['inputActions']) == 0 and ac9['device'] is None
    assert ac9['status'] == previous['status'] == 'failed'
    assert len(previous['checks']) == 12 and all(c['passed'] for c in previous['checks']) and previous['failureState']['mode'] == 'play'
    failure = ac9['failures'][0]
    assert failure.startswith('Error: WebDriver POST /session: The remote debugger did not return any connected web applications after 43484ms.')
    assert 'IncomingMessage.<anonymous>' in failure and 'webdriver-request.mjs:33:18' in failure
    current_log = (ROOT / 'raw/mobile-ac9cd44_ios-job.log').read_text()
    error_line = next(l for l in current_log.splitlines() if '- Error: WebDriver POST /session: The remote debugger' in l)
    error_at = error_line.split(' ', 1)[0]
    # Preserve the timestamp precision distinction: the parent uses Date.parse
    # millisecond precision; the logged timestamp includes additional digits.
    initialized = datetime.datetime.fromisoformat(ac9['checkedAt'].replace('Z', '+00:00'))
    emitted_error = datetime.datetime.fromisoformat(error_at.replace('Z', '+00:00'))
    delta_us = (emitted_error - initialized) // datetime.timedelta(microseconds=1)
    assert delta_us // 1000 == 583847 < ac9['transport']['sessionRequestTimeoutMs'] == 900000
    for ref in ['55fa8fe', 'ac9cd44', 'current']:
        source = (ROOT / ('source/' + ref + '-tools_test-ios-safari.mjs')).read_text()
        start = source.index("  const created = await webdriver('session', {")
        end = source.index('  sessionId = created?.sessionId', start)
        snippet = source[start:end].encode()
        assert len(snippet) == 1098
        snippets[ref] = sha(snippet)
        assert source.index("await webdriver(sessionPath('/url'), { body: { url: baseUrl } });") > end
        assert source.index('checkedAt: new Date()') < source.index('await waitForHttp(baseUrl)') < start
    assert len(set(snippets.values())) == 1 and snippets['current'] == '97a1a2ac54daa757a4c80cdb4c086a8a4128d7304e6e495e0dfbec12b8bf51ef'
    unchanged = []
    for filename in ['.github_workflows_mobile-simulator.yml', '.github_workflows_pages.yml', 'tools_select-ios-simulator.mjs', 'tools_webdriver-request.mjs']:
        versions = [(ROOT / ('source/' + ref + '-' + filename)).read_bytes() for ref in ['55fa8fe', 'ac9cd44', 'current']]
        assert versions[0] == versions[1] == versions[2]
        unchanged.append({'file': filename, 'sha256': sha(versions[0])})
    transport = (ROOT / 'source/ac9cd44-tools_webdriver-request.mjs').read_text()
    assert "response.on('end', () => {" in transport and 'payload?.value?.message' in transport.splitlines()[32]
    assert 'signal: AbortSignal.timeout(timeout)' in transport
    return {'original_reports_exact': True, 'ac9_failure': failure, 'init_to_logged_error_ms_at_millisecond_precision': delta_us // 1000, 'init_to_logged_error_microseconds': delta_us, 'remote_reported_interval_ms': 43484, 'exact_post_duration_known': False, 'client_budget_ms': 900000, 'prior_recorded_checks': 12, 'prior_whole_job_status': previous['status'], 'prior_mode': previous['failureState']['mode'], 'session_snippet_hashes': snippets, 'identical_sources': unchanged, 'response_rejection_branch_identified': True, 'explicit_helper_url_and_touch_path_not_reached': True}


inline_path = ROOT / 'refuter-inline-step-01.sh'


def proposal_minimality():
    old_text = (ROOT / 'source/current-.github_workflows_mobile-simulator.yml').read_text()
    new_text = (ROOT / 'proposed-mobile-simulator.yml').read_text()
    source = (ROOT / 'proposed-startup-log-export.mjs').read_text()
    old = yaml.safe_load(old_text)
    new = yaml.safe_load(new_text)
    steps = new['jobs']['ios-safari']['steps']
    matches = [i for i, step in enumerate(steps) if step.get('name') == 'Emit startup diagnostics in ordinary CI log']
    assert len(matches) == 1
    index = matches[0]
    added = steps[index]
    assert added['if'] == 'always()' and added['shell'] == 'bash'
    assert steps[index-1]['name'] == 'Stop recording'
    assert steps[index+1]['name'] == 'Preserve Safari screenshots, video, logs and report'
    run = added['run']
    assert run.startswith("node --input-type=module <<'NODE'\n") and run.endswith('NODE\n')
    body = run[len("node --input-type=module <<'NODE'\n"):-len('NODE\n')]
    assert body == source + '\n'
    del steps[index]
    assert new == old
    start = new_text.index('      - name: Emit startup diagnostics in ordinary CI log\n')
    end = new_text.index('      - name: Preserve Safari screenshots, video, logs and report\n', start)
    assert new_text[:start] + new_text[end:] == old_text
    inline_path.write_text(run)
    syntax = subprocess.run(['bash', '-n', str(inline_path)], capture_output=True, timeout=10)
    assert syntax.returncode == 0, syntax.stderr.decode()
    return {'inserted_steps': 1, 'removing_inserted_step_restores_original_yaml_and_bytes': True, 'placement': 'after existing Stop recording, before existing artifact step', 'inline_source': 'Exact exporter bytes plus one trailing blank separator line', 'inline_shell_sha256': sha(run.encode()), 'exporter_sha256': sha(source.encode()), 'bash_syntax_exit': syntax.returncode, 'capabilities_timeouts_and_existing_steps_changed': 0}


def export_boundaries():
    assert inline_path.exists()
    allowlist = ['appium.log', 'simulator-selection.json', 'xcode-version.txt', 'xcode-path.txt', 'simulator-sdk-version.txt']
    cap = 4 * 1024 * 1024
    outcomes = []
    for case, length in [('at-cap', cap), ('over-cap', cap+1)]:
        cwd = FIXTURES / case
        files_dir = cwd / 'test-results/ios-safari'
        files_dir.mkdir(parents=True)
        data = bytearray((bytes(range(256)) * ((length + 255)//256))[:length])
        marker = b'::error::synthetic fixture only\n\x00\xff'
        data[:len(marker)] = marker
        selection = b'{"fixture":true,"padding":"' + b'x' * (65536 - len(b'{"fixture":true,"padding":""}\n')) + b'"}\n'
        assert len(selection) == 65536
        json.loads(selection)
        expected = {'appium.log': bytes(data), 'simulator-selection.json': selection, 'xcode-version.txt': b'x' * 65537, 'xcode-path.txt': b''}
        for name, content in expected.items():
            (files_dir / name).write_bytes(content)
        (files_dir / 'not-allowlisted.txt').write_text('MUST_NOT_BE_EXPORTED')
        process = subprocess.Popen(['bash', '--noprofile', '--norc', str(inline_path)], cwd=cwd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        time.sleep(0.15)
        stdout, stderr = process.communicate(timeout=20)
        (ROOT / ('refuter-' + case + '-01.stdout.log.gz')).write_bytes(gzip.compress(stdout))
        (ROOT / ('refuter-' + case + '-01.stderr.log')).write_bytes(stderr)
        assert process.returncode == 0 and stderr == b''
        parsed = []
        for line in stdout.decode().splitlines():
            match = re.fullmatch(r'\[ios-startup-log-(meta|chunk|end|error)\] (.*)', line)
            assert match, line[:120]
            parsed.append({'kind': match[1], **json.loads(match[2])})
        assert not any(line.startswith(b'::') for line in stdout.splitlines())
        assert set(e['file'] for e in parsed) == set(allowlist)
        summaries = []
        for name, content in expected.items():
            entries = [e for e in parsed if e['file'] == name]
            assert entries[0]['kind'] == 'meta' and entries[-1]['kind'] == 'end'
            assert all(e['kind'] == 'chunk' for e in entries[1:-1])
            meta, end = entries[0], entries[-1]
            limit = cap if name == 'appium.log' else 65536
            complete = len(content) <= limit
            expected_ranges = [[0, len(content)]] if complete else [[0, limit//2], [len(content)-limit//2, len(content)]]
            assert meta['bytes'] == end['bytes'] == len(content)
            assert meta['sha256'] == end['sha256'] == sha(content)
            assert meta['complete'] == end['complete'] == complete
            assert meta['cap'] == limit and meta['ranges'] == expected_ranges and meta['stableDuringRead'] is True
            chunk_count, captured_bytes = 0, 0
            chunks = entries[1:-1]
            for low, high in expected_ranges:
                offset = low
                while offset < high:
                    chunk = chunks[chunk_count]
                    assert chunk['offset'] == offset
                    decoded = base64.b64decode(chunk['base64'], validate=True)
                    assert base64.b64encode(decoded).decode() == chunk['base64']
                    assert len(decoded) == min(3000, high-offset)
                    assert decoded == content[offset:offset+len(decoded)]
                    offset += len(decoded)
                    captured_bytes += len(decoded)
                    chunk_count += 1
                assert offset == high
            assert chunk_count == len(chunks) and captured_bytes == min(limit, len(content))
            summaries.append({'file': name, 'bytes': len(content), 'sha256': sha(content), 'complete': complete, 'ranges': expected_ranges, 'received_bytes': captured_bytes, 'stableDuringRead': meta['stableDuringRead'], 'all_ranges_exact': True, 'terminal_marker_matches': True})
        missing = [e for e in parsed if e['file'] == 'simulator-sdk-version.txt']
        assert len(missing) == 1 and missing[0]['kind'] == 'error' and missing[0]['code'] == 'ENOENT'
        outcomes.append({'case': case, 'reader_delay_seconds': 0.15, 'exit_status': process.returncode, 'stdout_bytes': len(stdout), 'stdout_sha256': sha(stdout), 'files': summaries, 'missing_file_explicit': True, 'unallowlisted_file_absent': True, 'raw_workflow_command_absent': True})
    return {'runtime': subprocess.check_output(['node', '--version']).decode().strip(), 'execution': 'Actual YAML-extracted inline shell, real files, real stdout pipe, delayed Python reader', 'outcomes': outcomes}


check('startup_source_and_original_ci', source_and_ci)
check('proposal_minimality_and_inline_shell', proposal_minimality)
check('independent_export_ranges_and_pipe', export_boundaries)
report['source_hashes_after'] = {str(p.relative_to(ROOT)): sha(p.read_bytes()) for p in tracked}
report['source_bytes_unchanged'] = report['source_hashes_before'] == report['source_hashes_after']
OUT.write_text(json.dumps(report, indent=2, ensure_ascii=False, allow_nan=False) + '\n')
print(json.dumps({'checks': [c['name'] for c in report['checks']], 'errors': report['errors'], 'source_bytes_unchanged': report['source_bytes_unchanged']}, indent=2))
assert report['source_bytes_unchanged']
raise SystemExit(bool(report['errors']))
