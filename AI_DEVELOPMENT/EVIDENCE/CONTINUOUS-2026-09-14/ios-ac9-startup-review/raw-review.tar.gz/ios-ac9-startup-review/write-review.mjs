import fs from 'node:fs';
import path from 'node:path';
import { execFileSync } from 'node:child_process';
import { validateFindings } from '../survival/.kit/lib/plan/findings.mjs';
const root = path.dirname(new URL(import.meta.url).pathname);
const read = p => JSON.parse(fs.readFileSync(path.join(root, p), 'utf8'));
const pins = read('pins.json');
const analysis = read('raw/startup-analysis.json');
const proposal = read('raw/proposal-verification-r3.json');
const review = {
  verdict: 'FAIL', score: 0,
  scoreMeaning: 'Unscored schema sentinel. No native, touch, audiovisual, element or product quality score.',
  verdictMeaning: 'The actual acquisition job failed during session startup and its cause remains unresolved. CPU parsing and proposed diagnostic transport checks do not repair or pass native startup.',
  blindComparison: 'No blind comparison or reference-media evaluation was performed. A stranger preference cannot be inferred from CI startup logs or CPU source checks.',
  round: 'ios-ac9-startup-r1', profile: 'actual-CI-session-startup-diagnostic', tier: 'CPU-source-review', nativeResolution: '0x0',
  refutationStatus: 'PENDING_SEPARATE_REFUTER',
  findings: [{
    id: 'IOS-AC9-STARTUP-TRACE', severity: 'major',
    shot: 'ac9cd44 iOS job103877862413 POST/session failure; original log lines361-400',
    problem: 'The failed job records zero checks and the remote-debugger error, but its ordinary job log contains no Appium startup trace. The active workflow sends Appium stdout/stderr to /dev/null and preserves appium.log only through its artifact. The available evidence therefore cannot distinguish Safari launch/inspection failure from the earlier startup stages.',
    why: 'Changing startup behavior without the actual launch, WDA and remote-debugger chronology would act on an unverified cause and could hide the failed acquisition.',
    owner: '.github/workflows/mobile-simulator.yml',
    fix: 'For one next existing GitHub CI run, insert the single always() diagnostic step in proposed-mobile-simulator.yml after Stop recording and before the existing artifact step. It exports appium.log up to4194304 bytes plus four selected environment files up to65536 bytes each, with full captured-snapshot SHA256, byte ranges, explicit incomplete/missing metadata and natural stdout draining. Keep session capabilities and all timeouts unchanged. Read node /workspace/scratch/0b7ad82bafe7/ios-ac9-startup-review/analyze-startup.mjs and raw/proposal-verification-r3.json: session snippet SHA must remain97a1a2ac54daa757a4c80cdb4c086a8a4128d7304e6e495e0dfbec12b8bf51ef, included range bytes must reconstruct exactly, and4194305-byte input must say complete:false.',
    hypothesis: 'Confirmed source mechanism for the diagnostic gap only: mobile-simulator.yml line79 redirects console output while lines100-107 upload the file. The actual session startup root cause is unconfirmed. The artifact upload succeeded; the source log itself is not claimed lost, corrupt, or nonexistent.',
    introducedOrPreexisting: 'Preexisting observation gap, byte-identical in55fa andac9. Not an introduced game or two-thumb defect.',
    evidence: ['source/current-.github_workflows_mobile-simulator.yml:79', 'source/current-.github_workflows_mobile-simulator.yml:100', 'raw/mobile-ac9cd44_ios-job.log:361', 'raw/mobile-ac9cd44_ios-job.log:388', 'raw/startup-analysis.json', 'raw/proposal-verification-r3.json', 'raw/proposal-yaml-validation.json'],
  }],
  actualObservation: {
    commit: pins.cwd_git_head, runId: '34812994101', jobId: '103877862413',
    log: 'raw/mobile-ac9cd44_ios-job.log', bytes: 36204, sha256: '616d99ff037194953cda9f1e9aa2d5d7e4a52a011969e99f3158dd0cc43c7538',
    failure: analysis.current.failure, recordedChecks: 0, recordedInputActions: 0,
    checkedAt: analysis.current.checkedAt, firstErrorAt: analysis.current.errorAt,
    reportInitializationToErrorMs: 583847, exactPostSessionDurationKnown: false,
    remoteDebuggerReportedIntervalMs: 43484, clientTotalBudgetMs: 900000,
    sessionCreationReturnedErrorEnvelope: true, clientTotalBudgetExpired: false,
    explicitGameUrlNavigationReached: false, touchFixReached: false,
    bootstatusFinished: true,
    artifact: { uploadSucceeded: true, filesReported: 11, uploadedZipBytes: 554414, sha256: 'f87427398c90c2c013905cb116d6dbde60566808ca5e1db2360e2d5b1b3e2d3d', contentsRetrievedForThisReview: false },
  },
  comparativeControl: {
    priorCommit: '55fa8fe10db89946d6ead8ae5e396f65adcdfe01', originalLog: 'raw/ios55-job.log', report: 'raw/55fa-original-report.json',
    recordedPassedChecks: 12, recordedFailureStateMode: 'play', wholeJobStatus: 'failed',
    sessionSourceByteIdentical: true, sessionSourceBytes: 1098, sessionSourceSha256: '97a1a2ac54daa757a4c80cdb4c086a8a4128d7304e6e495e0dfbec12b8bf51ef',
    unchanged: analysis.unchanged,
    sameLoggedEnvironment: { runnerImage: 'macos-15-arm64', imageVersion: '20260907.0337.1', macOS: '15.7.9', build: '24G830', platformVersion: '18.5', selectedDevice: 'iPhone SE (3rd generation)', appiumInstallPin: '3.6.0', xcuitestInstallPin: '12.1.3' },
    interpretation: 'This counters a deterministic claim that the unchanged startup configuration can never work. It does not prove an intermittent infrastructure cause or identical full runtime state/dependencies.',
  },
  hypothesesNotActionableYet: [
    { hypothesis: 'Safari launch, default page readiness or WebKit inspection handshake did not yield a discoverable web application.', missingEvidence: 'Actual Safari launch/bundle/PID/default-page and connected-application messages from this failed Appium session.', status: 'Unconfirmed; generic error text is not a root-cause diagnosis.' },
    { hypothesis: 'Slow earlier setup, WDA build/launch or retries account for much of the approximately584-second interval.', missingEvidence: 'Actual POST arrival time and per-stage Xcode/WDA timestamps, retries and responses.', status: 'Unconfirmed;43484ms must not be subtracted from583847ms and labeled measured WDA duration.' },
    { hypothesis: 'A resolved runtime dependency or selected Xcode detail differs despite matching top-level version pins and runner image label.', missingEvidence: 'Actual Xcode version/path file contents and resolved runtime package versions if the Appium trace implicates a dependency.', status: 'Unconfirmed; do not upgrade/downgrade runtime components based on this possibility.' },
  ],
  unsupportedOrCounteredClaims: [
    'The recent two-thumb action change caused this error: its source executes only after session creation and title/game checks, which were not reached.',
    'The production game lacks Web Inspector support: explicit navigation to its URL was not reached, so this log cannot establish that claim.',
    'The900000ms client session budget expired: error originated from parsed Appium response at webdriver-request.mjs line33, after less than that initialization-to-error interval.',
    'Simulator bootstatus was still pending: this actual log records isTerminal=YES and Finished before Appium starts. That alone does not establish Safari/WDA readiness.',
    'Raising all timeouts, resetting state or manually prelaunching Safari is a demonstrated repair: no present evidence validates such a mechanism.',
  ],
  proposedNextActualVerification: [
    'Author applies only the proposed observation step to the existing active mobile-simulator workflow, preserving the original failed job and its hashes. No product, helper, capability, timeout or startup-command change is proposed.',
    'Run one normal existing GitHub CI push/dispatch at its explicit resulting commit, with the same selected simulator policy and session payload. No local simulator/server/browser, external automation, authentication change or denied-artifact-route retry is needed.',
    'Recover the emitted allowlisted text snapshots through the ordinary job log. Verify each complete file against bytes/SHA256 and contiguous chunks; preserve incomplete ranges, missing files and unstableDuringRead state as limitations. Existing artifact output remains available through its normal authorized use; no prior rejected route is retried.',
    'Use the Appium trace to locate POST receipt, WDA build/launch/status, Safari launch and remote-debugger app discovery or failure. Preserve any server error stack and stage timing. Do not infer those from the43484ms summary alone.',
    'If the same startup succeeds, record only that observed run and continue the existing touch/game checks. It does not establish a startup repair. If it fails, select a bounded correction only when the newly captured trace supports its mechanism, and retain both runs.',
  ],
  proposedArtifacts: { exporter: 'proposed-startup-log-export.mjs', exporterSha256: proposal.candidateSha256, workflow: 'proposed-mobile-simulator.yml', workflowSha256: proposal.proposedWorkflowSha256, diff: 'raw/proposed-workflow.diff', appliedToRepository: false, insertedSteps: 1 },
  cpuControls: {
    startupSourceAndLogParsing: 'raw/startup-analysis.json', proposalTransport: 'raw/proposal-verification-r3.json', yaml: 'raw/proposal-yaml-validation.json',
    sourceCaptureMeaning: 'Only the exact session-payload construction snippet ran with a recorder function; no HTTP request or simulated Appium result was measured.',
    logFixtures: 'Synthetic byte patterns validate transport, not iOS or real Appium evidence.4194304 bytes round-trip exactly with a150ms delayed OS-pipe reader;4194305 bytes exports two exact ranges totaling4194304 and declares incomplete.',
    firstProbeFailure: 'verify-proposal.mjs attached the child close listener after a delay and missed completion, exit13. Its script and stderr remain.',
    secondProbeFailure: 'verify-proposal-r2.mjs registered close early but attached stdout data late; the small child had already exited and the collector retained zero bytes, exit1. Script and raw output remain. This is a probe error, not evidence of exporter loss.',
    correctedProbe: 'verify-proposal-r3.mjs attaches close/data listeners before pause. First data for large controls arrived after150/151ms; the small child auto-drained at56ms, so the small case is not claimed delayed for the full150ms.',
  },
  limits: [
    'This reviewer performed no new iOS, browser, server, simulator or CDP execution and no network/artifact retrieval.',
    'The ac9 Appium file, simulator environment file contents and native video were not retrieved; successful upload metadata is not the files themselves.',
    'The proposed exporter captures a file snapshot after existing cleanup. stableDuringRead checks size/mtime during reading and does not prove all server writes finished permanently.',
    'The4MiB content cap limits emitted Appium bytes, not in-memory readFileSync usage. A larger log is read to hash the captured snapshot and only its head/tail are exported.',
    'Only the active mobile workflow is proposed for the next experiment. The unchanged pages workflow has the same logging pattern; extending the observation step there is relevant if that workflow is the next actual run.',
    'Existing local official Appium web/gesture source was considered, but it does not establish this failed session startup cause. No WDA gesture semantics were re-reviewed as a startup explanation.',
    'No native PNG, blind comparison, reference-media, sound criteria, benchmark, element pass or additional mandatory review gate is claimed.',
  ],
  sourcePins: pins.files,
};
const knownOwners = new Set(execFileSync('git', ['ls-files', 'tools', '.github/workflows'], { cwd: path.join(root, '../survival'), encoding: 'utf8' }).trim().split('\n'));
const validation = validateFindings(review, { strict: true, knownOwners });
fs.writeFileSync(path.join(root, 'review-draft.json'), JSON.stringify(review, null, 2) + '\n');
fs.writeFileSync(path.join(root, 'raw/review-draft-validation.json'), JSON.stringify(validation, null, 2) + '\n');
if (!validation.ok) process.exitCode = 1;
console.log(JSON.stringify(validation));
