import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
const root = path.dirname(new URL(import.meta.url).pathname);
const fields = { node: / node: (v\S+)/, npm: / npm: (\S+)/, image: / Image: (macos-\S+)/, imageVersion: / Version: (20260907\.\S+)/, iOS: /IOS_SIMULATOR_PLATFORM_VERSION: (\S+)/ };
const result = {};
for (const file of ['raw/ios55-job.log', 'raw/mobile-ac9cd44_ios-job.log']) {
  const lines = fs.readFileSync(path.join(root, file), 'utf8').split('\n');
  const record = {};
  for (const [name, pattern] of Object.entries(fields)) {
    const line = lines.findIndex(l => pattern.test(l));
    assert(line >= 0, name);
    record[name] = { value: lines[line].match(pattern)[1], line: line + 1 };
  }
  result[file] = record;
}
for (const field of Object.keys(fields)) assert.equal(result['raw/ios55-job.log'][field].value, result['raw/mobile-ac9cd44_ios-job.log'][field].value);
fs.writeFileSync(path.join(root, 'raw/environment-comparison.json'), JSON.stringify(result, null, 2) + '\n');
console.log(JSON.stringify({ observedFieldsEqual: Object.keys(fields), result }));
