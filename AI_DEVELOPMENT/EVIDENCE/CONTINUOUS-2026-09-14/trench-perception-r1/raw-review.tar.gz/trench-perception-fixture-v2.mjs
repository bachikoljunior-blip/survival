// v2 corrects fixture menus.fromTitle and copies quest snapshots; v1 is retained.
// CPU review fixture. No browser/server. Actual world/actors/AI/combat/director.
// Canvas/text/surface materials, input acquisition, UI, camera/particle outputs,
// and WebAudio device are stubs. Audio event wiring/state selection remain real.
import fs from 'node:fs';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {buildCpuCity,THREE} from './cpu-city-fixture-v2.mjs';
import {Game,MODE} from './survival/src/game/game.js';
import {Director} from './survival/src/game/director.js';
import {Enemy,AISystem} from './survival/src/game/ai.js';
import {CombatSystem} from './survival/src/game/combat.js';
import {Player} from './survival/src/actors/player.js';
import {Audio} from './survival/src/audio/audio.js';
import {Rng} from './survival/src/core/rng.js';
import {Emitter,onSwallowedError} from './survival/src/core/util.js';
import {Storage} from './survival/src/game/state.js';
export {THREE,Game,MODE,Director,Enemy,AISystem,CombatSystem,Storage};
export const root='/workspace/scratch/0b7ad82bafe7';
export const repo=root+'/survival';
export const baseline='c65853f105bc192fae9d952d7e73eba62870dfcb';
export const sha=b=>createHash('sha256').update(b).digest('hex');
export function pinSources(){
  const paths=execFileSync('git',['ls-files','src'],{cwd:repo,encoding:'utf8'}).trim().split('\n');
  return Object.fromEntries(paths.map(p=>[p,sha(fs.readFileSync(repo+'/'+p))]));
}
export async function baselineDirector(){
  const original=execFileSync('git',['show',baseline+':src/game/director.js'],{cwd:repo,encoding:'utf8'});
  const transformed=original.replace(/from (['"])([^'"]+)\1/g,(_m,_q,p)=>{
    const url=p==='three'?new URL('./survival/node_modules/three/build/three.module.js',import.meta.url):new URL(p,new URL('./survival/src/game/director.js',import.meta.url));
    return 'from '+JSON.stringify(url.href);
  });
  const mod=await import('data:text/javascript;base64,'+Buffer.from(transformed).toString('base64'));
  return {Director:mod.Director,originalHash:sha(original),transformedHash:sha(transformed)};
}
const noop=()=>{};
const storage=new Map();
globalThis.localStorage={getItem:k=>storage.get(k)??null,setItem:(k,v)=>storage.set(k,String(v)),removeItem:k=>storage.delete(k)};
export const swallowedErrors=[];
onSwallowedError((where,error)=>swallowedErrors.push({where,error:String(error),stack:error.stack}));
export function makeGame(DirectorClass=Director){
  const {city}=buildCpuCity();
  const events=[],hudCalls=[],uiCalls=[];
  const g=Object.create(Game.prototype);
  Object.assign(g,{_m:new Map(),city,world:city.collision,gas:city.gas,nav:city.nav,
    scene:new THREE.Scene(),actors:[],time:0,playTime:0,mode:MODE.PLAY,rng:new Rng('trench-perception-review'),
    settings:{subtitles:true,showDamageNumbers:false},vibration:false,_meterCooldown:0,
    input:{step:noop,setEnabled:noop,clearToggle:noop},_playerInput:noop,
    camera:{yaw:0,_init:false,addShake:noop},zone:null,moodName:null,forcedMood:null,interiorPpm:null,
    mats:{character:()=>new THREE.MeshStandardMaterial(),glow:()=>new THREE.MeshBasicMaterial()},
    atmos:new Proxy({plumes:{setAnchorActive:noop}},{get:(t,k)=>k in t?t[k]:noop}),
    hud:new Proxy({},{get:(_t,k)=>(...args)=>hudCalls.push({time:g.time,method:k,args})}),
    dialogueUI:{show:(node,choices)=>uiCalls.push({time:g.time,node,choices}),hide:noop},
    menus:new Proxy({fromTitle:false},{get:(t,k)=>k in t?t[k]:noop}),
  });
  g.emit=function(name,...args){
    const clean=args.map(a=>a instanceof Enemy||a instanceof Player?{actor:a.id,kind:a.kind??'player'}:
      a&&typeof a==='object'&&a.target?{target:a.target.id,amount:a.amount}:a);
    events.push({time:g.time,name,args:clean});
    return Emitter.prototype.emit.call(g,name,...args);
  };
  g.player=new Player({x:0,y:.2,z:0,world:g.world,gas:g.gas,mats:g.mats,seed:17});
  g.addActor(g.player);
  g.combat=new CombatSystem(g);g.ai=new AISystem(g);g.director=new DirectorClass(g);
  g.quests=g.director.quests;g.systems=[g.combat,g.ai,g.director];
  g._wireFeedback();
  g.audio=Object.assign(Object.create(Audio.prototype),{game:g,ready:false,musicState:null,ambienceState:null});
  g.audio._wire();
  g.events=events;g.hudCalls=hudCalls;g.uiCalls=uiCalls;
  return g;
}
export function snap(g){return {time:g.time,mode:g.mode,music:g.audio.musicState,player:{pos:g.player.pos.toArray(),hp:g.player.hp,dead:g.player.dead},
  enemies:g.actors.filter(a=>a instanceof Enemy).map(a=>({id:a.id,kind:a.kind,pos:a.pos.toArray(),home:[a.homeX,a.homeY,a.homeZ],yaw:a.yaw,
    hp:a.hp,dead:a.dead,grounded:a.grounded,awareness:a.awareness,aggro:a.aggro,target:a.target?.id??null,aiState:a.aiState,
    localPpm:a.localPpm(g.gas),gasImmune:a.gasImmune,sat:a.lungs.sat,sees:a.canSee(g.player,g.world,g.gas),hears:a.hears(g.player,g.gas,g.world),
    lastSeen:{...a.lastSeen},attack:a.attack?.name??null,overlap:g.world.overlaps(a.pos.x,a.pos.y,a.pos.z,a.radius,a.height)?.tag??null})),
  flags:[...g.state.flags],quest:g.state.quests.has('cinderline')?JSON.parse(JSON.stringify(g.state.quests.get('cinderline'))):null,raid:g.director._raidActive?.id??null};}
export function tick(g,seconds,{sampleEvery=.25,stop=null}={}){
  const samples=[snap(g)];let key='';let next=g.time;
  for(let i=0;i<Math.round(seconds*60);i++){
    g.fixedUpdate(1/60);
    const state=g.actors.filter(a=>a instanceof Enemy).map(a=>a.id+':'+a.aiState+':'+a.aggro+':'+a.dead).join('|')+'|'+g.mode;
    if(state!==key||g.time>=next){samples.push(snap(g));key=state;next=g.time+sampleEvery;}
    if(stop?.(g))break;
  }
  return samples;
}
export function place(g,x,z,{y=null,crouch=0}={}){
  const ground=g.world.groundUnder(x,z,g.player.radius,6,12);
  g.player.placeAt(x,y??(ground?ground.y+.05:0),z,0);
  g.player.crouch=crouch;g.player.setMove(0,0,0);g.player.wantSprint=false;
  return {ground:ground?{y:ground.y,tag:ground.box.tag}:null,overlap:g.world.overlaps(x,g.player.pos.y,z,g.player.radius,g.player.height)?.tag??null};
}
export function enterTrench(g,{from=[65,20],chapter=5}={}){
  g.state.chapter=chapter;
  place(g,from[0],from[1]);
  g.quests.start('cinderline');
  g.director._pollReach();
  return snap(g);
}
