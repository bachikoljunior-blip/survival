// Read a fresh CPU probe result and assert the requested regression target.
import fs from 'node:fs';
import assert from 'node:assert/strict';
const [mode,path]=process.argv.slice(2);if(!mode||!path)throw new Error('Usage: node trench-perception-check-findings.mjs order|heap <fresh-probe.json>');
const report=JSON.parse(fs.readFileSync(path,'utf8'));
const check=report.checks.find(c=>c.name===(mode==='order'?'order-close-range-local-and-baseline':'runtime-spoil-heap-local-and-baseline'));
assert.equal(check?.status,'completed');
const local=check.result.find(r=>r.label==='local');
if(mode==='order'){
  const damage=local.damage.reduce((n,e)=>n+e.args[0].amount,0);
  console.log(JSON.stringify({mode,damageEvents:local.damage.length,damage}));
  assert.equal(local.damage.length,0,'Accepted passage must not cause hostile attack damage');
}else if(mode==='heap'){
  console.log(JSON.stringify({mode,isolatedRubble:local.isolatedRubble}));
  assert.ok(local.isolatedRubble.children>0,'Authored runtime rubble must create geometry');
  assert.ok(local.isolatedRubble.colliders>0,'Authored runtime rubble must create walkable colliders');
}else throw new Error('Unknown check');
