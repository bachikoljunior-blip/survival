// Separate hostile refutation. Fresh files; no product source modifications.
// Reuses appearance-only fixture; actual Game input mapping, interaction,
// actor/AI/combat/physics, quest/save and music event dispatch run below.
import fs from 'node:fs';
import assert from 'node:assert/strict';
import {execFileSync} from 'node:child_process';
import {root,repo,baseline,pinSources,baselineDirector,makeGame,snap,tick,place,enterTrench,Enemy,Storage,swallowedErrors,Game,MODE} from './trench-perception-fixture-v3.mjs';
import {City} from './survival/src/world/city.js';
import {Rng} from './survival/src/core/rng.js';
import {LAYER} from './survival/src/world/collision.js';

const pin='eb347f5eed42b31ed5db61dd8d3e3a6d8ff9ea400fe874e356fe78cde6aaef61';
const sourceHashes=pinSources(),checks=[];
const report={createdAt:new Date().toISOString(),baseline,reviewedDirectorSha256:pin,sourceHashes,scope:'Separate source-labelled CPU refutation only. Full City geometry/collision/gas, real Enemy perception and AI, Player/Combat, Game.fixedUpdate/input mapping/interaction, Director/QuestSystem/Storage and Audio._wire/setMusic. Canvas/material appearance, input acquisition, UI, camera output, post/particles and WebAudio device are stubs. No browser, GPU, listening, traversal completion or blind comparison.',checks};
const base=await baselineDirector();
report.baselineDirectorHashes={original:base.originalHash,importRewritten:base.transformedHash};
report.srcFilesDifferingFromBaseline=execFileSync('git',['diff','--name-only',baseline,'--','src'],{cwd:repo,encoding:'utf8'}).trim().split('\n').filter(Boolean);
assert.equal(sourceHashes['src/game/director.js'],pin,'Refuse changed Director pin');
assert.deepEqual(report.srcFilesDifferingFromBaseline,['src/game/director.js']);

async function check(name,fn){try{const result=await fn();checks.push({name,status:'completed',result});console.log(name+': completed');}catch(e){checks.push({name,status:'probe-error',error:String(e),stack:e.stack});console.log(name+': '+e.stack);}}
function brief(g){return {snapshot:snap(g),events:g.events,ui:g.uiCalls,hud:g.hudCalls};}
function inputFixture(g){
  const held=new Set(),pending=new Set(),enableEvents=[],calls=[];
  const inp={enabled:true,move:{x:0,y:0,mag:0},current:new Set(),
    step(){this.current=new Set(pending);pending.clear();},
    setEnabled(v){this.enabled=v;enableEvents.push({time:g.time,enabled:v,mode:g.mode});},
    clearToggle(k){held.delete(k);},on(){},takeLook(){return {x:0,y:0};},
    pressed(k){return this.enabled&&this.current.has(k);},down(k){return this.enabled&&held.has(k);}};
  g.input=inp;
  g.camera.forwardXZ=v=>v.set(-Math.sin(g.camera.yaw),0,-Math.cos(g.camera.yaw));
  g.camera.rightXZ=v=>v.set(Math.cos(g.camera.yaw),0,-Math.sin(g.camera.yaw));
  g._playerInput=function(dt){calls.push({time:g.time,mode:g.mode});return Game.prototype._playerInput.call(g,dt);};
  return {inp,held,pending,enableEvents,calls};
}
function observeDamage(g){
  const calls=[],original=g.player.damage;
  g.player.damage=function(hit){
    const hpBefore=this.hp,result=original.call(this,hit);
    calls.push({time:g.time,mode:g.mode,source:hit.source?{id:hit.source.id,kind:hit.source.kind,faction:hit.source.faction}:null,kind:hit.kind,inputAmount:hit.amount,result,hpBefore,hpAfter:this.hp,flags:[...g.state.flags],questStep:g.state.quests.get('cinderline')?.step});
    return result;
  };
  return calls;
}
const box=b=>b?{tag:b.tag,x:b.x,z:b.z,y0:b.y0,y1:b.y1,hw:b.hw,hd:b.hd,rot:b.rot,layer:b.layer}:null;
const support=(g,x,z)=>{const s=g.world.groundUnder(x,z,.34,12,20);return {x,z,y:s?.y??null,box:box(s?.box)};};

await check('order-close-range-local-and-baseline',()=>{
  const out=[];
  for(const [label,D] of [['local',undefined],['baseline',base.Director]]){
    const g=makeGame(D),inp=inputFixture(g);enterTrench(g);
    const placement=place(g,77,17.8);g.state.give('trenchOrder',1);
    const it=g.city.interactions.find(i=>i.id==='trench_talk');
    const distance=Math.hypot(g.player.pos.x-it.x,g.player.pos.z-it.z);
    g.player.yaw=g.player.targetYaw=Math.atan2(g.player.pos.x-it.x,g.player.pos.z-it.z);
    g._updateInteractTarget();assert.equal(g.player.interactTarget?.id,'trench_talk');
    assert.ok(distance<it.range);assert.equal(placement.overlap,null);
    const damageCalls=observeDamage(g),before=snap(g);
    inp.pending.add('interact');g.fixedUpdate(1/60);const accepted=snap(g);
    assert.ok(g.events.some(e=>e.name==='interact'&&e.args[0].id==='trench_talk'));
    assert.equal(accepted.mode,MODE.DIALOGUE);assert.equal(accepted.quest.step,2);
    assert.ok(['trench_talked','trench_passed','trench_talked_through'].every(f=>g.state.has(f)));
    // Deliberately request movement while reading; Game must suppress input
    // by its actual mode guard. No mode is assigned or forced in this test.
    inp.inp.move={x:1,y:0,mag:1};inp.held.add('sprint');
    const inputCallsBefore=inp.calls.length,trace=tick(g,8,{stop:g=>g.player.dead});
    const attacks=g.events.filter(e=>e.name==='actor:attackstart');
    const damage=g.events.filter(e=>e.name==='damageNumber'&&e.args[0].target===g.player.id);
    const hostileHits=damageCalls.filter(d=>d.source?.kind==='warden'&&d.hpAfter<d.hpBefore);
    assert.ok(hostileHits.length>0,'Attempted refutation: real input acceptance must still lead to attack damage');
    assert.ok(hostileHits.every(d=>d.mode===MODE.DIALOGUE&&d.questStep===2&&d.flags.includes('trench_passed')));
    assert.equal(inp.calls.length,inputCallsBefore,'Actual input mapping must not run during dialogue');
    assert.equal(g.player.moveInput.mag,0);assert.equal(g.player.wantSprint,false);
    out.push({label,placement,distance,range:it.range,itemCount:g.state.count('trenchOrder'),before,accepted,trace,attacks,damage,hostileHits,damageCalls,input:{calls:inp.calls,enableEvents:inp.enableEvents,requestedMove:inp.inp.move,actualMove:{...g.player.moveInput},wantSprint:g.player.wantSprint},...brief(g)});
  }
  return out;
});

await check('runtime-spoil-heap-local-and-baseline',()=>{
  const out=[];
  for(const [label,D] of [['local',undefined],['baseline',base.Director]]){
    const g=makeGame(D),dispatch=[];const original=g.city._prop;
    g.city._prop=function(cb,p,rng){
      const before={...cb.stats},boxCount=this._collecting?.length??null;
      const result=original.call(this,cb,p,rng);
      dispatch.push({spec:{...p},builderBefore:before,builderAfter:{...cb.stats},boxesBefore:boxCount,boxesAfter:this._collecting?.length??null});
      return result;
    };
    enterTrench(g);const group=g.city._runtimeGroups.get('trenchplant');
    const exact={kind:'rubble',x:90,z:16,w:16,d:9,h:2.6};
    const authored=dispatch.filter(d=>d.spec.kind==='rubble');assert.equal(authored.length,1);assert.deepEqual(authored[0].spec,exact);
    assert.deepEqual(authored[0].builderBefore,authored[0].builderAfter);assert.equal(authored[0].boxesBefore,authored[0].boxesAfter);
    const colliders=group.userData.boxes.map(box),center=support(g,90,16);
    const isolated=g.city.addRuntimeProps('refuter-rubble-'+label,[exact],'plant');
    let meshCount=0,vertexCount=0;isolated.traverse(o=>{if(o.isMesh){meshCount++;vertexCount+=o.geometry.attributes.position.count;}});
    const isolatedRubble={children:isolated.children.length,colliders:isolated.userData.boxes.length,meshCount,vertexCount};
    assert.equal(isolatedRubble.children,0);assert.equal(isolatedRubble.colliders,0);assert.equal(center.box.tag,'pitwall');assert.ok(Math.abs(center.y-.9)<1e-9);
    assert.equal(colliders.filter(b=>b.tag==='rubble').length,0);
    // Positive dispatch control uses the existing static structure format,
    // including r (runtime authored spec supplies w/d). It is NOT a patch.
    const staticCity=new City({structures:[{kind:'rubble',x:90,z:16,r:8,h:2.6}]},g.city.mats,g.city.tier);
    staticCity._buildStructures(new Rng('refuter-static-control'));
    const cb=[...staticCity._chunks.values()][0],staticGroup=cb.build(k=>g.city._mat(k));
    const staticSupport=staticCity.collision.groundUnder(90,16,.34,12,20);
    const staticPositive={children:staticGroup.children.length,stats:cb.stats,center:staticSupport?{y:staticSupport.y,box:box(staticSupport.box)}:null};
    assert.ok(staticPositive.children>0);assert.ok(staticPositive.center.y>2.4);
    const points=[];for(const x of [82,86,90,94])for(const z of [12,16,20])points.push(support(g,x,z));
    out.push({label,authoredDispatch:authored[0],colliders,center,points,isolatedRubble,staticPositive,scope:'Missing runtime authored heap only. No assertion that all other geometry, jumps, excavators or routes cannot meet the positional trigger.'});
  }
  return out;
});

await check('initial-spawn-default-raid-and-living-idempotence',()=>{
  const out=[];
  for(const [label,D] of [['local',undefined],['baseline',base.Director]]){
    const g=makeGame(D),first=enterTrench(g);const group=g.director._raidActive.group,ids=group.map(e=>e.id);
    assert.equal(first.enemies.length,3);assert.deepEqual(first.enemies.map(e=>e.kind),['warden','warden','scav']);
    assert.ok(first.enemies.every(e=>!e.overlap));
    assert.ok(first.enemies.every(e=>label==='local'?e.aiState==='idle'&&!e.aggro&&e.awareness===0&&e.target===null:e.aiState==='combat'&&e.aggro&&e.awareness===1&&e.target===g.player.id));
    const ash=g.hudCalls.filter(c=>c.method==='notice'&&/Ash crew/.test(c.args[0]));assert.equal(ash.length,label==='local'?0:1);
    g.quests.reenterActiveSteps();g.quests.reenterActiveSteps();assert.equal(g.director._raidActive.group,group);assert.deepEqual(group.map(e=>e.id),ids);
    assert.equal(g.city.interactions.filter(i=>i.id==='trench_talk').length,1);
    const trace=tick(g,.4),settled=snap(g);assert.ok(settled.enemies.filter(e=>e.kind==='warden').every(e=>e.grounded));
    assert.ok(settled.enemies.every(e=>e.hp===first.enemies.find(f=>f.id===e.id).hp));
    out.push({label,first,ids,repeatedSameGroup:true,trace,settled,ashCount:ash.length});
  }
  const g=makeGame();place(g,-110,-90);g.director.ctx.hooks.spawnCourtyardRaid();const group=g.director._raidActive.group,first=snap(g);
  g.director.ctx.hooks.spawnCourtyardRaid();assert.equal(g.director._raidActive.group,group);
  assert.ok(first.enemies.every(e=>e.aggro&&e.awareness===1&&e.aiState==='combat'));
  const ash=g.hudCalls.filter(c=>c.method==='notice'&&/Ash crew/.test(c.args[0]));assert.equal(ash.length,1);
  return {trench:out,courtyard:{first,repeatedSameGroup:true,ashCount:ash.length}};
});

await check('real-perception-controls',()=>{
  const g=makeGame();enterTrench(g);const e=g.director._raidActive.group[0],rows=[];
  for(const [name,x,z,crouch] of [['front-crouched',70,8,1],['rear-crouched',70,20,1],['rear-standing',70,20,0]]){
    place(g,x,z,{crouch});e.yaw=e.targetYaw=0;
    rows.push({name,enemy:snap(g).enemies[0],los:g.world.lineOfSight(e.pos.x,e.pos.y+e.height*.85,e.pos.z,g.player.pos.x,g.player.pos.y+g.player.height*.7,g.player.pos.z)});
  }
  assert.equal(rows[0].enemy.sees,true);assert.equal(rows[1].enemy.sees,false);assert.equal(rows[1].los,true);
  assert.equal(rows[1].enemy.hears,false);assert.equal(rows[2].enemy.hears,true);
  place(g,64,25,{crouch:1});e.yaw=e.targetYaw=Math.atan2(e.pos.x-g.player.pos.x,e.pos.z-g.player.pos.z);
  const a=[e.pos.x,e.pos.y+e.height*.85,e.pos.z],b=[g.player.pos.x,g.player.pos.y+g.player.height*.7,g.player.pos.z];
  const d=b.map((v,i)=>v-a[i]),distance=Math.hypot(...d),hit=g.world.raycast(...a,...d,distance-.05);
  const van={enemy:snap(g).enemies[0],hit:hit?{t:hit.t,box:box(hit.box)}:null,sightRange:e.sightRange(g.gas)};
  assert.equal(van.enemy.sees,false);assert.equal(van.hit.box.tag,'car');assert.equal(van.hit.box.x,66);assert.equal(van.hit.box.z,26);
  const hearing=[];for(const [name,x,z] of [['blocked',62,27],['clear',60,22]]){
    place(g,x,z);g.player.wantSprint=true;
    const clear=g.world.lineOfSight(e.pos.x,e.pos.y+e.height*.8,e.pos.z,g.player.pos.x,g.player.pos.y+g.player.height*.6,g.player.pos.z,LAYER.SOLID);
    hearing.push({name,clear,hears:e.hears(g.player,g.gas,g.world),distance:Math.hypot(x-e.pos.x,z-e.pos.z),fullRange:e.arch.hearing*1.4,attenuatedRange:e.arch.hearing*1.4*.36});
  }
  assert.equal(hearing[0].hears,false);assert.equal(hearing[0].clear,false);assert.equal(hearing[1].hears,true);
  return {fov:rows,van,hearing,scope:'Yaw and input are explicit test setup. No perception, FOV, raycast, LOS, collision or AI method is replaced.'};
});

await check('integrated-sight-hearing-and-recovery',()=>{
  const out=[];
  for(const [label,x,z,crouch] of [['sight',74,10,1],['hearing',70,20,0]]){
    const g=makeGame(),inp=inputFixture(g);enterTrench(g);place(g,x,z,{crouch});if(crouch)inp.held.add('crouch');
    for(const e of g.director._raidActive.group)e.think=4;
    const trace=tick(g,2);const first=trace.find(s=>s.enemies[0].aiState==='combat');assert.ok(first);
    const beforeCombat=trace.filter(s=>s.time<=first.time).map(s=>({time:s.time,sees:s.enemies[0].sees,hears:s.enemies[0].hears,awareness:s.enemies[0].awareness,aiState:s.enemies[0].aiState}));
    assert.ok(beforeCombat.every(s=>label==='hearing'?!s.sees&&s.hears:s.sees&&!s.hears));
    place(g,40,55,{crouch:1});inp.held.add('crouch');const recovery=tick(g,13);
    assert.ok(recovery.some(s=>s.enemies.some(e=>e.kind==='warden'&&e.aiState==='search')));
    assert.ok(snap(g).enemies.filter(e=>e.kind==='warden').every(e=>e.aiState==='idle'&&!e.aggro));
    out.push({label,beforeCombat,trace,recovery,...brief(g)});
  }
  return out;
});

await check('same-zone-music-queue-local-and-baseline',()=>{
  const out=[];
  for(const [label,D] of [['local',undefined],['baseline',base.Director]]){
    const g=makeGame(D),inp=inputFixture(g);g.state.chapter=5;place(g,60,20);g.quests.start('cinderline');g._updateZone(0);const before=snap(g);
    place(g,74,10,{crouch:1});inp.held.add('crouch');g.director._pollReach();const afterSpawn=snap(g),queueFrames=[];
    for(let i=0;i<120;i++){
      g.fixedUpdate(1/60);
      const queued=g.director._raidActive.group.flatMap(a=>a.events.filter(e=>e.name==='aggro').map(e=>({actor:a.id,kind:a.kind,event:e.name})));
      if(queued.length)queueFrames.push({time:g.time,music:g.audio.musicState,queued,snapshot:snap(g)});
    }
    const dispatch=g.events.filter(e=>['actor:aggro','music','zone'].includes(e.name));
    assert.equal(before.music,'authority');assert.equal(afterSpawn.music,label==='local'?'authority':'combat');
    if(label==='local'){
      assert.ok(queueFrames.length>0);assert.equal(queueFrames[0].music,'authority');
      const aggro=dispatch.find(e=>e.name==='actor:aggro'),combat=dispatch.find(e=>e.name==='music'&&e.args[0]==='combat');
      assert.ok(aggro&&combat);assert.ok(Math.abs(aggro.time-queueFrames[0].time-1/60)<1e-9);assert.equal(aggro.time,combat.time);assert.equal(g.audio.musicState,'combat');
    }
    out.push({label,before,afterSpawn,queueFrames,dispatch,...brief(g)});
  }
  return out;
});

await check('save-reentry-step-one-and-two',()=>{
  const g=makeGame();enterTrench(g);place(g,64,25,{crouch:1});assert.equal(g.director.save(true),true);
  const save=Storage.load();assert.equal(g.director.applySave(save),true);const restored=snap(g),ids=g.director._raidActive.group.map(e=>e.id);
  assert.equal(restored.enemies.length,3);assert.ok(restored.enemies.every(e=>!e.aggro&&e.awareness===0&&e.target===null));
  g.quests.reenterActiveSteps();g.quests.reenterActiveSteps();assert.deepEqual(g.director._raidActive.group.map(e=>e.id),ids);
  g.director._raidActive.group[0].kill('refuter-partial-group');const count=g.actors.filter(a=>a instanceof Enemy).length;
  g.quests.reenterActiveSteps();assert.equal(g.actors.filter(a=>a instanceof Enemy).length,count);
  assert.equal(g.director.applySave(save),true);const restoredAgain=snap(g);assert.equal(restoredAgain.enemies.length,3);
  assert.equal(g.city.interactions.filter(i=>i.id==='trench_talk').length,1);
  place(g,77,17.8);g.state.give('trenchOrder',1);g.director.interact(g.city.interactions.find(i=>i.id==='trench_talk'));g.fixedUpdate(1/60);
  const stepTwoBefore=snap(g);assert.equal(stepTwoBefore.quest.step,2);assert.equal(g.director.save(true),true);
  const save2=Storage.load();assert.equal(g.director.applySave(save2),true);const stepTwoRestored=snap(g);
  assert.equal(stepTwoRestored.quest.step,2);assert.equal(stepTwoRestored.enemies.length,0);assert.equal(stepTwoRestored.mode,MODE.DIALOGUE);
  return {save,restored,restoredAgain,stepTwoBefore,save2,stepTwoRestored,scope:'Step 2 uses actual order passage, not unsupported high-y positioning.'};
});

report.swallowedErrors=swallowedErrors;report.finalSourceHashes=pinSources();report.sourceUnchanged=JSON.stringify(report.sourceHashes)===JSON.stringify(report.finalSourceHashes);
fs.writeFileSync(root+'/trench-perception-refuter-probe-01.json',JSON.stringify(report,(_k,v)=>v&&typeof v==='object'&&v.pos?.isVector3&&Number.isInteger(v.id)?{actor:v.id,kind:v.kind??v.faction}:v,2)+'\n');
console.log(JSON.stringify({probeErrors:checks.filter(c=>c.status!=='completed').length,swallowedErrors,sourceUnchanged:report.sourceUnchanged}));
if(checks.some(c=>c.status!=='completed')||swallowedErrors.length||!report.sourceUnchanged)process.exitCode=1;
