import fs from 'node:fs';
import assert from 'node:assert/strict';
import {root,repo,baseline,pinSources,baselineDirector,makeGame,snap,tick,place,enterTrench,Enemy,Storage,swallowedErrors} from './trench-perception-fixture-v1.mjs';
const sourceHashes=pinSources(),checks=[];
const report={createdAt:new Date().toISOString(),baseline,sourceHashes,scope:'CPU only; actual City.build, runtime plant colliders, Game.spawnEnemy/fixedUpdate, Player/Enemy/AI/Combat, Director hooks/narrative, Storage, Audio wiring/state. Canvas/material appearance, UI, input acquisition, camera/particle output and WebAudio device stubbed. No rendered/audio/mobile/blind-comparison result.',checks};
async function test(name,fn){try{const result=await fn();checks.push({name,status:'completed',result});console.log(name+': completed');}catch(e){checks.push({name,status:'probe-error',error:String(e),stack:e.stack});console.log(name+': '+e.stack);}}
const base=await baselineDirector();report.baselineDirectorHashes={original:base.originalHash,importRewritten:base.transformedHash};
await test('local-production-hook-ground-and-idempotence',()=>{
  const g=makeGame();const first=enterTrench(g);assert.equal(first.quest.step,1);
  const initial=g.director._raidActive.group;
  const n=g.actors.length;g.quests.reenterActiveSteps();g.quests.reenterActiveSteps();
  assert.equal(g.actors.length,n);assert.equal(g.city.interactions.filter(i=>i.id==='trench_talk').length,1);
  const repeated=snap(g),trace=tick(g,2);
  return {first,repeated,sameGroup:g.director._raidActive.group===initial,trace,events:g.events,hud:g.hudCalls};
});
await test('baseline-production-hook-control',()=>{
  const g=makeGame(base.Director);const first=enterTrench(g);const trace=tick(g,2);
  return {first,trace,events:g.events,hud:g.hudCalls};
});
await test('courtyard-default-control',()=>{
  const g=makeGame();place(g,-110,-90);g.director.ctx.hooks.spawnCourtyardRaid();const first=snap(g),n=g.actors.length;
  g.director.ctx.hooks.spawnCourtyardRaid();assert.equal(g.actors.length,n);
  return {first,afterRepeat:snap(g),events:g.events,hud:g.hudCalls};
});
await test('real-trench-perception-map',()=>{
  const g=makeGame();enterTrench(g);const rows=[];
  for(const x of [58,62,66,68,70,72,74,76,78,82,86,90,96])for(const z of [4,8,12,16,18,20,24,28,32,36]){
    const placement=place(g,x,z,{crouch:1});
    rows.push({x,z,y:g.player.pos.y,...placement,enemies:snap(g).enemies.map(e=>({kind:e.kind,pos:e.pos,sees:e.sees,hears:e.hears,ppm:e.localPpm}))});
  }
  return {rows};
});
await test('sight-detection-and-loss-of-contact',()=>{
  const g=makeGame();enterTrench(g,{from:[74,10]});
  const trace=tick(g,2);place(g,40,55,{crouch:1});const recovery=tick(g,16);
  return {trace,recovery,events:g.events,final:snap(g)};
});
await test('order-acceptance-local',()=>{
  const g=makeGame();enterTrench(g);place(g,74,18);g.state.give('trenchOrder',1);
  const interaction=g.city.interactions.find(i=>i.id==='trench_talk');
  const before=snap(g);g.director.interact(interaction);const accepted=snap(g);
  const trace=tick(g,10,{stop:g=>g.player.dead});
  return {before,accepted,trace,events:g.events,hud:g.hudCalls,dialogue:g.uiCalls,final:snap(g)};
});
await test('order-acceptance-baseline-control',()=>{
  const g=makeGame(base.Director);enterTrench(g);place(g,74,18);g.state.give('trenchOrder',1);
  const interaction=g.city.interactions.find(i=>i.id==='trench_talk');
  g.director.interact(interaction);const accepted=snap(g);const trace=tick(g,10,{stop:g=>g.player.dead});
  return {accepted,trace,events:g.events,final:snap(g)};
});
await test('active-step-save-reentry',()=>{
  const g=makeGame();enterTrench(g);place(g,64,25,{crouch:1});
  const oldIds=g.director._raidActive.group.map(e=>e.id);assert.equal(g.director.save(true),true);
  const save=Storage.load();assert.ok(save);const saved=JSON.parse(JSON.stringify(save));
  assert.equal(g.director.applySave(save),true);const first=snap(g);const firstIds=g.director._raidActive.group.map(e=>e.id);
  g.quests.reenterActiveSteps();g.quests.reenterActiveSteps();const repeated=snap(g);
  assert.equal(g.director.applySave(save),true);const second=snap(g);const n=g.actors.filter(a=>a instanceof Enemy).length;
  assert.equal(n,3);assert.ok(firstIds.every(id=>!oldIds.includes(id)));
  return {saved,oldIds,first,repeated,second,interactionCount:g.city.interactions.filter(i=>i.id==='trench_talk').length,events:g.events};
});
report.swallowedErrors=swallowedErrors;report.finalSourceHashes=pinSources();
report.sourceUnchanged=JSON.stringify(sourceHashes)===JSON.stringify(report.finalSourceHashes);
fs.writeFileSync(root+'/trench-perception-probe-v1.json',JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({probeErrors:checks.filter(c=>c.status!=='completed').length,swallowedErrors,sourceUnchanged:report.sourceUnchanged}));
if(checks.some(c=>c.status!=='completed')||swallowedErrors.length||!report.sourceUnchanged)process.exitCode=1;
