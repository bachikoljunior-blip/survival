// Supplemental current-source courtyard and real wall hearing controls.
import fs from 'node:fs';
import assert from 'node:assert/strict';
import {root,makeGame,enterTrench,place,pinSources,snap} from './trench-perception-fixture-v3.mjs';
const sourceHashes=pinSources(),checks=[];
try{
  const yard=makeGame();place(yard,-110,-90);yard.director.ctx.hooks.spawnCourtyardRaid();
  const group=yard.director._raidActive.group;assert.equal(group.length,3);
  assert.ok(group.every(e=>e.aggro&&e.awareness===1&&e.target===yard.player&&e.aiState==='combat'));
  yard.director.ctx.hooks.spawnCourtyardRaid();assert.equal(yard.director._raidActive.group,group);assert.equal(yard.actors.length,4);
  const music=yard.events.filter(e=>e.name==='music');assert.deepEqual(music.map(e=>e.args[0]),['combat']);
  checks.push({name:'current-courtyard',status:'completed',result:{snapshot:snap(yard),music,ashCrewNoticeCount:yard.hudCalls.filter(c=>c.method==='notice'&&c.args[0].includes('Ash crew')).length}});
  const g=makeGame();enterTrench(g);const e=g.director._raidActive.group[0],rows=[];
  for(let x=60;x<=66;x++)for(let z=22;z<=27;z++){
    const p=place(g,x,z);if(p.ground?.tag==='car'||p.overlap)continue;g.player.wantSprint=true;
    const d=Math.hypot(x-e.pos.x,z-e.pos.z),range=e.arch.hearing*1.4;
    const clear=g.world.lineOfSight(e.pos.x,e.pos.y+e.height*.8,e.pos.z,x,g.player.pos.y+g.player.height*.6,z,1);
    rows.push({x,z,y:g.player.pos.y,d,range,attenuatedRange:range*.36,clear,hears:e.hears(g.player,g.gas,g.world),ground:p.ground});
  }
  const blocked=rows.find(r=>!r.clear&&r.d<r.range&&r.d>=r.attenuatedRange),clear=rows.find(r=>r.clear&&r.d>10&&r.d<r.range);
  assert.ok(blocked);assert.equal(blocked.hears,false);assert.ok(clear);assert.equal(clear.hears,true);
  checks.push({name:'actual-wall-hearing-attenuation',status:'completed',result:{blocked,clear,rows,scope:'Direct hears control on real City colliders. Sprint intent is the explicit test input; no actor position/awareness/FOV/LOS/perception result is mocked.'}});
}catch(error){checks.push({name:'probe-error',status:'probe-error',error:String(error),stack:error.stack});process.exitCode=1;}
const result={sourceHashes,sourceUnchanged:JSON.stringify(sourceHashes)===JSON.stringify(pinSources()),checks};
fs.writeFileSync(root+'/trench-perception-probe-v6.json',JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify(result.checks.map(c=>({name:c.name,status:c.status,...(c.error?{error:c.error}:{})})),null,2));
