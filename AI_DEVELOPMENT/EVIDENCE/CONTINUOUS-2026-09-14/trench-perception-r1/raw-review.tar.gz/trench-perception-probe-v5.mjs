// v5: current Director audio follow-up pinned; v1-v4 errors/failures retained.
import fs from 'node:fs';
import assert from 'node:assert/strict';
import {root,baseline,pinSources,baselineDirector,makeGame,snap,tick,place,enterTrench,Enemy,Storage,swallowedErrors} from './trench-perception-fixture-v3.mjs';
const sourceHashes=pinSources(),checks=[];
const report={createdAt:new Date().toISOString(),baseline,sourceHashes,scope:'Actual CPU game paths as fixture-v2 declares. No browser/render/physical audio measurement. v1 was retained: its save refusal was menus.fromTitle stub truthiness, and quest snapshot references were mutable; v2 fixes both fixture limitations.',checks};
async function test(name,fn){try{const result=await fn();checks.push({name,status:'completed',result});console.log(name+': completed');}catch(e){checks.push({name,status:'probe-error',error:String(e),stack:e.stack});console.log(name+': '+e.stack);}}
const base=await baselineDirector();
function startBeforeReach(g){g.state.chapter=5;place(g,60,20);g.quests.start('cinderline');g._updateZone(0);}
function brief(g){return {snapshot:snap(g),events:g.events,hud:g.hudCalls,ui:g.uiCalls};}
await test('save-reentry-local-and-baseline',()=>{
  const result=[];
  for(const [label,D] of [['local',undefined],['baseline',base.Director]]){
    const g=makeGame(D);enterTrench(g);place(g,64,25,{crouch:1});const before=snap(g);
    assert.equal(g.director.save(true),true);const save=Storage.load();assert.ok(save);
    const saved=JSON.parse(JSON.stringify(save));assert.equal(g.director.applySave(save),true);const after=snap(g);
    const ids=g.director._raidActive.group.map(e=>e.id);
    g.quests.reenterActiveSteps();g.quests.reenterActiveSteps();const repeated=snap(g);
    assert.deepEqual(g.director._raidActive.group.map(e=>e.id),ids);
    g.director._raidActive.group[0].kill('probe-clear'); // explicit death for idempotence partial-group control only
    const count=g.actors.filter(a=>a instanceof Enemy).length;g.quests.reenterActiveSteps();assert.equal(g.actors.filter(a=>a instanceof Enemy).length,count);
    assert.equal(g.director.applySave(save),true);const afterSecond=snap(g);
    assert.equal(g.actors.filter(a=>a instanceof Enemy).length,3);
    assert.equal(g.city.interactions.filter(i=>i.id==='trench_talk').length,1);
    result.push({label,before,saved,after,repeated,afterSecond,...brief(g)});
  }
  return result;
});
await test('real-fov-occlusion-hearing-controls',()=>{
  const g=makeGame();enterTrench(g);const e=g.director._raidActive.group[0];
  const controls=[];
  for(const [name,x,z,crouch] of [['front-crouched',70,8,1],['rear-crouched',70,20,1],['rear-standing',70,20,0],['front-standing',70,8,0]]){
    place(g,x,z,{crouch});e.yaw=e.targetYaw=0;
    const los=g.world.lineOfSight(e.pos.x,e.pos.y+e.height*.85,e.pos.z,g.player.pos.x,g.player.pos.y+g.player.height*.7,g.player.pos.z);
    controls.push({name,los,enemy:snap(g).enemies[0],player:snap(g).player});
  }
  assert.equal(controls[0].enemy.sees,true);assert.equal(controls[1].enemy.sees,false);assert.equal(controls[1].los,true);
  assert.equal(controls[1].enemy.hears,false);assert.equal(controls[2].enemy.hears,true);
  const occluded=[];
  for(let x=60;x<=84;x+=1)for(let z=2;z<=30;z+=1){
    const placement=place(g,x,z,{crouch:1});if(placement.overlap)continue;
    const dist=Math.hypot(x-e.pos.x,z-e.pos.z);if(dist<3||dist>=e.sightRange(g.gas))continue;
    e.yaw=e.targetYaw=Math.atan2(e.pos.x-x,e.pos.z-z);
    if(e.canSee(g.player,g.world,g.gas))continue;
    const ax=e.pos.x,ay=e.pos.y+e.height*.85,az=e.pos.z,bx=x,by=g.player.pos.y+g.player.height*.7,bz=z;
    const dx=bx-ax,dy=by-ay,dz=bz-az,d=Math.hypot(dx,dy,dz);
    const hit=g.world.raycast(ax,ay,az,dx,dy,dz,d-.05);
    if(hit)occluded.push({player:snap(g).player,enemy:snap(g).enemies[0],dist,sightRange:e.sightRange(g.gas),hit:{tag:hit.box.tag,t:hit.t,box:{x:hit.box.x,z:hit.box.z,y0:hit.box.y0,y1:hit.box.y1,hw:hit.box.hw,hd:hit.box.hd,rot:hit.box.rot,layer:hit.box.layer}}});
  }
  assert.ok(occluded.length>0);return {controls,occluded:occluded.slice(0,8),occludedCount:occluded.length,scope:'Direct perception controls use actual colliders. Yaw is deliberately set for front/rear and aimed occlusion tests; perception is never stubbed.'};
});
await test('pure-hearing-and-sight-integrated-transitions',()=>{
  const result=[];
  for(const [label,x,z,crouch] of [['sight',74,10,1],['hearing',70,20,0]]){
    const g=makeGame();enterTrench(g);place(g,x,z,{crouch});
    // Freeze only the idle look timer to avoid process-global actor-ID RNG
    // differences between controls. AI, perception, pathing and motion run.
    for(const e of g.director._raidActive.group)e.think=4;
    const trace=tick(g,2);place(g,40,55,{crouch:1});const recovery=tick(g,13);
    assert.ok(trace.some(s=>s.enemies.some(e=>e.kind==='warden'&&e.aiState==='suspicious')));
    assert.ok(trace.some(s=>s.enemies.some(e=>e.kind==='warden'&&e.aiState==='combat')));
    assert.ok(recovery.some(s=>s.enemies.some(e=>e.kind==='warden'&&e.aiState==='search')));
    assert.ok(snap(g).enemies.filter(e=>e.kind==='warden').every(e=>e.aiState==='idle'&&!e.aggro));
    result.push({label,trace,recovery,...brief(g)});
  }
  return result;
});
await test('same-zone-music-local-and-baseline',()=>{
  const result=[];
  for(const [label,D] of [['local',undefined],['baseline',base.Director]]){
    const g=makeGame(D);startBeforeReach(g);const before=snap(g);
    place(g,74,10,{crouch:1});g.director._pollReach();const afterSpawn=snap(g);const trace=tick(g,2);
    result.push({label,before,afterSpawn,trace,...brief(g)});
  }
  return result;
});
await test('order-close-range-local-and-baseline',()=>{
  const result=[];
  for(const [label,D] of [['local',undefined],['baseline',base.Director]]){
    const g=makeGame(D);enterTrench(g);const placement=place(g,77,17.8);g.state.give('trenchOrder',1);
    const it=g.city.interactions.find(i=>i.id==='trench_talk');const distance=Math.hypot(g.player.pos.x-it.x,g.player.pos.z-it.z);
    assert.ok(distance<it.range);assert.equal(placement.overlap,null);
    g.director.interact(it);const accepted=snap(g);const trace=tick(g,8,{stop:g=>g.player.dead});
    const attacks=g.events.filter(e=>e.name==='actor:attackstart');const damage=g.events.filter(e=>e.name==='damageNumber');
    result.push({label,placement,distance,range:it.range,accepted,trace,attacks,damage,...brief(g)});
  }
  return result;
});
await test('positional-slip-and-save-next-step',()=>{
  const g=makeGame();enterTrench(g);place(g,90,16,{y:2.61,crouch:1});const placement=snap(g);
  assert.ok(g.player.pos.y>2.4);g.director._checkTrenchPassed();const slipped=snap(g);
  assert.ok(g.state.has('trench_slipped'));assert.equal(g.state.quests.get('cinderline').step,2);
  assert.equal(g.director.save(true),true);const save=Storage.load();assert.equal(g.director.applySave(save),true);
  return {placement,slipped,restored:snap(g),saved:save,...brief(g),scope:'Position/quest/save control only at explicitly unsupported y=2.61. This does not prove a playable traversal route; the authored runtime rubble dispatch fails in v4.'};
});
report.swallowedErrors=swallowedErrors;report.finalSourceHashes=pinSources();report.sourceUnchanged=JSON.stringify(sourceHashes)===JSON.stringify(report.finalSourceHashes);
fs.writeFileSync(root+'/trench-perception-probe-v5.json',JSON.stringify(report,(_k,v)=>v && typeof v==='object' && v.pos?.isVector3 && Number.isInteger(v.id) ? {actor:v.id,kind:v.kind??v.faction}:v,2)+'\n');
console.log(JSON.stringify({probeErrors:checks.filter(c=>c.status!=='completed').length,swallowedErrors,sourceUnchanged:report.sourceUnchanged}));
if(checks.some(c=>c.status!=='completed')||swallowedErrors.length||!report.sourceUnchanged)process.exitCode=1;
