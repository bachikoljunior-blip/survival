import fs from 'node:fs';
import assert from 'node:assert/strict';
import {root,baseline,pinSources,baselineDirector,makeGame,snap,tick,place,enterTrench,Storage,swallowedErrors} from './trench-perception-fixture-v3.mjs';
const sourceHashes=pinSources(),checks=[];
const report={createdAt:new Date().toISOString(),baseline,sourceHashes,scope:'Actual CPU production hooks, real geometry/collision, real actors/AI/combat/save. No browser or renderer. v2 failed close-order probe reached real hit then failed missing appearance-only post.grade stub; v3 provides inert grade state. v2 spoil-heap failure remains a product observation to investigate here.',checks};
async function test(name,fn){try{const result=await fn();checks.push({name,status:'completed',result});console.log(name+': completed');}catch(e){checks.push({name,status:'probe-error',error:String(e),stack:e.stack});console.log(name+': '+e.stack);}}
const base=await baselineDirector();
await test('order-close-range-local-and-baseline',()=>{
  const result=[];
  for(const [label,D] of [['local',undefined],['baseline',base.Director]]){
    const g=makeGame(D);enterTrench(g);const placement=place(g,77,17.8);g.state.give('trenchOrder',1);
    const it=g.city.interactions.find(i=>i.id==='trench_talk');const distance=Math.hypot(g.player.pos.x-it.x,g.player.pos.z-it.z);
    assert.ok(distance<it.range);assert.equal(placement.overlap,null);
    g.director.interact(it);const accepted=snap(g);const trace=tick(g,8,{stop:g=>g.player.dead});
    const attacks=g.events.filter(e=>e.name==='actor:attackstart');const damage=g.events.filter(e=>e.name==='damageNumber');
    assert.ok(attacks.length);assert.ok(damage.some(e=>e.args[0].target===g.player.id));
    result.push({label,placement,distance,range:it.range,accepted,trace,attacks,damage,final:snap(g),events:g.events,hud:g.hudCalls,ui:g.uiCalls});
  }
  return result;
});
await test('runtime-spoil-heap-local-and-baseline',()=>{
  const result=[];
  for(const [label,D] of [['local',undefined],['baseline',base.Director]]){
    const g=makeGame(D);enterTrench(g);const group=g.city._runtimeGroups.get('trenchplant');
    const colliders=group.userData.boxes.map(b=>({tag:b.tag,x:b.x,z:b.z,y0:b.y0,y1:b.y1,hw:b.hw,hd:b.hd,rot:b.rot,layer:b.layer}));
    const points=[];
    for(const x of [82,84,86,88,90,92,94])for(const z of [12,14,16,18,20]){
      const ground=g.world.groundUnder(x,z,.34,12,20);
      points.push({x,z,y:ground?.y,tag:ground?.box.tag});
    }
    // Calls the actual runtime prop path with the exact authored spoil-heap
    // spec. Its empty output demonstrates dispatch behavior, not rendering.
    const isolated=g.city.addRuntimeProps('cpu-review-rubble',[{kind:'rubble',x:90,z:16,w:16,d:9,h:2.6}],'plant');
    const probe={children:isolated.children.length,colliders:isolated.userData.boxes.length};
    const rubble=colliders.filter(b=>b.tag==='rubble');
    assert.equal(probe.children,0);assert.equal(probe.colliders,0);assert.equal(rubble.length,0);
    result.push({label,colliders,points,isolatedRubble:probe});
  }
  return result;
});
await test('explicit-high-slip-save-reentry',()=>{
  const g=makeGame();enterTrench(g);place(g,90,16,{y:2.61,crouch:1});const positioned=snap(g);
  g.director._checkTrenchPassed();const slipped=snap(g);assert.ok(g.state.has('trench_slipped'));assert.equal(g.state.quests.get('cinderline').step,2);
  assert.equal(g.director.save(true),true);const save=Storage.load();assert.equal(g.director.applySave(save),true);const restored=snap(g);
  assert.equal(restored.quest.step,2);assert.equal(restored.enemies.length,0);assert.equal(restored.mode,'dialogue');
  return {positioned,slipped,saved:save,restored,events:g.events,scope:'Explicit unsupported high placement validates only the positional trigger and next-step restore, never a playable stealth route. Active-step-2 restore does not respawn the line, in contrast to step 1.'};
});
report.swallowedErrors=swallowedErrors;report.finalSourceHashes=pinSources();report.sourceUnchanged=JSON.stringify(sourceHashes)===JSON.stringify(report.finalSourceHashes);
fs.writeFileSync(root+'/trench-perception-probe-v3.json',JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({probeErrors:checks.filter(c=>c.status!=='completed').length,swallowedErrors,sourceUnchanged:report.sourceUnchanged}));
if(checks.some(c=>c.status!=='completed')||swallowedErrors.length||!report.sourceUnchanged)process.exitCode=1;
