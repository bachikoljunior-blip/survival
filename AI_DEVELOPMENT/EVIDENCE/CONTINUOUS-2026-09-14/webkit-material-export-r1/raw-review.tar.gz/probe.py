from pathlib import Path
import subprocess, os, json, hashlib, gzip, time, shutil, traceback
import yaml

ROOT=Path(__file__).resolve().parent
WORK=ROOT.parent
SCRIPT=ROOT/'source/tools_export-webkit-material.mjs'
FILES=['report.json']+[f'visual-{n}-frame.png' for n in ['stacks','marrow','arcade','cinder','survey','ventfield','south','plant','marrow_roof']]
CAP=2*1024*1024
sha=lambda x:hashlib.sha256(x).hexdigest()
results={'scope':'CPU export only; real previous CI files are not current-build or native-iOS measurements','cases':[],'errors':[]}
for name in ['prior-originals','at-cap','over-cap','missing','empty-png','empty-report']:
    try:
        cwd=ROOT/'raw'/f'fixture-{name}'
        target=cwd/'test-results/iphone-webkit';target.mkdir(parents=True,exist_ok=True)
        data={f:(b'{"status":"failed","failures":["CPU fixture"]}\n' if f=='report.json' else b'CPU transport bytes only, not PNG pixels\x00\xff') for f in FILES}
        if name=='prior-originals': data={f:(WORK/'ci-d19c424'/f).read_bytes() for f in FILES}
        elif name=='at-cap': data[FILES[1]]=(bytes(range(256))*(CAP//256))
        elif name=='over-cap': data[FILES[1]]=(bytes(range(256))*(CAP//256))+b'x'
        elif name=='missing': del data[FILES[1]]
        elif name=='empty-png': data[FILES[1]]=b''
        elif name=='empty-report': data['report.json']=b''
        for f,b in data.items():(target/f).write_bytes(b)
        (target/'not-allowed.png').write_bytes(b'::warning::MUST NOT EXPORT\n')
        env=dict(os.environ,GITHUB_SHA='CPU_EXPORT_CONTEXT_NOT_ORIGINAL_CAPTURE_COMMIT')
        started=time.monotonic()
        p=subprocess.Popen(['node',str(SCRIPT)],cwd=cwd,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        time.sleep(.15)
        out,err=p.communicate(timeout=30)
        (ROOT/'raw'/f'{name}.stdout.log.gz').write_bytes(gzip.compress(out))
        (ROOT/'raw'/f'{name}.stderr.txt').write_bytes(err)
        entries=[]
        for line in out.splitlines():
            prefix,body=line.split(b'] ',1)
            assert prefix.startswith(b'[webkit-material-')
            entries.append((prefix[len(b'[webkit-material-'):].decode(),json.loads(body)))
        assert not err
        assert not any(d.get('file')=='not-allowed.png' for k,d in entries)
        records=[]
        for f in FILES:
            meta=[d for k,d in entries if k=='meta' and d['file']==f]
            chunks=[d for k,d in entries if k=='chunk' and d['file']==f]
            end=[d for k,d in entries if k=='end' and d['file']==f]
            error=[d for k,d in entries if k=='error' and d['file']==f]
            if f not in data:
                assert len(error)==1 and error[0]['code']=='ENOENT' and not(meta or chunks or end)
                records.append({'file':f,'missing':True,'chunks':0});continue
            b=data[f];assert len(meta)==1
            m=meta[0];assert m['bytes']==len(b) and m['sha256']==sha(b) and m['stableDuringRead'] is True
            assert m['commit']==env['GITHUB_SHA']
            if len(b)>CAP:
                assert m['complete'] is False and not chunks and not end
                records.append({'file':f,'bytes':len(b),'complete':False,'chunks':0,'sha256':sha(b)});continue
            assert m['complete'] is True and len(end)==1
            import base64
            decoded=b''
            for c in chunks:
                assert c['offset']==len(decoded)
                decoded+=base64.b64decode(c['base64'],validate=True)
            assert decoded==b and end[0]['bytes']==len(b) and end[0]['sha256']==sha(b)
            assert (target/f).read_bytes()==b
            records.append({'file':f,'bytes':len(b),'complete':True,'sha256':sha(b),'decodedBytes':len(decoded),'exact':True})
        expected_exit=1 if name in ['over-cap','missing'] else 0
        assert p.returncode==expected_exit
        results['cases'].append({'name':name,'exit':p.returncode,'delayBeforeReadMs':150,'stdoutBytes':len(out),'stdoutSha256':sha(out),'seconds':time.monotonic()-started,'records':records,'unallowlistedAbsent':True,'allInputBytesUnchanged':True})
    except Exception:
        results['errors'].append({'name':name,'error':traceback.format_exc()})

try:
    current=yaml.safe_load((ROOT/'source/.github_workflows_gates.yml').read_text())
    baseline=yaml.safe_load((ROOT/'source/HEAD-gates.yml').read_text())
    steps=current['jobs']['f3-execution']['steps']
    selected=[s for s in steps if s.get('run')=='node tools/export-webkit-material.mjs']
    assert len(selected)==1
    step=selected[0];i=steps.index(step)
    assert step['if']=='always()' and not step.get('continue-on-error',False)
    assert steps[i-1]['name']=='Preserve WebKit screenshots, video, trace and report'
    assert steps[i+1]['name']=='Exercise post-boot recovery in mobile WebKit'
    assert steps[i-2]['run']=='npm run test:iphone-webkit'
    steps.remove(step)
    assert current['jobs']['f3-execution']==baseline['jobs']['f3-execution']
    results['workflow']={'f3OnlyOneAddedStep':True,'producerBeforeExport':True,'afterExistingArtifactStep':True,'if':'always()','continueOnError':False,'f3RestDeepEqualToHEAD':True,'separateNarrativeJobChangesExcludedFromScope':True,'failureMeaning':'Explicit always schedules observation despite an earlier failure; it does not change the earlier step outcome. Export failure exits1 with no continue-on-error. This is source interpretation, not a GitHub runner measurement.'}
except Exception:results['errors'].append({'name':'workflow','error':traceback.format_exc()})
results['sourceSha256']=sha(SCRIPT.read_bytes())
(ROOT/'raw/probe.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps({'cases':len(results['cases']),'errors':results['errors'],'workflow':results.get('workflow'),'sourceSha256':results['sourceSha256']},indent=2))
raise SystemExit(bool(results['errors']))
