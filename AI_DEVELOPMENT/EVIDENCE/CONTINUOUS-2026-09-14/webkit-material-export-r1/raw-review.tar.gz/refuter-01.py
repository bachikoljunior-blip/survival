import base64
import gzip
import hashlib
import json
import os
import pathlib
import re
import subprocess
import time
import traceback

import yaml

ROOT = pathlib.Path('/workspace/scratch/0b7ad82bafe7/webkit-material-export-r1')
WORK = ROOT.parent
OUT = ROOT / 'refuter-01.json'
FIXTURES = ROOT / 'refuter-fixtures-01'
assert not OUT.exists() and not FIXTURES.exists(), 'Preserve all prior attempts.'
FIXTURES.mkdir()
sha = lambda b: hashlib.sha256(b).hexdigest()
pins = json.loads((ROOT / 'pins.json').read_text())
tracked = [ROOT / p['snapshot'] for p in pins['files']]
for p in pins['files']:
    assert sha((ROOT / p['snapshot']).read_bytes()) == p['sha256']
script = ROOT / 'source/tools_export-webkit-material.mjs'
files = ['report.json'] + ['visual-' + n + '-frame.png' for n in ['stacks', 'marrow', 'arcade', 'cinder', 'survey', 'ventfield', 'south', 'plant', 'marrow_roof']]
cap = 2 * 1024 * 1024
report = {'scope': 'Independent CPU byte transport and workflow source refutation. No browser/server/native/network execution or product/helper/workflow edits.', 'checks': [], 'cases': [], 'errors': [], 'source_hashes_before': {str(p.relative_to(ROOT)): sha(p.read_bytes()) for p in tracked}}
(ROOT / 'refuter-initial-read-failure.txt').write_text('Initial read attempted source/export-webkit-material.mjs and returned ENOENT. Correct pinned source is source/tools_export-webkit-material.mjs. No probe output or source was overwritten.\n')


def run_case(name, contents, expected_exit):
    cwd = FIXTURES / name
    directory = cwd / 'test-results/iphone-webkit'
    directory.mkdir(parents=True)
    for f, data in contents.items():
        (directory / f).write_bytes(data)
    (directory / 'not-allowlisted.txt').write_text('::error::this file must not be exported\n')
    before = {p.name: sha(p.read_bytes()) for p in directory.iterdir()}
    env = dict(os.environ, GITHUB_SHA='INDEPENDENT_EXPORT_CONTEXT_NOT_ORIGINAL_CAPTURE')
    child = subprocess.Popen(['node', str(script)], cwd=cwd, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    time.sleep(0.15)
    stdout, stderr = child.communicate(timeout=30)
    (ROOT / ('refuter-' + name + '-01.stdout.log.gz')).write_bytes(gzip.compress(stdout))
    (ROOT / ('refuter-' + name + '-01.stderr.log')).write_bytes(stderr)
    assert stderr == b'' and child.returncode == expected_exit
    entries = []
    for line in stdout.decode().splitlines():
        match = re.fullmatch(r'\[webkit-material-(meta|chunk|end|error)\] (.*)', line)
        assert match, line[:100]
        entries.append({'kind': match[1], **json.loads(match[2])})
    assert set(e['file'] for e in entries) == set(files)
    observed_file_order = []
    for entry in entries:
        if not observed_file_order or entry['file'] != observed_file_order[-1]:
            observed_file_order.append(entry['file'])
    assert observed_file_order == files
    results = []
    for f in files:
        records = [e for e in entries if e['file'] == f]
        if f not in contents:
            assert len(records) == 1 and records[0]['kind'] == 'error' and records[0]['code'] == 'ENOENT'
            results.append({'file': f, 'missing': True, 'code': 'ENOENT', 'chunks': 0, 'end_marker': False})
            continue
        original = contents[f]
        meta = records[0]
        assert meta['kind'] == 'meta' and meta['bytes'] == len(original) and meta['sha256'] == sha(original)
        assert meta['cap'] == cap and meta['stableDuringRead'] is True
        assert meta['commit'] == env['GITHUB_SHA']
        if len(original) > cap:
            assert len(records) == 1 and meta['complete'] is False
            results.append({'file': f, 'bytes': len(original), 'sha256': sha(original), 'complete': False, 'chunks': 0, 'end_marker': False})
            continue
        assert meta['complete'] is True and records[-1]['kind'] == 'end'
        end = records[-1]
        assert end['bytes'] == len(original) and end['sha256'] == sha(original)
        chunks = records[1:-1]
        decoded = bytearray()
        for c in chunks:
            assert c['kind'] == 'chunk' and c['offset'] == len(decoded)
            data = base64.b64decode(c['base64'], validate=True)
            assert base64.b64encode(data).decode() == c['base64']
            assert len(data) == min(3000, len(original)-len(decoded))
            decoded.extend(data)
        assert bytes(decoded) == original
        item = {'file': f, 'bytes': len(original), 'sha256': sha(original), 'complete': True, 'decoded_bytes': len(decoded), 'exact': True, 'chunks': len(chunks), 'end_marker': True}
        if f == 'report.json' and original:
            item['decoded_report_status'] = json.loads(decoded)['status']
        results.append(item)
    assert {p.name: sha(p.read_bytes()) for p in directory.iterdir()} == before
    return {'name': name, 'exit_status': child.returncode, 'reader_delay_seconds': 0.15, 'stdout_bytes': len(stdout), 'stdout_sha256': sha(stdout), 'records': results, 'all_inputs_unchanged': True, 'unallowlisted_absent': True, 'record_order_matches_allowlist': True, 'commit_meaning': 'Exporter environment context only; prior images are not recast as current captures.'}


prior = {f: (WORK / 'ci-d19c424' / f).read_bytes() for f in files}
prior_hashes = {f: sha(data) for f, data in prior.items()}
prior_report = json.loads(prior['report.json'])
assert len(prior_report['visualViews']['views']) == 9
for view in prior_report['visualViews']['views']:
    f = pathlib.PurePosixPath(view['native']['path']).name
    assert sha(prior[f]) == view['native']['pngSha256']
report['prior_report_grounding'] = {'source_directory': 'ci-d19c424', 'checkedAt': prior_report['checkedAt'], 'recorded_status': prior_report['status'], 'all_nine_frame_hashes_match_prior_report': True, 'current_build_claim': False}
small = {f: (b'{"status":"failed","failures":["synthetic CPU fixture"]}\n' if f == 'report.json' else b'Synthetic transport bytes, not PNG pixels\x00\xff') for f in files}
combined = dict(small)
json_prefix = b'{"status":"failed","failures":["synthetic CPU fixture"],"padding":"'
json_suffix = b'"}\n'
combined['report.json'] = json_prefix + b'x' * (cap-len(json_prefix)-len(json_suffix)) + json_suffix
assert len(combined['report.json']) == cap and json.loads(combined['report.json'])['status'] == 'failed'
combined[files[1]] = bytes(range(256)) * (cap//256) + b'x'
combined[files[2]] = bytes(range(255, -1, -1)) * (cap//256)
del combined[files[3]]
empty_png = {**small, files[1]: b''}
empty_report = {**small, 'report.json': b''}
for name, contents, expected in [('prior-originals', prior, 0), ('combined-failure-large-success', combined, 1), ('empty-png', empty_png, 0), ('empty-report', empty_report, 0)]:
    try:
        report['cases'].append(run_case(name, contents, expected))
    except Exception:
        report['errors'].append({'case': name, 'traceback': traceback.format_exc()})

try:
    current = yaml.safe_load((ROOT / 'source/.github_workflows_gates.yml').read_text())
    baseline = yaml.safe_load((ROOT / 'source/HEAD-gates.yml').read_text())
    f3 = current['jobs']['f3-execution']
    original_steps = f3['steps']
    indexes = [i for i, s in enumerate(original_steps) if s.get('run') == 'node tools/export-webkit-material.mjs']
    assert len(indexes) == 1
    index = indexes[0]
    added = original_steps[index]
    assert added['if'] == 'always()' and not added.get('continue-on-error', False)
    assert original_steps[index-1]['name'] == 'Preserve WebKit screenshots, video, trace and report'
    assert original_steps[index-2]['run'] == 'npm run test:iphone-webkit'
    assert original_steps[index+1]['name'] == 'Exercise post-boot recovery in mobile WebKit'
    retained_fault_if = original_steps[index+1].get('if')
    del original_steps[index]
    assert f3 == baseline['jobs']['f3-execution']
    producer = (ROOT / 'source/tools_mobile_visual_capture.mjs').read_text()
    harness = (ROOT / 'source/tools_test-iphone-webkit.mjs').read_text()
    assert producer.index('const png=PNG.sync.read(bytes);') < producer.index('writeFileSync(native,bytes);')
    assert 'writeFileSync(REPORT, `${JSON.stringify(report, null, 2)}\\n`);' in harness
    assert "report.status = report.failures.length ? 'failed' : 'passed';" in harness
    assert 'if (report.failures.length) process.exit(1);' in harness
    report['checks'].append({'name': 'workflow_and_producer', 'result': {'single_f3_added_step': True, 'removing_added_step_restores_f3_deep_equality': True, 'always_step_without_continue_on_error': True, 'retained_next_fault_condition': retained_fault_if, 'producer_decodes_png_before_file_write': True, 'report_writer_serializes_status_and_failures': True, 'separate_narrative_job_not_reviewed': True}})
except Exception:
    report['errors'].append({'case': 'workflow_and_producer', 'traceback': traceback.format_exc()})

assert {f: sha((WORK / 'ci-d19c424' / f).read_bytes()) for f in files} == prior_hashes
report['prior_originals_unchanged'] = True
report['source_hashes_after'] = {str(p.relative_to(ROOT)): sha(p.read_bytes()) for p in tracked}
report['sources_unchanged'] = report['source_hashes_before'] == report['source_hashes_after']
report['runtime'] = {'node': subprocess.check_output(['node', '--version']).decode().strip(), 'platform': os.uname().sysname}
OUT.write_text(json.dumps(report, indent=2, ensure_ascii=False, allow_nan=False) + '\n')
print(json.dumps({'cases': [{'name': c['name'], 'exit_status': c['exit_status'], 'stdout_bytes': c['stdout_bytes']} for c in report['cases']], 'checks': report['checks'], 'errors': report['errors'], 'sources_unchanged': report['sources_unchanged'], 'prior_originals_unchanged': report['prior_originals_unchanged']}, indent=2))
assert report['sources_unchanged']
raise SystemExit(bool(report['errors']))
