import hashlib, json, os, pathlib, subprocess, tarfile, time
root=pathlib.Path('/workspace/scratch/0b7ad82bafe7')
base=root/'audio-evaluator'
runtime=base/'runtime/llama-b10809'
def sha(p):
 h=hashlib.sha256()
 with open(p,'rb') as f:
  for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
 return h.hexdigest()
report={'scope':'Read-only metadata/provenance audit. No inference or download.', 'commands':[], 'archives':{}, 'model_hashes':[]}
for title,env in [('bare version (preserved repeat of failed metadata-only invocation)',os.environ.copy()),('scoped library path version',dict(os.environ,LD_LIBRARY_PATH=str(runtime)))]:
 args=[str(runtime/'llama-mtmd-cli'),'--version']
 p=subprocess.run(args,cwd=runtime,env=env,capture_output=True,text=True,timeout=15)
 report['commands'].append({'title':title,'args':args,'cwd':str(runtime),'LD_LIBRARY_PATH_override':str(runtime) if title.startswith('scoped') else None,'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr})
report['commands'].append({'title':'Earlier disabled upstream source access','tool':'web__run open','status':'DisabledError for all three URLs; no content returned','urls':['https://raw.githubusercontent.com/ggml-org/llama.cpp/5266f24da75dc449bd56cbed7addb9c8e4a6a73e/tools/mtmd/'+p for p in ['mtmd-cli.cpp','mtmd.cpp','models/qwen2.5omni.cpp']],'record_kind':'Retrospective verbatim status, not a new network retry'})
archive=root/'survival/AI_DEVELOPMENT/EVIDENCE/CONTINUOUS-2026-09-14/audio-evaluator-calibration/raw-calibration.tar.gz'
provpath=archive.parent/'provenance.json'
prov=json.loads(provpath.read_text());expected={x['path']:x for x in prov['files']}
members=[]
with tarfile.open(archive) as t:
 for m in t.getmembers():
  assert m.isfile() and m.name in expected
  digest=hashlib.sha256(t.extractfile(m).read()).hexdigest()
  original=base/m.name
  members.append({'name':m.name,'bytes':m.size,'sha256':digest,'matches_provenance':digest==expected[m.name]['sha256'] and m.size==expected[m.name]['bytes'],'matches_original':digest==sha(original)})
report['archives']['calibration']={'path':str(archive.relative_to(root)),'sha256':sha(archive),'provenance_sha256':sha(provpath),'members':members,'all_expected_members':len(members)==len(expected)}
release=json.loads((base/'runtime-binary-release.json').read_text())
rtar=base/'llama-b10809-bin-ubuntu-x64.tar.gz'
asset=next(a for a in release['assets'] if a['name']==rtar.name)
digest=sha(rtar);binary_members=[]
with tarfile.open(rtar) as t:
 for m in t.getmembers():
  name=pathlib.PurePosixPath(m.name).name
  if m.isfile() and (name in ['llama-mtmd-cli','libmtmd.so.0.4.0','libllama.so.0.4.0','libllama-common.so.0.4.0'] or name.startswith('libggml')):
   original=runtime/name
   d=hashlib.sha256(t.extractfile(m).read()).hexdigest()
   binary_members.append({'name':name,'sha256':d,'matches_actual':d==sha(original)})
report['archives']['runtime']={'path':str(rtar.relative_to(root)),'bytes':rtar.stat().st_size,'sha256':digest,'matches_release_digest':asset['digest']=='sha256:'+digest,'matches_release_size':asset['size']==rtar.stat().st_size,'release_tag':release['tag_name'],'release_commit':release['target_commitish'],'binary_members':binary_members}
for name,record in [('Qwen2.5-Omni-7B-Q8_0.gguf','model-download.json'),('mmproj-Qwen2.5-Omni-7B-f16.gguf','projector-recovery-download.json')]:
 print('Hashing existing model: '+name,flush=True)
 p=base/name;start=time.monotonic();d=sha(p)
 report['model_hashes'].append({'name':name,'bytes':p.stat().st_size,'sha256':d,'seconds':time.monotonic()-start,'original_record':record})
report['environment_provenance_limitation']='Successful argv is recorded, calibration-v2 correction records bundled-runtime cwd, and parent confirms LD_LIBRARY_PATH set to this runtime directory. Full original shell/Python source and environment were not found. Current bare library-load failure is not attributed to the later completed false captions.'
(root/'audio-evaluator-diagnostic-02.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'commands':report['commands'][:2],'archive_matches':all(m['matches_provenance'] and m['matches_original'] for m in members),'runtime_matches':report['archives']['runtime']['matches_release_digest'],'model_hashes':report['model_hashes']},indent=2),flush=True)
