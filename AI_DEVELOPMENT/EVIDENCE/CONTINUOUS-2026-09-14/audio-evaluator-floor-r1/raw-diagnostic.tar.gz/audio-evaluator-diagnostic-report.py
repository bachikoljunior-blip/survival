import hashlib,json,pathlib
root=pathlib.Path('/workspace/scratch/0b7ad82bafe7')
def read(name):return json.loads((root/name).read_text())
def pin(p):return {'path':str(p.relative_to(root)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
metadata=read('audio-evaluator-diagnostic-01.json');identity=read('audio-evaluator-diagnostic-02.json');numeric=read('audio-evaluator-diagnostic-preprocess.json')
runtime_ref='5266f24da75dc449bd56cbed7addb9c8e4a6a73e'
upstream=[]
for local,remote,repo,ref in [
 ('mtmd-cli.cpp','tools/mtmd/mtmd-cli.cpp','ggml-org/llama.cpp',runtime_ref),
 ('mtmd.cpp','tools/mtmd/mtmd.cpp','ggml-org/llama.cpp',runtime_ref),
 ('mtmd-helper.cpp','tools/mtmd/mtmd-helper.cpp','ggml-org/llama.cpp',runtime_ref),
 ('mtmd-audio.cpp','tools/mtmd/mtmd-audio.cpp','ggml-org/llama.cpp',runtime_ref),
 ('mtmd-audio.h','tools/mtmd/mtmd-audio.h','ggml-org/llama.cpp',runtime_ref),
 ('clip.cpp','tools/mtmd/clip.cpp','ggml-org/llama.cpp',runtime_ref),
 ('clip-model.h','tools/mtmd/clip-model.h','ggml-org/llama.cpp',runtime_ref),
 ('arg.cpp','common/arg.cpp','ggml-org/llama.cpp',runtime_ref),
 ('qwen-processor-v4523.py','src/transformers/models/qwen2_5_omni/processing_qwen2_5_omni.py','huggingface/transformers','v4.52.3'),
 ('whisper-feature-v4523.py','src/transformers/models/whisper/feature_extraction_whisper.py','huggingface/transformers','v4.52.3'),
 ('audio-utils-v4523.py','src/transformers/audio_utils.py','huggingface/transformers','v4.52.3')]:
  p=root/('audio-evaluator-diagnostic-source-'+local)
  upstream.append({**pin(p),'repository':repo,'ref':ref,'upstream_path':remote,'url':f'https://github.com/{repo}/blob/{ref}/{remote}','acquisition':'GitHub connector fetch; read-only exact relevant public source'})
review={
 'verdict':'FAIL','score':0,'scoreMeaning':'Unscored sentinel required by critic schema. No audio quality score assigned.',
 'verdictMeaning':'The recorded evaluator remains rejected. This bounded diagnostic verifies a runtime preprocessing mismatch, not model repair or a product/element result.',
 'blindComparison':'No blind comparison or reference-media evaluation was performed. Nothing here predicts which sound a stranger would prefer, and all product/audio elements remain unmeasured.',
 'round':'audio-evaluator-diagnostic-1','profile':'exact-input-runtime-source-critic','tier':'CPU-source-and-preprocessing-only','nativeResolution':'0x0',
 'nativeResolutionMeaning':'No raster output applies to this diagnostic.',
 'refutationStatus':'PENDING_SEPARATE_REFUTER',
 'scope':{'new_inference_runs':0,'model_downloads':0,'paid_api_calls':0,'product_edits':0,'reference_media_evaluations':0,'unchanged_controls_repeated_inference':0,'performed':'Read-only archive/PCM/GGUF/hash/version inspection; pinned upstream source review; isolated preprocessing source execution against both original controls.'},
 'findings':[{
  'id':'AE-PREPROC-01','severity':'major','shot':'Exact zeroPCM negative control in b10809 Qwen2.5Omni audio preprocessing',
  'problem':'The pinned runtime Whisper preprocessor yields -0.8061800003 in all 384000 mel values for the original four-second zeroPCM control; the Qwen reference Whisper processor yields -1.5. A single floor override makes the isolated source result match all 384000 values exactly.',
  'why':'The selected runtime changes the representation of this known silent input before model encoding, so the failed negative control cannot establish model-only unreliability or justify skipping a concrete frontend correction.',
  'owner':'tools/mtmd/mtmd-audio.cpp','ownerRepository':'ggml-org/llama.cpp','ownerRef':runtime_ref,
  'fix':'In a separate diagnostic runtime copy, apply the reference 1e-10 floor to the validated Qwen/Whisper path, preserving the original binaries and outputs. Verify zero max error across384000 silence values and unchanged tone-control feature hash using python /workspace/scratch/0b7ad82bafe7/audio-evaluator-diagnostic-preprocess.py; inspect audio-evaluator-diagnostic-preprocess.json. This source harness target is not an inference success gate.',
  'hypothesis':'Confirmed mechanism for the feature mismatch: filter_params defaults mel_floor to5.960464477539063e-08 and Whisper does not override it before log10/clamp/normalization. Causality for the false silence caption is UNPROVEN. The same floor cannot explain the known-sequence transposition: original and changed tone features are byte-identical.',
  'evidence':[
   {'file':'audio-evaluator-diagnostic-source-clip.cpp','lines':[1285,1288,1765,1785],'claim':'qwen2.5o audio is remapped to QWEN2A; audio uses16kHz/400FFT/400window/160hop.'},
   {'file':'audio-evaluator-diagnostic-source-mtmd.cpp','lines':[930,938],'claim':'QWEN2A/QWEN25O select mtmd_audio_preprocessor_whisper.'},
   {'file':'audio-evaluator-diagnostic-source-mtmd-audio.cpp','lines':[285,350,568,577],'sha256':'1d3eed8a85ea98d5c8cd96223fdb561b699affccea23f5b668d602bd3b22521f','claim':'Default floor, clamp, and missing Whisper override.'},
   {'file':'audio-evaluator-diagnostic-source-qwen-processor-v4523.py','lines':[68,71,98,160,170],'claim':'Reference Qwen processor selects WhisperFeatureExtractor,16k and max-length padding.'},
   {'file':'audio-evaluator-diagnostic-source-whisper-feature-v4523.py','lines':[114,136,158,164],'claim':'Reference NumPy method uses audio_utils floor; Torch explicitly clamps1e-10.'},
   {'file':'audio-evaluator-diagnostic-preprocess.json','claim':'All original/floor-only/reference values and source-compilation scope; tone feature hash68d1b7348e7134d252c6cb3329b4c1f85fd9fe6e6476c9a1aa54d51fc8ae1fa5 for both variants.'}
  ],
  'notEstablished':['This difference caused the false sine-wave caption.','A corrected full runtime captions silence correctly.','A corrected frontend fixes the sequence transposition.','The evaluator can judge product sound or stereo positioning.']
 }],
 'controls':[
  {'id':'INPUT-IDENTITY','result':'confirmed','evidence':'audio-evaluator-diagnostic-01.json','details':'Original WAV headers are mono16k PCM16. Silence has64000/64000 zero samples. Calibration0-2s zero,2-4s440Hz,4-6s1kHz alternating0.25s on/off. Numeric measures identify controls only and do not replace listening.'},
  {'id':'ARCHIVE-IDENTITY','result':'confirmed','evidence':'audio-evaluator-diagnostic-02.json','details':'All20 preserved calibration archive members match both provenance SHA256 and current originals. Runtime archive matches publisher digest/size;21 selected runtime binary/library members match originals. Both full GGUF hashes match recorded publisher LFS hashes.'},
  {'id':'MODEL-RUNTIME-PIN','result':'confirmed metadata, not accuracy','evidence':'audio-evaluator-diagnostic-01.json and-02.json','details':'Actual version0.4.0-dev build10809 commit5266f24da. Q8 qwen2vl text width3584 and audio projector qwen2.5o output3584,128mel. Audio boundary tokens are present. Matching metadata does not prove neural correctness.'},
  {'id':'CLI-TEMPLATE-ATTACHMENT','result':'no concrete input/template error found','evidence':'pinned arg.cpp1803-1810,2631-2637;mtmd-cli.cpp260-310,483-501;mtmd.cpp930-938,1570-1598,1643-1650;mtmd-helper.cpp304-402','details':'-f reads the prompt;--audio fills the media vector;CLI prepends a media marker, loads the WAV and interleaves it into the formatted text;mtmd adds audio_bos/eos. Recorded runs completed a media encoding batch. Missing--jinja is not an evidenced fix.'},
  {'id':'FLOOR-NEGATIVE-CAUSAL-CONTROL','result':'strong mechanism claim refuted for tone transposition','evidence':'audio-evaluator-diagnostic-preprocess.json','details':'Both original/floor1e-10 tone buffers are byte-identical. Both differ from the NumPy reference by max1.9669533e-5 in3 of384000 values; overall mean error3.7956e-9. The floor mismatch cannot account for that control ordering error.'},
  {'id':'CHANNEL-RETENTION','result':'mono only','evidence':'audio-evaluator-diagnostic-source-mtmd-helper.cpp325-328','details':'decode_audio_from_buf hardcodes channels=1 and requests float mono from miniaudio. Stereo channels are not retained independently; this route cannot substantiate stereo localization. No sound criterion is reduced to accommodate this limitation.'}
 ],
 'recorded_outcomes':[
  {'run':'calibration','exit_code':1,'outcome':'No backends loaded; no inference or caption. Preserved initial failure is separate from successful runs.'},
  {'run':'calibration-v2','exit_code':0,'stdout':(root/'audio-evaluator/calibration-v2-stdout.txt').read_text(),'interpretation':'Misses initial silence and reports intermittent-before-continuous order, unlike the original input.'},
  {'run':'silence-control','exit_code':0,'stdout':(root/'audio-evaluator/silence-control-stdout.txt').read_text(),'interpretation':'Reports two sine-wave events in exact zeroPCM. This exact recorded pipeline failed its negative control.'}
 ],
 'limits':[
  'No model-only causal attribution is supported: weights, frontend and downstream runtime are not isolated by the recorded captions.',
  'The separate source harness executes pinned preprocessing calculations with a metadata-only context shim; it does not invoke original shared-library model/projector inference.',
  'Full original launcher source/environment and an actual rendered multimodal prompt/tensor dump were not archived. Calibration-v2 records corrected runtime cwd; parent confirms scopedLD_LIBRARY_PATH. The current bare--version failure is a reproducibility limitation, not a cause of completed captions.',
  'The initial missing backend, generic image-token warning and experimental-runtime warning do not demonstrate the later caption mechanism.',
  'HF Transformersv4.52.3 is the pinned model-family reference processor used for this numerical comparison, not a claim that this package/version executed in the recorded GGUF run.',
  'No element pass, blind result, spatial-audio result, criteria narrowing or spectral replacement of listening is claimed.'
 ],
 'sourcePins':upstream,
 'modelPins':identity['model_hashes'],
 'runtimePin':{k:v for k,v in identity['archives']['runtime'].items() if k!='binary_members'},
 'rawEvidence':['audio-evaluator-diagnostic-01.py','audio-evaluator-diagnostic-01.json','audio-evaluator-diagnostic-01.log','audio-evaluator-diagnostic-02.py','audio-evaluator-diagnostic-02.json','audio-evaluator-diagnostic-02.log','audio-evaluator-diagnostic-preprocess.py','audio-evaluator-diagnostic-preprocess.json','audio-evaluator-diagnostic-preprocess.log'],
 'retainedFailedAttempts':['Original calibration backend failure remains archived.','Bare metadata-only--version fails before load; successful scoped-path--version also recorded in-02.json.','web__run upstream opens returned DisabledError, captured retrospectively in-02.json.','Wrong qwen2.5omni.cpp path returned404; exact response retained in-source-qwen25omni-fetch.json.','HFv4.51.3 Qwen processor path returned404; exact response retained in-source-processor-v4513-fetch.json. Relevantv4.52.3 source succeeded.'],
 'ownershipMap':{'repository':'ggml-org/llama.cpp','ref':runtime_ref,'knownOwners':[x['upstream_path'] for x in upstream if x['repository']=='ggml-org/llama.cpp']}
}
(root/'audio-evaluator-diagnostic-review-draft.json').write_text(json.dumps(review,indent=2)+'\n')
print(json.dumps({'draft':'audio-evaluator-diagnostic-review-draft.json','candidate_findings':len(review['findings']),'independent_refutation_pending':True}))
