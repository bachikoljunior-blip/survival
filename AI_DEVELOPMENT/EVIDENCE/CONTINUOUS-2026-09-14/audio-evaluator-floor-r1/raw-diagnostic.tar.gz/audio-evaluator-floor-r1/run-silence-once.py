import datetime
import hashlib
import json
import pathlib
import subprocess
import time

BASE = pathlib.Path(__file__).resolve().parent
PLAN = json.loads((BASE / 'silence-run-plan.json').read_text())
BUILD = json.loads((BASE / 'build.json').read_text())
assert BUILD.get('exitCode') == 0, 'A completed successful build is required before inference'
RECORD = pathlib.Path(PLAN['outputPaths']['record'])
assert not RECORD.exists(), 'This controlled inference was already started; do not repeat it'
for label in ['input', 'prompt']:
    item = PLAN[label]
    assert hashlib.sha256(pathlib.Path(item['path']).read_bytes()).hexdigest() == item['sha256'], label
manifest = json.loads((BASE / 'source-manifest.json').read_text())
for relative, original in manifest['original'].items():
    expected = manifest['changed'].get(relative, original)
    assert hashlib.sha256((BASE / 'source-floor1e10' / relative).read_bytes()).hexdigest() == expected, relative

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

record = {
    **PLAN,
    'status': 'starting one controlled inference',
    'startedAt': now(),
    'inferenceAttemptsInThisDiagnostic': 1,
    'unchangedToneInferenceAttempts': 0,
    'neuralInferenceExecuted': False,
    'buildRecordSha256': hashlib.sha256((BASE / 'build.json').read_bytes()).hexdigest(),
    'buildManifestSha256': hashlib.sha256((BASE / 'build-manifest.json').read_bytes()).hexdigest(),
    'sourceManifestSha256': hashlib.sha256((BASE / 'source-manifest.json').read_bytes()).hexdigest(),
    'launcherSha256': hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),
    'timeoutSeconds': 240,
}
with RECORD.open('x') as out:
    out.write(json.dumps(record, indent=2) + '\n')
start = time.monotonic()
process = None
observed_maps = False
try:
    with pathlib.Path(PLAN['outputPaths']['stdout']).open('xb') as stdout, pathlib.Path(PLAN['outputPaths']['stderr']).open('xb') as stderr:
        process = subprocess.Popen(PLAN['args'], cwd=PLAN['cwd'], env=PLAN['environment'],
                                   stdin=subprocess.DEVNULL, stdout=stdout, stderr=stderr)
        record['pid'] = process.pid
        record['status'] = 'running one controlled inference'
        RECORD.write_text(json.dumps(record, indent=2) + '\n')
        while process.poll() is None:
            if not observed_maps:
                try:
                    maps = pathlib.Path(f'/proc/{process.pid}/maps').read_text()
                    if 'libmtmd.so' in maps and 'libggml-cpu-' in maps:
                        (BASE / 'silence-floor1e10-loaded-maps.txt').write_text(maps)
                        loaded = sorted({line.split()[-1] for line in maps.splitlines()
                                         if '/build-floor1e10/bin/' in line})
                        record['loadedVariantRuntimePaths'] = loaded
                        record['mapsSnapshotAfterSeconds'] = time.monotonic() - start
                        observed_maps = True
                except (OSError, PermissionError) as error:
                    record.setdefault('mapsErrors', []).append(repr(error))
                    observed_maps = True
            if time.monotonic() - start > record['timeoutSeconds']:
                process.terminate()
                try:
                    process.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    process.kill()
                    process.wait(timeout=10)
                record['timedOut'] = True
                break
            time.sleep(0.5)
        record['exitCode'] = process.wait()
except Exception as error:
    record['error'] = repr(error)
finally:
    if process is not None and process.poll() is None:
        process.terminate()
        process.wait(timeout=10)
    record['finishedAt'] = now()
    record['seconds'] = time.monotonic() - start
    record['status'] = 'finished; interpret retained output separately'
    record['outputs'] = {}
    for name in ['stdout', 'stderr']:
        file = pathlib.Path(PLAN['outputPaths'][name])
        if file.exists():
            data = file.read_bytes()
            record['outputs'][name] = {'path': str(file), 'bytes': len(data),
                                       'sha256': hashlib.sha256(data).hexdigest()}
    error_text = pathlib.Path(PLAN['outputPaths']['stderr']).read_text() if pathlib.Path(PLAN['outputPaths']['stderr']).exists() else ''
    record['mediaEncodingStarted'] = 'encoding mtmd batch' in error_text
    record['mediaEncodingCompleted'] = 'mtmd batch encoding done' in error_text
    record['neuralInferenceExecuted'] = record['mediaEncodingCompleted'] and record.get('exitCode') == 0
    RECORD.write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps({'record': str(RECORD), 'exitCode': record.get('exitCode'), 'seconds': record['seconds'],
                      'mediaEncodingCompleted': record['mediaEncodingCompleted'], 'outputs': record['outputs']}, indent=2))
