from pathlib import Path
import hashlib, json, wave
from datetime import datetime, timezone

root = Path('/workspace/scratch/0b7ad82bafe7')
work = root / 'audio-evaluator-floor-r1'
sha = lambda b: hashlib.sha256(b).hexdigest()
load = lambda p: json.loads(p.read_text())
record = load(work / 'silence-floor1e10-record.json')
plan = load(work / 'silence-run-plan.json')
original = load(root / record['originalRecord'])
build = load(work / 'build-manifest.json')
preflight = load(work / 'refuter-preflight.json')
checks = []

for key, filename in [('sourceManifestSha256','source-manifest.json'), ('buildManifestSha256','build-manifest.json'),
                      ('buildRecordSha256','build.json'), ('launcherSha256','run-silence-once.py')]:
    assert sha((work / filename).read_bytes()) == record[key], filename
checks.append({'name':'Actual run record pins source/build manifests, completed build and launcher bytes', 'passed':True})

assert record['args'] == plan['args']
assert len(record['args']) == len(original['args'])
assert [i for i,(a,b) in enumerate(zip(record['args'],original['args'])) if a != b] == [0]
assert record['cwd'] == plan['cwd'] and record['environment'] == plan['environment']
launcher = (work / 'run-silence-once.py').read_text()
assert "subprocess.Popen(PLAN['args'], cwd=PLAN['cwd'], env=PLAN['environment']" in launcher
assert "assert not RECORD.exists()" in launcher and "RECORD.open('x')" in launcher
assert "open('xb')" in launcher
assert record['inferenceAttemptsInThisDiagnostic'] == 1 and record['unchangedToneInferenceAttempts'] == 0
checks.append({'name':'Executed launcher uses the unchanged planned arguments except binary path, recorded cwd/environment, and exclusive new artifacts', 'passed':True})

wav = Path(record['input']['path'])
with wave.open(str(wav),'rb') as reader:
    header = {'channels':reader.getnchannels(),'sampleWidth':reader.getsampwidth(),'sampleRate':reader.getframerate(),'frames':reader.getnframes()}
    pcm = reader.readframes(reader.getnframes())
assert header == {'channels':1,'sampleWidth':2,'sampleRate':16000,'frames':64000}
assert len(pcm) == 128000 and not any(pcm)
assert sha(wav.read_bytes()) == record['input']['sha256'] == preflight['originalControl']['wavSha256']
prompt = Path(record['prompt']['path']).read_bytes()
assert sha(prompt) == record['prompt']['sha256'] == preflight['originalControl']['promptSha256']
checks.append({'name':'Actual input remains exactly four seconds of zero PCM; actual prompt and WAV hashes match both preflight and completed record', 'passed':True})

outputs = {}
for name,item in record['outputs'].items():
    data = Path(item['path']).read_bytes()
    assert len(data) == item['bytes'] and sha(data) == item['sha256']
    outputs[name] = {'bytes':len(data),'sha256':sha(data),'text':data.decode()}
assert record['exitCode'] == 0 and not record.get('timedOut',False)
assert 'encoding mtmd batch' in outputs['stderr']['text'] and 'mtmd batch encoding done' in outputs['stderr']['text']
assert 'music starts at 2.02 seconds and lasts until 28.02 seconds' in outputs['stdout']['text']
checks.append({'name':'Retained output is nonempty completed inference and positively asserts music absent from zeroPCM', 'passed':True})

runtime = {}
for name,info in build['runtime'].items():
    if name == 'llama-mtmd-cli' or name.startswith('libmtmd.so') or name.startswith('libllama.so'):
        file = work / 'build-floor1e10/bin' / name
        target = str(file.resolve())
        if target not in runtime:
            data = file.read_bytes()
            assert len(data) == info['bytes'] and sha(data) == info['sha256']
            runtime[target] = {'bytes':len(data),'sha256':sha(data),'manifestName':name}
assert any(v['manifestName'] == 'llama-mtmd-cli' for v in runtime.values())
assert any(v['manifestName'].startswith('libmtmd.so') for v in runtime.values())
for name,info in build['buildMetadata'].items():
    data = (work / 'build-floor1e10' / name).read_bytes()
    assert len(data) == info['bytes'] and sha(data) == info['sha256']
commands = load(work / 'build-floor1e10/compile_commands.json')
audio_commands = [c for c in commands if c['file'].endswith('/tools/mtmd/mtmd-audio.cpp')]
assert len(audio_commands) == 1
assert audio_commands[0]['file'] == str(work/'source-floor1e10/tools/mtmd/mtmd-audio.cpp')
assert sha(Path(audio_commands[0]['file']).read_bytes()) == preflight['sourceHashes']['variant']
checks.append({'name':'Selected binary/library artifacts and build metadata still match the run-pinned build manifest; compile command points at the audited modified source', 'passed':True})

result = {
 'checkedAt':datetime.now(timezone.utc).isoformat(),
 'scope':'Independent read-only source/build/input/launcher/output audit of the single already-completed corrected-runtime silence run. No inference, build, source execution, model download, original-control rerun or product edit by this refuter.',
 'checks':checks,
 'sourcePreflight':'audio-evaluator-floor-r1/refuter-preflight.json',
 'runtimeArtifactsVerified':runtime,
 'compileCommand':audio_commands[0],
 'input':{**header,'durationSeconds':header['frames']/header['sampleRate'],'nonzeroSamples':0,'sha256':sha(wav.read_bytes())},
 'prompt':{'sha256':sha(prompt),'text':prompt.decode()},
 'outputs':outputs,
 'run':{'startedAt':record['startedAt'],'finishedAt':record['finishedAt'],'seconds':record['seconds'],'exitCode':record['exitCode'],'attempts':record['inferenceAttemptsInThisDiagnostic'],'toneInferenceAttempts':record['unchangedToneInferenceAttempts']},
 'verdictOnIndividualNegativeControl':'FAIL',
 'evidenceMeaning':'The caption asserts continuous music from 2.02 to 28.02 seconds in an exact four-second zero-PCM input. This violates the decision rule recorded before the run, irrespective of inferred padding or language-model mechanisms.',
 'notMeasured':{
   'inferenceProcessLoadedLibraryMaps':record.get('mapsErrors',[]),
   'reason':'The inference process maps collection failed with FileNotFoundError. On-disk binaries, compile/link metadata and recorded launch environment are verified; a live loaded-library map was not acquired.',
   'originalEnvironmentParity':'Original full launcher environment was not archived, and the recorded original GNU11.4 release differs from this GNU13.3 local build. No sole-floor causal conclusion follows.',
 },
 'modelIdentity':'Existing complete model hashes in original-integrity.json and the prior diagnostic audit are accepted; multi-gigabyte model hashes are not redundantly recomputed here.',
 'constraints':['No tone inference or reevaluation: the prior original/floor tone features were byte-identical.','No product/reference/stereo/blind comparison.','No passing evaluator qualification.','No model-only diagnosis.'],
}
with (work/'refuter-result-audit.json').open('x') as f:
    json.dump(result,f,indent=2);f.write('\n')
print(json.dumps({'path':str(work/'refuter-result-audit.json'),'checks':len(checks),'control':'FAIL','runtimeArtifactsVerified':len(runtime)}))
