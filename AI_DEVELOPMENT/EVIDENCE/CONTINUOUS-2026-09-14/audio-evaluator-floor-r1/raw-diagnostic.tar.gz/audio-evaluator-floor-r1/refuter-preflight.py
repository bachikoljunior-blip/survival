from pathlib import Path
import hashlib
import json
import difflib
from datetime import datetime, timezone

root = Path('/workspace/scratch/0b7ad82bafe7')
work = root / 'audio-evaluator-floor-r1'
manifest_path = work / 'source-manifest.json'
manifest = json.loads(manifest_path.read_text())
variant = work / 'source-floor1e10'
original = work / 'source-original' / ('llama.cpp-' + manifest['sourceRef'])
sha = lambda b: hashlib.sha256(b).hexdigest()
actual_changed = []
errors = []
for relative, expected_original in manifest['original'].items():
    old = (original / relative).read_bytes()
    new = (variant / relative).read_bytes()
    if sha(old) != expected_original:
        errors.append({'file': relative, 'kind': 'original hash mismatch'})
    expected_new = manifest['changed'].get(relative, expected_original)
    if sha(new) != expected_new:
        errors.append({'file': relative, 'kind': 'variant hash mismatch'})
    if old != new:
        actual_changed.append(relative)

relative = 'tools/mtmd/mtmd-audio.cpp'
old = (original / relative).read_bytes()
new = (variant / relative).read_bytes()
line = b'    params.mel_floor        = 1e-10f;\n'
# The insertion is constrained to the Whisper preprocessor's own params block.
anchor = b'    filter_params params;\n    params.n_mel            = hparams.n_mel_bins;'
whisper = old.index(b'bool mtmd_audio_preprocessor_whisper::preprocess(')
start = old.index(anchor, whisper)
expected_new = old[:start] + old[start:].replace(anchor, b'    filter_params params;\n' + line + b'    params.n_mel            = hparams.n_mel_bins;', 1)
assert new == expected_new
assert actual_changed == manifest['onlyChangedPaths'] == [relative]
assert len(manifest['original']) == manifest['fileCount'] == 3527
assert not errors, errors
connector = (root / 'audio-evaluator-diagnostic-source-mtmd-audio.cpp').read_bytes()
assert connector == old + b'\n'
prompt_path = root / 'audio-evaluator/calibration-prompt.txt'
wav_path = root / 'audio-evaluator/silence-control.wav'
original_record = json.loads((root / 'audio-evaluator/silence-control-record.json').read_text())
diagnostic_refuter = json.loads((root / 'audio-evaluator-diagnostic-refuter-review.json').read_text())
result = {
    'checkedAt': datetime.now(timezone.utc).isoformat(),
    'scope': 'Read-only source/archive-manifest preflight. No source execution, compilation, model inference, control repetition, model download, product edit, browser, socket or server by this refuter.',
    'sourceRef': manifest['sourceRef'],
    'manifestSha256': sha(manifest_path.read_bytes()),
    'fileCount': len(manifest['original']),
    'actualChangedPaths': actual_changed,
    'hashAuditErrors': errors,
    'sourceHashes': {'archiveOriginal': sha(old), 'variant': sha(new), 'oldConnectorText': sha(connector)},
    'diff': ''.join(difflib.unified_diff(old.decode().splitlines(True), new.decode().splitlines(True), fromfile='archive-original/' + relative, tofile='floor1e10/' + relative)),
    'connectorDifference': 'The retained connector text has one additional final LF versus the exact public-archive source; all earlier bytes match.',
    'failedProbeSetup': 'The first audit attempt asserted the LF difference in the opposite direction and stopped before writing this output. The verified direction is connector = archive + LF. No inference or product edit occurred.',
    'checks': [
        {'name': 'All 3527 original and variant file hashes match their recorded identities', 'passed': True},
        {'name': 'Only one source file differs and it has exactly the intended Whisper floor assignment insertion', 'passed': True},
        {'name': 'Connector/archive prior-source difference is final LF only', 'passed': True},
    ],
    'originalControl': {
        'record': 'audio-evaluator/silence-control-record.json',
        'args': original_record['args'],
        'exitCode': original_record['exit_code'],
        'wavSha256': sha(wav_path.read_bytes()),
        'promptSha256': sha(prompt_path.read_bytes()),
        'promptText': prompt_path.read_text(),
    },
    'previousEvidenceAcceptedWithoutRerun': {
        'source': 'audio-evaluator-diagnostic-refuter-review.json',
        'toneFeatureIdentity': diagnostic_refuter['accepted_controls']['tone_feature_identity'],
        'meaning': 'The old tone feature identity precludes claiming a floor-driven tone-order repair. No tone inference or reevaluation is planned or performed by this refuter.',
    },
    'unmeasured': ['New full-runtime output has not yet been supplied for review.', 'Source identity alone is not binary identity or proof of loaded library selection.', 'Original released build used GNU11.4 versus the local GNU13.3 build; original full environment was not archived. A later output difference will not prove sole floor causality.', 'No product sound, stereo-localization or reference blind comparison is established.'],
}
output = work / 'refuter-preflight.json'
with output.open('x') as f:
    json.dump(result, f, indent=2)
    f.write('\n')
print(json.dumps({'path': str(output), 'files': result['fileCount'], 'changed': actual_changed, 'errors': len(errors)}))
