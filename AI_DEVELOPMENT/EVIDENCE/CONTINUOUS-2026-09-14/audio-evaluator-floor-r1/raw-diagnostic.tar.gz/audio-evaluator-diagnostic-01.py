import array, hashlib, json, math, os, struct, sys, wave
from pathlib import Path
root=Path('/workspace/scratch/0b7ad82bafe7')
base=root/'audio-evaluator'
def sha(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
    return h.hexdigest()
class GGUF:
    def __init__(self,path):
        self.f=open(path,'rb');self.path=path
    def scalar(self,fmt):
        return struct.unpack('<'+fmt,self.f.read(struct.calcsize('<'+fmt)))[0]
    def string(self):
        return self.f.read(self.scalar('Q')).decode('utf8')
    def value(self,t):
        fmt={0:'B',1:'b',2:'H',3:'h',4:'I',5:'i',6:'f',7:'?',10:'Q',11:'q',12:'d'}
        if t in fmt:return self.scalar(fmt[t])
        if t==8:return self.string()
        if t==9:
            sub,n=self.scalar('I'),self.scalar('Q')
            return [self.value(sub) for _ in range(n)]
        raise ValueError(t)
    def read(self):
        assert self.f.read(4)==b'GGUF'
        version,nt,nkv=self.scalar('I'),self.scalar('Q'),self.scalar('Q')
        kv={}
        for _ in range(nkv):
            k=self.string();kv[k]=self.value(self.scalar('I'))
        positions={'metadata_end':self.f.tell()}
        tensors=[]
        for _ in range(nt):
            name=self.string();nd=self.scalar('I');shape=[self.scalar('Q') for _ in range(nd)];dtype=self.scalar('I');offset=self.scalar('Q')
            tensors.append({'name':name,'shape':shape,'dtype':dtype,'offset':offset})
        positions['tensor_index_end']=self.f.tell()
        tokens=kv.get('tokenizer.ggml.tokens',[]);types=kv.get('tokenizer.ggml.token_type',[])
        special=[{'id':i,'token':v,'type':types[i] if i<len(types) else None} for i,v in enumerate(tokens) if ('audio' in v.lower() or v in ['</s>','<|im_start|>','<|im_end|>','<|AUDIO|>','<|IMAGE|>','<|vision_bos|>','<|vision_eos|>']) and ('<' in v or '>' in v)]
        summary={k:({'count':len(v),'first':v[:5],'last':v[-5:]} if isinstance(v,list) else v) for k,v in kv.items()}
        self.f.close()
        return {'file':str(self.path.relative_to(root)),'bytes':self.path.stat().st_size,'version':version,'tensor_count':nt,'metadata_count':nkv,'metadata':summary,'special_tokens':special,'positions':positions,'tensors':tensors}
def pcm(path):
    with wave.open(str(path),'rb') as w:
        p={'channels':w.getnchannels(),'sample_width':w.getsampwidth(),'rate':w.getframerate(),'frames':w.getnframes(),'compression':w.getcomptype()};b=w.readframes(w.getnframes())
    assert p['channels']==1 and p['sample_width']==2 and p['compression']=='NONE'
    a=array.array('h');a.frombytes(b)
    if sys.byteorder!='little':a.byteswap()
    windows=[];step=p['rate']//4
    for start in range(0,len(a),step):
        s=a[start:start+step];n=len(s)
        fits={}
        for freq in [440,1000]:
            sn=sum(v*math.sin(2*math.pi*freq*i/p['rate']) for i,v in enumerate(s))*2/n
            cs=sum(v*math.cos(2*math.pi*freq*i/p['rate']) for i,v in enumerate(s))*2/n
            fits[str(freq)]={'amplitude_pcm':math.hypot(sn,cs),'max_residual_pcm':max(abs(v-sn*math.sin(2*math.pi*freq*i/p['rate'])-cs*math.cos(2*math.pi*freq*i/p['rate'])) for i,v in enumerate(s))}
        windows.append({'start_s':start/p['rate'],'end_s':(start+n)/p['rate'],'nonzero':sum(v!=0 for v in s),'peak_pcm':max(abs(v) for v in s),'rms_pcm':math.sqrt(sum(v*v for v in s)/n),'sinusoid_fits':fits})
    return {'file':path.name,'sha256':sha(path),**p,'duration_s':len(a)/p['rate'],'nonzero_samples':sum(v!=0 for v in a),'zero_samples':sum(v==0 for v in a),'windows':windows,'scope':'Numerical inspection establishes known control input bytes/timing only; it does not replace listening or score audio quality.'}
report={'scope':'Read-only metadata and PCM audit. No inference, model execution, reference-media evaluation or download.', 'models':[], 'pcm':[], 'files':{}}
for filename in ['Qwen2.5-Omni-7B-Q8_0.gguf','mmproj-Qwen2.5-Omni-7B-f16.gguf']:
    print('Reading GGUF metadata: '+filename,flush=True);m=GGUF(base/filename).read();report['models'].append(m)
for filename in ['calibration.wav','silence-control.wav']:report['pcm'].append(pcm(base/filename))
for p in base.iterdir():
    if p.is_file() and p.suffix in ['.json','.txt','.cpp','.wav']:
        report['files'][str(p.relative_to(root))]={'bytes':p.stat().st_size,'sha256':sha(p)}
for name in ['runtime/llama-b10809/llama-mtmd-cli','runtime/llama-b10809/libmtmd.so.0.4.0','runtime/llama-b10809/libllama.so.0.4.0']:
    p=base/name;report['files'][str(p.relative_to(root))]={'bytes':p.stat().st_size,'sha256':sha(p)}
out=root/'audio-evaluator-diagnostic-01.json';out.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'models':[{'file':m['file'],'version':m['version'],'tensors':m['tensor_count'],'metadata':m['metadata_count']} for m in report['models']],'pcm':[{'file':p['file'],'frames':p['frames'],'nonzero':p['nonzero_samples']} for p in report['pcm']]}),flush=True)
