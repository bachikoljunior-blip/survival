import ast
import hashlib
import json
import math
import pathlib
import struct
import subprocess
import tarfile
import traceback
import types
import typing
import warnings
import wave

import numpy as np

ROOT = pathlib.Path('/workspace/scratch/0b7ad82bafe7')
OUT = ROOT / 'audio-evaluator-diagnostic-refuter-01.json'
assert not OUT.exists(), 'Preserve existing attempts; choose a fresh filename.'
report = {'scope': 'Independent source, archive and preprocessing-only refutation. No neural inference, reference-media evaluation, download or product edit.', 'checks': [], 'errors': []}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read_source(name):
    return (ROOT / ('audio-evaluator-diagnostic-source-' + name)).read_text()


def record(name, fn):
    try:
        report['checks'].append({'name': name, 'result': fn()})
    except Exception:
        report['errors'].append({'name': name, 'traceback': traceback.format_exc()})


source_files = sorted(ROOT.glob('audio-evaluator-diagnostic-source-*'))
report['sources_before'] = {p.name: sha(p.read_bytes()) for p in source_files}


def metadata():
    # Read only the small GGUF metadata header, not tensors or model execution.
    path = ROOT / 'audio-evaluator/mmproj-Qwen2.5-Omni-7B-f16.gguf'
    fmts = {0: '<B', 1: '<b', 2: '<H', 3: '<h', 4: '<I', 5: '<i', 6: '<f', 7: '<?', 10: '<Q', 11: '<q', 12: '<d'}
    with path.open('rb') as f:
        def num(fmt):
            return struct.unpack(fmt, f.read(struct.calcsize(fmt)))[0]
        def string():
            return f.read(num('<Q')).decode()
        def value(kind):
            if kind == 8:
                return string()
            if kind == 9:
                subtype, count = num('<I'), num('<Q')
                return [value(subtype) for _ in range(count)]
            return num(fmts[kind])
        assert f.read(4) == b'GGUF'
        version, tensors, count = num('<I'), num('<Q'), num('<Q')
        result = {}
        for _ in range(count):
            key = string()
            result[key] = value(num('<I'))
        offset = f.tell()
    assert result['clip.projector_type'] == 'qwen2.5o'
    assert result['clip.has_audio_encoder'] is True
    assert result['clip.audio.num_mel_bins'] == 128
    clip = read_source('clip.cpp')
    assert '? PROJECTOR_TYPE_QWEN25VL\n                                    : PROJECTOR_TYPE_QWEN2A;' in clip
    init = read_source('mtmd.cpp').split('void init_audio() {', 1)[1].split('case PROJECTOR_TYPE_QWEN3A:', 1)[0]
    assert 'case PROJECTOR_TYPE_QWEN2A:' in init and 'mtmd_audio_preprocessor_whisper>(ctx_a)' in init
    pre = read_source('mtmd-audio.cpp').split('bool mtmd_audio_preprocessor_whisper::preprocess', 1)[1].split('// mtmd_audio_preprocessor_qwen3a', 1)[0]
    assert 'params.mel_floor' not in pre
    return {'version': version, 'tensors': tensors, 'metadata_count': count, 'bytes_read': offset, 'metadata': result, 'actual_audio_route': 'qwen2.5o -> QWEN2A -> mtmd_audio_preprocessor_whisper', 'whisper_floor_override_present': False}


def provenance():
    parent = json.loads((ROOT / 'audio-evaluator-diagnostic-02.json').read_text())
    path = ROOT / 'survival/AI_DEVELOPMENT/EVIDENCE/CONTINUOUS-2026-09-14/audio-evaluator-calibration/raw-calibration.tar.gz'
    actual = sha(path.read_bytes())
    assert actual == parent['archives']['calibration']['sha256']
    expected = {m['name']: m for m in parent['archives']['calibration']['members']}
    members = []
    with tarfile.open(path, 'r:gz') as tar:
        for member in tar.getmembers():
            if not member.isfile():
                continue
            name = pathlib.PurePosixPath(member.name).name
            b = tar.extractfile(member).read()
            h = sha(b)
            assert name in expected
            assert h == expected[name]['sha256'] == sha((ROOT / 'audio-evaluator' / name).read_bytes())
            members.append({'name': name, 'sha256': h, 'bytes': len(b)})
    assert len(members) == len(expected)
    runtime = parent['archives']['runtime']
    return {'calibration_archive_sha256': actual, 'members_rechecked_against_archive_original_and_parent_record': members, 'parent_full_model_hashes': parent['model_hashes'], 'full_model_hashes_recomputed_by_refuter': False, 'runtime_provenance_read_from_parent': runtime, 'environment_limit': parent['environment_provenance_limitation']}


def pcm_and_captions():
    result = []
    for name, expected_frames in [('silence-control', 64000), ('calibration', 96000)]:
        path = ROOT / 'audio-evaluator' / (name + '.wav')
        with wave.open(str(path), 'rb') as w:
            assert (w.getnchannels(), w.getsampwidth(), w.getframerate(), w.getnframes()) == (1, 2, 16000, expected_frames)
            samples = np.frombuffer(w.readframes(w.getnframes()), dtype='<i2')
        if name == 'silence-control':
            assert np.count_nonzero(samples) == 0
        else:
            assert np.count_nonzero(samples[:32000]) == 0
        stem = 'calibration-v2' if name == 'calibration' else name
        run = json.loads((ROOT / 'audio-evaluator' / (stem + '-record.json')).read_text())
        assert run['exit_code'] == 0
        stderr = (ROOT / 'audio-evaluator' / (stem + '-stderr.txt')).read_text()
        assert 'mtmd batch encoding done' in stderr
        result.append({'input': path.name, 'sha256': sha(path.read_bytes()), 'frames': len(samples), 'nonzero_samples': int(np.count_nonzero(samples)), 'quarter_second_nonzero_samples': [int(np.count_nonzero(samples[i:i+4000])) for i in range(0, len(samples), 4000)], 'run_exit_code': run['exit_code'], 'argv': run['args'], 'caption': (ROOT / 'audio-evaluator' / (stem + '-stdout.txt')).read_text(), 'encoded_media_log_present': True})
    initial = json.loads((ROOT / 'audio-evaluator/calibration-record.json').read_text())
    assert initial['exit_code'] == 1
    assert (ROOT / 'audio-evaluator/calibration-stdout.txt').read_bytes() == b''
    return {'controls': result, 'initial_backend_failure_excluded_from_caption_evidence': True, 'prompt': (ROOT / 'audio-evaluator/calibration-prompt.txt').read_text()}


def preprocessing():
    source = read_source('mtmd-audio.cpp')
    expected_body = source[:source.index('// mtmd_audio_preprocessor_qwen3a')].replace('#include "mtmd-audio.h"', '#include "audio-evaluator-diagnostic-preprocess-shim.h"', 1)
    prefix = 'audio-evaluator-diagnostic-preprocess-'
    original = (ROOT / (prefix + 'original.cpp')).read_text()
    variant = (ROOT / (prefix + 'floor1e10.cpp')).read_text()
    assert original.startswith(expected_body)
    added = '    params.mel_floor        = 1e-10f; // diagnostic variant: only Qwen/Whisper floor differs\n'
    assert variant.count(added) == 1 and variant.replace(added, '', 1) == original
    header = read_source('mtmd-audio.h')
    assert (ROOT / (prefix + 'shim.h')).read_text().endswith(header[header.index('struct mtmd_audio_mel {'):header.index('struct mtmd_audio_preprocessor_conformer')])
    actual_floor = float(np.float32(5.960464477539063e-08))
    # The trailing worker fast-fill uses 1e-10, but the current padding updates
    # n_samples; all returned 3000 frames execute the real FFT loop.
    loop_bounds = []
    for samples in [64000, 96000]:
        padded = samples + 480000 + 400
        n_len = (padded - 400) // 160 + 1
        assert padded // 160 + 1 > n_len > 3000
        loop_bounds.append({'input_samples': samples, 'padded_samples': padded, 'out_full_frames': n_len, 'worker_fft_limit_before_out_len_clamp': padded // 160 + 1, 'returned_frames': 3000, 'returned_frames_enter_1e10_tail_branch': 0})
    utils = ast.parse(read_source('audio-utils-v4523.py'))
    allowed = {'hertz_to_mel', 'mel_to_hertz', '_create_triangular_filter_bank', 'mel_filter_bank', 'window_function', 'spectrogram', 'amplitude_to_db', 'power_to_db'}
    ns = {'np': np, 'warnings': warnings, **vars(typing)}
    exec(compile(ast.Module(body=[n for n in utils.body if isinstance(n, ast.FunctionDef) and n.name in allowed], type_ignores=[]), 'independent-pinned-audio-utils', 'exec'), ns)
    feature = ast.parse(read_source('whisper-feature-v4523.py'))
    cls = next(n for n in feature.body if isinstance(n, ast.ClassDef) and n.name == 'WhisperFeatureExtractor')
    fn = next(n for n in cls.body if isinstance(n, ast.FunctionDef) and n.name == '_np_extract_fbank_features')
    exec(compile(ast.Module(body=[fn], type_ignores=[]), 'independent-pinned-whisper-method', 'exec'), ns)
    reference = types.SimpleNamespace(n_fft=400, hop_length=160, dither=0.0, mel_filters=ns['mel_filter_bank'](201, 128, 0.0, 8000.0, 16000, norm='slaney', mel_scale='slaney'))
    controls = []
    for name in ['silence-control', 'calibration']:
        path = ROOT / 'audio-evaluator' / (name + '.wav')
        with wave.open(str(path), 'rb') as w:
            pcm = np.frombuffer(w.readframes(w.getnframes()), dtype='<i2').astype(np.float32) / 32768.0
        inp = ROOT / (prefix + name + '-input.f32')
        assert inp.read_bytes() == pcm.astype('<f4').tobytes()
        ref = ns['_np_extract_fbank_features'](reference, np.pad(pcm, (0, 480000-len(pcm)))[None, :], 'cpu')[0]
        outputs = {}
        records = []
        for kind in ['original', 'floor1e10']:
            exe = ROOT / (prefix + kind)
            cmd = [str(exe), str(inp)]
            run = subprocess.run(cmd, capture_output=True, timeout=30)
            if run.returncode:
                failure = ROOT / ('audio-evaluator-diagnostic-refuter-failed-' + name + '-' + kind)
                failure.with_suffix('.stdout').write_bytes(run.stdout)
                failure.with_suffix('.stderr').write_bytes(run.stderr)
            assert run.returncode == 0, run.stderr.decode()
            assert run.stdout == (ROOT / (prefix + name + '-' + kind + '.f32')).read_bytes()
            data = np.frombuffer(run.stdout, dtype='<f4').reshape(128, 3000)
            outputs[kind] = data
            delta = np.abs(data - ref)
            records.append({'variant': kind, 'args': cmd, 'binary_sha256': sha(exe.read_bytes()), 'exit_code': run.returncode, 'stderr': run.stderr.decode(), 'stdout_sha256': sha(run.stdout), 'retained_buffer_identical': True, 'min': float(data.min()), 'max': float(data.max()), 'max_abs_difference_to_reference': float(delta.max()), 'mean_abs_difference_to_reference': float(delta.mean()), 'bins_difference_gt_1e5': int((delta > 1e-5).sum())})
        changed = int(np.count_nonzero(outputs['original'] != outputs['floor1e10']))
        if name == 'silence-control':
            assert changed == 384000
            assert np.all(outputs['floor1e10'] == ref) and np.all(ref == -1.5)
            dominance = None
        else:
            assert changed == 0
            # Recover the global log-power peak from normalized max to show why
            # the max-8 dynamic clamp dominates both proposed absolute floors.
            peak_log = float(outputs['original'].max()) * 4.0 - 4.0
            dominance = {'peak_log10_power': peak_log, 'dynamic_log10_floor': peak_log-8, 'absolute_log10_floor': math.log10(actual_floor), 'dynamic_floor_is_higher': peak_log-8 > math.log10(actual_floor)}
            assert dominance['dynamic_floor_is_higher']
        controls.append({'name': name, 'shape': list(ref.shape), 'variants': records, 'floor_only_changed_bins': changed, 'dynamic_clamp': dominance})
    return {'original_calculation_source_is_exact_prefix_except_header_include': True, 'variant_is_exact_one_assignment_change': True, 'header_types_match_original': True, 'source_sha256': sha(source.encode()), 'floor': actual_floor, 'floor_log10': math.log10(actual_floor), 'normalized_silence_mathematical': (math.log10(actual_floor)+4)/4, 'reference_floor': 1e-10, 'reference_normalized_silence': -1.5, 'worker_bounds': loop_bounds, 'controls': controls, 'scope_limit': 'Existing isolated source executables were rerun, with metadata shim only. This is not invocation of the released libmtmd frontend/projector or a caption/inference test.'}


record('metadata_and_branch', metadata)
record('archive_identity', provenance)
record('pcm_and_completed_captions', pcm_and_captions)
record('isolated_source_preprocessing', preprocessing)
report['sources_after'] = {p.name: sha(p.read_bytes()) for p in source_files}
report['source_bytes_unchanged'] = report['sources_before'] == report['sources_after']
assert report['source_bytes_unchanged']
OUT.write_text(json.dumps(report, indent=2, ensure_ascii=False, allow_nan=False) + '\n')
print(json.dumps({'output': str(OUT), 'checks': [c['name'] for c in report['checks']], 'errors': report['errors'], 'source_bytes_unchanged': report['source_bytes_unchanged']}, indent=2))
raise SystemExit(bool(report['errors']))
