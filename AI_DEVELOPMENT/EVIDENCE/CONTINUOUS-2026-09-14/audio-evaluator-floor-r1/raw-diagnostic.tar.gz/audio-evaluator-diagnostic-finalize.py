import hashlib,json,pathlib
root=pathlib.Path('/workspace/scratch/0b7ad82bafe7')
review=json.loads((root/'audio-evaluator-diagnostic-review-draft.json').read_text())
evidence=json.loads((root/'audio-evaluator-diagnostic-refuter-01.json').read_text())
assert evidence['errors']==[] and evidence['source_bytes_unchanged']
assert len(evidence['checks'])==4
review['refutationStatus']='COMPLETE_SEPARATE_REFUTER'
review['independentRefutation']={'agent':'/root/trench_perception_review/trench_refuter','evidence':'audio-evaluator-diagnostic-refuter-01.json','groups':4,'errors':0,'result':'AE-PREPROC-01 survives as a source preprocessing mismatch. Tone-order causality is refuted; silence-caption repair is unproven. Refuter independently recomputed reference features and both isolated source variants, inspected source extraction/one-line delta, and checked original PCM/archive identity.'}
f=review['findings'][0]
f['why']='The selected runtime changes the representation of this known silent input before model encoding. This supports a controlled diagnostic correction and prevents attributing the failed negative control solely to model weights.'
f['fix']='Apply the reference 1e-10 floor in a separate copy of the validated Qwen/Whisper runtime path, preserving original binaries and outputs. Target: max absolute silence-feature error0 over384000 values; tone-control features unchanged. Read retained numeric evidence with python -m json.tool /workspace/scratch/0b7ad82bafe7/audio-evaluator-diagnostic-preprocess.json. A new full-runtime caption test requires fresh output paths; this preprocessing result does not establish inference repair.'
f['refutation']={'status':'survived narrowly','evidence':'audio-evaluator-diagnostic-refuter-01.json','changes_after_refutation':['Removed implication that correction is mandatory.','Replaced an overwriting harness rerun command with a read-only command.','Retained explicit no-causality/no-caption-repair scope.']}
review['rawEvidence'] += ['audio-evaluator-diagnostic-refuter-01.py','audio-evaluator-diagnostic-refuter-01.json','audio-evaluator-diagnostic-refuter-01.log','audio-evaluator-diagnostic-original-integrity.json']
review['integrity']='Original25 evidence/runtime files pinned before diagnosis remain byte-identical; all models/runtime archives separately hashed in-02.json.'
refreport=root/'audio-evaluator-diagnostic-refuter-report.json'
if refreport.exists():
 review['independentRefutation']['report']=refreport.name
 review['rawEvidence'].append(refreport.name)
(root/'audio-evaluator-diagnostic-review.json').write_text(json.dumps(review,indent=2)+'\n')
print(json.dumps({'report':'audio-evaluator-diagnostic-review.json','surviving_findings':len(review['findings']),'refutation':review['refutationStatus']}))
