import ast, hashlib, json, pathlib, subprocess, types, typing, warnings, wave
import numpy as np
root=pathlib.Path('/workspace/scratch/0b7ad82bafe7')
prefix='audio-evaluator-diagnostic-'
def read(name):return (root/(prefix+'source-'+name)).read_text()
def digest(b):return hashlib.sha256(b).hexdigest()
source=read('mtmd-audio.cpp')
body=source[:source.index('// mtmd_audio_preprocessor_qwen3a')].replace('#include "mtmd-audio.h"','#include "audio-evaluator-diagnostic-preprocess-shim.h"',1)
header=read('mtmd-audio.h')
structs=header[header.index('struct mtmd_audio_mel {'):header.index('struct mtmd_audio_preprocessor_conformer')]
shim='''#pragma once
#include <cassert>
#include <cstdint>
#include <cstdio>
#include <vector>
#include <string>
#define GGML_ASSERT(x) assert(x)
#define LOG_ERR(...) fprintf(stderr, __VA_ARGS__)
// Metadata context only. No model, decoder, backend, embedding, or inference stub is executed.
struct clip_hparams { int n_mel_bins=128; int audio_n_fft=400; int audio_window_len=400; int audio_sample_rate=16000; int audio_hop_len=160; };
struct clip_ctx { clip_hparams hp; };
inline const clip_hparams * clip_get_hparams(const clip_ctx * c) { return &c->hp; }
'''+structs
(root/(prefix+'preprocess-shim.h')).write_text(shim)
main='''
#include <iostream>
int main(int argc, char **argv) {
 if (argc != 2) return 2;
 std::ifstream f(argv[1],std::ios::binary|std::ios::ate); if(!f)return 3;
 auto sz=f.tellg(); f.seekg(0); std::vector<float> samples((size_t)sz/4); f.read((char*)samples.data(),sz);
 clip_ctx context; mtmd_audio_preprocessor_whisper processor(&context); processor.initialize();
 std::vector<mtmd_audio_mel> output;
 if(!processor.preprocess(samples.data(),samples.size(),output))return 4;
 std::cerr << "chunks=" << output.size();
 for(const auto &m:output){std::cerr << " n_mel=" << m.n_mel << " n_len=" << m.n_len; fwrite(m.data.data(),sizeof(float),m.data.size(),stdout);}
 std::cerr << "\\n"; return 0;
}
'''
fixed=body.replace('    filter_params params;\n    params.n_mel            = hparams.n_mel_bins;', '    filter_params params;\n    params.mel_floor        = 1e-10f; // diagnostic variant: only Qwen/Whisper floor differs\n    params.n_mel            = hparams.n_mel_bins;',1)
assert fixed!=body and fixed.count('diagnostic variant:')==1
report={'scope':'Preprocessing-only source execution, no neural model execution or inference. Original upstream calculation functions are compiled unchanged except first include replaced by a metadata/log/assert shim; second variant adds one mel_floor assignment. This does not establish caption repair.', 'source_commit':'5266f24da75dc449bd56cbed7addb9c8e4a6a73e','source_sha256':digest(source.encode()),'reference':'HF Transformers v4.52.3 Qwen2_5OmniProcessor selects WhisperFeatureExtractor; actual NumPy reference method/functions loaded by AST. Parameters128 mel/16k/400 FFT/160 hop are pinned runtime + GGUF values. No optional normalization or dither.', 'commands':[], 'controls':[]}
for name,code in [('original',body),('floor1e10',fixed)]:
 path=root/(prefix+'preprocess-'+name+'.cpp');path.write_text(code+main)
 cmd=['g++','-std=c++17','-O2','-pthread',str(path),'-o',str(path.with_suffix(''))]
 p=subprocess.run(cmd,capture_output=True,text=True,timeout=30)
 report['commands'].append({'args':cmd,'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'source_sha256':digest(path.read_bytes())})
 if p.returncode:
  (root/(prefix+'preprocess-failed.json')).write_text(json.dumps(report,indent=2)+'\n');raise RuntimeError(p.stderr)
# Evaluate only pure function definitions from the reference file; omit all audio loading/network helpers.
utils_src=read('audio-utils-v4523.py');tree=ast.parse(utils_src)
allowed={'hertz_to_mel','mel_to_hertz','_create_triangular_filter_bank','mel_filter_bank','window_function','spectrogram','amplitude_to_db','power_to_db'}
selected=[n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name in allowed]
ns={'np':np,'warnings':warnings,**vars(typing)}
exec(compile(ast.Module(body=selected,type_ignores=[]),'pinned-audio-utils-subset','exec'),ns)
feature_tree=ast.parse(read('whisper-feature-v4523.py'))
cls=next(n for n in feature_tree.body if isinstance(n,ast.ClassDef) and n.name=='WhisperFeatureExtractor')
fn=next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name=='_np_extract_fbank_features')
exec(compile(ast.Module(body=[fn],type_ignores=[]),'pinned-whisper-numpy-method','exec'),ns)
refself=types.SimpleNamespace(n_fft=400,hop_length=160,dither=0.0,mel_filters=ns['mel_filter_bank'](num_frequency_bins=201,num_mel_filters=128,min_frequency=0.0,max_frequency=8000.0,sampling_rate=16000,norm='slaney',mel_scale='slaney'))
for name in ['silence-control','calibration']:
 path=root/'audio-evaluator'/(name+'.wav')
 with wave.open(str(path),'rb') as w:
  assert (w.getnchannels(),w.getsampwidth(),w.getframerate())==(1,2,16000)
  pcm=np.frombuffer(w.readframes(w.getnframes()),dtype='<i2').astype(np.float32)/32768.0
 inp=root/(prefix+'preprocess-'+name+'-input.f32');inp.write_bytes(pcm.astype('<f4').tobytes())
 refinput=np.pad(pcm,(0,480000-len(pcm)))
 refout=ns['_np_extract_fbank_features'](refself,np.array([refinput]),'cpu')[0]
 outputs={}
 control={'input':str(path.relative_to(root)),'input_sha256':digest(path.read_bytes()),'input_frames':len(pcm),'reference_shape':list(refout.shape),'variants':{},'windows':[]}
 for variant in ['original','floor1e10']:
  cmd=[str(root/(prefix+'preprocess-'+variant)),str(inp)]
  p=subprocess.run(cmd,capture_output=True,timeout=30)
  outfile=root/(prefix+'preprocess-'+name+'-'+variant+'.f32');outfile.write_bytes(p.stdout)
  report['commands'].append({'args':cmd,'exit_code':p.returncode,'stderr':p.stderr.decode(),'stdout_file':outfile.name,'stdout_bytes':len(p.stdout),'stdout_sha256':digest(p.stdout)})
  assert p.returncode==0
  data=np.frombuffer(p.stdout,dtype='<f4').reshape(128,3000);outputs[variant]=data
  delta=np.abs(data-refout)
  control['variants'][variant]={'min':float(data.min()),'max':float(data.max()),'max_abs_difference_to_reference':float(delta.max()),'mean_abs_difference_to_reference':float(delta.mean()),'bins_difference_gt1e5':int((delta>1e-5).sum())}
 for lo,hi in [(0,2),(2,4),(4,6),(6,30)]:
  sl=slice(int(lo*100),int(hi*100));before=np.abs(outputs['original'][:,sl]-refout[:,sl]);after=np.abs(outputs['floor1e10'][:,sl]-refout[:,sl])
  control['windows'].append({'start_s':lo,'end_s':hi,'original_max_error':float(before.max()),'original_mean_error':float(before.mean()),'floor_only_max_error':float(after.max()),'floor_only_mean_error':float(after.mean()),'floor_only_changed_bins':int((outputs['original'][:,sl]!=outputs['floor1e10'][:,sl]).sum())})
 if name=='silence-control':control['reference_unique_values']=np.unique(refout).tolist()
 report['controls'].append(control)
report['limitations']=['No original libmtmd neural inference or projector encoding was run; this isolates pinned preprocessor source only.','Metadata shim supplies source-confirmed Qwen settings and no audio signal; numerical processing functions are copied directly.','Reference inputs are padded to30s per Qwen processor source. Additional runtime length/masking differences are outside this isolated floor comparison.','No caption outcome is inferred from numerical agreement and no sound-quality criteria are changed.']
(root/(prefix+'preprocess.json')).write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'controls':report['controls'],'commands_ok':all(c['exit_code']==0 for c in report['commands'])},indent=2))
