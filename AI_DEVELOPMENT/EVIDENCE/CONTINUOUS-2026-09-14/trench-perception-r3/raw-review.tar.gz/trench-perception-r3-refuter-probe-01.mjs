// R3 independent narrow refutation. Prior probes retained; no product edits.
import fs from 'node:fs';
import assert from 'node:assert/strict';
import {root,sha,pinSources,makeGame,snap,tick,place,enterTrench,inputFixture,observeDamage,Storage,Enemy,MODE,swallowedErrors} from './trench-perception-r2-fixture-v1.mjs';
import {setLocale,locale} from './survival/src/content/i18n.js';
const expected={
 'src/game/director.js':'1dfd99d47e3023d0e257cd0a0dfab6255fa3a9bb61910b92b4d632237d09020d',
 'src/content/locale/ja/ui.js':'5d47dd0ceba8079a28568da0e66235d59ad31fd6a7935e4e1e05409d9cb611b7',
 'src/game/ai.js':'dd3a37e8681a1d728c574db86e875be91807f7c75589494162e1f63cbe056597',
 'src/world/city.js':'81acdf64d65c087b9db556091896e4de0fb0fa4d60ed1d2d20e47d491c7efa4b',
 'src/world/props.js':'6044093c5bf49b66b6e8f90f012ad2bee0746bdb79bbddb7b338d6c98b8c5f38'
};
const sourceHashes=pinSources(),checks=[];for(const [p,h] of Object.entries(expected))assert.equal(sourceHashes[p],h);
const report={createdAt:new Date().toISOString(),sourceHashes,expected,scope:'Separate source-labelled CPU refutation of live/fresh-instance save reentry, declared item gate/localization and real imminent-attack cancellation. Real Game input mapping/Director/QuestSystem/Storage/AI/Combat. Appearance, input acquisition, UI, camera/post/audio devices are fixture stubs; no perception, damage or movement result is forced. Unchanged world/Player controls are inspected from retained evidence.',checks};
if(globalThis.document&&!globalThis.document.documentElement)globalThis.document.documentElement={lang:'en',setAttribute(){}};
async function check(name,fn){const e={name,status:'running',result:{}};checks.push(e);try{await fn(e.result);e.status='completed';console.log(name+': completed');}catch(error){e.status='probe-error';e.error=String(error);e.stack=error.stack;console.log(name+': '+error.stack);}}
const enemies=g=>g.actors.filter(a=>a instanceof Enemy).map(a=>({id:a.id,kind:a.kind,faction:a.faction,state:a.aiState,awareness:a.awareness,aggro:a.aggro,target:a.target?.id??null,attack:a.attack?{name:a.attack.name,t:a.attack.t,windup:a.attack.windup}:null}));
const full=g=>({...snap(g),enemies:enemies(g),tokens:[...g.combat.attackTokens],lock:g.camera.lockTarget?.id??null,itemCount:g.state.countItem('trenchOrder'),reachTimer:g.director._reachTimer,interactionCount:g.city.interactions.filter(i=>i.id==='trench_talk').length});
function interact(g,input){const it=g.city.interactions.find(i=>i.id==='trench_talk');assert.ok(it);const distance=Math.hypot(g.player.pos.x-it.x,g.player.pos.z-it.z);assert.ok(distance<it.range);g.player.yaw=g.player.targetYaw=Math.atan2(g.player.pos.x-it.x,g.player.pos.z-it.z);g._updateInteractTarget();assert.equal(g.player.interactTarget?.id,it.id);input.pending.add('interact');g.fixedUpdate(1/60);return {distance,range:it.range};}
async function priorDirector(){const original=fs.readFileSync(root+'/trench-perception-r2-reviewed-director.js','utf8');assert.equal(sha(original),'0ca1755de0ca76bbe18b48cba1753ff2ba107aaea3b4ff7c89a2bc9d139ebd22');const s=original.replace(/from (['"])([^'"]+)\1/g,(_m,_q,p)=>'from '+JSON.stringify(p==='three'?new URL('./survival/node_modules/three/build/three.module.js',import.meta.url).href:new URL(p,new URL('./survival/src/game/director.js',import.meta.url)).href));return (await import('data:text/javascript;base64,'+Buffer.from(s).toString('base64'))).Director;}

await check('live-and-fresh-instance-prepoll-reentry-counterfactual',async r=>{
 const old=await priorDirector();r.cases=[];
 for(const [label,D] of [['current',undefined],['prior-r2',old]]){
  const g=makeGame(D),input=inputFixture(g);enterTrench(g);g.fixedUpdate(1/60);place(g,77,17.8);g.state.give('trenchOrder',1);const interaction=interact(g,input),accepted=full(g);
  assert.equal(accepted.quest.step,1);assert.ok(g.state.has('trench_talked'));assert.equal(g.state.has('trench_passed'),false);
  const live=[full(g)];g.quests.reenterActiveSteps();live.push(full(g));g.quests.reenterActiveSteps();live.push(full(g));
  const liveCounts=live.map(s=>s.enemies.length);assert.deepEqual(liveCounts,label==='current'?[3,3,3]:[3,6,9]);
  if(label==='current')assert.deepEqual(live.map(s=>s.enemies.map(e=>e.id)),Array(3).fill(live[0].enemies.map(e=>e.id)));
  assert.equal(g.director.save(true),true);const save=Storage.load();assert.ok(save);
  const loaded=makeGame(D),loadedInput=inputFixture(loaded);assert.equal(loaded.director.applySave(save),true);
  const restored=[full(loaded)];loaded.quests.reenterActiveSteps();restored.push(full(loaded));loaded.quests.reenterActiveSteps();restored.push(full(loaded));
  const restoredCounts=restored.map(s=>s.enemies.length);assert.deepEqual(restoredCounts,label==='current'?[0,0,0]:[3,6,9]);
  const applyCounts=[];for(let i=0;i<3;i++){assert.equal(loaded.director.applySave(save),true);applyCounts.push(enemies(loaded).length);}assert.deepEqual(applyCounts,label==='current'?[0,0,0]:[3,3,3]);
  const beforePoll=full(loaded),trace=tick(loaded,.35),afterPoll=full(loaded);
  assert.equal(afterPoll.quest.step,2);assert.ok(loaded.state.has('trench_passed'));assert.ok(loaded.state.has('trench_talked_through'));assert.equal(afterPoll.itemCount,1);
  if(label==='current'){loaded.director.ctx.hooks.spawnTrenchLine();loaded.director.ctx.hooks.spawnTrenchLine();assert.equal(enemies(loaded).length,0);}
  r.cases.push({label,interaction,accepted,live,liveCounts,save,restored,restoredCounts,applyCounts,beforePoll,trace,afterPoll,final:full(loaded),scope:'No timer/flag mutation. Load uses a fresh game instance. Prior control swaps only pinned R2 Director; all other R3 modules are identical between cases.'});
 }
});

await check('normal-item-rejection-localization-then-acceptance',r=>{
 r.cases=[];
 for(const language of ['en','ja']){
  setLocale(language);assert.equal(locale(),language);const g=makeGame(),input=inputFixture(g);enterTrench(g);place(g,77,17.8);const before=full(g);assert.equal(before.itemCount,0);
  const noticeStart=g.hudCalls.length,eventStart=g.events.length,uiStart=g.uiCalls.length,interaction=interact(g,input),blocked=full(g);
  const notices=g.hudCalls.slice(noticeStart).filter(c=>c.method==='notice'),events=g.events.slice(eventStart);
  const expectedText=language==='en'?'You need Trench cut order.':'「掘削指示書」が必要だ。';assert.ok(notices.some(n=>n.args[0]===expectedText));
  assert.ok(events.some(e=>e.name==='sfx'&&e.args[0]==='locked'));assert.equal(g.uiCalls.length,uiStart);
  assert.equal(blocked.mode,MODE.PLAY);assert.equal(blocked.quest.step,1);assert.ok(!g.state.has('trench_talked')&&!g.state.has('trench_passed'));assert.ok(blocked.enemies.every(e=>e.faction==='hostile'));
  g.state.give('trenchOrder',1);interact(g,input);const accepted=full(g);assert.equal(accepted.itemCount,1);assert.equal(accepted.mode,MODE.DIALOGUE);assert.ok(g.state.has('trench_talked'));assert.ok(accepted.enemies.every(e=>e.faction==='neutral'&&!e.aggro&&!e.attack&&e.target===null));
  tick(g,.35);const afterPoll=full(g);assert.equal(afterPoll.quest.step,2);assert.equal(afterPoll.itemCount,1);
  r.cases.push({language,interaction,before,blocked,notices,events,accepted,afterPoll,scope:'Declared item gate and notice-call localization; no rendered UI or full-chapter no-item journey claim.'});
 }
 setLocale('en');
});

await check('imminent-attack-noitem-negative-and-item-positive',r=>{
 r.cases=[];
 for(const hasItem of [false,true]){
  const g=makeGame(),input=inputFixture(g);enterTrench(g);place(g,77,17.8);if(hasItem)g.state.give('trenchOrder',1);const damage=observeDamage(g);let committed=null;
  for(let i=0;i<600&&!committed;i++){g.fixedUpdate(1/60);committed=g.director._raidActive.group.find(e=>e.attack&&e.attack.t>=e.attack.windup-1/30&&e.attack.t<e.attack.windup);}
  assert.ok(committed);assert.ok(g.combat.attackTokens.has(committed.id));g.camera.lockTarget=committed;const before=full(g),at=g.time+1/60;interact(g,input);const afterInput=full(g),trace=tick(g,hasItem?8:1.2);
  const hits=damage.filter(d=>d.time>=at&&d.source?.kind==='warden'&&d.hpAfter<d.hpBefore);
  if(hasItem){assert.equal(hits.length,0);assert.equal(g.director._raidActive,null);assert.equal(g.camera.lockTarget,null);assert.equal(g.combat.attackTokens.size,0);assert.ok(enemies(g).every(e=>e.faction==='neutral'&&!e.aggro&&!e.attack&&e.target===null));assert.equal(g.state.countItem('trenchOrder'),1);}
  else{assert.ok(hits.length>0);assert.ok(afterInput.tokens.length>0);assert.equal(afterInput.lock,committed.id);assert.equal(afterInput.mode,MODE.PLAY);assert.ok(!g.state.has('trench_talked')&&!g.state.has('trench_passed'));}
  r.cases.push({hasItem,before,at,afterInput,trace,after:full(g),hits,damage,duration:hasItem?8:1.2,scope:'Separate real games with process-global Actor-ID RNG; no identical-state rewind. Attack/AI/Combat/damage execution is real.'});
 }
});

report.swallowedErrors=swallowedErrors;report.finalSourceHashes=pinSources();report.sourceUnchanged=JSON.stringify(sourceHashes)===JSON.stringify(report.finalSourceHashes);
fs.writeFileSync(root+'/trench-perception-r3-refuter-probe-01.json',JSON.stringify(report,(_k,v)=>v&&typeof v==='object'&&v.pos?.isVector3&&Number.isInteger(v.id)?{actor:v.id,kind:v.kind??v.faction}:v,2)+'\n');
console.log(JSON.stringify({probeErrors:checks.filter(c=>c.status==='probe-error').length,swallowedErrors,sourceUnchanged:report.sourceUnchanged}));
if(checks.some(c=>c.status==='probe-error')||swallowedErrors.length||!report.sourceUnchanged)process.exitCode=1;
