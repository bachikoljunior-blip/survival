import fs from 'node:fs';
import assert from 'node:assert/strict';
import {root,pinSources,makeGame,snap,tick,place,enterTrench,inputFixture,observeDamage,Storage,Enemy,MODE,swallowedErrors} from './trench-perception-r2-fixture-v1.mjs';
import {setLocale} from './survival/src/content/i18n.js';
const sourceHashes=pinSources(),checks=[];
const expected={
  'src/game/director.js':'1dfd99d47e3023d0e257cd0a0dfab6255fa3a9bb61910b92b4d632237d09020d',
  'src/content/locale/ja/ui.js':'5d47dd0ceba8079a28568da0e66235d59ad31fd6a7935e4e1e05409d9cb611b7',
  'src/game/ai.js':'dd3a37e8681a1d728c574db86e875be91807f7c75589494162e1f63cbe056597',
  'src/world/city.js':'81acdf64d65c087b9db556091896e4de0fb0fa4d60ed1d2d20e47d491c7efa4b',
  'src/world/props.js':'6044093c5bf49b66b6e8f90f012ad2bee0746bdb79bbddb7b338d6c98b8c5f38'
};
for(const [p,h] of Object.entries(expected))assert.equal(sourceHashes[p],h);
if(globalThis.document&&!globalThis.document.documentElement)globalThis.document.documentElement={lang:'en',setAttribute(){}}; // Appearance-only locale DOM attribute sink.
const report={round:3,createdAt:new Date().toISOString(),sourceHashes,expected,scope:'Narrow repair review: normal Game input, actual Director/QuestSystem/Storage, Enemy/AI/Combat, Player/City collision. Appearance/output devices and input acquisition are fixture stubs; locale DOM attributes use an inert sink. No perception, damage, movement or collision result is forced.',checks};
async function check(name,fn){const entry={name,status:'running',result:{}};checks.push(entry);try{await fn(entry.result);entry.status='completed';console.log(name+': completed');}catch(e){entry.status='probe-error';entry.error=String(e);entry.stack=e.stack;console.log(name+': '+e.stack);}}
function enemies(g){return g.actors.filter(a=>a instanceof Enemy).map(e=>({id:e.id,kind:e.kind,faction:e.faction,aggro:e.aggro,state:e.aiState,awareness:e.awareness,target:e.target?.id??null,attack:e.attack?{name:e.attack.name,t:e.attack.t,windup:e.attack.windup}:null}));}
function full(g){return {...snap(g),enemies:enemies(g),tokens:[...g.combat.attackTokens],lock:g.camera.lockTarget?.id??null,reachTimer:g.director._reachTimer,itemCount:g.state.countItem('trenchOrder')};}
function interact(g,input){const it=g.city.interactions.find(i=>i.id==='trench_talk');g.player.yaw=g.player.targetYaw=Math.atan2(g.player.pos.x-it.x,g.player.pos.z-it.z);g._updateInteractTarget();assert.equal(g.player.interactTarget?.id,it.id);input.pending.add('interact');g.fixedUpdate(1/60);}

await check('accepted-prepoll-live-and-save-reentry',r=>{
  const g=makeGame(),input=inputFixture(g);enterTrench(g);g.fixedUpdate(1/60);place(g,77,17.8);g.state.give('trenchOrder',1);interact(g,input);
  r.accepted=full(g);assert.equal(r.accepted.quest.step,1);assert.ok(g.state.has('trench_talked'));assert.equal(g.state.has('trench_passed'),false);
  r.liveCounts=[enemies(g).length];for(let i=0;i<2;i++){g.quests.reenterActiveSteps();r.liveCounts.push(enemies(g).length);}assert.deepEqual(r.liveCounts,[3,3,3]);assert.ok(enemies(g).every(e=>e.faction==='neutral'&&!e.attack&&!e.aggro));
  assert.equal(g.director.save(true),true);const save=Storage.load();r.save=save;assert.equal(g.director.applySave(save),true);
  r.loadedCounts=[enemies(g).length];for(let i=0;i<2;i++){g.quests.reenterActiveSteps();r.loadedCounts.push(enemies(g).length);}assert.deepEqual(r.loadedCounts,[0,0,0]);
  r.applyCounts=[];for(let i=0;i<3;i++){assert.equal(g.director.applySave(save),true);r.applyCounts.push(enemies(g).length);}assert.deepEqual(r.applyCounts,[0,0,0]);
  r.beforePoll=full(g);r.trace=tick(g,.35);r.afterPoll=full(g);assert.equal(g.state.quests.get('cinderline').step,2);assert.ok(g.state.has('trench_passed'));assert.ok(g.state.has('trench_talked_through'));assert.equal(g.state.countItem('trenchOrder'),1);
  g.director.ctx.hooks.spawnTrenchLine();g.director.ctx.hooks.spawnTrenchLine();assert.equal(enemies(g).length,0);r.final=full(g);
});

await check('required-item-normal-input-locales-and-nonconsumption',r=>{
  r.cases=[];
  for(const language of ['en','ja']){
    setLocale(language);const g=makeGame(),input=inputFixture(g);enterTrench(g);place(g,77,17.8);const before=full(g),noticeStart=g.hudCalls.length;assert.equal(g.state.countItem('trenchOrder'),0);
    interact(g,input);const blocked=full(g),notices=g.hudCalls.slice(noticeStart).filter(c=>c.method==='notice');
    const expectedText=language==='en'?'You need Trench cut order.':'「掘削指示書」が必要だ。';
    assert.ok(notices.some(c=>c.args[0]===expectedText));assert.equal(g.state.has('trench_talked'),false);assert.equal(g.state.has('trench_passed'),false);assert.equal(g.state.quests.get('cinderline').step,1);assert.equal(g.mode,MODE.PLAY);assert.ok(enemies(g).every(e=>e.faction!=='neutral'));
    g.state.give('trenchOrder',1);interact(g,input);const accepted=full(g);assert.equal(g.state.countItem('trenchOrder'),1);assert.ok(g.state.has('trench_talked'));assert.ok(enemies(g).every(e=>e.faction==='neutral'&&!e.aggro&&!e.attack));tick(g,.35);const afterPoll=full(g);assert.equal(afterPoll.quest.step,2);assert.equal(afterPoll.itemCount,1);
    r.cases.push({language,before,blocked,notices,accepted,afterPoll,events:g.events,scope:'No-item chapter-5 setup tests authored requiresItem consistency only; normal full-chapter no-item reachability is not asserted.'});
  }
  setLocale('en');
});

await check('committed-swing-item-gate-negative-and-cancel-positive',r=>{
  r.cases=[];
  for(const hasItem of [false,true]){
    const g=makeGame(),input=inputFixture(g);enterTrench(g);place(g,77,17.8);if(hasItem)g.state.give('trenchOrder',1);const damage=observeDamage(g);let committed=null;
    for(let i=0;i<600&&!committed;i++){g.fixedUpdate(1/60);committed=g.director._raidActive.group.find(e=>e.attack&&e.attack.t>=e.attack.windup-1/30&&e.attack.t<e.attack.windup);}
    assert.ok(committed);assert.ok(g.combat.attackTokens.has(committed.id));g.camera.lockTarget=committed;const before=full(g),at=g.time+1/60;interact(g,input);const afterInput=full(g),trace=tick(g,hasItem?8:1.2);
    const hits=damage.filter(d=>d.time>=at&&d.source?.kind==='warden'&&d.hpAfter<d.hpBefore);
    if(hasItem){assert.equal(hits.length,0);assert.equal(g.director._raidActive,null);assert.equal(g.camera.lockTarget,null);assert.equal(g.combat.attackTokens.size,0);assert.ok(enemies(g).every(e=>e.faction==='neutral'&&!e.aggro&&!e.attack&&e.target===null));assert.equal(g.state.countItem('trenchOrder'),1);}
    else{assert.ok(hits.length>0);assert.equal(g.state.has('trench_talked'),false);assert.equal(g.state.has('trench_passed'),false);}
    r.cases.push({hasItem,before,at,afterInput,trace,after:full(g),hits,damage});
  }
});

await check('actual-quest-oblique-climb-segment',r=>{
  const g=makeGame(),input=inputFixture(g);enterTrench(g);r.initial=place(g,96,16);r.start=full(g);assert.equal(r.initial.overlap,null);
  const targets=[[92.75,15.3],[91.9,17.5],[90,16]],trace=[];let phase=0,maxGroundedY=-Infinity;
  for(let i=0;i<720;i++){
    if(phase===1&&g.player.grounded&&!g.player._vault&&g.player.pos.y>1.9)phase=2;
    let target=targets[phase],dx=target[0]-g.player.pos.x,dz=target[1]-g.player.pos.z,d=Math.hypot(dx,dz);
    if(phase===0&&d<.14){phase=1;target=targets[phase];dx=target[0]-g.player.pos.x;dz=target[1]-g.player.pos.z;d=Math.hypot(dx,dz);}
    input.inp.move=d>.08?{x:dx/d,y:dz/d,mag:1}:{x:0,y:0,mag:0};g.fixedUpdate(1/60);
    if(g.player.grounded&&!g.player._vault)maxGroundedY=Math.max(maxGroundedY,g.player.pos.y);
    trace.push({time:g.time,pos:g.player.pos.toArray(),grounded:g.player.grounded,state:g.player.state,vault:!!g.player._vault,phase,input:{...input.inp.move},questStep:g.state.quests.get('cinderline').step,flags:[...g.state.flags]});
    if(g.player.grounded&&!g.player._vault&&g.player.pos.y>2.4)break;
  }
  Object.assign(r,{targets,trace,maxGroundedY,final:full(g),vaults:g.events.filter(e=>e.name==='actor:vault'),scope:'Only supported initial position setup; later movement comes from real normal Game input/Player physics/vault/collision. No sprint. This is the final climb segment, not the complete earlier-chapter approach.'});
  assert.ok(maxGroundedY>2.4);assert.equal(r.final.quest.step,2);assert.ok(g.state.has('trench_slipped'));assert.ok(g.state.has('trench_passed'));assert.equal(g.state.has('trench_talked'),false);assert.equal(r.vaults.length,2);
});

report.swallowedErrors=swallowedErrors;report.finalSourceHashes=pinSources();report.sourceUnchanged=JSON.stringify(sourceHashes)===JSON.stringify(report.finalSourceHashes);
fs.writeFileSync(root+'/trench-perception-r3-probe-01.json',JSON.stringify(report,(_k,v)=>v&&typeof v==='object'&&v.pos?.isVector3&&Number.isInteger(v.id)?{actor:v.id,kind:v.kind??v.faction}:v,2)+'\n');
console.log(JSON.stringify({probeErrors:checks.filter(c=>c.status==='probe-error').length,swallowedErrors,sourceUnchanged:report.sourceUnchanged}));
if(checks.some(c=>c.status==='probe-error')||swallowedErrors.length||!report.sourceUnchanged)process.exitCode=1;
