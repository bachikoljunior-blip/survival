import fs from 'node:fs';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {validateFindings} from './survival/.kit/lib/plan/findings.mjs';
const root='/workspace/scratch/0b7ad82bafe7',probe=JSON.parse(fs.readFileSync(root+'/trench-perception-r3-probe-01.json'));
if(!probe.sourceUnchanged||probe.swallowedErrors.length||probe.checks.some(c=>c.status!=='completed'))throw Error('Probe incomplete');
const result=n=>probe.checks.find(c=>c.name===n).result;
const reentry=result('accepted-prepoll-live-and-save-reentry'),gate=result('required-item-normal-input-locales-and-nonconsumption'),attack=result('committed-swing-item-gate-negative-and-cancel-positive'),climb=result('actual-quest-oblique-climb-segment');
const review={
  round:'trench-perception-repair-cpu-03',profile:'Independent narrow CPU/source review of repeated-entry and declared-item repairs',tier:'medium CPU geometry; no GPU or output-device evaluation',nativeResolution:'0x0',nativeResolutionMeaning:'No raster target; absence marker only.',
  verdict:'FAIL',verdictMeaning:'Conservative required schema field: no product or element approval is established by CPU-only evidence. No surviving verified source defect is asserted in this draft; the separate refutation is pending.',score:0,scoreMeaning:'Required unscored sentinel, not a product quality score.',
  blindComparison:'Not performed. Source-labelled CPU controls cannot establish a blind stranger preference, sensory quality, an element pass, or a product pass.',
  scope:probe.scope,sourceHashes:probe.sourceHashes,changedSourcePins:Object.fromEntries(['src/game/director.js','src/content/locale/ja/ui.js'].map(p=>[p,probe.sourceHashes[p]])),findings:[],
  repairOutcome:'All four narrow scenario groups complete with source hashes unchanged and no probe or swallowed errors. These observations await the required separate refutation.',
  resolvedCandidates:[{id:'R2-REENTRY',status:'candidate resolved, pending separate refutation',detail:'Before the passage poll, repeated active-step entry preserves the three existing neutral actors. Accepted-state save/load creates no replacement line; repeated entry and repeated applySave remain zero. The next ordinary poll advances to step 2.'}],
  controls:[
    {id:'R3-REENTRY',evidence:'trench-perception-r3-probe-01.json :: accepted-prepoll-live-and-save-reentry',setup:'One actual Game tick establishes the normal poll phase; normal input handoff on the next tick. No timer or passage-flag assignments.',liveCounts:reentry.liveCounts,loadedReentryCounts:reentry.loadedCounts,repeatedApplySaveCounts:reentry.applyCounts,nextPollQuest:reentry.afterPoll.quest,itemCount:reentry.afterPoll.itemCount},
    {id:'R3-ITEM',evidence:'trench-perception-r3-probe-01.json :: required-item-normal-input-locales-and-nonconsumption',cases:gate.cases.map(c=>({language:c.language,blockedMode:c.blocked.mode,blockedQuest:c.blocked.quest,blockedFlags:c.blocked.flags,notices:c.notices,acceptedFlags:c.accepted.flags,acceptedItemCount:c.accepted.itemCount,afterPollItemCount:c.afterPoll.itemCount})),scope:'Declared requiresItem enforcement and localization only. A normal full-chapter journey with no order is not established; no exploit claim is made. Notice text is inspected at the UI call boundary, not rendered.'},
    {id:'R3-ATTACK',evidence:'trench-perception-r3-probe-01.json :: committed-swing-item-gate-negative-and-cancel-positive',cases:attack.cases.map(c=>({hasItem:c.hasItem,committedAttacks:c.before.enemies.filter(e=>e.attack),postInputRaid:c.afterInput.raid,postInputTokens:c.afterInput.tokens,postInputLock:c.afterInput.lock,wardenHits:c.hits.length,wardenDamage:c.hits.reduce((a,h)=>a+h.hpBefore-h.hpAfter,0),afterItemCount:c.after.itemCount,durationSeconds:c.hasItem?8:1.2})),scope:'Without the item, the request is rejected and two real Warden hits occur; with it, an imminent actual AI attack is canceled and eight seconds show zero Warden damage. Cases are separate games with process-global Actor-ID RNG, not identical-state rewinds.'},
    {id:'R3-CLIMB',evidence:'trench-perception-r3-probe-01.json :: actual-quest-oblique-climb-segment',start:[96,16],initial:climb.initial,targets:climb.targets,cameraYaw:0,phaseTransitions:['distance below 0.14 m from first target','grounded, not vaulting, y above 1.9 m'],elapsedSeconds:climb.final.time,position:climb.final.player.pos,groundedHeight:climb.maxGroundedY,vaultTimes:climb.vaults.map(v=>v.time),quest:climb.final.quest,flags:climb.final.flags,scope:climb.scope}
  ],
  carriedEvidence:[{detail:'AI, City, Props, Player, Combat, Game, Storage and narrative source hashes remain identical to round 2; their separately refuted neutral reinforcement, legacy geometry/RNG and cleanup controls are retained in round-2 evidence. No optional rerun is used to inflate coverage.',report:'trench-perception-r2-review.json',refutation:'trench-perception-r2-refuter-review.json'}],
  limitations:['No browser, rendered surface correspondence, physical touch acquisition, discoverability, combat feel, audible music, or full prior-chapter journey was measured.','The climb begins at one explicitly supported approach point; all later motion comes from actual Player physics.','No product/element quality approval or blind comparison follows from these source controls.'],
  rawArtifacts:['trench-perception-r3-probe-01.mjs','trench-perception-r3-probe-01.json','trench-perception-r3-probe-01.log','trench-perception-r2-fixture-v1.mjs','trench-perception-fixture-v3.mjs','cpu-city-fixture-v2.mjs'],
  refutation:'Required separate pass pending; draft only.',retention:'All earlier attempts, failed direct routes, disproved findings and source-mismatch runs remain unchanged.'
};
for(const [p,name] of [['src/game/director.js','director'],['src/content/locale/ja/ui.js','ja-ui']]){
  const bytes=fs.readFileSync(root+'/survival/'+p),h=createHash('sha256').update(bytes).digest('hex');if(h!==probe.sourceHashes[p])throw Error('Source changed before snapshot '+p);
  fs.writeFileSync(root+'/trench-perception-r3-reviewed-'+name+'.js',bytes);
}
const knownOwners=new Set(execFileSync('git',['ls-files','src'],{cwd:root+'/survival',encoding:'utf8'}).trim().split('\n'));
const validation=validateFindings(review,{strict:true,knownOwners});
fs.writeFileSync(root+'/trench-perception-r3-review-draft.json',JSON.stringify(review,null,2)+'\n');
fs.writeFileSync(root+'/trench-perception-r3-draft-validation.json',JSON.stringify(validation,null,2)+'\n');
console.log(JSON.stringify(validation));if(!validation.ok)process.exitCode=1;
